"""Where the viewer finds the Rust executables it runs: floe-index
(find_binary) and the floe2 command line (find_floe2).

The vfsd client that lived here (the frozen floe's KLayout tile path)
is the dev-only oracle's since P3 (tools/oracle/floe_oracle/vfsclient.py,
docs/SHARED_APP_LAYER.ko.md)."""


import os
import shutil
import sys


def beside_floe2(name):
    """Where the floe2 that started this viewer (FLOE2_BIN, set by
    rust/floe2/src/gtk.rs) finds its `name`, as app-core native::Discovery
    looks: its checkout's rust/target/release when it is a
    rust/target/<profile> build, else beside it - the bundle's runtime/bin,
    a cross build's target/<triple>/release. So the viewer runs and Help >
    About names the binaries floe2 runs, however floe2 was started."""
    floe2 = os.environ.get("FLOE2_BIN")
    if not floe2:
        return []
    floe2 = os.path.abspath(floe2)
    root = floe2
    for _ in range(4):
        root = os.path.dirname(root)
    candidates = []
    if floe2.startswith(os.path.join(root, "rust", "target") + os.sep):
        candidates.append(os.path.join(root, "rust", "target", "release", name))
    candidates.append(os.path.join(os.path.dirname(floe2), name))
    return candidates


def find_binary():
    """Find the matched floe-index used by indexing and VFS clients.

    An explicit override wins, followed by floe2's own (beside_floe2), the
    development build, the portable slot beside Python, and PATH.  Keeping
    PATH last prevents an older system binary from silently taking
    precedence over the package.
    """
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates = []
    configured = os.environ.get("FLOE_INDEX_BIN")
    if configured:
        if os.path.isfile(configured) and os.access(configured, os.X_OK):
            return os.path.abspath(configured)
        raise RuntimeError(
            "FLOE_INDEX_BIN is set but is not an executable file: %s" %
            configured)
    candidates.extend(beside_floe2("floe-index"))
    candidates.extend((
        os.path.join(here, "rust", "target", "release", "floe-index"),
        os.path.join(os.path.dirname(sys.executable), "floe-index"),
    ))
    on_path = shutil.which("floe-index")
    if on_path:
        candidates.append(on_path)
    for cand in candidates:
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return os.path.abspath(cand)
    raise RuntimeError(
        "floe-index binary not found; set FLOE_INDEX_BIN, build it with "
        "'cd rust && cargo build --release -p floe-index', or install it "
        "beside floe2 or Python/on PATH (checked: %s)" %
        ", ".join(candidates or ["no candidates"]))


def find_renderd():
    """The floe-renderd the view service launches (Help > About probes
    it): FLOE_RENDERD_BIN, else floe2's own (beside_floe2), the
    development build, a dist build, the portable slot beside Python, and
    PATH."""
    candidates = []
    configured = os.environ.get("FLOE_RENDERD_BIN")
    if configured:
        candidates.append(configured)
    candidates.extend(beside_floe2("floe-renderd"))
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates.extend((
        os.path.join(here, "rust", "target", "release", "floe-renderd"),
        os.path.join(here, "rust", "dist", "floe-renderd-linux-gnu"),
        os.path.join(here, "rust", "dist", "floe-renderd-linux-x86_64"),
        os.path.join(os.path.dirname(sys.executable), "floe-renderd"),
    ))
    on_path = shutil.which("floe-renderd")
    if on_path:
        candidates.append(on_path)
    for cand in candidates:
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return os.path.abspath(cand)
    raise RuntimeError(
        "floe-renderd not found; set FLOE_RENDERD_BIN (checked: %s)" %
        ", ".join(candidates))


def find_floe2():
    """The Rust command line `floe2` (rust/floe2, docs/SHARED_APP_LAYER.ko.md):
    FLOE2_BIN - its launcher sets it when it starts the viewer - else the
    development build, the portable slot beside Python, and PATH."""
    configured = os.environ.get("FLOE2_BIN")
    if configured and os.path.isfile(configured) and \
            os.access(configured, os.X_OK):
        return os.path.abspath(configured)
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates = [os.path.join(here, "rust", "target", "release", "floe2"),
                  os.path.join(os.path.dirname(sys.executable), "floe2")]
    on_path = shutil.which("floe2")
    if on_path:
        candidates.append(on_path)
    for cand in candidates:
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return os.path.abspath(cand)
    raise RuntimeError(
        "the floe2 command line (Rust) not found; set FLOE2_BIN or build it "
        "with 'cd rust && cargo build --release -p floe2' (checked: %s)" %
        ", ".join(candidates))
