"""Native viewer - GTK3/PyGObject shell.

Same hard environment constraints as flateyes (the sibling image viewer):
targets are closed-network RHEL-family hosts where only PyGObject/GTK3 is
stock and NOTHING can be installed. In particular there is NO pycairo, so
the GTK "draw" signal is unusable: every frame is composed into a
GdkPixbuf (klayout render frames, rubber band, rulers,
snap marker, selection outline) and shown by one Gtk.Image; text labels
are Gtk.Label widgets positioned with margins inside a Gtk.Overlay.

GTK imports are lazy (import_gtk), so importing this module works
headless and the spawned render process never touches GTK.
"""

import bisect
import decimal
import functools
import gc
import math
import os
import queue
import re
import signal
import sys
import threading
import time
from types import SimpleNamespace

from . import __version__
from . import gtkservice
from . import fillpat
from .hangul import EntryEditable, HangulComposer, TextViewEditable
from .product import name as product_name
from .gtkservice import CELL_QUERY_KINDS

# DETAIL level: the user sees the name; the screen-px size cut behind each
# is the shared app layer's (app-core shots::Detail::cut_px)
DETAIL_LEVELS = ("low", "medium", "high")
DETAIL_PX = (5.0, 3.0, 1.0)
# the `d` dialog's own cut, px: over 0 and at most this (app-core
# view::MAX_CUT_PX, which refuses a larger one)
MAX_CUT_PX = 100.0
DEFAULT_DETAIL = 1              # medium


def _is_deck_path(path):
    return bool(path) and str(path).lower().endswith(".jb")


Gtk = Gdk = GdkPixbuf = GLib = Pango = None

APP = product_name()
POLL_MS = 25
# LOD starts ON (rev 31): the skeleton is gone, so the first fit
# view is a live working set - merged variants must engage there
# without a keypress. The planner's fidelity/worth gates and the
# probe exactness rule keep it self-limiting; 'l' still toggles.
# LOD is retired from the viewer (user decision 2026-09-22): no toggle, off
DEFAULT_LOD = False
DEFAULT_FRAMES = True
DEFAULT_LABELS = True
DEFAULT_LABEL_FONT_PX = 14
MIN_LABEL_FONT_PX = 6
MAX_LABEL_FONT_PX = 96

BLACK = 0x000000FF
BAND_IN = 0xFFFFFFFF       # forward drag: zoom in (plain white, user
BAND_OUT = 0xFFFFFFFF      # call 2026-08-09; direction no longer
                           # color-coded - backward drag zooms out)
RULER_CORE = 0xFFFFFFFF    # plain white solid ruler (same call)
SNAP_VERTEX = 0xFFFFFFFF   # plain white (user call 2026-08-09;
SNAP_EDGE = 0xFFFFFFFF     # vertex/edge no longer color-coded)
SNAP_SHAPES_MAX = 256      # segments of a drawn shape one snap is given
                           # (app-core view::overlay SNAP_SEGMENTS_MAX)
SEL_CORE = 0xFFFFFFFF
DRC_RED = 0xFF5252FF       # NOT-WAIVED errors (geometry+numbers)

DRC_PAGE = 1000            # error-grid cells per page
DRC_GRID_W = 5             # error numbers per browser grid row
# What the panes start at (0.12.505, user 2026-11-16: "레이어 목록의 시작
# 가로크기를 300px, 룰 목록의 시작 가로크기를 260px, CD 목록 기본 크기를
# 210x350 px, drc 하단 설명 부분의 높이를 170px로 시작 크기를 설정해줘").
# Start sizes: every divider is the user's to drag from there, down to the
# floor its part had. Until then the layer panel started at its floor
# (210), the rule list at 44% of the DRC page (183 px of the 420 a load
# widened the left pane to), the group list was 234 x 108, and the detail
# had what the window's first height left under 420 px of lists (286 at
# the default size).
LAYER_PANE_PX = 300        # the layer panel's width
DRC_RULES_PX = 260         # the DRC page's rule list: its width
DRC_GROUPS_W_PX = 210      # the CD group list: its width - the error grid's, under it
DRC_GROUPS_PX = 350        # ... and its height
DRC_DETAIL_PX = 170        # the error detail's height
# the least a divider leaves the group list, and the error grid under it:
# two rows
DRC_LIST_MIN_PX = 44
# the grouping modes that have no step to set: none at all, the same CD
# (the service's `value` basis groups by the CD itself, 0.12.484) and the
# reason groups (0.12.502: the groups are what the rule's requests and waives say)
DRC_NO_STEP = ("off", "value", "reason")
# ... and the ones that make no CD group: no count of them before a rule's
# name, no `CD grouped` rule filter
DRC_NO_CD = ("off", "reason")
# The bases the DRC pane's basis combo offers, in its order: (mode id, the
# entry's words). Since 0.12.525 not the two by the difference from the
# rule's bound - `absolute`, |CD - bound|, and `ratio`, that as a percentage
# of the bound, each with its step -, DRC_DELTA_HIDDEN (user 2026-11-18:
# "drc cd 그룹 조건에서 abstract와 ratio를 제거해줘. 기능을 원복할 수 도
# 있으니 UI 상에서만 제거해줘"): they are out of the combo alone. What makes
# and shows their groups is kept - the service's bases, drc-prepare's
# groups, the step and its dialog, the counts -, and they are back with
# their two entries before the others here and DRC_DELTA_DEFAULT "absolute"
# again; the step button is in sight again by itself (it is where a basis of
# the combo has a step to set).
DRC_DELTA_BASES = (("value", "same CD"), ("reason", "reason"), ("off", "off"))
DRC_DELTA_HIDDEN = (("absolute", "absolute"), ("percent", "ratio"))
# the basis a viewer starts with: the combo's first (`absolute` until 0.12.524)
DRC_DELTA_DEFAULT = "value"
DRC_SAY_AFTER_S = 0.7      # a CD measurement longer than this says where it is
DRC_VIEW_FRACTION = 0.3    # error extent ~30% of the view on a jump
DRC_HL_CAP = 1000          # highlight-in-view marker budget
DRC_LARGE_RULE = 100000    # in-view lists of rules this large: a service job
DRC_GREEN = 0x00E676FF     # WAIVED errors (geometry+numbers;
                           # cyan->green, user call 2026-08-17)
DRC_MARK_PX = 9            # collapsed-marker circle diameter; geometry
                           # whose screen span shrinks BELOW this
                           # paints as the marker (no gap where the
                           # shape draws smaller than the marker).
                           # 5 until 0.12.525; since 0.12.526 the size a
                           # click gave an error until then (user
                           # 2026-11-18: "화면에 표시되는 에러 마커의 기본
                           # 크기를 클릭했을때 커지는 크기로 변경하고 마커위에
                           # 마우스 커서가 hover하면 조금 더 커지게") - the
                           # service draws its picture's circles this size
                           # too (drc_markers `radius`)
DRC_HOVER_PX = 13          # the marker under the pointer, and the clicked
                           # error's (9 until 0.12.525: the clicked one
                           # stays larger than the others); the pointer's
                           # marker is a small widget over the canvas
                           # (_drc_hover_set), the canvas is not drawn again
# canonical order of the rule-type combo (SVRF measurement metrics
# from the rules.json sidecar; "other" = no parsed measurement)
DRC_METRICS = ("width", "space", "notch", "enclosure", "overlap",
               "extension", "area", "density", "length", "angle",
               "perimeter", "vertex", "other")

# FLOE_DRC_PROF=1: print a per-stage timing breakdown of the DRC
# browser paths to stderr - for machine-specific slowness reports
_DRC_PROF = bool(os.environ.get("FLOE_DRC_PROF"))


class _MainThreadGc(object):
    """Python's cyclic garbage collector, run on the GTK thread alone while
    a viewer runs (user 2026-11-16: "cd 그룹 중 하나를 우클릭해서 select all을
    한 다음 첫번째 에러를 클릭하면 앱이 크래시됨").

    The collector runs by itself on whichever thread passes its allocation
    threshold - the service's reader thread (`floe2-gtk-service`) as readily
    as the GTK one - and what it frees there can be a GTK widget: a popup
    menu whose handlers refer to it is such a cycle, garbage from the moment
    the menu closes. A widget that is freed takes its window with it, on
    that thread: the macOS backend stops the process there ("Must only be
    used from the main thread", SIGTRAP - the crash reported), and on X11 it
    is an Xlib call out of turn. So while a viewer runs the collector does
    not run by itself (`hold`), and the viewer's poll runs it on the GTK
    thread (`step`) by the collector's own measure - the young objects past
    their threshold -, an older generation every tenth and every hundredth
    time as the collector's own counters would have it.

    Counted, not a switch: the gates' viewers in one process come and go,
    and the collector is the process' own again when the last one has quit
    (`release`) - after one collection here, so that what the viewer left is
    freed on this thread and not by the first thread to allocate."""

    held = 0
    was = True
    passes = 0
    full_took = 0.0
    full_at = 0.0

    @classmethod
    def hold(cls):
        if cls.held == 0:
            cls.was = gc.isenabled()
            gc.disable()
        cls.held += 1

    @classmethod
    def release(cls):
        if cls.held == 0:
            return
        cls.held -= 1
        if cls.held == 0:
            gc.collect()
            if cls.was:
                gc.enable()

    @classmethod
    def step(cls):
        """One look, on the GTK thread: a collection when the young objects
        are past the collector's threshold. Returns the generation
        collected, None for none."""
        if cls.held == 0:
            return None
        if gc.get_count()[0] < (gc.get_threshold()[0] or 700):
            return None
        cls.passes += 1
        generation = 2 if cls.passes % 100 == 0 else 1 if cls.passes % 10 == 0 else 0
        started = time.monotonic()
        # (a whole collection costs by the size of the heap: not more often
        # than a twentieth of the time goes to it)
        if generation == 2 and started - cls.full_at < 20 * cls.full_took:
            generation = 1
        gc.collect(generation)
        if generation == 2:
            cls.full_at = time.monotonic()
            cls.full_took = cls.full_at - started
        return generation


class _dprof(object):
    """with _dprof("tag"): ... -> [drcprof] tag N ms (>=1ms)."""
    __slots__ = ("tag", "t0")

    def __init__(self, tag):
        self.tag = tag

    def __enter__(self):
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *_exc):
        if _DRC_PROF:
            dt = (time.perf_counter() - self.t0) * 1e3
            if dt >= 1.0:
                sys.stderr.write("[drcprof] %-28s %8.1f ms\n"
                                 % (self.tag, dt))
                sys.stderr.flush()
        return False
DRC_GOLD = 0xFFD700FF      # box-selected errors (canvas marker + grid cell)
# numbers ON a gold selected cell (user call 2026-09-08): the bright
# red/green of the dark list are unreadable on gold (contrast ~1.0),
# so a selected cell shows the same hues darkened - red ~4.8, green
# ~4.9 against gold - while the canvas marker colours stay as they are
DRC_RED_ON_GOLD = 0xB00020FF
DRC_GREEN_ON_GOLD = 0x006B3CFF
# a waive a confirmer has rejected: the error's number in the grid, until
# its reviewer waives it again (0.12.469; the canvas draws it as not waived)
# - and a request a waiver has declined, until its requester asks again
# (0.12.473): what was sent back to the one who made it
DRC_REJECTED = 0xFFA726FF
DRC_REJECTED_ON_GOLD = 0x8A4B00FF
# an error whose waive is asked for and nobody has waived: its number in the
# grid of a role's session (0.12.472; the canvas draws it as not waived)
DRC_REQUESTED = 0x64B5F6FF
DRC_REQUESTED_ON_GOLD = 0x0D47A1FF
DRC_NOT_REQUIRED = 0x9E9E9EFF       # excluded numbers; neutral across waive states
DRC_NOT_REQUIRED_ON_GOLD = 0x555555FF
DRC_NOT_REQUIRED_CURRENT = 0xE6E6E6FF

# cell tree (SPEC-VIEWER §8c): the selected cell's instances are outlined
# on the canvas in this colour (2 px, like the DRC marks; cyan so it reads
# against the layer palette and the white rulers), an instance narrower
# than CELL_MARK_PX on screen collapses to a CELL_MARK_PX marker square
CELL_HL = 0x40E0FFFF
CELL_MARK_PX = 7
# instance boxes one highlight query asks for (renderd's own cap: a wide
# view of a cell with millions of instances answers partially, "more")
CELL_INSTS_CAP = 4096
# name-search rows shown (the total travels beside them)
CELL_FIND_LIMIT = 2000
# a keystroke in the search box queries after this pause
CELL_SEARCH_MS = 150
# zoom to a cell: its extent spans this fraction of the view on both axes
CELL_VIEW_FRACTION = 0.8
# the left pane's start width (cells | DRC pages); every page must keep
# its minimum width under it, or GtkPaned clips the page's left side
LEFT_PANE_PX = 260


# A viewer started with `floe2 view --no-file-load` (FLOE_NO_FILE_LOAD):
# what a command that would load a file picked in the viewer says instead
NO_FILE_LOAD = "loading files is off in this viewer (--no-file-load)"
# ... and what File > clip region… says: the same switch turns that export
# of the layout off (user 2026-11-15: "--no-file-load 모드에서는 clip
# region... 메뉴도 비활성해줘")
NO_CLIP = "saving a clip is off in this viewer (--no-file-load)"


class _DrcPanel(object):
    """Widget refs of the embedded DRC browser (attribute bag)."""
    __slots__ = ("_conflict",
                 "_rules", "_rstore", "_rule_name", "_grid", "_gstore",
                 "_detail", "_hl", "_wf", "_wf_role", "_selv", "_search",
                 "_tf", "_plabel", "_pprev", "_pnext", "_delta_mode",
                 "_delta_step", "_delta_store", "_delta_tree", "_delta_label",
                 "_delta_prev", "_delta_next", "_delta_controls",
                 "_delta_list", "_delta_bar", "_vsplit",
                 "_hsplit", "_hsplit_start", "_detail_box")


class _DrcTeamWindow:
    """Read-only peer snapshots; every action keeps the viewer's own DB."""

    def __init__(self, viewer):
        self.viewer, self.db = viewer, viewer._drc
        self.sources, self.aggregate = [], None
        self.import_conflicts, self.import_source = None, None
        self.job, self.closed, self.page = None, False, 0
        self._guard = False
        self.window = Gtk.Window(title="DRC reviewers - mine: %s"
                                 % getattr(viewer._drc, "_reviewer", "?"))
        self.window.set_transient_for(viewer.window)
        self.window.set_default_size(970, 650)
        viewer._only_close_button(self.window)
        viewer._center_on_parent(self.window)
        self.window.connect("destroy", self._destroy)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_border_width(8)
        self.window.add(box)
        self.controls = []

        def row():
            widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            box.pack_start(widget, False, False, 0)
            return widget

        def button(parent, label, callback):
            widget = Gtk.Button(label=label)
            widget.connect("clicked", lambda *_: callback())
            parent.pack_start(widget, False, False, 0)
            self.controls.append(widget)
            return widget

        top = row()
        self.load_button = button(top, "Load peer work…", self._load_dialog)
        if not viewer._file_load:
            self.file_load_off()
        button(top, "Export my review…", self._export)
        button(top, "Refresh", self._refresh)
        button(top, "Statistics CSV…", self._csv)
        self.peer = Gtk.ComboBoxText()
        self.peer.set_hexpand(True)
        top.pack_start(self.peer, True, True, 0)
        self.controls.append(self.peer)
        self.peer.connect("changed", lambda *_: self._changed())
        self.source_label = Gtk.Label(label="No peer loaded. Peer originals remain read-only.")
        self.source_label.set_xalign(0)
        self.source_label.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
        box.pack_start(self.source_label, False, False, 0)
        self.stats = Gtk.Label(label="Statistics have not been refreshed.")
        self.stats.set_xalign(0)
        self.stats.set_line_wrap(True)
        self.stats.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        box.pack_start(self.stats, False, False, 0)
        filters = row()
        self.rule = Gtk.ComboBoxText()
        for ci, check in enumerate(self.db.checks):
            self.rule.append(str(ci), check.name)
        self.rule.set_active(viewer._drc_open if viewer._drc_open is not None else 0)
        self.rule.set_hexpand(True)
        filters.pack_start(self.rule, True, True, 0)
        self.controls.append(self.rule)
        self.rule.connect("changed", lambda *_: self._changed())
        self.mode = Gtk.ComboBoxText()
        self.mode.append("work", "Selected peer's work")
        self.mode.append("conflict", "Conflicts among visited reviewers")
        self.mode.append("import", "Import conflicts with selected peer")
        self.mode.set_active(0)
        self.mode.connect("changed", lambda *_: self._changed())
        filters.pack_start(self.mode, False, False, 0)
        self.controls.append(self.mode)
        self.store = Gtk.ListStore(int, int, str, str, str, str)
        self.tree = Gtk.TreeView(model=self.store)
        for j, title in ((2, "Error"), (3, "Mine: V / W / NR"),
                         (4, "Peer: V / W / NR"), (5, "Conflict")):
            column = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=j)
            column.set_expand(True)
            self.tree.append_column(column)
        self.tree.get_selection().set_mode(Gtk.SelectionMode.MULTIPLE)
        self.tree.connect("row-activated", self._jump)
        scroll = Gtk.ScrolledWindow()
        scroll.add(self.tree)
        box.pack_start(scroll, True, True, 0)
        pages = row()
        self.prev = button(pages, "Previous", lambda: self._turn(-1))
        self.page_label = Gtk.Label(label="0 errors")
        pages.pack_start(self.page_label, True, True, 0)
        self.next = button(pages, "Next", lambda: self._turn(1))
        apply_row = row()
        button(apply_row, "Apply all peer work safely", self._apply)
        button(apply_row, "Use peer judgement on selected rows", lambda: self._apply(True))
        manual = row()
        for label, field, on in (("Waive selected", "waive", True),
                                 ("Unwaive selected", "waive", False),
                                 ("Exclude selected", "not-required", True),
                                 ("Require selected", "not-required", False)):
            button(manual, label, lambda f=field, v=on: self._manual(f, v))
        help_label = Gtk.Label(label=("V = visited · W = waived · NR = not for review. "
            "Double-click opens my error geometry.\n"
            "Safe apply preserves different judgements on my visited errors; "
            "peer visits are never copied. Selected-row actions are explicit overrides.\n"
            "Refresh includes my latest work. Reload peer files to receive their newer work."))
        help_label.set_xalign(0)
        help_label.set_line_wrap(True)
        box.pack_start(help_label, False, False, 0)
        self.status = Gtk.Label(
            label="Load peer work to compare reviews." if viewer._file_load
            else "Loading peer work is off in this viewer (--no-file-load).")
        self.status.set_xalign(0)
        self.status.set_line_wrap(True)
        self.status.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        self.status.set_max_width_chars(100)
        box.pack_start(self.status, False, False, 0)
        self.window.show_all()

    def file_load_off(self):
        """--no-file-load: the load button is off for good - not one of the
        controls a finished job makes sensitive again. At the window's
        start, or when a forwarded launch turns the viewer's loads off
        while it is open (Viewer._file_load_latch)."""
        load = self.load_button
        if load in self.controls:
            self.controls.remove(load)
        load.set_sensitive(False)
        load.set_tooltip_text(NO_FILE_LOAD)

    def _valid(self):
        return not self.closed and self.viewer._drc is self.db

    def _source(self):
        index = self.peer.get_active()
        return self.sources[index] if 0 <= index < len(self.sources) else None

    def _ci(self):
        value = self.rule.get_active_id()
        return int(value) if value is not None else None

    def _destroy(self, *_):
        self.closed = True
        if self.job is not None and not self.job["write"]:
            self.job["cancel"].set()
        if getattr(self.viewer, "_drc_team", None) is self:
            self.viewer._drc_team = None
        if self.job is None:
            self._close_sources()

    def _close_sources(self):
        for source in self.sources + [item for item in
                (self.aggregate, self.import_conflicts) if item is not None]:
            source.close()
        self.sources, self.aggregate = [], None
        self.import_conflicts, self.import_source = None, None

    def _start(self, label, work, complete, *, write=False, changed=False):
        if not self._valid():
            return False
        if self.job is not None or self.viewer._drc_review_pending():
            self.status.set_text("An operation is running; wait for it to finish.")
            return False
        cancel = threading.Event()
        # the service writes the visits it accepted before a team job
        # (drc_team.rs wait_visits): no barrier here
        job = dict(db=self.db, label=label, cancel=cancel, done=False, result=None,
                   error=None, progress=None, write=write, changed=changed,
                   complete=complete, waive_changed=bool(changed and changed != "flags"))
        self.job = job
        self.viewer._drc_team_busy = job
        if write:
            self.viewer._drc_team_write = job
        for widget in self.controls:
            widget.set_sensitive(False)
        self.tree.set_sensitive(False)
        self.status.set_text(label + "…")

        def run():
            try:
                job["result"] = work(cancel.is_set,
                    lambda done, total, *_: job.update(progress=(done, total)))
                if isinstance(job["result"], dict) and "changed_waived" in job["result"]:
                    job["waive_changed"] = bool(job["result"]["changed_waived"])
            except Exception as exc:
                job["error"] = str(exc)
            finally:
                job["done"] = True
        # Accepted writes finish even when a window closes. Read scans cancel.
        threading.Thread(target=run, name="drc-team", daemon=not write).start()
        GLib.timeout_add(POLL_MS, self._poll)
        return True

    def _poll(self):
        job = self.job
        if job is None:
            return False
        if not self._valid() and not job["write"]:
            job["cancel"].set()
        if not job["done"]:
            if self._valid() and job["progress"] is not None:
                self.status.set_text("%s: %d / %d" % (job["label"], *job["progress"]))
            return True
        self.job = None
        if getattr(self.viewer, "_drc_team_busy", None) is job:
            self.viewer._drc_team_busy = None
        if getattr(self.viewer, "_drc_team_write", None) is job:
            self.viewer._drc_team_write = None
        if job["changed"] and self.viewer._drc is self.db:
            # A failed batch may already have committed earlier chunks.
            self.viewer._drc_team_changed(self.db, waived=job["waive_changed"])
        if not self._valid():
            result = job["result"]
            if hasattr(result, "close"):
                result.close()
            elif isinstance(result, tuple) and result and isinstance(result[0], list):
                for source in result[0]:
                    source.close()
            if job["error"] and job["write"]:
                self.viewer._set_live_status("Previous review operation failed: " + job["error"])
            if self.closed:
                self._close_sources()
            else:
                self.status.set_text("The DRC database changed. Reopen Reviewers for the new database.")
            return False
        for widget in self.controls:
            widget.set_sensitive(True)
        self.tree.set_sensitive(True)
        if job["error"]:
            self.status.set_text(job["label"] + " failed: " + job["error"])
            if job["changed"]:
                self.stats.set_text("Review changed partially; refresh statistics before continuing.")
        else:
            self.status.set_text(job["label"] + " complete")
            job["complete"](job["result"])
        if self.job is None and getattr(self, "_open_load_when_ready", False):
            self._open_load_when_ready = False
            self._load_dialog()
        return False

    def _choose(self, title, save=False, multiple=False, default=None):
        if not self._valid() or self.job is not None:
            return None
        if not save and self.viewer._load_refused(title):
            # --no-file-load: no chooser of a file to read
            self.status.set_text("%s: %s" % (title, NO_FILE_LOAD))
            return None
        dialog = Gtk.FileChooserDialog(title=title, parent=self.window,
            action=Gtk.FileChooserAction.SAVE if save else Gtk.FileChooserAction.OPEN)
        dialog.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                           "Save" if save else "Open", Gtk.ResponseType.OK)
        dialog.set_current_folder(os.path.dirname(os.path.abspath(self.db.path)))
        if save:
            dialog.set_do_overwrite_confirmation(True)
            if default:
                dialog.set_current_name(default)
        else:
            dialog.set_select_multiple(multiple)
        answer = None
        if dialog.run() == Gtk.ResponseType.OK:
            answer = dialog.get_filenames() if multiple else dialog.get_filename()
        dialog.destroy()
        self.window.present()
        return answer if self._valid() else None

    def _load_dialog(self):
        paths = self._choose("Load peer review bundles or waiver files", multiple=True)
        if paths:
            self._load_paths(paths)

    def _load_paths(self, paths):
        from .gtkservice import open_review
        paths = tuple(paths)

        def work(cancelled, progress):
            loaded, errors = [], []
            for path in paths:
                if cancelled():
                    break
                try:
                    loaded.append(open_review(self.db, path,
                        cancelled=cancelled, progress=progress))
                except Exception as exc:
                    errors.append("%s: %s" % (os.path.basename(path), exc))
            return loaded, errors

        def complete(result):
            loaded, errors = result
            self._guard = True
            try:
                for source in loaded:
                    # A reviewer has one active snapshot, never two votes.
                    old = next((s for s in self.sources if s.reviewer == source.reviewer), None)
                    if old is not None:
                        if ((old.exported_ns, old.snapshot_id) >=
                                (source.exported_ns, source.snapshot_id)):
                            source.close()
                            errors.append("%s: kept the newer loaded snapshot" % source.reviewer)
                            continue
                        self.sources.remove(old)
                        old.close()
                    self.sources.append(source)
                self.peer.remove_all()
                for source in self.sources:
                    self.peer.append_text(source.reviewer)
                self.peer.set_active(len(self.sources) - 1)
            finally:
                self._guard = False
            self._load_errors = "; ".join(errors)
            self.page = 0
            if loaded:
                self._refresh()
            else:
                self.status.set_text("No peer loaded: " + self._load_errors)
        self._start("Load peer work", work, complete)

    def _refresh(self):
        from .gtkservice import aggregate_reviews
        sources = tuple(self.sources)

        def complete(result):
            if self.aggregate is not None:
                self.aggregate.close()
            if self.import_conflicts is not None:
                self.import_conflicts.close()
            self.import_conflicts, self.import_source = None, None
            self.aggregate = result
            self.refreshed_at = time.strftime("%H:%M:%S")
            publish = getattr(self.viewer, "_drc_conflict_publish", None)
            if publish is not None:
                publish(result, self.refreshed_at)
            self._page_load()
        self._start("Refresh reviewer statistics",
            lambda cancel, progress: aggregate_reviews(self.db, sources,
                cancelled=cancel, progress=progress), complete)

    @staticmethod
    def _state(value, source=None):
        fields = (("visited", value.visited), ("waive", value.waived),
                  ("not_required", value.not_required))
        return " / ".join("—" if source is not None and not getattr(source, name + "_known", True)
                          else "yes" if flag else "no" for name, flag in fields)

    @staticmethod
    def _stats_line(scope, counts):
        return ("%s: total %d · visited (any reviewer) %d · waived %d · "
                "not for review %d · unvisited targets %d · conflicts %d" %
                (scope, counts["total"], counts["visited"], counts["waived"],
                 counts["not_required"], counts["pending"], counts["conflicts"]))

    def _changed(self):
        if not self._guard:
            self.page = 0
            self._page_load()

    def _page_load(self):
        ci, source, aggregate = self._ci(), self._source(), self.aggregate
        if aggregate is None:
            return
        if ci is None:
            def complete_empty(counts):
                self.store.clear()
                self.stats.set_text(self._stats_line("Whole DB", counts) + "\nNo rules in this database.")
                self.page_label.set_text("0 errors")
                self.prev.set_sensitive(False)
                self.next.set_sensitive(False)
            self._start("Read reviewer statistics", lambda *_: aggregate.counts(), complete_empty)
            return
        if source is not None and self.import_source is not source:
            from .gtkservice import import_conflicts

            def complete(result):
                if self.import_conflicts is not None:
                    self.import_conflicts.close()
                self.import_conflicts, self.import_source = result, source
                self._page_load()
            self._start("Compare safe-import judgements",
                lambda cancel, progress: import_conflicts(self.db, source,
                    cancelled=cancel, progress=progress), complete)
            return
        kind = self.mode.get_active_id()
        provider = (aggregate if kind == "conflict" else
                    self.import_conflicts if kind == "import" else source)
        query_kind = "conflict" if kind in ("conflict", "import") else "work"
        imports = self.import_conflicts if self.import_source is source else None
        page = self.page

        def work(cancelled, progress):
            from .gtkservice import VISITED, NOT_REQUIRED
            count = provider.members(ci, query_kind).count() if provider is not None else 0
            actual_page = min(page, max(0, (count - 1) // DRC_PAGE))
            ids = provider.page(ci, actual_page * DRC_PAGE, DRC_PAGE, kind=query_kind) if provider else ()
            peers = source.get_many(ci, ids) if source else [None] * len(ids)
            teams = aggregate.get_many(ci, ids)
            rows = []
            for ei, peer_value, team in zip(ids, peers, teams):
                if cancelled():
                    raise InterruptedError("page cancelled")
                flags = self.db.review_flags(ci, ei)
                own_waived = self.db.get_status(ci, ei) == gtkservice.STATUS_WAIVED
                mine = "%s / %s / %s" % tuple("yes" if value else "no" for value in
                    (flags & VISITED, own_waived, flags & NOT_REQUIRED))
                peer = self._state(peer_value, source) if source else "—"
                conflict = "reviewers" if team.conflict else ""
                if (source is not None and flags & VISITED and
                        ((source.waive_known and peer_value.waived != own_waived) or
                         (source.not_required_known and peer_value.not_required != bool(flags & NOT_REQUIRED))) and
                        (peer_value.visited or peer_value.waived or peer_value.not_required)):
                    conflict = (conflict + "; " if conflict else "") + "import protected"
                rows.append((ci, ei, "#%d" % (ei + 1), mine, peer, conflict))
            return (rows, count, actual_page, aggregate.counts(), aggregate.counts(ci),
                    imports.counts()["conflicts"] if imports is not None else 0,
                    imports.counts(ci)["conflicts"] if imports is not None else 0)

        def complete(result):
            rows, count, self.page, total, rule, import_total, import_rule = result
            self.store.clear()
            for data in rows:
                self.store.append(data)
            self.page_label.set_text("%d errors · page %d / %d · %d per page" %
                (count, self.page + 1, max(1, (count + DRC_PAGE - 1) // DRC_PAGE), DRC_PAGE))
            self.prev.set_sensitive(self.page > 0)
            self.next.set_sensitive((self.page + 1) * DRC_PAGE < count)
            self.stats.set_text("Snapshot %s · Mine + loaded peers (%d reviewers) · Refresh after further edits/visits\n%s\n%s\n"
                "Import conflicts with selected peer: Whole DB %d · Whole rule %d" %
                (self.refreshed_at, total["reviewers"], self._stats_line("Whole DB", total),
                 self._stats_line("Whole rule " + self.db.checks[ci].name, rule), import_total, import_rule))
            self.source_label.set_text(("Peer %s — %s" %
                (source.reviewer, getattr(source, "original_path", source.path)))
                if source else "No peer selected; aggregate includes my review.")
            error = getattr(self, "_load_errors", "")
            if error:
                self.status.set_text("Some sources were not loaded: " + error)
                self._load_errors = ""
            elif getattr(self, "_notice", ""):
                self.status.set_text(self._notice)
        self._start("Read reviewer page", work, complete)

    def _turn(self, delta):
        self.page = max(0, self.page + delta)
        self._page_load()

    def _jump(self, _tree, path, _column):
        if not self._valid() or self.job is not None:
            return
        row = self.store[path]
        ci, ei = int(row[0]), int(row[1])
        # _drc_jump sets the global position and own review_target itself.
        self.viewer._drc_jump(ci, ei, isolate=True)
        self.status.set_text("Opened my error geometry; Refresh updates the review comparison.")

    def _selection(self):
        model, paths = self.tree.get_selection().get_selected_rows()
        ci = self._ci()
        if ci is None:
            return None, []
        return ci, sorted({int(model[path][1]) for path in paths})

    def _apply(self, force=False):
        from .gtkservice import apply_review
        source = self._source()
        if source is None:
            self.status.set_text("Load and select a peer first.")
            return
        ci, membership = self._selection() if force else (None, None)
        if force and not membership:
            self.status.set_text("Select rows whose judgement should be replaced with this peer's.")
            return

        def complete(result):
            self._load_errors = ""
            self._notice = ("Applied %d errors; preserved %d conflicting visited errors. "
                "Changed waives %d; review exclusions %d." %
                (result["applied"], result["conflicts_skipped"],
                 result["changed_waived"], result["changed_not_required"]))
            if result.get("locked"):
                self._notice += (" Kept %d confirmed waive(s): they are locked."
                                 % result["locked"])
            if result.get("rejected"):
                self._notice += (" Left %d error(s) as they were: their waive is "
                                 "rejected (waive them again with a reason)."
                                 % result["rejected"])
            self._refresh()
            self.status.set_text(self._notice + " Refreshing…")
        self._start("Apply selected peer judgement" if force else "Apply peer work safely",
            lambda cancel, progress: apply_review(self.db, source, ci=ci,
                errors=membership, force=force, progress=progress),
            complete, write=True, changed=True)

    def _manual(self, field, on):
        ci, members = self._selection()
        if not members:
            self.status.set_text("Select rows to change my judgement.")
            return

        reason = None
        if on:
            # why, as the viewer's own waive asks it (0.12.463)
            kind = "waive" if field == "waive" else "not-required"
            viewer = self.viewer
            try:
                reply = self.db.reason_read(ci, members, kind)
            except Exception as exc:
                self.status.set_text("My judgement is unchanged: %s" % exc)
                return
            # (a waive of errors under a rejection says whose, and starts
            # from the reason the rejected waive has: the main window's)
            rejecters = gtkservice._rejecters(reply.get("rejected_by"))
            reason = viewer._drc_reason_dialog(
                kind, len(members),
                reply.get("prefill") or ("" if rejecters else viewer._drc_reason_last.get(kind, "")),
                reply.get("known") or (), parent=self.window, rejected_by=rejecters)
            if reason is None or not self._valid():
                if self._valid():
                    self.status.set_text("Cancelled; my judgement is unchanged.")
                return
            viewer._drc_reason_last[kind] = reason

        def work(cancelled, progress):
            from .gtkservice import set_members
            return set_members(self.db, ci, members, field, on,
                               progress=progress, reason=reason)

        def complete(unkept):
            if unkept:
                self._notice = "The reason was not saved: %s" % unkept
            count, by = (self.db.locked_take() if hasattr(self.db, "locked_take")
                         else (0, ()))
            if count and field == "waive":
                # (confirmed waives were left as they were: said as the
                # main window's status line says it)
                said = self.viewer._drc_locked_said((count, by), on)
                self._notice = ((self._notice + " ") if self._notice else "") + \
                    said.lstrip(" ·") + "."
            rejected = (self.db.rejected_take() if hasattr(self.db, "rejected_take")
                        else (0, ()))
            if rejected[0] and field == "waive":
                said = self.viewer._drc_rejected_said(rejected)
                self._notice = ((self._notice + " ") if self._notice else "") + \
                    said.lstrip(" ·") + "."
            self._refresh()
        self._start("Change my " + field, work, complete,
                    write=True, changed="flags" if field == "not-required" else "waive")

    def _export(self):
        from .gtkservice import export_review
        from .gtkservice import db_name_of
        reviewer = str(getattr(self.db, "_reviewer", "reviewer"))
        reviewer = "".join(char if char.isalnum() or char in "._-" else "_" for char in reviewer)
        path = self._choose("Export my review (visited, waived, not for review)",
                            save=True, default="%s.%s.floereview" %
                            (db_name_of(self.db.path), reviewer))
        if path and self._output_allowed(path):
            self._start("Export my review", lambda cancel, progress:
                export_review(self.db, path, progress=progress),
                lambda snapshot: snapshot.close(), write=True)

    def _output_allowed(self, path):
        try:
            review_path = getattr(self.db, "review_path", None)
        except Exception as exc:
            self.status.set_text("Cannot verify my review path: %s" % exc)
            return False
        protected = [self.db.path, getattr(self.db, "_waive_path", None), review_path,
                     getattr(self.db, "reason_path", None)]
        for source in self.sources:
            protected.extend((source.path, getattr(source, "original_path", None),
                              source.metadata.get("source_path"),
                              source.metadata.get("source_waive_path")))
        target = os.path.realpath(path)
        if any(value and os.path.realpath(value) == target for value in protected):
            self.status.set_text("Choose another output file; DRC inputs and loaded peer originals are read-only here.")
            return False
        return True

    def _csv(self):
        path = self._choose("Export all reviewer statistics", save=True,
                            default="reviewers.csv")
        if not path or not self._output_allowed(path):
            return
        sources = tuple(self.sources)

        def work(cancelled, progress):
            # aggregated and written by the service (drc_team_csv)
            from .gtkservice import team_csv
            team_csv(self.db, sources, path, cancelled=cancelled, progress=progress)
        self._start("Export reviewer statistics", work, lambda _result: None, write=True)



class _DrcWaivesWindow(_DrcTeamWindow):
    """The team's waives - every reviewer's, with who waived each error and
    why - and their confirmation (user 2026-11-13: "사용자중 팀의 모든 waive를
    뷰어에서 보고 confirm하는 역할이 필요함"). Anyone reads the list; a viewer
    started with the confirmer's role (`floe2 view --role confirmer`)
    confirms: its own reviewer's mark, kept in that reviewer's file
    (app-core drc::confirm). One started with the waiver's role declines
    requests (0.12.473). The window has the buttons of its session's roles
    and no other. The list is the reviewers' files as the last Refresh
    read them."""

    KINDS = (("unconfirmed", "To confirm"), ("confirmed", "Confirmed"),
             ("waived", "All team waives"), ("rejected", "Rejected"),
             # (the roles' workflow: asked for, waived by nobody yet - and
             # the requests a waiver declined)
             ("requested", "Requested"), ("declined", "Declined"))
    NOT_CONFIRMER = ("confirming is for a viewer started with the confirmer's "
                     "role (floe2 view --role confirmer)")
    NOT_WAIVER = ("declining is for a viewer started with the waiver's role "
                  "(floe2 view --role waiver)")
    LOCKS = ("a confirmed waive is locked: its reviewer cannot turn it back "
             "or change its reason")
    UNLOCKS = ("takes your confirmation back: a waive no confirmer has "
               "confirmed is its reviewer's to turn back again")
    REJECTS = ("rejects the selected waives, asking why: they count for "
               "nothing and stay with their reviewers, shown as rejected, "
               "until each waives the error again with a reason - which "
               "brings it back to this list, with what was said before")
    UNREJECTS = ("takes your rejection of the selected errors back: their "
                 "waives are as they were before it")
    DECLINES = ("declines the selected requests, asking why: they count for "
                "nothing and stay with their requesters, shown as declined, "
                "until each asks again with a reason - which brings the "
                "error back to the Requested list, with what was said before")
    UNDECLINES = ("takes your decline of the selected errors back: their "
                  "requests are as they were before it")

    def __init__(self, viewer):
        self.viewer, self.db = viewer, viewer._drc
        self.sources, self.aggregate = [], None
        self.import_conflicts, self.import_source = None, None
        self.job, self.closed, self.page = None, False, 0
        self._guard, self._fresh, self._notice = False, True, ""
        self._rules = {}            # rule -> its counts, where somebody waived
        self.controls = []
        confirmer = bool(getattr(self.db, "confirmer", False))
        waiver = bool(getattr(self.db, "waiver", False))
        role = getattr(self.db, "role", "")
        self.window = Gtk.Window(title="DRC team waives - %s%s" % (
            getattr(self.db, "_reviewer", "?"), " (%s)" % role if role else ""))
        self.window.set_transient_for(viewer.window)
        self.window.set_default_size(900, 560)
        viewer._only_close_button(self.window)
        viewer._center_on_parent(self.window)
        self.window.connect("destroy", self._destroy)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_border_width(8)
        self.window.add(box)

        def row():
            widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            box.pack_start(widget, False, False, 0)
            return widget

        def button(parent, label, callback):
            widget = Gtk.Button(label=label)
            widget.connect("clicked", lambda *_: callback())
            parent.pack_start(widget, False, False, 0)
            self.controls.append(widget)
            return widget

        top = row()
        self.rule = Gtk.ComboBoxText()
        self.rule.set_hexpand(True)
        top.pack_start(self.rule, True, True, 0)
        self.controls.append(self.rule)
        self.rule.connect("changed", lambda *_: self._changed())
        self.mode = Gtk.ComboBoxText()
        for key, title in self.KINDS:
            self.mode.append(key, title)
        self.mode.set_active(0)
        self.mode.connect("changed", lambda *_: self._changed())
        top.pack_start(self.mode, False, False, 0)
        self.controls.append(self.mode)
        button(top, "Refresh", self._refresh)
        self.store = Gtk.ListStore(int, int, str, str, str, str, str)
        self.tree = Gtk.TreeView(model=self.store)
        for j, title in ((2, "Error"), (3, "Waived by"), (4, "Reason"),
                         (5, "Confirmed by"), (6, "Rejected by")):
            column = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=j)
            column.set_expand(j == 4)
            column.set_resizable(True)
            self.tree.append_column(column)
            if j == 6:
                # (the lists of the requests say who declined there)
                self.verdict_column = column
        self.tree.get_selection().set_mode(Gtk.SelectionMode.MULTIPLE)
        self.tree.connect("row-activated", self._jump)
        scroll = Gtk.ScrolledWindow()
        scroll.add(self.tree)
        box.pack_start(scroll, True, True, 0)
        pages = row()
        self.prev = button(pages, "Previous", lambda: self._turn(-1))
        self.page_label = Gtk.Label(label="0 errors")
        pages.pack_start(self.page_label, True, True, 0)
        self.next = button(pages, "Next", lambda: self._turn(1))
        # the buttons of the session's roles, and no other (0.12.473: a
        # session of several roles has each role's; one without the role
        # has no dead button of it - the list is read-only there)
        self.confirm_buttons, self.reject_buttons, self.decline_buttons = [], [], []
        if confirmer or waiver:
            actions = row()
        if confirmer:
            self.confirm_buttons = [
                button(actions, "Confirm selected", lambda: self._confirm(True)),
                button(actions, "Unconfirm selected", lambda: self._confirm(False)),
                button(actions, "Confirm all of rule", lambda: self._confirm(True, True))]
            # the confirmer's other verdict (0.12.468)
            self.reject_buttons = [
                button(actions, "Reject selected", lambda: self._reject(True)),
                button(actions, "Unreject selected", lambda: self._reject(False))]
            # a confirmed waive is locked (0.12.467)
            for widget, text in zip(self.confirm_buttons, (self.LOCKS, self.UNLOCKS, self.LOCKS)):
                widget.set_tooltip_text(text)
            for widget, text in zip(self.reject_buttons, (self.REJECTS, self.UNREJECTS)):
                widget.set_tooltip_text(text)
        if waiver:
            # the waiver's verdict on a request (0.12.473)
            self.decline_buttons = [
                button(actions, "Decline selected", lambda: self._decline(True)),
                button(actions, "Undecline selected", lambda: self._decline(False))]
            for widget, text in zip(self.decline_buttons, (self.DECLINES, self.UNDECLINES)):
                widget.set_tooltip_text(text)
        self.status = Gtk.Label(label="Reading the team's waives…")
        self.status.set_xalign(0)
        self.status.set_line_wrap(True)
        self.status.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        self.status.set_max_width_chars(100)
        box.pack_start(self.status, False, False, 0)
        self.window.show_all()
        self._page_load()

    def _destroy(self, *_):
        if getattr(self.viewer, "_drc_waives_win", None) is self:
            self.viewer._drc_waives_win = None
        super()._destroy()

    def _refresh(self):
        """Read the reviewers' files anew."""
        self._fresh = True
        self._page_load()

    def _page_load(self):
        ci = self._ci()
        if ci is None:
            # before the first answer: the rule the viewer has open
            ci = self.viewer._drc_open if self.viewer._drc_open is not None else 0
        if not self.db.checks:
            self.status.set_text("No rules in this database.")
            return
        kind, page, fresh = self.mode.get_active_id(), self.page, self._fresh

        def work(cancelled, progress):
            from .gtkservice import team_waives
            reply = team_waives(self.db, ci, kind, page * DRC_PAGE, DRC_PAGE,
                                refresh=fresh, cancelled=cancelled, progress=progress)
            last = max(0, (reply["count"] - 1) // DRC_PAGE)
            if page > last:
                # the list is shorter than it was: its last page
                reply = team_waives(self.db, ci, kind, last * DRC_PAGE, DRC_PAGE,
                                    cancelled=cancelled, progress=progress)
            reply["page"] = min(page, last)
            return reply

        def complete(reply):
            self._fresh = False
            self._show(ci, kind, reply)
        self._start("Read the team's waives", work, complete)

    @staticmethod
    def _counts_text(counts):
        text = "waived %d · confirmed %d · to confirm %d" % (
            counts["waived"], counts["confirmed"], counts["unconfirmed"])
        if counts.get("rejected"):
            text += " · rejected %d" % counts["rejected"]
        if counts.get("requested"):
            text += " · requested %d" % counts["requested"]
        if counts.get("declined"):
            text += " · declined %d" % counts["declined"]
        return text

    def _show(self, ci, kind, reply):
        # the rules somebody waived in, and the one shown among them
        self._rules = {int(r["check"]): r for r in reply.get("rules") or []}
        if ci not in self._rules and self._rules:
            # nothing waived in the rule asked about: the first rule that
            # has what the list shows, else the first with any waive
            wanted = [c for c, r in sorted(self._rules.items()) if r.get(kind)]
            ci = (wanted or sorted(self._rules))[0]
            self._fill_rules(ci)
            self.page = 0
            self._page_load()
            return
        self._fill_rules(ci)
        self.page = reply.get("page", 0)
        self.store.clear()
        for row in reply["rows"]:
            reasons = row.get("reasons") or []
            why = (reasons[0]["text"] if len(reasons) == 1 else
                   "; ".join("%s: %s" % (w["reviewer"], w["text"]) for w in reasons))
            # what was before a waive was waived again: the reason it had,
            # the rejection it answers (kept by its reviewer's own log)
            past = self.viewer._drc_past_text(row.get("history") or (),
                                              len(row.get("waived_by") or ()) > 1)
            if past:
                why = "%s  [%s]" % (why, past) if why else "[%s]" % past
            # (who asked for the waive, and why as they said - a requester
            # whose request of it is declined is said so, where another's
            # request of the same error is not)
            shut = set(row.get("declined_of") or ())
            askers = row.get("requested_by") or []
            some = bool(shut) and len(shut) < len(askers)
            asked = "; ".join(
                "%s%s%s" % (w["reviewer"],
                            " (declined)" if some and w["reviewer"] in shut else "",
                            ": %s" % w["text"] if w.get("text") else "")
                for w in askers)
            if asked:
                asked = "requested by %s" % asked
                why = "%s  [%s]" % (why, asked) if why else asked
            # (the lists of the requests say who declined, the others who
            # rejected: the last column is the list's verdict)
            verdict = "declined_by" if kind in ("requested", "declined") else "rejected_by"
            rejected = "; ".join(
                "%s: %s" % (w["reviewer"], w["text"]) if w.get("text") else w["reviewer"]
                for w in row.get(verdict) or [])
            # (a reviewer whose waive of it is rejected is said so, where
            # another's waive of the same error is not)
            gone = set(row.get("rejected_of") or ())
            holders = row.get("waived_by") or []
            mark = bool(gone) and len(gone) < len(holders)
            self.store.append((ci, int(row["error"]), "#%d" % (row["error"] + 1),
                               ", ".join("%s (rejected)" % name if mark and name in gone
                                         else name for name in holders), why,
                               ", ".join(row.get("confirmed_by") or []), rejected))
        if hasattr(self, "verdict_column"):
            self.verdict_column.set_title(
                "Declined by" if kind in ("requested", "declined") else "Rejected by")
        count = reply["count"]
        self.page_label.set_text("%d errors · page %d / %d · %d per page" % (
            count, self.page + 1, max(1, (count + DRC_PAGE - 1) // DRC_PAGE), DRC_PAGE))
        self.prev.set_sensitive(self.page > 0)
        self.next.set_sensitive((self.page + 1) * DRC_PAGE < count)
        confirmers = reply.get("confirmers") or []
        text = "%s: %s\nWhole result: %s · %d reviewer(s)%s" % (
            self.db.checks[ci].name, self._counts_text(reply["rule"]),
            self._counts_text(reply["all"]), len(reply.get("reviewers") or []),
            " · confirmed by %s" % ", ".join(confirmers) if confirmers else "")
        if reply.get("skipped"):
            text += "\nNot read: " + "; ".join(
                "%s (%s)" % (os.path.basename(s["file"]), s["reason"])
                for s in reply["skipped"][:3])
        if self._notice:
            text = self._notice + "\n" + text
            self._notice = ""
        self.status.set_text(text)

    def _fill_rules(self, ci):
        """The rule list: the rules somebody waived in (to confirm / waived
        beside each name), the shown one selected."""
        self._guard = True
        try:
            self.rule.remove_all()
            rules = dict(self._rules)
            if ci not in rules and ci < len(self.db.checks):
                rules[ci] = dict(waived=0, confirmed=0, unconfirmed=0)
            for check in sorted(rules):
                label = "%s  (to confirm %d of %d waived" % (
                    self.db.checks[check].name, rules[check]["unconfirmed"],
                    rules[check]["waived"])
                if rules[check].get("rejected"):
                    label += ", %d rejected" % rules[check]["rejected"]
                if rules[check].get("requested"):
                    label += ", %d requested" % rules[check]["requested"]
                if rules[check].get("declined"):
                    label += ", %d declined" % rules[check]["declined"]
                self.rule.append(str(check), label + ")")
            self.rule.set_active_id(str(ci))
        finally:
            self._guard = False

    def _jump(self, _tree, path, _column):
        if not self._valid() or self.job is not None:
            return
        row = self.store[path]
        self.viewer._drc_jump(int(row[0]), int(row[1]), isolate=True)

    def _ask(self, text):
        dialog = Gtk.MessageDialog(transient_for=self.window, modal=True,
                                   message_type=Gtk.MessageType.QUESTION,
                                   buttons=Gtk.ButtonsType.OK_CANCEL, text=text)
        answer = dialog.run() == Gtk.ResponseType.OK
        dialog.destroy()
        return answer

    def _confirm(self, on, everything=False):
        """Confirm the selected rows' waives (or every waive of the rule that
        is not confirmed yet), or take this reviewer's confirmation of the
        selected rows back."""
        if not getattr(self.db, "confirmer", False):
            self.status.set_text(self.NOT_CONFIRMER)
            return
        ci = self._ci()
        if ci is None:
            return
        if everything:
            members = None
            waiting = (self._rules.get(ci) or {}).get("unconfirmed", 0)
            if not waiting:
                self.status.set_text("No waive of this rule waits for a confirmation.")
                return
            if not self._ask("Confirm all %d waives of %s that are not confirmed yet?"
                             % (waiting, self.db.checks[ci].name)) or not self._valid():
                return
        else:
            ci, members = self._selection()
            if not members:
                self.status.set_text("Select the rows to %s." % (
                    "confirm" if on else "take the confirmation back from"))
                return

        def work(cancelled, progress):
            from .gtkservice import confirm_waives
            return confirm_waives(self.db, ci, members, on, progress=progress)

        def complete(event):
            changed, skipped = event.get("changed", 0), event.get("skipped", 0)
            self._notice = ("Confirmed %d waive(s)." % changed if on else
                            "Took back the confirmation of %d waive(s)." % changed)
            if skipped:
                self._notice += " %d are nobody's waive any more." % skipped
            self._fresh = True
            self._page_load()
            self.viewer._drc_team_waives_changed(self.db)
        self._start("Confirm waives" if on else "Take confirmations back",
                    work, complete, write=True)

    def _reject(self, on):
        """Reject the selected rows' waives, asking why (user 2026-11-14:
        "confirmer가 다른 리뷰어의 waive를 반려할 수 있게 해줘"), or take this
        confirmer's rejection of the selected rows back. A rejection is one
        line of the confirmer's own log; the waives stay with their
        reviewers, whose viewers show them as rejected when they next look,
        until each waives the error again with a reason."""
        if not getattr(self.db, "confirmer", False):
            self.status.set_text(self.NOT_CONFIRMER)
            return
        ci, members = self._selection()
        if not members:
            self.status.set_text("Select the rows to %s." % (
                "reject" if on else "take the rejection back from"))
            return
        reason = None
        if on:
            viewer = self.viewer
            try:
                reply = self.db.reason_read(ci, members, "reject")
            except Exception as exc:
                self.status.set_text("Nothing was rejected: %s" % exc)
                return
            reason = viewer._drc_reason_dialog(
                "reject", len(members), viewer._drc_reason_last.get("reject", ""),
                reply.get("known") or (), parent=self.window)
            if reason is None or not self._valid():
                if self._valid():
                    self.status.set_text("Cancelled; nothing was rejected.")
                return
            viewer._drc_reason_last["reject"] = reason

        def work(cancelled, progress):
            from .gtkservice import reject_waives
            return reject_waives(self.db, ci, members, on, reason=reason,
                                 progress=progress)

        def complete(event):
            changed, skipped = event.get("changed", 0), event.get("skipped", 0)
            self._notice = ("Rejected the waive of %d error(s)." % changed if on else
                            "Took back the rejection of %d error(s)." % changed)
            if skipped:
                self._notice += (" %d are nobody's waive, or rejected already." % skipped
                                 if on else " %d were not rejected by you." % skipped)
            self._fresh = True
            self._page_load()
            # (the confirmer's own waive of a rejected error went with it)
            self.viewer._drc_own_statuses_changed(self.db, ci, event.get("counts"))
            self.viewer._drc_team_waives_changed(self.db)
        self._start("Reject waives" if on else "Take rejections back",
                    work, complete, write=True)

    def _decline(self, on):
        """Decline the selected rows' requests, asking why (user 2026-11-14:
        "요청 거절 상태도 만들어줘"), or take this waiver's decline of the
        selected rows back. A decline is one line of the waiver's own log;
        the requests stay with their requesters, whose viewers show them as
        declined when they next look, until each asks again with a
        reason."""
        if not getattr(self.db, "waiver", False):
            self.status.set_text(self.NOT_WAIVER)
            return
        ci, members = self._selection()
        if not members:
            self.status.set_text("Select the rows to %s." % (
                "decline" if on else "take the decline back from"))
            return
        reason = None
        if on:
            viewer = self.viewer
            try:
                reply = self.db.reason_read(ci, members, "decline")
            except Exception as exc:
                self.status.set_text("Nothing was declined: %s" % exc)
                return
            reason = viewer._drc_reason_dialog(
                "decline", len(members), viewer._drc_reason_last.get("decline", ""),
                reply.get("known") or (), parent=self.window)
            if reason is None or not self._valid():
                if self._valid():
                    self.status.set_text("Cancelled; nothing was declined.")
                return
            viewer._drc_reason_last["decline"] = reason

        def work(cancelled, progress):
            from .gtkservice import decline_requests
            return decline_requests(self.db, ci, members, on, reason=reason,
                                    progress=progress)

        def complete(event):
            changed, skipped = event.get("changed", 0), event.get("skipped", 0)
            self._notice = ("Declined the request of %d error(s)." % changed if on else
                            "Took back the decline of %d error(s)." % changed)
            if skipped:
                self._notice += (" %d have no request that waits, or are declined already."
                                 % skipped if on
                                 else " %d were not declined by you." % skipped)
            self._fresh = True
            self._page_load()
            # (the errors' states are others in this session's lists too)
            self.viewer._drc_own_statuses_changed(self.db, ci, event.get("counts"))
            self.viewer._drc_team_waives_changed(self.db)
        self._start("Decline requests" if on else "Take declines back",
                    work, complete, write=True)


class _DrcMigrationWindow(_DrcTeamWindow):
    """Compare a prior run by exact geometry before transferring own work."""

    def __init__(self, viewer):
        self.viewer, self.db = viewer, viewer._drc
        self.plan, self.job, self.closed = None, None, False
        self.page, self._guard, self._applied = 0, False, None
        self.controls = []
        self.window = Gtk.Window(title="DRC review from previous run")
        self.window.set_transient_for(viewer.window)
        self.window.set_default_size(980, 620)
        viewer._only_close_button(self.window)
        viewer._center_on_parent(self.window)
        self.window.connect("destroy", self._destroy)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_border_width(8)
        self.window.add(box)

        def row():
            widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            box.pack_start(widget, False, False, 0)
            return widget

        def button(parent, label, callback):
            widget = Gtk.Button(label=label)
            widget.connect("clicked", lambda *_: callback())
            parent.pack_start(widget, False, False, 0)
            self.controls.append(widget)
            return widget

        inputs = row()
        self.previous = Gtk.Entry()
        self.previous.set_placeholder_text("Previous results (.db or .tray)")
        inputs.pack_start(self.previous, True, True, 0)
        button(inputs, "Previous results…", lambda: self._browse(self.previous,
            "Choose previous DRC results (.db or .tray)"))
        inputs = row()
        self.review_file = Gtk.Entry()
        self.review_file.set_placeholder_text("Automatic: my saved review for the previous results")
        inputs.pack_start(self.review_file, True, True, 0)
        button(inputs, "Review file…", lambda: self._browse(self.review_file,
            "Choose previous review (.floereview, review SQLite, or waiver file)"))
        button(inputs, "Automatic", lambda: self.review_file.set_text(""))
        for entry in (self.previous, self.review_file):
            self.controls.append(entry)
            entry.connect("changed", lambda *_: self._inputs_changed())
        actions = row()
        button(actions, "Compare geometry", self._prepare)
        self.apply_button = button(actions, "Apply exact matches", self._apply)
        self.apply_button.set_sensitive(False)
        self.cancel_button = Gtk.Button(label="Cancel operation")
        self.cancel_button.connect("clicked", lambda *_: self._cancel_operation())
        self.cancel_button.set_sensitive(False)
        actions.pack_start(self.cancel_button, False, False, 0)
        self.stats = Gtk.Label(label="Choose the previous results, then compare geometry.")
        self.stats.set_xalign(0)
        self.stats.set_line_wrap(True)
        self.stats.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        box.pack_start(self.stats, False, False, 0)
        filters = row()
        self.rule = Gtk.ComboBoxText()
        for ci, check in enumerate(self.db.checks):
            self.rule.append(str(ci), check.name)
        self.rule.set_active(viewer._drc_open if viewer._drc_open is not None else 0)
        filters.pack_start(self.rule, True, True, 0)
        self.rule.connect("changed", lambda *_: self._changed())
        self.mode = Gtk.ComboBoxText()
        for key, title in (("matched", "Exact matches"), ("conflict", "Conflicts only"),
                           ("ambiguous", "Ambiguous previous states")):
            self.mode.append(key, title)
        self.mode.set_active(0)
        filters.pack_start(self.mode, False, False, 0)
        self.mode.connect("changed", lambda *_: self._changed())
        self.controls.extend((self.rule, self.mode))
        self.store = Gtk.ListStore(int, int, str, str, str, str)
        self.tree = Gtk.TreeView(model=self.store)
        for index, title in ((2, "New error"), (3, "Current: V / W / NR"),
                              (4, "Previous: V / W / NR"), (5, "Result")):
            column = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=index)
            column.set_expand(True)
            self.tree.append_column(column)
        self.tree.connect("row-activated", self._jump)
        scroll = Gtk.ScrolledWindow()
        scroll.add(self.tree)
        box.pack_start(scroll, True, True, 0)
        pages = row()
        self.prev = button(pages, "Previous", lambda: self._turn(-1))
        self.page_label = Gtk.Label(label="0 errors")
        pages.pack_start(self.page_label, True, True, 0)
        self.next = button(pages, "Next", lambda: self._turn(1))
        self.prev.set_sensitive(False)
        self.next.set_sensitive(False)
        help_label = Gtk.Label(label=("Only the same rule name and exactly identical geometry can carry review state forward.\n"
            "Duplicate visits are combined; waived and not-for-review are transferred only where each field agrees. "
            "Disputed fields (—) keep their current values. Different decisions on already visited new errors are protected.\n"
            "Double-click opens the new error. Previous result and review files remain read-only."))
        help_label.set_xalign(0)
        help_label.set_line_wrap(True)
        help_label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        box.pack_start(help_label, False, False, 0)
        self.status = Gtk.Label(label="No comparison prepared.")
        self.status.set_xalign(0)
        self.status.set_line_wrap(True)
        self.status.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        self.status.set_max_width_chars(100)
        box.pack_start(self.status, False, False, 0)
        self.window.show_all()

    def _destroy(self, *_):
        if getattr(self.viewer, "_drc_migration", None) is self:
            self.viewer._drc_migration = None
        super()._destroy()

    def _close_sources(self):
        plan, self.plan = self.plan, None
        if plan is not None:
            plan.close()

    def _browse(self, entry, title):
        path = self._choose(title)
        if path:
            entry.set_text(path)

    def _inputs_changed(self):
        if self.job is not None:
            return
        self._close_sources()
        self._applied = None
        self.store.clear()
        self.apply_button.set_sensitive(False)
        self.prev.set_sensitive(False)
        self.next.set_sensitive(False)
        self.page_label.set_text("0 errors")
        self.stats.set_text("Inputs changed. Compare geometry before applying review state.")

    def _poll(self):
        again = super()._poll()
        if self._valid():
            self.apply_button.set_sensitive(self.job is None and self.plan is not None)
            self.cancel_button.set_sensitive(self.job is not None)
            if self.job is not None and self.job.get("phase") and self.job.get("progress"):
                self.status.set_text("%s: %s · %d / %d" %
                    (self.job["label"], self.job["phase"], *self.job["progress"]))
        return again

    def _progress_callback(self, callback):
        job = self.job
        def update(done, total, phase=""):
            callback(done, total)
            if job is not None:
                job["phase"] = str(phase)
        return update

    def _start(self, *args, **kwargs):
        started = super()._start(*args, **kwargs)
        self.cancel_button.set_sensitive(self.job is not None)
        return started

    def _cancel_operation(self):
        if self.job is not None:
            self.job["cancel"].set()
            self.cancel_button.set_sensitive(False)
            self.status.set_text("Cancelling… Already applied chunks are retained.")

    def _jump(self, _tree, path, _column):
        if not self._valid() or self.job is not None:
            return
        row = self.store[path]
        self.viewer._drc_jump(int(row[0]), int(row[1]), isolate=True)
        self.status.set_text("Opened the new error. Apply rechecks current judgements before transfer.")

    def _prepare(self):
        from .gtkservice import prepare_migration
        if self.viewer._load_refused("review from previous run"):
            self.status.set_text("review from previous run: " + NO_FILE_LOAD)
            return
        old_path = self.previous.get_text().strip()
        state_path = self.review_file.get_text().strip() or None
        if not old_path:
            self.status.set_text("Choose the previous DRC results first.")
            return

        def complete(plan):
            self._close_sources()
            self.plan, self.page, self._applied = plan, 0, None
            self._page_load()

        self._start("Compare previous geometry", lambda cancel, progress:
            prepare_migration(self.db, old_path, state_path=state_path, cancelled=cancel,
                progress=self._progress_callback(progress)), complete)

    @staticmethod
    def _flags(state):
        if state is None:
            return "ambiguous"
        return " / ".join("—" if flag is None else "yes" if flag else "no"
                          for flag in (state.visited, state.waived, state.not_required))

    def _page_load(self):
        ci, plan = self._ci(), self.plan
        if ci is None or plan is None or not self._valid() or self.job is not None:
            return
        mode, requested = self.mode.get_active_id() or "matched", self.page

        def work(cancel, progress):
            from .gtkservice import VISITED, NOT_REQUIRED
            count = len(plan.members(ci, mode))
            pages = max(1, (count + DRC_PAGE - 1) // DRC_PAGE)
            page = max(0, min(requested, pages - 1))
            rows = []
            ids = plan.page(ci, page * DRC_PAGE, DRC_PAGE, kind=mode)
            ambiguous = plan.members(ci, "ambiguous").contains_many(ids)
            protected = plan.members(ci, "protected").contains_many(ids)
            carried = plan.get_many(ci, ids)
            for ei, is_ambiguous, is_protected, previous in zip(ids, ambiguous, protected, carried):
                if cancel():
                    raise InterruptedError("comparison page cancelled")
                flags = self.db.review_flags(ci, ei)
                mine = SimpleNamespace(visited=bool(flags & VISITED),
                    waived=self.db.get_status(ci, ei) == 1, not_required=bool(flags & NOT_REQUIRED))
                if previous is None:
                    status = "geometry match unverified"
                elif is_protected:
                    status = "current judgement protected"
                    if is_ambiguous:
                        status += "; partial prior consensus"
                elif is_ambiguous:
                    status = "partial consensus; differing fields retained"
                else:
                    status = "exact match"
                rows.append((ci, ei, "#%d" % (ei + 1), self._flags(mine),
                             self._flags(previous), status))
            return page, pages, count, rows, plan.rule_counts(ci), dict(plan.summary)

        def complete(result):
            page, pages, count, rows, counts, summary = result
            self.page = page
            self.store.clear()
            for row in rows:
                self.store.append(row)
            self.page_label.set_text("%d / %d · %d errors" % (page + 1, pages, count))
            self.prev.set_sensitive(page > 0)
            self.next.set_sensitive(page + 1 < pages)
            def line(label, values):
                return ("%s: matched review %d (partial %d) · no transferable match %d · ambiguous %d · conflicts %d" %
                    (label, values.get("matched", 0), values.get("partial", 0), values.get("unmatched", 0),
                     values.get("ambiguous", 0), values.get("conflict", 0)))
            text = line("Whole new DB", summary) + "\n" + line(self.db.checks[ci].name, counts)
            if summary.get("invalid_old", 0) or summary.get("invalid_new", 0):
                text += ("\nGeometry excluded (invalid or too large): previous %d · new %d" %
                         (summary.get("invalid_old", 0), summary.get("invalid_new", 0)))
            if summary.get("no_rule_match_source_work", 0):
                text += ("\nPrevious review skipped (missing or duplicate rule names): %d" %
                         summary["no_rule_match_source_work"])
            if self._applied is not None:
                text += ("\nApplied: visited %d · waived %d · not for review %d · protected %d" %
                    tuple(self._applied.get(key, 0) for key in
                        ("changed_visited", "changed_waived", "changed_not_required", "conflicts_skipped")))
                if self._applied.get("locked"):
                    text += " · confirmed waives kept %d" % self._applied["locked"]
                if self._applied.get("rejected"):
                    text += " · rejected waives left %d" % self._applied["rejected"]
            self.stats.set_text(text)
        self._start("Read geometry matches", work, complete)

    def _apply(self):
        from .gtkservice import apply_migration
        plan = self.plan
        if plan is None:
            self.status.set_text("Compare geometry first.")
            return

        def complete(result):
            self._applied = result
            self._page_load()
        self._start("Apply previous review to exact matches", lambda cancel, progress:
            apply_migration(self.db, plan, cancelled=cancel,
                progress=self._progress_callback(progress)),
            complete, write=True, changed=True)


class _CellPanel(object):
    """Widget refs of the cell tree panel (attribute bag)."""
    __slots__ = ("_search", "_tree", "_store", "_results", "_info",
                 "_hl", "_top", "_build", "_name_cell")


def _cell_row_text(_column, cell, model, it, _data=None):
    """A cell tree row's words: the cell's name and, two spaces after it,
    its count (a tree row's `×N`, a search result's instances) - the name
    alone for a row without one. The models keep the two apart (columns 0
    and 1): the name is the name wherever it is read."""
    name, count = model[it][0], model[it][1]
    cell.set_property("text", "%s  %s" % (name, count) if count else name)

MIN_SPP = 0.01     # max zoom-in: 1 px = 0.01 dbu; keeps render bboxes
                   # from collapsing to zero width after int rounding
FIT_ZOOM_OUT = 16.0  # max zoom-out: 16x beyond the fit view. The size
                     # cut is cut_px / px_per_um, so the ladder of the
                     # rev 45 thin-frame lattice (2 -> 1 -> gone) and
                     # Calibre wide-view comparisons need room past
                     # fit; the die stays centered out there.
WHEEL_ZOOM_STEP = 0.96  # at most 4% per wheel event (was 10%)
# Calibre-parity keys (user call 2026-08-10): arrows pan half the
# viewport, Shift+arrows the old fine tenth; Ctrl+Z halves the view
# span (zoom in 50%), Shift+Z doubles it back.
KEY_PAN_FRACTION = 0.50
KEY_PAN_FRACTION_FINE = 0.10

# Application CSS for the side panes (one provider, installed once the
# GTK screen exists). Kept as a constant so its syntax is testable
# without a window - a parse error here would surface only at startup.
PANEL_CSS = (
    # combo popups as a LIST, not a menu: GTK menu grabs misfire under
    # XQuartz/remote X (field report 2026-08-18 - the popup closed on
    # the slightest pointer move during the click). List mode selects
    # on a plain row click and never times out.
    b"combobox { -GtkComboBox-appears-as-list: true; } "
    # centred loading banner over the canvas (user call 2026-09-15)
    b".floe-loading { background-color: rgba(0, 0, 0, 0.75); "
    b"color: #ffffff; padding: 12px 22px; border-radius: 8px; "
    b"font-size: 15px; } "
    # Calibre-style layer panel: black background, white text (scoped
    # hooks, never a universal `*` on a ScrolledWindow subtree - see
    # the retina clip note where the classes are attached).
    b".floe-layers, .floe-layers * "
    b"{ background-color: #000000; } "
    b".floe-layers-bg { background-color: #000000; } "
    b".floe-layer-selected, .floe-layer-selected * "
    b"{ background-color: #31566d; } "
    # scrollbars: a plain rectangular grey slider on a near-black
    # trough - traditional square corners, solid fill (no gradient),
    # narrow. opacity:1 keeps it from auto-hiding on the macOS GTK
    # theme. Shared by the layer and DRC panes.
    b".floe-layers-frame scrollbar trough "
    b"{ background-color: #0a0a0a; background-image: none; "
    b"border: none; padding: 0; } "
    b".floe-layers-frame scrollbar slider "
    b"{ background-image: none; background-color: #9a9a9a; "
    b"border: 1px solid #2a2a2a; border-radius: 0; "
    b"min-width: 9px; min-height: 9px; margin: 1px; "
    b"opacity: 1; } "
    b".floe-layers-frame scrollbar slider:hover "
    b"{ background-color: #c0c0c0; } "
    b".floe-layers-frame scrollbar slider:active "
    b"{ background-color: #e0e0e0; } "
    # DRC pane (user calls 2026-09-08, 2026-09-10): ONLY the rules
    # list and the error-number grid are dark - black like the layer
    # pane (the deep grey of 2026-09-08 was revised back to black on
    # 2026-09-10) - with white text; the detail text, search entry,
    # buttons and filters keep the theme. The grid keeps its markup
    # colours (waived green / red, gold selection with darkened
    # numbers, blue current cell); the selected rule row uses the
    # layer pane's blue.
    b".floe-drc-list, .floe-drc-list.view "
    b"{ background-color: #000000; color: #ffffff; } "
    b".floe-drc-list:selected, .floe-drc-list.view:selected "
    b"{ background-color: #31566d; color: #ffffff; } "
    # the rule between the error detail and the filter buttons under
    # it (user call 2026-09-10: nothing marked that boundary) - an
    # explicit colour and height, since the macOS GTK theme draws a
    # bare Gtk.Separator nearly invisible
    b".floe-drc-rule { background-color: #808080; min-height: 1px; "
    b"margin: 2px 0; } "
    # ONE font for the whole viewer (user call 2026-11-14: "cells 패널과
    # 오른쪽 버튼 메뉴도 같은 폰트로 맞춰줘. 메뉴 바, 상태줄등 가능하면 모두
    # 같은 폰트로 맞춰줘"): the font the layer list always had - the
    # monospace face, one step smaller than the theme's (user report
    # 2026-08-13; the rows said it in their markup until 0.12.476, when
    # the DRC pane and the windows beside the main one were given it).
    # The rule is on the top of each widget tree - the main window, the
    # windows and dialogs opened beside it, a menu's and a combo list's
    # own window, a tooltip - and every text under it inherits: the menu
    # bar, the status lines, the panes and their tabs, the lists, the
    # entries and the buttons. `smaller` is the size inherited / 1.2,
    # pango's `small`: the glyphs the layer rows had, pixel for pixel
    # (UI_FONT_MARKUP; the gtk_view gate holds every text to it). It is
    # relative, so a window that sits under another in the tree - a
    # submenu's under its item - takes the size it inherits and is not
    # made smaller twice.
    b"window, dialog, messagedialog, tooltip "
    b"{ font-family: monospace; font-size: smaller; } "
    b"window window, window tooltip, dialog window, dialog tooltip, "
    b"messagedialog window, messagedialog tooltip, tooltip window "
    b"{ font-size: inherit; } "
    # the DRC pane's buttons are low (user call 2026-11-11: the pagers'
    # arrows, and with them the CD controls and the filter row's combos)
    # - about a text line, where the theme's are 34 px
    b".floe-drc-low button { min-height: 0; padding: 1px 8px; } "
    b".floe-drc-low flowboxchild { padding: 0; } "
    # DRC note panel: flateyes-style translucent top-left chip
    b".floe-note-panel { background-color: rgba(0,0,0,0.6); "
    b"color: #f0f0f0; padding: 4px 10px; border-radius: 4px; "
    b"font-size: 12px; }"
)

# Help > Open Source Licenses: what the window shows outside a portable
# bundle - a summary by license family, surveyed 2026-11-16 against a real
# conda-forge resolve of the bundle's runtime and `cargo metadata` of the
# three binaries (the list of 2026-08-22 still named KLayout, NumPy and
# Pillow, which the product has not had since P4f, and left most of what
# ships out). From a bundle the window shows that bundle's own list
# instead (oss_licenses_text): NOTICES/THIRD-PARTY-NOTICES.txt, written by
# tools/portable_notices.py from what the build resolved, with the license
# texts beside it - which is why this one names families, not versions.
_OSS_LICENSES = """\
floe2 uses these open source components, each under its own license.

A portable bundle carries the exact list for its build, the license
texts, and how to get the source of the LGPL / GPL components, in its
NOTICES/ directory (bundles built from 0.12.511 on). From such a bundle
this window shows that list in place of this summary.

viewer (Python, GTK 3: the bundle's runtime, from conda-forge)
  Python 3                        Python-2.0 (PSF)
  PyGObject                       LGPL-2.1-or-later
  pycairo, cairo                  LGPL-2.1-only or MPL-1.1
  GTK 3, ATK, graphite2,
  gobject-introspection           LGPL-2.0-or-later
  GLib, Pango, gdk-pixbuf,
  librsvg, at-spi2, FriBidi,
  libxcrypt, keyutils             LGPL-2.1-or-later
  libiconv, libnsl                LGPL-2.1-only
  libgcc, libstdc++, libgomp      GPL-3.0 with the GCC Runtime
                                  Library Exception
  hicolor icon theme (its index)  GPL-2.0-or-later
  FreeType                        FreeType License (FTL)
  D-Bus                           AFL-2.1
  HarfBuzz, fontconfig, pixman,
  X11 client libraries, Wayland,
  libxkbcommon, libepoxy, libdrm,
  libffi, Expat, libxml2, ICU,
  Kerberos 5, ncurses             MIT / X11 style
  OpenSSL, CUPS, LERC             Apache-2.0
  zlib, libpng, libjpeg-turbo,
  libtiff, libwebp, bzip2, xz,
  Zstandard, PCRE2, libedit,
  libuuid, libglvnd, Tcl/Tk       BSD / zlib style
  SQLite                          public domain
  Ubuntu fonts                    Ubuntu Font Licence 1.0
  DejaVu Sans Mono                Bitstream Vera Licence
  Source Code Pro, Inconsolata    SIL OFL 1.1

command line, indexer, renderer (Rust: floe2, floe-index, floe-renderd)
  Rust standard library           MIT or Apache-2.0
  crates.io crates
  (rust/Cargo.lock)               MIT, Apache-2.0, Zlib, 0BSD,
                                  Unlicense, Unicode-3.0
  LLVM libunwind                  Apache-2.0 with LLVM exceptions
  SQLite                          public domain
  musl libc, Zig's C library and
  compiler runtime (static build) MIT
  Noto Sans Mono (embedded font)  SIL OFL 1.1"""


def oss_licenses_text():
    """What Help > Open Source Licenses shows: the running bundle's own
    list - NOTICES/THIRD-PARTY-NOTICES.txt beside its runtime/, which
    tools/portable_notices.py wrote from what that build resolved (every
    conda package and crate with its license, where the texts are, how
    to get the LGPL / GPL components' source) - where the viewer runs
    from a portable bundle that has one; else the summary above (a
    source checkout, a bundle older than 0.12.511)."""
    prefix = os.path.abspath(sys.prefix)
    if os.path.basename(prefix) == "runtime":
        path = os.path.join(os.path.dirname(prefix), "NOTICES",
                            "THIRD-PARTY-NOTICES.txt")
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                text = f.read(1 << 20)
        except OSError:
            text = ""
        if text.strip():
            return text.rstrip("\n")
    return _OSS_LICENSES


# Help > License Agreement: the product's own terms - the floe2 End User
# License Agreement, EULA.txt beside this module. It is a file of the
# package, so a bundle, an update and a source checkout each carry the text
# of their own version; a bundle has a copy at its top as well, for who
# reads before running anything (tools/make_portable.sh).
_EULA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "EULA.txt")
_EULA_MISSING = (
    "The license agreement (EULA.txt) is not with this copy of the viewer.\n"
    "Ask for it: FLATIDE Inc., https://flatide.com")


def eula_text():
    """What Help > License Agreement shows: this package's EULA.txt (the
    agreement in Korean and in English), or where to ask for it when the
    file is not there."""
    try:
        with open(_EULA_PATH, encoding="utf-8", errors="replace") as f:
            text = f.read(1 << 20)
    except OSError:
        text = ""
    return text.rstrip("\n") if text.strip() else _EULA_MISSING


CAL_ZOOM_IN = 0.5        # spp factor for Ctrl+Z (Shift+Z = inverse)

# layer recolor palette: (hex, name) in grid order, straight from
# the packaged colornames.def (fillpat.COLOR_TABLE)
PALETTE_COLORS = tuple((h, n) for n, h in fillpat.COLOR_TABLE)

MINIMAP_PX = 180           # square palette area; die keeps its aspect ratio
MINIMAP_DOT_MIN = 6        # view box smaller than this becomes a dot
# empty border around the die inside the minimap (user call 2026-09-29:
# the die outline sat on the image's first and last pixel on its long
# axis - hidden at the widget edge, and covered by the fit view's box,
# which was clipped to the die). The view box may extend into it.
MINIMAP_PAD = 6
MINIMAP_BG = 0x141414FF
MINIMAP_EDGE = 0x666666FF
MINIMAP_VIEW = 0x8ECDF5FF
MINIMAP_FRONT = 0x46565FFF  # depth-frontier outlines: dim slate,
                            # well under the view box brightness

# the scale border (user 2026-10-13: "a band around the viewport that reads
# lengths, as Calibre's, with the reference length; the coordinates at the
# four corners"): a band along the frame's four edges, two tones
# alternating every reference length - the view's service says where
# (app-core view::border: 1, 2 or 5 x 10^n um, 60 px or wider, counted
# from the origin) -, a rule toward the layout, the length written over
# the top band, each corner's coordinates in um as a chip
BORDER_PX = 12             # the band each side, its rule included
BORDER_EVEN = 0xDCDCDCFF   # the segments of even ordinal from the origin
BORDER_ODD = 0x3C3C3CFF    # the odd ones (and the corner squares)
BORDER_RULE = 0x8C8C8CFF   # the line between the band and the layout

# Layer/datatype is operationally capped at 999.999. The number column is
# independent of the current design's actual maximum, so changing files or
# expanding a group never moves the palette columns. A small fractional
# margin is converted from the active font width by LayerRow.
LAYER_NUM_WIDTH = len("999.999")  # MINIMUM number column; the panel
                                  # widens it to the longest actual
                                  # pair + 1 so the swatch column can
                                  # never break alignment
LAYER_NUM_MARGIN_CHARS = 0.6      # number -> swatch breathing room
LAYER_NAME_MARGIN_CHARS = 1.2     # swatch -> name: over a full glyph
LAYER_STRIKE_RGB = (242, 242, 242)  # hidden-layer strike: bright,
                                    # readable over dimmed text/swatch
LAYER_SWATCH_WH = (31, 14)  # layer-row color/fill box, fixed px
LAYER_PICK_BG = "#FFD819"   # object-pick: opaque yellow box behind the
                            # layer id (number column), drawn over the
                            # blue row selection with dark text on top
LAYER_PICK_FG = "#101010"   # id text on the yellow pick box (contrast)


def import_gtk():
    """flateyes-style lazy GTK import: exit 3 with a clear message when
    PyGObject is missing or the display is unreachable."""
    global Gtk, Gdk, GdkPixbuf, GLib, Pango
    try:
        import gi
        import warnings
        warnings.simplefilter("ignore", getattr(
            gi, "PyGIDeprecationWarning", DeprecationWarning))
        gi.require_version("Gtk", "3.0")
        gi.require_version("GdkPixbuf", "2.0")
        from gi.repository import Gtk as _Gtk, Gdk as _Gdk, \
            GdkPixbuf as _GdkPixbuf, GLib as _GLib, Pango as _Pango
    except (ImportError, ValueError) as exc:
        sys.stderr.write(
            "%s: PyGObject/GTK3 is required to open a window (%s)\n"
            "  verify with: python3 -c 'import gi; "
            "gi.require_version(\"Gtk\", \"3.0\")'\n" % (APP, exc))
        sys.exit(3)
    Gtk, Gdk, GdkPixbuf, GLib, Pango = \
        _Gtk, _Gdk, _GdkPixbuf, _GLib, _Pango
    ok = Gtk.init_check(sys.argv)
    if isinstance(ok, tuple):
        ok = ok[0]
    if not ok:
        sys.stderr.write(
            "%s: cannot open display %s (X session not reachable)\n"
            % (APP, os.environ.get("DISPLAY", "")))
        sys.exit(3)
    # Pin the theme so the UI looks the same on the dev Mac and the
    # remote-X deployment: HighContrast draws solid, clearly outlined,
    # always-visible (non-overlay) scrollbars/widgets - far more legible
    # than the default flat theme (user call 2026-08-29). GTK_THEME= in
    # the environment still overrides this for anyone who wants another.
    if not os.environ.get("GTK_THEME"):
        try:
            settings = Gtk.Settings.get_default()
            if settings is not None:
                settings.set_property("gtk-theme-name", "HighContrast")
        except (AttributeError, TypeError):
            pass


def fill_rect(buf, x, y, w, h, rgba):
    """Clipped rectangle fill via a shared-pixels subpixbuf (flateyes
    pattern - the only way to draw without cairo)."""
    x, y, w, h = int(round(x)), int(round(y)), int(round(w)), int(round(h))
    if x < 0:
        w += x
        x = 0
    if y < 0:
        h += y
        y = 0
    w = min(w, buf.get_width() - x)
    h = min(h, buf.get_height() - y)
    if w > 0 and h > 0:
        buf.new_subpixbuf(x, y, w, h).fill(rgba)


def stamp_segment(buf, a, b, casing, core, px=2):
    """Line segment: flat rects for H/V, dabs for free angles.
    px=1 draws a hairline core (rulers/zoom band, user call
    2026-08-09); the casing geometry only serves the 2px default."""
    ax, ay = a
    bx, by = b
    off = 0 if px == 1 else 1
    if round(ay) == round(by):    # horizontal
        if casing is not None:
            fill_rect(buf, min(ax, bx), ay - 2, abs(bx - ax) + 1, 5, casing)
        fill_rect(buf, min(ax, bx), ay - off, abs(bx - ax) + 1, px, core)
    elif round(ax) == round(bx):  # vertical
        if casing is not None:
            fill_rect(buf, ax - 2, min(ay, by), 5, abs(by - ay) + 1, casing)
        fill_rect(buf, ax - off, min(ay, by), px, abs(by - ay) + 1, core)
    else:
        steps = min(int(max(abs(bx - ax), abs(by - ay))) + 1, 8000)
        pts = [(ax + (bx - ax) * i / steps, ay + (by - ay) * i / steps)
               for i in range(steps + 1)]
        if casing is not None:
            for x, y in pts:
                fill_rect(buf, x - 1, y - 1, 3, 3, casing)
        for x, y in pts:
            fill_rect(buf, x - off, y - off, px, px, core)


def stamp_dotted(buf, a, b, casing, core):
    """Dotted segment (label leaders): dabs every few px, visually
    distinct from the solid ruler lines."""
    ax, ay = a
    bx, by = b
    steps = min(int(max(abs(bx - ax), abs(by - ay))) + 1, 8000)
    for i in range(0, steps + 1, 5):
        x = ax + (bx - ax) * i / max(1, steps)
        y = ay + (by - ay) * i / max(1, steps)
        if casing is not None:
            fill_rect(buf, x - 1, y - 1, 3, 3, casing)
        fill_rect(buf, x - 1, y - 1, 2, 2, core)


@functools.lru_cache(maxsize=96)
def circle_rgba(radius, color, secondary=None, solid=False):
    """A filled, antialiased circle sprite as packed RGBA bytes,
    (2 * radius + 1) px square (feature/jobdeck-drc floe/drc_marker_style.py,
    without NumPy): colours 0xRRGGBBAA, `secondary` on the right half, a
    translucent middle with a ~2 px outline, or opaque when `solid`."""
    radius = int(radius)
    if radius < 1:
        raise ValueError("circle radius must be positive")
    size = radius * 2 + 1
    stroke = min(2.0, radius / 2.0)

    def channels(rgba):
        rgba = int(rgba)
        return ((rgba >> 24) & 255, (rgba >> 16) & 255,
                (rgba >> 8) & 255, rgba & 255)

    left = channels(color)
    right = channels(secondary) if secondary is not None else left
    out = bytearray(size * size * 4)
    for row, yy in enumerate(range(-radius, radius + 1)):
        for col, xx in enumerate(range(-radius, radius + 1)):
            distance = math.sqrt(xx * xx + yy * yy)
            coverage = min(1.0, max(0.0, radius + 0.5 - distance))
            if coverage == 0:
                continue
            outline = distance >= radius - stroke
            alpha = (255.0 if solid else 72.0 + 136.0 * outline) * coverage
            c = right if xx >= 0 else left
            i = (row * size + col) * 4
            out[i:i + 4] = bytes((c[0], c[1], c[2],
                                  int(round(alpha * c[3] / 255.0))))
    return bytes(out)


def stamp_drc_circle(buf, x, y, radius, color, secondary=None, sprites=None,
                     solid=False):
    """Composite a circle sprite centred at (x, y), clipped at the edges."""
    if sprites is None:
        sprites = {}
    key = (radius, color, secondary, solid)
    sprite = sprites.get(key)
    side = 2 * radius + 1
    if sprite is None:
        sprite = GdkPixbuf.Pixbuf.new_from_bytes(
            GLib.Bytes.new(circle_rgba(radius, color, secondary, solid)),
            GdkPixbuf.Colorspace.RGB, True, 8, side, side, side * 4)
        sprites[key] = sprite
    origin_x, origin_y = int(round(x)) - radius, int(round(y)) - radius
    left, top = max(0, origin_x), max(0, origin_y)
    right = min(buf.get_width(), origin_x + side)
    bottom = min(buf.get_height(), origin_y + side)
    if right > left and bottom > top:
        sprite.composite(buf, left, top, right - left, bottom - top,
                         origin_x, origin_y, 1, 1,
                         GdkPixbuf.InterpType.NEAREST, 255)


def drc_ticks(value):
    """A length or area in 0.00001 ticks as the DRC details and rulers show
    it: the value's shortest digits rounded half up (Python
    Decimal(str(value)) - the service's ticks, app-core drc::analysis)."""
    d = decimal.Decimal(str(value))
    if not d.is_finite():
        raise ValueError("measurement must be finite")
    if d.is_zero() or d.adjusted() < -6:
        return 0
    with decimal.localcontext() as ctx:
        ctx.prec = max(40, len(d.as_tuple().digits) + 8)
        return int((d * 100000).to_integral_value(
            rounding=decimal.ROUND_HALF_UP))


def format_ticks(ticks, signed=False):
    """[-]whole.fffff of a tick count."""
    ticks = int(ticks)
    sign = "-" if ticks < 0 else "+" if signed else ""
    whole, fractional = divmod(abs(ticks), 100000)
    return "%s%d.%05d" % (sign, whole, fractional)


def format_um5(value):
    """`value` to five decimals, half up (rulers, the measuring status)."""
    try:
        return format_ticks(drc_ticks(value))
    except (ValueError, decimal.DecimalException):
        return "%.5f" % value


class _DrcAreaLabel(object):
    """An area or zero-gap readout at a point, kept with the auto rulers
    (Tab/Esc/k/the next jump) and drawn without a line or arrowheads."""
    __slots__ = ("point", "text")

    def __init__(self, x, y, text):
        self.point, self.text = (x, y), text

    def __iter__(self):
        return iter(self.point * 2)


class _DrcOffsetRuler(object):
    """A normal 4-coordinate ruler tagged for screen-space offset.

    Keeping the source segment in world coordinates preserves its exact
    measurement while the viewer can move only its painted dimension line.
    The object remains unpackable everywhere ordinary ruler tuples are used.
    """
    __slots__ = ("segment",)

    def __init__(self, segment):
        self.segment = tuple(segment)

    def __iter__(self):
        return iter(self.segment)


# ---- ruler-label placement (flateyes port) ---------------------------------

def rects_overlap(p, q):
    return (p[0] < q[2] and p[2] > q[0]
            and p[1] < q[3] and p[3] > q[1])


def seg_hits_rect(p, q, rect):
    """Does segment p-q pass through rect? (Liang-Barsky reject test.)"""
    x0, y0, x1, y1 = rect
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for num, den in ((p[0] - x0, -dx), (x1 - p[0], dx),
                     (p[1] - y0, -dy), (y1 - p[1], dy)):
        if den == 0:
            if num < 0:
                return False
        else:
            r = num / den
            if den < 0:
                t0 = max(t0, r)   # entering this boundary
            else:
                t1 = min(t1, r)   # leaving it
            if t0 > t1:
                return False
    return True


def leader_seg(a, b, rect):
    """Leader for a readout at rect: from the label edge to the
    closest point of segment a-b. The foot lands on that specific
    line (not a shared crossing), so crossing rulers stay
    identifiable. None when the segment already passes under the
    label - adjacency says it all."""
    lx0, ly0, lx1, ly1 = rect
    lcx, lcy = (lx0 + lx1) / 2.0, (ly0 + ly1) / 2.0
    dx, dy = b[0] - a[0], b[1] - a[1]
    denom = dx * dx + dy * dy
    t = 0.0 if denom == 0 else \
        ((lcx - a[0]) * dx + (lcy - a[1]) * dy) / denom
    t = max(0.0, min(1.0, t))
    px, py = a[0] + t * dx, a[1] + t * dy
    ex = min(max(px, lx0), lx1)   # stop at the label boundary
    ey = min(max(py, ly0), ly1)
    if abs(ex - px) < 1 and abs(ey - py) < 1:
        return None
    return ((ex, ey), (px, py))


def shove_label(x, y, w, h, placed, vw, vh):
    """Nudge a w*h label from its desired (x, y) so it clears every
    label already placed this pass: drop it just below the blocking
    label, wrap to a fresh column when one fills, and keep it inside
    the viewport. Best-effort and bounded: a viewport packed
    edge-to-edge with labels may keep a residual overlap rather than
    loop forever."""
    gap = 3
    max_x = max(2, vw - w - 2)
    max_y = max(2, vh - h - 2)
    x = min(max(2, x), max_x)
    y = min(max(2, y), max_y)
    for _ in range(len(placed) * 2 + 2):
        rect = (x, y, x + w, y + h)
        hit = next((r for r in placed if rects_overlap(rect, r)), None)
        if hit is None:
            break
        y = hit[3] + gap            # just below the blocking label
        if y > max_y:               # column full: start the next one
            x = min(x + w + gap, max_x)
            y = 2
    return x, y


def spread_label_spot(a, b, mid_x, mid_y, w, h):
    """Desired top-left for a ruler's readout when several rulers
    share the view: shift along the line (tangent) so crossing rulers
    don't pile their labels on the shared crossing, then lift off the
    line (normal) so each chip sits beside its own line."""
    dvx, dvy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dvx, dvy) or 1.0
    tx, ty = dvx / length, dvy / length              # unit tangent
    nx, ny = -ty, tx                                 # unit normal
    if ny > 0 or (abs(ny) < 1e-9 and nx < 0):        # aim it upward
        nx, ny = -nx, -ny
    sdir = 1.0 if tx >= 0 else -1.0                  # toward right end
    shift = min(0.30 * length, 64.0)
    fx = mid_x + sdir * tx * shift
    fy = mid_y + sdir * ty * shift
    lift = (abs(nx) * w + abs(ny) * h) / 2.0 + 12
    return fx + nx * lift - w / 2.0, fy + ny * lift - h / 2.0


def pick_label_spot(a, b, w, h, placed, leaders, others, vw, vh):
    """Place one ruler's readout so the whole arrangement stays
    legible: try anchors along the ruler's own line and both sides of
    it, and take the first spot whose chip covers no other chip or
    leader and whose own leader does not run under an earlier chip
    (chips are widgets above the overlay, so anything under one is
    lost). The strict first sweep also refuses to cover the other
    rulers' lines, which walks chips away from a shared crossing;
    rulers packed too closely for that retry without it, and the
    plain spread + shove remains the last resort."""
    dvx, dvy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dvx, dvy) or 1.0
    tx, ty = dvx / length, dvy / length
    # first side = the upward normal, matching the single-ruler habit
    first = -1.0 if tx > 0 else 1.0
    for strict in (True, False):
        for frac in (0.5, 0.34, 0.66, 0.2, 0.8):
            ax = a[0] + dvx * frac
            ay = a[1] + dvy * frac
            if not (0 <= ax <= vw and 0 <= ay <= vh):
                continue   # anchor scrolled out: label points nowhere
            for side in (first, -first):
                nx, ny = -ty * side, tx * side
                lift = (abs(nx) * w + abs(ny) * h) / 2.0 + 12
                x = ax + nx * lift - w / 2.0
                y = ay + ny * lift - h / 2.0
                x = min(max(2, x), max(2, vw - w - 2))
                y = min(max(2, y), max(2, vh - h - 2))
                rect = (x, y, x + w, y + h)
                if any(rects_overlap(rect, r) for r in placed):
                    continue
                if any(seg_hits_rect(s[0], s[1], rect)
                       for s in leaders):
                    continue   # chip would sit on an earlier leader
                if strict and any(seg_hits_rect(oa, ob, rect)
                                  for oa, ob in others):
                    continue   # chip would cover someone else's line
                seg = leader_seg(a, b, rect)
                if seg is not None and any(
                        seg_hits_rect(seg[0], seg[1], r)
                        for r in placed):
                    continue   # leader would vanish under a chip
                return x, y
    mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
    x, y = spread_label_spot(a, b, mx, my, w, h)
    return shove_label(x, y, w, h, placed, vw, vh)


def fill_triangle(buf, p0, p1, p2, color):
    """Solid triangle via 1-px horizontal scanline fills."""
    pts = (p0, p1, p2)
    y0 = int(math.floor(min(p[1] for p in pts)))
    y1 = int(math.ceil(max(p[1] for p in pts)))
    for y in range(y0, y1 + 1):
        yc = y + 0.5
        xs = []
        for a, b in ((p0, p1), (p1, p2), (p2, p0)):
            if (a[1] <= yc) != (b[1] <= yc):
                t = (yc - a[1]) / (b[1] - a[1])
                xs.append(a[0] + t * (b[0] - a[0]))
        if len(xs) >= 2:
            fill_rect(buf, min(xs), y, max(xs) - min(xs) + 1, 1, color)


def stamp_arrow(buf, tip, ang, casing, core, size=11, half=4):
    """Solid triangular arrowhead (the original tkinter-viewer look):
    tip at the given point, pointing along ang (screen radians)."""
    ux, uy = math.cos(ang), math.sin(ang)
    px, py = -uy, ux

    def tri(tx, ty, sz, hf):
        bx, by = tx - sz * ux, ty - sz * uy
        return ((tx, ty), (bx + hf * px, by + hf * py),
                (bx - hf * px, by - hf * py))

    if casing is not None:
        fill_triangle(buf, *tri(tip[0] + 2 * ux, tip[1] + 2 * uy,
                                size + 4, half + 1.5), casing)
    fill_triangle(buf, *tri(tip[0], tip[1], size, half), core)


def rect_outline(buf, x0, y0, x1, y1, casing, core, px=2):
    for a, b in (((x0, y0), (x1, y0)), ((x0, y1), (x1, y1)),
                 ((x0, y0), (x0, y1)), ((x1, y0), (x1, y1))):
        stamp_segment(buf, a, b, casing, core, px)


def _probe_binary_version(find_binary):
    """One '--version' stamp line from a Rust helper binary, resolved
    exactly the way the app would launch it. A pre-0.12.13
    floe-renderd has no --version: it greets `ready version=...` on
    stdout and exits on the closed stdin, so that shape is accepted
    too. The timeout is generous: macOS scans a freshly written
    executable on its first launch (the gate's stub scripts took
    1.5 to 6+ s to print one line), and a loaded shared host is slow
    to spawn anything."""
    import subprocess
    path = find_binary()
    probe = subprocess.run(
        [path, "--version"], stdin=subprocess.DEVNULL,
        capture_output=True, text=True, timeout=30)
    for line in probe.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith("ready "):
            for token in line.split()[1:]:
                if token.startswith("version="):
                    return "%s %s" % (os.path.basename(path),
                                      token.split("=", 1)[1])
            break
        return line
    raise RuntimeError("no version line from %s" % path)


def component_versions(worker):
    """Help > About body lines: which floe-index / floe-renderd builds
    the app is wired to. Closed-network hosts carry several
    circulating binaries (rust/BUILD.md stamp policy), so About must
    answer "which one is this" without a terminal. The running
    daemon's handshake stamp wins over probing the binary on disk -
    the two can differ after an in-place binary swap."""
    from . import vfsclient
    lines = []
    try:
        lines.append(_probe_binary_version(vfsclient.find_binary))
    except Exception as exc:
        lines.append("floe-index unavailable: %s" %
                     str(exc).splitlines()[0][:60])
    build = getattr(worker, "renderd_build", None)
    build = build() if callable(build) else None
    if build:
        lines.append("floe-renderd %s [running]" % build)
    else:
        try:
            lines.append(_probe_binary_version(vfsclient.find_renderd))
        except Exception as exc:
            lines.append("floe-renderd unavailable: %s" %
                         str(exc).splitlines()[0][:60])
    return lines


# what the load dialog's browser never lists (user call 2026-09-10):
# the pre-2026-09-16 cache/pack names <src>.floe and <db>.ice (the
# current names .<src>.ice and .<db>.tray are dotfiles, hidden by the
# dotfile rule) - GTK's own chooser applies no filter to folders, so
# caches cluttered every data directory
BROWSE_HIDDEN_SUFFIXES = (".floe", ".ice")


def list_browse_entries(folder, patterns):
    """(folders, files, links) of `folder` for the file dialogs' browser.
    Folders are names; files are (name, size, mtime) and symbolic links
    (name, target) admitted by one of the fnmatch `patterns` on their
    own name (case-insensitive). Dotfiles, *.floe and *.ice are never
    listed; each list sorts case-insensitively. An unreadable folder
    lists nothing.

    Nothing here follows a symbolic link (user call 2026-10-21): a
    data folder of links to other volumes made the dialog stat every
    link's target before it opened - an automount or an unreachable
    NFS server per link. So a link is judged by its own name, as a
    file is (user call 2026-10-26: under the .jb filter every link of
    the folder was listed), with the text of the link itself
    (readlink) beside it; the browser follows the one link the user
    activates. A link to a folder is a name too: the all-files filter
    lists it."""
    import fnmatch
    folders, files, links = [], [], []
    try:
        it = os.scandir(folder)
    except OSError:
        return [], [], []
    lowered = [p.lower() for p in patterns]
    with it:
        for e in it:
            name = e.name
            if name.startswith(".") or name.lower().endswith(
                    BROWSE_HIDDEN_SUFFIXES):
                continue
            try:
                is_link = e.is_symlink()
                is_dir = not is_link and e.is_dir(follow_symlinks=False)
            except OSError:
                continue
            if is_dir:
                folders.append(name)
                continue
            if not any(fnmatch.fnmatch(name.lower(), p) for p in lowered):
                continue
            if is_link:
                try:
                    target = os.readlink(e.path)
                except OSError:
                    target = ""
                links.append((name, target))
                continue
            try:
                st = e.stat(follow_symlinks=False)
                files.append((name, st.st_size, st.st_mtime))
            except OSError:
                files.append((name, -1, 0))
    folders.sort(key=str.lower)
    files.sort(key=lambda t: t[0].lower())
    links.sort(key=lambda t: t[0].lower())
    return folders, files, links


def browse_rows(folder, patterns):
    """The file dialogs' browser rows of `folder` under `patterns`:
    (display, size, modified, is_dir, name, is_link, tip). Folders come
    first as `name/`; then the files and the symbolic links the
    patterns admit (list_browse_entries) in one name order, a link as
    `name@` (ls -F; user call 2026-10-26) with no size or time - its
    target is not looked at - and its own text `name -> target` for
    the tip; the tip of the others is the display. Tips are plain text
    (the dialog escapes them for the tooltip's markup)."""
    folders, files, links = list_browse_entries(folder, patterns)
    rows = [(name + "/", "", "", True, name, False, name + "/")
            for name in folders]
    entries = [(name, size, mtime, None) for name, size, mtime in files]
    entries += [(name, -1, 0, target) for name, target in links]
    entries.sort(key=lambda t: (t[0].lower(), t[0]))
    for name, size, mtime, target in entries:
        if target is not None:
            rows.append((name + "@", "", "", False, name, True,
                         "%s -> %s" % (name, target or "?")))
        elif size < 0:
            rows.append((name, "", "", False, name, False, name))
        else:
            rows.append((name, fmt_bytes(size),
                         time.strftime("%Y-%m-%d %H:%M",
                                       time.localtime(mtime)),
                         False, name, False, name))
    return rows


def fmt_bytes(n):
    """1023 B, 4.2 KB, 1.3 MB, 2.0 GB."""
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%d %s" if unit == "B" else "%.1f %s") % (n, unit)
        n /= 1024


def fmt_count(n):
    """Human shape count: 950 / 12k / 3.4M / 1.2G."""
    if n >= 1e9:
        return "%.1fG" % (n / 1e9)
    if n >= 1e6:
        return "%.1fM" % (n / 1e6)
    if n >= 10e3:
        return "%.0fk" % (n / 1e3)
    return str(int(n))


def frame_rect(buf, x0, y0, w, h, color):
    """1-px rectangle border (rect_outline is too heavy for the minimap)."""
    fill_rect(buf, x0, y0, w, 1, color)
    fill_rect(buf, x0, y0 + h - 1, w, 1, color)
    fill_rect(buf, x0, y0, 1, h, color)
    fill_rect(buf, x0 + w - 1, y0, 1, h, color)


def pixbuf_of(width, height, pixels, alpha=False):
    """A pixbuf over packed RGB (or RGBA) bytes, the bytes kept by it."""
    channels = 4 if alpha else 3
    return GdkPixbuf.Pixbuf.new_from_bytes(
        GLib.Bytes.new(bytes(pixels)), GdkPixbuf.Colorspace.RGB, alpha, 8,
        width, height, width * channels)


def outlined_pixbuf(width, height, inner_row, outline=(102, 102, 102)):
    """width x height RGB with a 1 px outline (the palette swatches and
    fill slots); inner_row(y, n) -> the RGB bytes of the n pixels inside
    it on row y (x = 1 .. n)."""
    edge = bytes(outline)
    if width < 3 or height < 3:
        return pixbuf_of(width, height, edge * (width * height))
    rows = [edge * width]
    for y in range(1, height - 1):
        rows.append(edge + inner_row(y, width - 2) + edge)
    rows.append(edge * width)
    return pixbuf_of(width, height, b"".join(rows))


def tiled_row(bits, n, on=b"\x00\x00\x00", off=b"\xff\xff\xff"):
    """n pixels from x = 1 of a 16-wide `*`/`.` bitmap row tiled 1:1."""
    tile = b"".join(on if c == "*" else off for c in bits[:16].ljust(16, "."))
    return (tile * (n // 16 + 2))[3:3 + 3 * n]


class PixbufCell:
    """A widget showing paint(width, height) -> pixbuf at the size it is
    given, with no GTK "draw" handler: the target hosts have no pycairo
    (module docstring), and a cairo-drawn widget stays blank there (field
    2026-10-10: the hidden-layer strike and the palettes were). The image
    is an overlay child, so its size never enters the request and the
    cell still shrinks with the pane; it is painted again after a size
    change (from idle, outside the allocation) and on refresh(). It is
    opaque and covers its window whole (an overlay child's window may
    paint an opaque background on some X servers) and takes no input."""

    def __init__(self, paint, width, height):
        self._paint = paint
        self._size = None
        self.widget = Gtk.Overlay()
        base = Gtk.Box()
        base.set_size_request(width, height)
        self.widget.add(base)
        self.image = Gtk.Image()
        self.image.set_halign(Gtk.Align.START)
        self.image.set_valign(Gtk.Align.START)
        self.widget.add_overlay(self.image)
        # an overlay child gets a GDK window of its own: without
        # pass-through a click lands there, with coordinates of that
        # window, and the palette's pick (the grid's coordinates) took
        # the wrong swatch
        self.widget.set_overlay_pass_through(self.image, True)
        self.widget.connect("size-allocate", self._on_allocate)

    def _on_allocate(self, _widget, alloc):
        size = (alloc.width, alloc.height)
        if size != self._size and size[0] > 0 and size[1] > 0:
            self._size = size
            GLib.idle_add(self._repaint, size)

    def _repaint(self, size):
        if size == self._size:
            self.image.set_from_pixbuf(self._paint(*size))
        return False

    def refresh(self):
        if self._size is not None:
            self.image.set_from_pixbuf(self._paint(*self._size))


def _panel_debug_hook(scroller, box, rows_getter):
    """FLOE_PANEL_DEBUG=1: log palette geometry on every scroll tick
    and size change - allocation vs GdkWindow vs mapped state for the
    first/last rows in view. Field tool for the shrinking-range bug:
    the log shows WHICH layer of the stack (logical allocation, gdk
    window position, map state, adjustment clamp) diverges on the
    machine where it reproduces."""
    if not os.environ.get("FLOE_PANEL_DEBUG"):
        return

    def dump(tag, *_a):
        try:
            adj = scroller.get_vadjustment()
            sa = scroller.get_allocation()
            ba = box.get_allocation()
            vp = scroller.get_child()
            binpos = viewpos = None
            try:
                # BIN window: moves with the scroll, must be as tall
                # as the content and sit at y = -adj.value.
                # VIEW window: the stationary clip, must span the
                # whole scroller interior - a short/misplaced view
                # window clips rows to a moving band.
                bw = vp.get_bin_window() if hasattr(
                    vp, "get_bin_window") else None
                if bw is not None:
                    g = bw.get_geometry()
                    binpos = (g.x, g.y, g.width, g.height)
                vw = vp.get_view_window() if hasattr(
                    vp, "get_view_window") else None
                if vw is not None:
                    g = vw.get_geometry()
                    viewpos = (g.x, g.y, g.width, g.height)
            except Exception:
                pass
            lo = hi = None
            unmapped = 0
            for r in rows_getter():
                w = r.widget
                if not w.get_visible():
                    continue
                a = w.get_allocation()
                inview = (a.y + a.height > adj.get_value()
                          and a.y < adj.get_value()
                          + adj.get_page_size())
                if not inview:
                    continue
                if not w.get_mapped():
                    unmapped += 1
                gw = w.get_window()
                pos = gw.get_position() if gw else None
                ent = (a.y, a.height, w.get_mapped(), pos)
                if lo is None:
                    lo = ent
                hi = ent
            sys.stderr.write(
                "[panel] %s adj=%.0f/%.0f pg=%.0f scr=(y%d h%d) "
                "box_h=%d bin=%s view=%s first=%s last=%s "
                "unmapped_in_view=%d\n"
                % (tag, adj.get_value(), adj.get_upper(),
                   adj.get_page_size(), sa.y, sa.height,
                   ba.height, binpos, viewpos, lo, hi, unmapped))
            sys.stderr.flush()
        except Exception as exc:
            sys.stderr.write("[panel] dump failed: %s\n" % exc)

    scroller.get_vadjustment().connect(
        "value-changed", lambda *a: dump("scroll"))
    scroller.connect(
        "size-allocate", lambda *a: dump("alloc"))
    box.connect(
        "size-allocate", lambda *a: dump("box-alloc"))


# The viewer's one font as pango markup of a text drawn where no window's
# rule reaches - on a widget that is in no window yet, which has the
# theme's own font: the monospace face, one step smaller (PANEL_CSS says
# the same for everything under a window).
UI_FONT_MARKUP = '<span face="monospace" size="small">%s</span>'


def _ui_glyph_size():
    """(width, height) in pixels of one glyph cell of the viewer's font,
    measured outside any window (UI_FONT_MARKUP): what a row lays its
    columns out by before it is in the window."""
    layout = Gtk.Label().create_pango_layout("")
    layout.set_markup(UI_FONT_MARKUP % "0", -1)
    return layout.get_pixel_size()


def _start_size_after(paned, part, px, vertical=False):
    """Start `part` - what stands after `paned`'s divider - at `px` of
    width (of height in a vertical paned). A GtkPaned's position is the
    size of what stands BEFORE its divider, and that follows the window's:
    the divider is put once, at the paned's first layout, by what `part`
    has over or under `px` there. Once: the divider is the user's from
    then on, and a part that does not resize with its paned keeps the size
    while the window's changes."""
    held = []

    def placed(pn, _alloc):
        have = part.get_allocated_height() if vertical else part.get_allocated_width()
        if have <= 1:
            return          # not laid out yet
        pn.disconnect(held.pop())
        if have != px:
            pn.set_position(pn.get_position() + have - px)
    held.append(paned.connect("size-allocate", placed))


def _remote_x_scroll_repaint(scroller):
    """Repaint the whole scrolled area on every scroll step.

    GTK scrolls a viewport by BLITTING the still-visible region
    server-side (copy-area) and repainting only the exposed strip.
    Remote X servers of this deployment (Exceed, XQuartz - the same
    family as the XRender black-image bug) botch that blit: each
    step leaves an unpainted band, so the visible strip appears to
    shrink from the top and bottom as you scroll. Invalidating the
    scroller per adjustment tick forces a full repaint of what is
    on screen - the panels hold at most a few dozen visible rows,
    so the cost is negligible on any display path.

    queue_draw alone only SCHEDULES the repaint, and while a
    scrollbar slider is held the pending redraw can sit behind the
    drag: after a horizontal offset a vertical drag then looked
    frozen until the next event (a wheel tick) flushed it. Force the
    invalidation to paint synchronously so each step lands at once.

    The scrollbars have their OWN GdkWindows, so the scroller's
    queue_draw does not repaint the SLIDER. And a synchronous flush
    on EVERY tick backfires on a fast wheel burst: the content
    (adjustment value) lands correctly but the rapid per-tick paints
    coalesce and the slider's FINAL frame is dropped - it freezes
    mid-track until the pointer enters the scrollbar (user report
    2026-08-29, GTK3-Quartz). So each tick only INVALIDATES cheaply,
    and a short debounce forces one authoritative synchronous repaint
    once the burst settles, which always lands the final slider."""
    bars = (lambda: (scroller, scroller.get_vscrollbar(),
                     scroller.get_hscrollbar()))
    settle = {"id": 0}

    def _flush(widget):
        if widget is None:
            return
        widget.queue_draw()
        win = widget.get_window()
        if win is not None:
            try:
                win.process_updates(True)  # paint now, not at idle
            except (AttributeError, TypeError):
                pass  # removed in some GTK3 builds; queue_draw stands

    def _settled():
        settle["id"] = 0
        for w in bars():
            _flush(w)
        return False  # one-shot

    def repaint(*_a):
        # cheap per-tick invalidation keeps slow scrolling smooth
        for w in bars():
            if w is not None:
                w.queue_draw()
        # ...and a debounced synchronous repaint guarantees the final
        # slider position after a fast burst, without hammering
        # process_updates on every tick (which drops the last frame)
        if settle["id"]:
            GLib.source_remove(settle["id"])
        settle["id"] = GLib.timeout_add(40, _settled)
    for adj in (scroller.get_vadjustment(),
                scroller.get_hadjustment()):
        if adj is not None:
            adj.connect("value-changed", repaint)
    try:
        scroller.set_kinetic_scrolling(False)
    except AttributeError:
        pass


# an index run refused for a busy target (floe_vfs::lock, EX_TEMPFAIL)
BUSY_EXIT = 75
# a DRC error's review status byte (floe2 gtk-service; 2 is reserved)
STATUS_NONE = gtkservice.STATUS_NONE
STATUS_WAIVED = gtkservice.STATUS_WAIVED
# how far a one-edge CD ruler is drawn off its edge, screen px
EDGE_RULER_OFFSET_PX = 14


def offset_screen_segment(a, b, distance=EDGE_RULER_OFFSET_PX):
    """Move a screen-space segment along a stable normal: the upper
    side, the right side as the tie-break for a vertical segment - the
    rule is independent of endpoint order, so the viewer and a rendered
    snapshot place a one-edge CD ruler identically."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy)
    if length <= 0:
        return a, b
    nx, ny = -dy / length, dx / length
    if ny > 1e-12 or (abs(ny) <= 1e-12 and nx < 0):
        nx, ny = -nx, -ny
    ox, oy = nx * distance, ny * distance
    return ((a[0] + ox, a[1] + oy),
            (b[0] + ox, b[1] + oy))


def deck_skipped_note(skipped):
    """The status line of a deck whose placements are not all drawn: how
    many, and the first by its CHIP, level, source and reason (the deck's
    `$N` reads `level N`, user 2026-10-26)."""
    first = skipped[0]
    return "jobdeck: %d placement(s) not drawn - CHIP %s level %d %s: %s" % (
        len(skipped), first["chip"], first["idx"], first["tc"],
        first["reason"])


def _level_row_text(row, keep=3):
    """(summary, full) for one level row of the load dialog: the summary
    names at most `keep` sources and counts the rest (review 2026-09-10
    (9th) P2-2: 250 file names in one label made the dialog 26,000 px
    wide); `full` lists them all for the tooltip."""
    names = [os.path.basename(s) for s in row["sources"]]
    shown = ", ".join(names[:keep])
    if len(names) > keep:
        shown += ", +%d more" % (len(names) - keep)
    summary = "%d CHIP%s · %d instance%s · %d source%s: %s" % (
        len(row["chips"]), "" if len(row["chips"]) == 1 else "s",
        row["instances"], "" if row["instances"] == 1 else "s",
        len(names), "" if len(names) == 1 else "s", shown)
    full = "CHIPs: %s\nsources:\n  %s" % (
        ", ".join(row["chips"]), "\n  ".join(names))
    return summary, full


def listed_meta(cache):
    """The cache's meta with the layer table the viewer lists (user
    2026-10-08, the field's EBEAM files: Calibre listed 3.0 and 3.300
    where floe listed 3.1 and 3.2 too, nothing drawn on them). A
    layout's pair that holds no shape and no text (stored_shapes 0: only
    the file's LAYERNAME table names it - KLayout lists it, and so does
    the index) is left out of the panel, the visible set and the layer
    properties; the index, `info` and the renderer keep every pair. A
    jobdeck's table is the deck's (its level heads hold nothing by
    design). FLOE_EMPTY_LAYERS=show lists every pair as before."""
    meta = cache.meta
    if getattr(cache, "is_jobdeck", False) or \
            os.environ.get("FLOE_EMPTY_LAYERS") == "show":
        return meta
    layers = meta.get("layers", [])
    listed = [l for l in layers if l.get("stored_shapes") != 0]
    if len(listed) == len(layers):
        return meta
    left = ["%d/%d" % (l["layer"], l["datatype"])
            for l in layers if l.get("stored_shapes") == 0]
    sys.stderr.write(
        "[%s] %d layer%s not listed - the file's layer table names "
        "them, no shape or text is on them: %s%s (FLOE_EMPTY_LAYERS=show "
        "lists them)\n" % (APP, len(left), "" if len(left) == 1 else "s",
                           ", ".join(left[:8]),
                           ", ..." if len(left) > 8 else ""))
    return dict(meta, layers=listed)


class LayerRow(object):
    """One layer row: [marker][layer.datatype][swatch][name].

    Double-clicking the row toggles
    visibility (hidden = strikethrough, place and color kept). The
    fixed-width marker and layer/datatype columns keep every color swatch
    aligned and the marker doubles as the expand control on group parents:
    '+' collapsed / '-' expanded (single click), ' ' for childless layers
    and children."""

    def __init__(self, l, marker, num_width, tooltip, on_toggle,
                 on_select, on_expand=None):
        self.key = (l["layer"], l["datatype"])
        # Calibre-style row: "127.1  <swatch>  NAME" - number first,
        # a color marker, then the name in plain white on black
        # datatype 0 displays bare (Calibre style): 2.0 -> 2
        raw_num = ("%d" % self.key[0] if self.key[1] == 0
                   else "%d.%d" % (self.key[0], self.key[1]))
        # Render exactly num_width monospace glyph cells in every row so the
        # swatches stay aligned. Layer/datatype text itself is left-aligned.
        self._num = raw_num.ljust(num_width)
        name = l["name"] or ""
        # placeholder names arrive as "layer/type": show them in
        # the l.d form (same dt-0 omission as the number column)
        if "/" in name:
            a, _, b = name.partition("/")
            if a.isdigit() and b.isdigit():
                name = a if b == "0" else "%s.%s" % (a, b)
        self._name = name
        self._color = l["color"]
        self._marker = marker
        self._on_toggle = on_toggle
        self._on_select = on_select
        self._on_expand = on_expand
        self._active = True
        self._partial = False
        self._picked = False
        self._selected = False
        self._fill_rows = None      # None = default speckle checker
        self._mlbl = Gtk.Label()
        self._mlbl.set_xalign(0.0)
        mbox = Gtk.EventBox()
        mbox.add(self._mlbl)
        # Every marker accepts the row context menu. Group parents also use
        # its left click as the expand/collapse control.
        mbox.connect("button-press-event", self._on_marker_click)
        self._nlbl = Gtk.Label()
        self._nlbl.set_xalign(0.0)
        # (a glyph cell of the viewer's font, which the row has once it
        # is in the window: PANEL_CSS)
        probe_width, probe_height = _ui_glyph_size()
        self._mlbl.set_size_request(max(1, probe_width * 2), -1)
        self._nlbl.set_size_request(max(1, probe_width * num_width), -1)
        small_gap = max(1, round(probe_width * LAYER_NUM_MARGIN_CHARS))
        self._nlbl.set_margin_end(small_gap)
        self._clbl = Gtk.Image()
        self._clbl.set_halign(Gtk.Align.CENTER)
        self._clbl.set_valign(Gtk.Align.CENTER)
        swatch_w, swatch_h = LAYER_SWATCH_WH
        self._swatch_refs = []
        self._swatch_wh = (swatch_w, swatch_h)
        self._swatch_on = self._speckle_swatch(swatch_w, swatch_h)
        self._clbl.set_from_pixbuf(self._swatch_on)
        self._clbl.set_size_request(swatch_w, swatch_h)
        self._lbl = Gtk.Label()
        self._lbl.set_xalign(0.0)
        # the alias sits visibly APART from the swatch: at least a
        # full glyph of air, not the thin number-column gap
        self._lbl.set_margin_start(max(
            1, round(probe_width * LAYER_NAME_MARGIN_CHARS)))
        # Preserve the complete layer name. The palette scroller owns the
        # width constraint and exposes overflow through its bottom scrollbar.
        self._lbl.set_ellipsize(Pango.EllipsizeMode.NONE)
        content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        content.pack_start(self._nlbl, False, False, 0)
        content.pack_start(self._clbl, False, False, 0)
        content.pack_start(self._lbl, True, True, 0)
        nbox = Gtk.EventBox()
        nbox.add(content)
        nbox.connect("button-press-event", self._on_name_click)
        # input-only sub-boxes: the hidden-layer strike is ONE line
        # across the whole row OVER the children (an overlay image), and
        # a child with a visible window would composite over it (the
        # gaps were exactly where the old per-span strike vanished)
        mbox.set_visible_window(False)
        nbox.set_visible_window(False)
        row_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self._row_pad = max(1, round(probe_height * 0.1))
        row_box.set_margin_bottom(self._row_pad)
        row_box.pack_start(mbox, False, False, 0)
        row_box.pack_start(nbox, True, True, 0)
        # Keep the inter-row padding inside an event window. A click in the
        # gap therefore belongs to this (upper) row instead of falling
        # through the layer palette without selecting anything.
        # the strike: an opaque 1 px image of the line over the row at
        # the line's height, painted for the row's width (no cairo "draw"
        # handler - the hosts have no pycairo, it never showed there; and
        # nothing transparent - an overlay child may get a window of its
        # own with an opaque background, and a row-sized image with a
        # transparent rest hid the whole row there, field 2026-10-10)
        row = Gtk.Overlay()
        row.add(row_box)
        self._strike = Gtk.Image()
        self._strike.set_halign(Gtk.Align.START)
        self._strike.set_valign(Gtk.Align.START)
        self._strike.set_no_show_all(True)
        row.add_overlay(self._strike)
        # its own GDK window takes no input: the row's clicks are the row's
        row.set_overlay_pass_through(self._strike, True)
        self._strike_size = None
        row.connect("size-allocate", self._on_row_allocate)
        self.widget = Gtk.EventBox()
        self.widget.add(row)
        self.widget.connect("button-press-event", self._on_row_click)
        self.widget.set_tooltip_text(tooltip)
        self._paint()

    def _speckle_swatch(self, width, height):
        """Layer-palette preview: the layer's ASSIGNED fill pattern
        tiled 1:1 in the layer color (default = the renderer's 1px
        speckle checker), inside a solid border. Hidden rows keep
        the same swatch - the row-wide strike from _draw_strike is
        the only hidden marker."""
        color = int(self._color.lstrip("#"), 16)
        rgb = ((color >> 16) & 255, (color >> 8) & 255, color & 255)
        rgb_bytes = bytes(rgb)
        rows = (self._fill_rows.split("\n")
                if self._fill_rows else None)
        pixels = bytearray(width * height * 3)
        for y in range(height):
            for x in range(width):
                border = x in (0, width - 1) or y in (0, height - 1)
                if not border:
                    if rows is not None:
                        r = rows[y % 16]
                        if x % 16 >= len(r) or r[x % 16] != "*":
                            continue
                    elif (x + y) & 1:
                        continue
                off = (y * width + x) * 3
                pixels[off:off + 3] = rgb_bytes
        # (the strike line itself is drawn row-wide by _draw_strike)
        # Keep the immutable backing bytes with the row. Pixbuf normally
        # retains its own GLib reference, and this also makes that lifetime
        # explicit across older GTK3/PyGObject bundles.
        buf = GLib.Bytes.new(bytes(pixels))
        self._swatch_refs.append(buf)
        return GdkPixbuf.Pixbuf.new_from_bytes(
            buf, GdkPixbuf.Colorspace.RGB, False, 8,
            width, height, width * 3)

    def _paint(self):
        # a geometry pick marks the layer ID column (the number in
        # FRONT of the fill swatch) with an opaque yellow box behind
        # the digits (2026-08-29): Pango's background draws it under
        # the glyphs, so the row-selection blue underneath is covered
        # yet the id text stays readable in dark ink on top. Smaller
        # than the full-row selection (id column only), and on top of
        # it because the label paints after the row's CSS background.
        fg = "#d9f2ff" if self._selected else "#ffffff"
        # hidden = ONE bright line cairo-drawn edge to edge by
        # _draw_strike (no per-span pango strike: it vanished in
        # the margins/swatch gaps and doubled over a drawn line).
        # Text and swatch keep their full colors - the strike alone
        # marks the hidden state (dimmed text was too dark to read,
        # user call 2026-08-10)
        # the name uses the SAME monospace face as the number column:
        # the default proportional font drew thinner strokes that
        # antialiased to gray next to the bright digits (user report
        # 2026-08-13). The face and the size are the window's since
        # 0.12.477 (PANEL_CSS: the whole viewer has the rows' font) -
        # said here again they would be applied twice, and the rows
        # would be a step smaller than everything else
        self._mlbl.set_markup(
            '<span foreground="%s">%s</span>'
            % (fg, GLib.markup_escape_text(self._marker)))
        if self._picked:
            self._nlbl.set_markup(
                '<span foreground="%s" background="%s">%s</span>'
                % (LAYER_PICK_FG, LAYER_PICK_BG,
                   GLib.markup_escape_text(self._num)))
        else:
            self._nlbl.set_markup(
                '<span foreground="%s">%s</span>'
                % (fg, GLib.markup_escape_text(self._num)))
        self._lbl.set_markup(
            '<span foreground="%s">%s</span>'
            % (fg, GLib.markup_escape_text(
                self._name + (" [partial]" if self._partial else ""))))
        self._clbl.set_from_pixbuf(self._swatch_on)
        self._strike.set_visible(not self._active)
        self.widget.queue_draw()

    def _on_row_allocate(self, _widget, alloc):
        size = (alloc.width, alloc.height)
        if size != self._strike_size and size[0] > 0 and size[1] > 0:
            self._strike_size = size
            GLib.idle_add(self._paint_strike, size)

    def _paint_strike(self, size):
        """Hidden layer: one continuous bright line across the FULL
        row - text, swatch, margins and trailing space alike - an opaque
        row-wide, 1 px image at the line's height (nothing else of the
        row is covered). (The geometry-pick highlight is the yellow id
        box painted by the number label's Pango background - see _paint,
        2026-08-29 - not a row outline.)"""
        if size != self._strike_size:
            return False
        width, height = size
        y = max(0, (height - self._row_pad) // 2)
        if self._strike.get_margin_top() != y:
            self._strike.set_margin_top(y)
        self._strike.set_from_pixbuf(
            pixbuf_of(width, 1, bytes(LAYER_STRIKE_RGB) * width))
        return False

    def set_marker(self, marker):
        self._marker = marker
        self._paint()

    def set_picked(self, on):
        on = bool(on)
        if on == self._picked:
            return
        self._picked = on
        self._paint()   # yellow id box via the number-label markup

    def set_color(self, color):
        """Palette recolor: rebuild the swatch in place."""
        if color == self._color:
            return
        self._color = color
        self._swatch_on = self._speckle_swatch(*self._swatch_wh)
        self._paint()

    def set_fill(self, rows):
        """Fill assignment changed: retile the swatch (None =
        default speckle checker)."""
        if rows == self._fill_rows:
            return
        self._fill_rows = rows
        self._swatch_on = self._speckle_swatch(*self._swatch_wh)
        self._paint()

    def set_selected(self, on):
        on = bool(on)
        if on == self._selected:
            return
        self._selected = on
        context = self.widget.get_style_context()
        if on:
            context.add_class("floe-layer-selected")
        else:
            context.remove_class("floe-layer-selected")
        self._paint()

    def _on_marker_click(self, _w, event):
        if event.type == Gdk.EventType.BUTTON_PRESS and event.button == 3:
            self._on_select(self, event)
            return True
        if event.type != Gdk.EventType.BUTTON_PRESS or event.button != 1:
            return False
        if self._on_expand is None:
            self._on_select(self, event)
            return True
        self._on_expand(self)
        return True

    def _on_row_click(self, _w, event):
        if event.type != Gdk.EventType.BUTTON_PRESS or \
                event.button not in (1, 3):
            return False
        self._on_select(self, event)
        return True

    def _on_name_click(self, _w, event):
        if event.button == 3 and event.type == Gdk.EventType.BUTTON_PRESS:
            self._on_select(self, event)
            return True
        if event.button != 1:
            return False
        if event.type in (Gdk.EventType.BUTTON_PRESS,
                          Gdk.EventType._2BUTTON_PRESS,
                          Gdk.EventType._3BUTTON_PRESS):
            self._on_select(self, event)
            # GTK turns the 4th rapid click into a TRIPLE press, so
            # back-to-back double-clicks arrive as 2BP then 3BP -
            # only honoring 2BP silently swallowed every second
            # toggle (field report; it looked render-related but is
            # pure event classification)
            if event.type in (Gdk.EventType._2BUTTON_PRESS,
                              Gdk.EventType._3BUTTON_PRESS):
                self.set_active(not self._active)
            return True
        return False

    def get_active(self):
        return self._active

    def set_group_state(self, on, partial=False):
        """Reflect child state without firing a parent toggle."""
        self._active = bool(on)
        self._partial = bool(partial)
        self._paint()

    def set_active(self, on):
        on = bool(on)
        if on == self._active:
            return
        self._active = on
        self._paint()
        self._on_toggle(self, self.key)


class Viewer:
    # the file loads are on unless the start says otherwise (__init__)
    _file_load = True
    # (a viewer made without __init__ - the gates' - has the rest too)
    _load_items = ()
    _reviewer = None
    # what a launch said its user does in the waive workflow (floe2 view
    # --role: "requester", "waiver", "confirmer", or several of them with
    # commas; "" - a reviewer as before the roles): what the DRC opens that
    # follow are opened as
    _role = ""
    _drc_waives_win = None
    # the error detail's lines of the team's review (_drc_team_lines): the
    # ask not answered yet, the last answer's lines, the poll's timer, the
    # error the detail shows
    _drc_team_pending = None
    _drc_team_row = None
    _drc_team_shown = None
    _drc_team_timer = None
    _drc_team_quiet = False
    _drc_detail_of = None
    # this reviewer's waives a confirmer rejected (0.12.468), and what the
    # confirmers confirmed: the service is asked every RETURNED_MS to follow
    # them (_drc_returned_tick) - the waives stay, shown as rejected -, and
    # its answer polled (_drc_returned_poll)
    RETURNED_MS = 2000
    _drc_returned_timer = None
    _drc_returned_asked = None
    # a verdict asked from a right-click menu (_drc_verdict): the service's
    # job, until its answer
    _drc_verdict_job = None
    # what a verdict said, kept for the end of the selection's recheck that
    # follows it (the errors it took may have left the filter's list): the
    # status line is the verdict's, not the recheck's count
    _drc_selection_after = None
    _drc_source = None
    _drc_reviewer = None
    _title_drc = ""
    _request_waiting = None
    _request_timer = None
    # the instance socket's watch in the main loop (its GLib source id)
    _server_watch = None
    # the layer properties file a launch named (floe2 view --layerprops)
    _props_bound = None
    _props_next = None
    _props_note = None

    def __init__(self, cache, server_sock=None, show=True, goto=None,
                 detail=None, dump=False, depth=None, lod=DEFAULT_LOD,
                 frames=DEFAULT_FRAMES, labels=DEFAULT_LABELS,
                 label_font_px=DEFAULT_LABEL_FONT_PX,
                 frame_cache=True, margin=False,
                 stream_kb=None, stream_target_ms=500,
                 render_debug=False, thin="auto", density=None,
                 occupancy=None, file_load=True, layerprops=None,
                 role="", maximized=False, debug=False):
        # the garbage collector runs on this thread from here on, by the
        # poll (_MainThreadGc): let go at the quit, or with the window
        _MainThreadGc.hold()
        self._gc_held = True
        self.server_sock = server_sock
        # `floe2 view --debug` (user 2026-11-15: "--debug 옵션 추가해서 ...
        # 숨기고 --debug 옵션에서만 나오게"): the renderer's switches and its
        # reports are a developer's - View > thin shapes at wide views,
        # density under the cut and occupancy summary at wide views, the
        # `v` / `o` toggles, the perf line of the status area and the depth
        # label's thin / density / occupancy parts are there with the option
        # alone (_debug_show, _depth_label, _set_status, _toggle_density,
        # _toggle_occupancy), and so is the perf line printed to the
        # terminal for every settled frame (_ctl_frame; 0.12.481, the same
        # day: "터미널의 perf 줄도 --debug 옵션에서만 나오게 수정해줘").
        # --thin, --density and --occupancy set the start either way: a
        # command line's own choice is no toggle
        self._debug = bool(debug)
        # `floe2 view --role` (user 2026-11-14: "error -> waive request ->
        # waive -> confirm ... role은 requester, waiver, confirmer로
        # 나누어야 함"; "--role waiver,confirmer나 --role
        # requester,waiver,confirmer가 가능하게"): the results are opened as
        # a session of that role, or of those
        self._role = role or ""
        # False (`floe2 view --no-file-load`, user 2026-11-11: a launcher
        # that starts everyone's viewer under one account must not let a
        # user open whatever that account can read): the viewer shows what
        # its command line named and loads no file picked here - the load
        # commands are insensitive in the menus and refuse (_load_refused)
        self._file_load = bool(file_load)
        self._load_items = []       # the menus' load commands (_build_menubar)
        # the reviewer a forwarded launch stated (its --userid /
        # FLOE_REVIEWER): the id the DRC opens that follow ask the service
        # for; None = the service's own - this process' FLOE_REVIEWER, else
        # where it runs
        self._reviewer = None
        self._drc_source = None     # the results file the open db was asked by
        self._drc_reviewer = None   # the reviewer that open asked for
        self._title_drc = ""        # the title's part while results are loaded
        # a forwarded request held back until the window is free of a
        # dialog and of a review write (_request_hold)
        self._request_waiting = None
        self._request_timer = None
        # the layer properties file a launch names for its layout (`floe2
        # view SRC --layerprops FILE`, user 2026-11-11: "layer property
        # 파일도 실행 옵션으로 지정할 수 있게"): _props_next while that layout
        # is being opened, _props_bound once it is - the file is put on the
        # layer table whenever that layout's table is built
        # (_props_bound_apply) -, _props_note what to say of it once the
        # view is up
        self._props_bound = None
        self._props_next = (os.path.realpath(layerprops)
                            if layerprops and cache is not None else None)
        self._props_note = None
        self.cx = self.cy = 0
        self.spp = 1.0              # dbu per screen pixel
        self._start_goto = goto     # [x_um, y_um(, window_um)] from the CLI
        self.visible = set()
        self.last_frame = None      # (pixbuf, bbox, dbu_per_px, key)
        self._frame_anchor = None   # view center the frame was shown at
        # §F2R-21: the last landed margin (label-free geometry) as a
        # display base for the strip a pan uncovers before the fresh
        # frame lands; (pixbuf, bbox, dbu_per_px, key) like last_frame
        self._margin_frame = None
        self._drag = None
        self._drag_origin = None
        self._drag_moved = False
        self._drag_btn = None       # button that started the pan
        self._zoomdrag = None       # rubber-band anchor (view px)
        self._band_cur = None
        self._band_ext = None       # (min x, max x) of the band drag
        self._did_fit = False
        # a window that starts maximized (`maximized`, run_viewer's) is
        # allocated at its default size first and gets the screen's a
        # moment later where a window manager maps it: the view the start's
        # fit made is kept here, and while the view is still that one a new
        # size is fitted again (_start_fit_follows)
        self._start_maximized = bool(maximized)
        self._start_fit = None
        # what makes the start's view again at a new size, where it is not
        # the fit: a launch's goto, the error a launch jumps to
        # (_start_view_follow); None: the fit
        self._start_again = None
        self.worker = None
        self._worker_starting = False
        # A layout switch after the window is allocated needs a fit once the
        # replacement worker opens.  Initial CLI --goto does not: allocation
        # has already applied that exact view, and a late async open callback
        # must never overwrite it with fit-to-die.
        self._fit_after_worker_start = False
        self._layer_rows = {}
        self._selected_layers = set()
        self._layer_select_anchor = None
        self._pick_expanded = None  # group auto-expanded for a pick
        self._frontier_depths = []  # baked minimap frontier (meta)
        self._minimap_bases = {}    # depth -> rendered base pixbuf
        self._layer_order = []
        self._layer_menu = None
        # start depth: a plain open shows hierarchy level 1 (fast first
        # paint on huge chips - the industry default), a --goto jump is
        # an inspection: full depth unless --depth says otherwise.
        # 999 = full; runtime digits/`d` dialog change it as before.
        # Open default is depth 0 (top geometry + outlines): the fastest
        # truthful first view on any chip.
        if depth is None:
            depth = 999 if goto is not None else 0
        self.depth_value = max(0, min(999, int(depth)))
        # Explicit request controls; no shell environment is consulted.
        # retired (2026-09-22): the `lod` argument is accepted and ignored
        self.lod_on = False
        # the page hairline policy (review 2026-09-11): "auto" = keep
        # for every source (2026-09-23 user decision: a plain layout
        # too; it was cull); "keep" / "cull" explicit
        # (View > keep thin shapes, --thin, a forwarded thin=)
        self.thin_mode = thin if thin in ("auto", "keep", "cull") else "auto"
        # the density under the cut (renderd's density stack, user
        # 2026-10-05: "a density on/off option in the viewer"): View >
        # density under the cut / `v` switch it live, --density (or a
        # forwarded density=) sets it; unset it starts on (user 2026-10-12:
        # "turn the density on by default"; floe2 render's start, app-core
        # shots::density_default) - FLOE_RUST_DENSITY_STACK=off, in the
        # environment the viewer shares with renderd, is the kill switch
        self.density_on = (os.environ.get("FLOE_RUST_DENSITY_STACK") != "off"
                           if density is None else bool(density))
        # the occupancy summary at wide views (user 2026-10-20: "an option
        # to see the occupancy when a jobdeck-indexed layout is opened in
        # the plain layout mode"): None = renderd's rule (a jobdeck's passes
        # draw it, a plain layout's frames do not - user decision
        # 2026-09-24), a bool the user's choice - View > occupancy summary
        # at wide views / `o` switch it live, --occupancy (or a forwarded
        # occupancy=) sets it; the rule reads the same FLOE_RUST_OCCUPANCY
        # the renderer does (_occupancy_effective)
        self.occupancy_on = None if occupancy is None else bool(occupancy)
        # the scale border starts on (user 2026-10-13); View > scale
        # border / `s` toggles it, FLOE_SCALE_BORDER=off starts it off
        self.border_on = os.environ.get("FLOE_SCALE_BORDER") != "off"
        self._border = None         # (the view's key, the service's border)
        self._border_shown = None   # the border drawn on the frame shown
        self._border_labels = None  # its chips: corners and the length
        self.frames_on = bool(frames)
        # Frame is the normal UI control for both hierarchy outlines and
        # texts. An explicit --labels off remains available as a startup/
        # automation override, but frames off always suppresses texts.
        self.labels_on = self.frames_on and bool(labels)
        self.label_font_px = max(
            MIN_LABEL_FONT_PX,
            min(MAX_LABEL_FONT_PX, int(label_font_px)))
        # Exact settled-frame reuse is a Rust optimization.  Stable floe
        # accepts the same control so A/B command lines remain identical.
        self.frame_cache_on = bool(frame_cache)
        # --margin (default off, user decision 2026-09-27): the background
        # margin prefetch alone; pan reuse stays either way. Off, every pan
        # and zoom renders a viewport frame and nothing lands after it.
        self.margin_on = bool(margin)
        # the Python render loop's adapter options (--stream-kb,
        # --stream-target-ms, --render-debug): accepted for the command
        # line, unused since the view controller draws (P4f)
        self.stream_kb = stream_kb
        self.stream_target_ms = int(stream_target_ms)
        self.render_debug = bool(render_debug)
        self._depth_used = "?"      # depth of the last frame ("?" = none yet)
        self.max_depth = None        # learned from the VFS daemon
        # DETAIL level: 0=low, 1=medium, 2=high. Users only ever see
        # the name; the screen-px threshold behind each (DETAIL_PX) is
        # an implementation detail that may be retuned without changing
        # what "medium" means. --detail sets the start value, the `d`
        # dialog changes it at runtime. Higher detail = smaller cut.
        self.detail = (DEFAULT_DETAIL if detail is None else
                       max(0, min(len(DETAIL_PX) - 1, int(detail))))
        self.cut_px = DETAIL_PX[self.detail]
        # a cut of the user's own, screen px (the `d` dialog's entry, user
        # 2026-10-28: a jobdeck's near views tried down to 0.1 px): in place
        # of the level's until a level is chosen again; None = the level's
        self.cut_custom = None
        # live-render span budget, scaled to the cache's tile size
        # (finer --tile-mb grids allow proportionally more tiles);
        # the real value lands in _apply_cache (cache may be None -
        # empty start, user call 2026-08-22)
        self.dump = bool(dump)      # --dump: save debug frame dumps
        self._quitting = False
        # folder floe was launched from: the load-layout dialog's
        # initial base (user call 2026-08-22) - GTK would otherwise
        # open at Recent/Home on an empty start
        self._launch_dir = os.getcwd()
        # ruler / snap / pick state
        self.mode = "normal"
        self.rulers = []
        self._ruler_start = None
        self._ruler_free = False
        self._auto_rulers = []
        self._drc_ruler = []        # auto CD ruler of the current jump
        self.snap_on = True
        self._snap_seq = 0
        self._snap_res = None
        self._snap_sent = 0.0
        self.selection = None
        self._sel_text = ""
        self._pick_seq = 0
        self._pick_px = None
        self._pick_nth = 0
        self._pick_mode = "replace"
        # cell tree (SPEC-VIEWER §8c): the panel's widgets, the queries
        # in flight (seq -> (what, row reference, src)), the sources of
        # the open cache/deck, the selected cell (src, ci, name), the
        # highlight (its instance boxes in the view) and the view key it
        # was asked for, the sources whose hierarchy index was found
        # missing (asked about once per load)
        self._cellwin = None
        self._cell_seq = 0
        self._cell_pending = {}
        self._cell_sources = None
        self._cell_sel = None
        self._cell_hl = None
        # the instances of the selected cell are not highlighted until the
        # switch is turned on (user 2026-11-15: "cell highlight instances
        # 디폴트값을 off로 해줘"; on from the cell tree's start, 2026-09-29,
        # until 0.12.491)
        self._cell_hl_on = False
        self._cell_hl_key = None
        self._cell_find_seq = None
        self._cell_insts_seq = None
        self._cell_info_seq = None
        # the selected cell's status line (user 2026-10-15): its facts as
        # the service words them (cell_info) and its instances in the view
        # (the highlight's) - kept beside the cursor's coordinates
        self._cell_sel_text = ""
        self._cell_view_text = ""
        self._cell_search_timer = None
        self._cell_mode = "tree"
        self._cell_nohier = set()
        # the view root (SPEC-VIEWER §8c): None = the top cell; else
        # {"cell", "name", "bbox" (its recursive bbox, its coordinates),
        # "height"} - every render, clip and cell query starts there
        self._view_root = None
        self._title_base = "%s - no layout" % APP
        self._cursor = (0, 0)
        self._pending = None
        self._pending_t0 = 0.0
        self._pending_timer = None
        self._color_epoch = 0       # bumped per palette recolor/refill
        # fill pattern palette: 20 slots (Calibre names), editable
        # 16x16 bitmaps; (l, d) -> slot assignments
        self._fill_patterns = fillpat.default_patterns()
        self._layer_patterns = {}
        self._layer_widths = {}     # (l, d) -> outline px (기본 1)
        self._fill_slots = []
        self._ddlg = None
        self._gdlg = None
        self._cdlg = None
        self._fontdlg = None
        self._sdlg = None           # the CD group step's modal
        self._drc_reason_last = {}  # kind -> the review reason typed last
        self._svrfdlg = None        # the SVRF info window (i)
        self._drc_detail_at = None  # (rule, error or None) the detail pane shows
        self._digit_last = None     # depth digit-pair state ('99' = full)
        self._digit_t = 0.0
        # DRC results browser ('e' key)
        self._drc = None            # drc.DrcDb or drc.IcePack
        self._drcwin = None
        self.drc_mark = None        # {"kind": 'p'|'e', "pts": [(dbu)]}
        # scale right after the last error jump: a zoom the user makes
        # while viewing errors sticks across n/p and clicks (2026-09-08)
        self._drc_jump_spp = None
        self._drc_zoom_lock = False  # a user zoom is being kept this session
        self._drc_hits = []         # frame's painted markers:
                                    # (px, py, ci, ei) for hover/pick
        self._drc_point_hits = None # pixel hit map, never an error list
        self._drc_tip = None        # last tooltip text set
        # the marker under the pointer, drawn DRC_HOVER_PX by a widget over
        # the canvas (0.12.526): (ci, ei, its box on the canvas, colour)
        # shown, the widget (made at the first), its circles by colour, and
        # the pointer over the canvas in canvas px (None out of it)
        self._drc_hover = None
        self._drc_hover_img = None
        self._drc_hover_sprites = {}
        self._pointer = None
        self.overlay_mode = 0       # Tab cycles (user call
        # 2026-08-21): 0 = everything shown, 1 = OTHER errors
        # hidden (jumped error + rulers stay), 2 = all overlays
        # hidden (the old flateyes-parity clean look)
        # prev/next walk by ARITHMETIC over cumulative counts, never
        # a materialized per-error list: a pack can hold
        # hundreds of millions of violations
        self._drc_cum = []          # check idx -> first flat position
        self._drc_total = 0
        self._drc_pos = -1
        self._drc_open = None       # the one open (selected) rule
        self._drc_clusters = None   # optional user-authored cluster sidecar
        self._drc_cluster = None    # selected child; None = entire rule
        self._drc_grid_ci = None    # rule the number grid shows
        self._drc_grid_rows = 0
        self._drc_cell = None       # marked grid cell (row, col)
        self._drc_gridw = DRC_GRID_W   # columns, reflowed to pane
        self._drc_cellw = 60        # px per number cell (probe)
        self._drc_page = 0          # error-grid page of the rule
        self._drc_rules_busy = False   # rebuilding the rules list
        self._drc_page_marks = []   # this grid page's (ci, ei,
                                    # kind, pts dbu) for the canvas
        self._drc_grid_base = None  # filtered ei base (None = all)
        self._drc_wfilter = "notwaived"   # all | notwaived | waived
        self._drc_search = ""       # rule-name substring filter
        self._drc_only = None       # the one rule listed (--drc-rule)
        self._drc_rmeta = None      # <deck>.rules.json dict (the
                                    # `floe-index svrf` sidecar metadata)
        self._drc_rmatch = (0, 0)   # sidecar-matched / db rules
        self._drc_tfilter = "all"   # rule-type filter (svrf metric)
        self._drc_rtypes = None     # rule name -> metric frozenset
        self._drc_tf_busy = False   # rebuilding the type combo
        self._drc_lyr_saved = None  # visibility snapshot before a
                                    # double-click layer isolation
        self._drc_show_sel = False  # 'selected' list filter
        self._drc_sel = None        # (ci, immutable Selection, (), Selection)
        self._drc_selection_worker = None
        self._drc_selection_key = None
        self._drc_review_job = None
        self._drc_sels = {}         # (ci, cluster) -> selection
        self._esel_start = None     # pending first box corner (dbu)
        self._drc_grid_map = []     # the grid PAGE's ei list
        self._drc_focus = None      # single-clicked error (ci, ei,
                                    # kind, pts dbu) - emphasized in
                                    # place, no zoom change
        self._drc_hl = False        # highlight-in-view toggle (v2)
        self._mono = False          # grayscale layers (b key)
        self._mono_saved = False    # mono state before highlight
        self._drc_hl_res = None     # (view key, [(kind, pts dbu)])
        self._drc_marker_worker = None
        # the review flags and the team's shared review (feature/jobdeck-
        # drc 2026-10-09..11; floe2 gtk-service drc_team.rs)
        self._drc_review_read_error = None
        self._drc_team = None
        self._drc_migration = None
        self._drc_team_write = None
        self._drc_team_busy = None
        self._drc_conflict_only = False
        self._drc_conflict_source = None
        self._drc_conflict_members = None
        self._drc_conflict_key = None
        self._drc_conflict_job = None
        self._drc_conflict_retired = []
        self._drc_conflict_revision = 0
        self._drc_conflict_stamp = ""
        self._drc_marker_revision = 0
        self._drc_marker_key = None
        self._drc_marker_result = None
        self._drc_marker_overlay = None
        self._drc_marker_busy = False
        self._drc_marker_said = None  # the job whose partial picture the status line told
        self._drc_query_worker = None
        self._drc_hl_key = None
        self._drc_delta_worker = None
        self._drc_delta_key = None
        self._drc_delta_groups = None
        self._drc_group_counts = {}  # (rule, basis, requested step) -> count/unknown
        self._drc_group_cache_worker = None
        self._drc_group_cache_key = None
        self._drc_delta_group = None
        self._drc_delta_busy = False
        self._drc_delta_ui_busy = False
        self._drc_delta_revision = 0
        self._drc_delta_mode = DRC_DELTA_DEFAULT
        self._drc_delta_step = None  # resolved interval; None while automatic is pending
        self._drc_delta_steps = {}   # (rule index, mode) -> manual interval in ticks
        self._drc_delta_auto_steps = {}  # whole-rule automatic intervals
        self._drc_delta_step_scope = None
        self._drc_delta_step_text = "auto"
        self._drc_delta_page = 0    # group pages are separate from error pages
        self._drc_delta_error = None
        self._drc_delta_soft = None  # the key of reason groups asked again behind the list shown
        self._drc_delta_since = 0.0  # when the grouping in the making was asked
        self._drc_delta_said = False  # ... and whether the status line told of it
        self._labels = []           # Gtk.Label pool for ruler distances
        self._note_panel = None     # top-left translucent DRC note panel

        self.window = Gtk.Window(title=APP)
        self.window.set_default_size(1280, 860)
        self.window.connect("delete-event", lambda *_: self._quit())
        self.window.connect("destroy", lambda *_: self._gc_release())
        self.window.connect("key-press-event", self._on_key)

        # window > outer(V) > [paned(H): view | panel] + status rows.
        # The status/info rows sit OUTSIDE the paned, spanning the
        # full window width - the panel can no longer run over them
        # (field report) - and the paned handle between the view and
        # the panel drags the panel width.
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.window.add(outer)
        outer.pack_start(self._build_menubar(), False, False, 0)
        # [left pane (future cell/object lists, minimap at the
        # bottom) | [canvas | layer panel]] - user call 2026-08-10
        lpaned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        for pn in (lpaned, paned):
            try:
                pn.set_wide_handle(True)
            except AttributeError:
                pass
        outer.pack_start(lpaned, True, True, 0)
        self._outer = outer
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                       spacing=2)
        left.set_size_request(MINIMAP_PX + 16, -1)
        # placeholder container: the Calibre-style cell/object
        # browser lands here later; the DRC browser lives here
        # permanently (user call 2026-08-13)
        self._left_stack = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL)
        # the cell tree and the DRC browser share the pane as two pages
        # (2026-09-29, SPEC-VIEWER §8c): the tree opens by default, a
        # DRC db load or 'e' raises the DRC page, 't' the tree
        nb = Gtk.Notebook()
        nb.append_page(self._build_cell_panel(), Gtk.Label(label="cells"))
        nb.append_page(self._build_drc_panel(), Gtk.Label(label="DRC"))
        self._left_nb = nb
        self._left_stack.pack_start(nb, True, True, 0)
        left.pack_start(self._left_stack, True, True, 0)
        self._left_pane = left
        self._lpaned = lpaned
        # shrink=True: without it the paned handle floors at the
        # left content's NATURAL minimum (the DRC nav row alone is
        # ~450px) and the pane cannot be dragged small (field
        # report 2026-08-18) - shrinking simply clips the content
        lpaned.pack1(left, resize=False, shrink=True)
        lpaned.pack2(paned, resize=True, shrink=True)
        # the cell tree is the pane's default page (2026-09-29): it starts
        # at LEFT_PANE_PX so cell names and counts read at once (the
        # old 196 px floor was the minimap's, which moved right); the
        # pane still shrinks to the pages' minimum
        lpaned.set_position(LEFT_PANE_PX)

        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        side.set_size_request(210, -1)
        # breathing room against the window edge: without it the
        # layer scrollbar and the palette's last column sit flush
        # on the app border (user call 2026-08-11)
        side.set_margin_end(6)
        paned.pack2(side, resize=False, shrink=False)
        # it starts LAYER_PANE_PX wide (user 2026-11-16; until 0.12.504 at
        # the 210 px above, which stay its floor)
        _start_size_after(paned, side, LAYER_PANE_PX)
        self._layer_pane = side
        # the pane-top "floe" title and the size·grid line moved
        # into the WINDOW TITLE (user call 2026-08-22) - the pane
        # starts straight at the toggle row

        trow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        side.pack_start(trow, False, False, 4)
        for text, cb in (("expand all", self._expand_all),
                         ("collapse all", self._collapse_all)):
            b = Gtk.Button(label=text)
            b.connect("clicked", lambda _w, f=cb: f())
            trow.pack_start(b, True, True, 0)

        # the layer search, above the list (user 2026-11-15: "레이어 목록에서
        # 레이어 검색창을 목록 상단에 추가해줘"): the rows whose number or
        # name holds the text are the list while the box has one
        # (_on_layer_search), as `find rule…` and `find cell…` do it for
        # their lists
        try:
            lse = Gtk.SearchEntry()
            lse.connect("search-changed", self._on_layer_search)
        except AttributeError:
            lse = Gtk.Entry()
            lse.connect("changed", self._on_layer_search)
        lse.set_placeholder_text("find layer…")
        lse.set_width_chars(8)   # keep the pane's width floor small
        self._layer_search_entry = lse
        side.pack_start(lse, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        # Calibre-style layer panel: black background, white text.
        # FIELD BUG (mac/retina): the universal `.floe-layers *`
        # background MUST NOT include the ScrolledWindow's own
        # subtree - on the quartz backend that background renders
        # with a broken clip band that overpaints the rows (a
        # shrinking strip that tracks the scroll; full invalidation
        # cannot repair it because every redraw repeats the same
        # mis-clip). Pixel-gated bisect: class on the scroller =
        # broken, class only on the rows box = clean. Hence three
        # scoped hooks: `.floe-layers` for the rows box subtree,
        # `.floe-layers-bg` DIRECTLY on the viewport (panel area
        # below the rows stays black), `.floe-layers-frame` on the
        # scroller solely for the scrollbar selectors.
        css = Gtk.CssProvider()
        css.load_from_data(PANEL_CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), css,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        scroller.get_style_context().add_class("floe-layers-frame")
        # GTK overlay/automatic scrollbars can reserve their gutter only while
        # scrolling (notably with the macOS GTK theme). That changes both the
        # width and height of the viewport and clips the edge rows. Keep both
        # gutters allocated for the lifetime of the palette.
        try:
            scroller.set_overlay_scrolling(False)
        except AttributeError:
            pass  # compatibility with older GTK3 builds
        try:
            scroller.set_propagate_natural_width(False)
        except AttributeError:
            pass
        scroller.set_policy(Gtk.PolicyType.ALWAYS,
                            Gtk.PolicyType.ALWAYS)
        _remote_x_scroll_repaint(scroller)
        self._layers_scroller = scroller
        self._layers_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self._layers_box.set_margin_top(4)
        self._layers_box.set_margin_bottom(4)
        # NATURAL height, never viewport-fill (field bug): a filled
        # box keeps the tall allocation it got while the window was
        # large; shrink the window into scrollable territory at the
        # wrong moment and the adjustment upper stays at that stale
        # height - a phantom scroll range of empty box. Scrolling
        # then walks the rows out of view with dead black above and
        # below (rows live only at the top of the oversized box).
        # START-aligned, the box is always exactly as tall as its
        # rows and the phantom range cannot exist.
        self._layers_box.set_valign(Gtk.Align.START)
        self._layers_box.get_style_context().add_class("floe-layers")
        scroller.add(self._layers_box)
        # implicit viewport: the black panel background, styled
        # DIRECTLY (never via a `*` selector - see the CSS note)
        scroller.get_child().get_style_context().add_class(
            "floe-layers-bg")
        side.pack_start(scroller, True, True, 4)

        # Range watchdog for the same field bug: the adjustment
        # upper legitimately equals max(content, viewport) - but a
        # missed viewport re-allocate during an interactive window
        # shrink leaves upper at the OLD viewport height while the
        # page has already shrunk. That phantom range scrolls the
        # rows out of a mostly-empty box: the panel shows a
        # shrinking band with dead black above and below. Re-clamp
        # whenever the geometry or the scroll position changes;
        # when GTK got it right this is a no-op.
        def _clamp_palette_range(*_a):
            adj = scroller.get_vadjustment()
            # GTK3 folds widget margins into preferred sizes
            nat = self._layers_box.get_preferred_height()[1]
            want = max(nat, adj.get_page_size())
            if adj.get_upper() > want + 2:
                adj.set_upper(want)
                adj.set_value(max(0.0, min(
                    adj.get_value(),
                    want - adj.get_page_size())))

        scroller.connect("size-allocate", _clamp_palette_range)
        scroller.get_vadjustment().connect(
            "value-changed", _clamp_palette_range)
        _panel_debug_hook(scroller, self._layers_box,
                          lambda: list(self._layer_rows.values()))

        # Overview minimap: lives in the RIGHT pane notebook since
        # 2026-08-22 (user call - the left pane keeps its full
        # height for the DRC browser); tabbed with the palettes
        # below, minimap tab shown by default.
        self._minimap_image = Gtk.Image()
        self._minimap_image.set_size_request(MINIMAP_PX, MINIMAP_PX)
        self._minimap_image.set_halign(Gtk.Align.CENTER)
        self._minimap_image.set_valign(Gtk.Align.CENTER)
        self._minimap_event = Gtk.EventBox()
        self._minimap_event.set_size_request(MINIMAP_PX, MINIMAP_PX)
        self._minimap_event.set_halign(Gtk.Align.CENTER)
        # keep the box at its natural square inside the notebook
        # page too - without a vertical alignment it stretches to
        # the tallest page and the centered image drifts off the
        # click coordinates (belt: the handler also translates)
        self._minimap_event.set_valign(Gtk.Align.CENTER)
        self._minimap_event.add(self._minimap_image)
        self._minimap_event.connect(
            "button-press-event", self._on_minimap_click)
        self._minimap_event.set_tooltip_text(
            "Click inside the die to center the viewport")

        # layer color palette (user call 2026-08-10): click a layer
        # row to select it, then a swatch here to recolor. Personal
        # overrides persist under ~/.cache/floe; meta.json untouched.
        pal = Gtk.Grid()
        pal.set_row_spacing(2)
        pal.set_column_spacing(2)
        # homogeneous + hexpand: the 7 swatch columns share the
        # panel width, so resizing the pane resizes the swatches
        pal.set_column_homogeneous(True)
        pal.set_hexpand(True)
        pal_cells = []   # (swatch DrawingArea, color) for the pick
        for i, (col, cname) in enumerate(PALETTE_COLORS):
            rgb = tuple(int(col[j:j + 2], 16) for j in (1, 3, 5))

            # the colour inside a grey outline (reads on black too)
            cell = PixbufCell(
                lambda w, h, rgb=bytes(rgb): outlined_pixbuf(
                    w, h, lambda _y, n: rgb * n), 12, 14)
            da = cell.widget
            da.set_hexpand(True)
            da.set_tooltip_text(
                "%s (%s) - recolor the selected layer(s)"
                % (cname, col))
            pal.attach(da, i % 7, i // 7, 1, 1)
            pal_cells.append((da, col))
        # ONE event box per palette grid, swatch resolved by
        # coordinates (2026-08-22; see _palette_grid_pick - the
        # "dead clicks" were no-layer-selected in the end, this
        # structure stays as a simplification)
        pal_eb = Gtk.EventBox()
        pal_eb.add(pal)
        pal_eb.connect(
            "button-press-event",
            lambda w, ev: self._palette_grid_pick(
                w, ev, pal_cells,
                lambda c, _e: self._apply_palette_color(c)))
        # color + fill palettes share ONE notebook tab; the minimap
        # is the other (and default) tab - built after patg below
        palbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                         spacing=2)
        palbox.pack_start(pal_eb, False, False, 4)

        # fill pattern palette (user call 2026-08-11): 20 Calibre
        # fills, 5x4. Left click assigns to the selected layer(s);
        # right click edits the bitmap (Solid/Clear are fixed).
        patg = Gtk.Grid()
        patg.set_row_spacing(2)
        patg.set_column_spacing(2)
        patg.set_column_homogeneous(True)
        patg.set_hexpand(True)
        patg_cells = []   # (slot DrawingArea, index) for the pick
        for i, fname in enumerate(fillpat.FILL_NAMES):

            def _paint_slot(width, height, i=i):
                # white paper, black dots (user call 2026-08-11): the
                # 16x16 bitmap tiled 1:1 across the box (no stretching)
                rows = self._fill_patterns[i].split("\n")
                return outlined_pixbuf(
                    width, height, lambda y, n: tiled_row(rows[y % 16], n))

            cell = PixbufCell(_paint_slot, 12, 20)
            da = cell.widget
            da.set_hexpand(True)
            self._fill_slots.append(cell)
            da.set_tooltip_text(
                "%s - click: fill selected layer(s)" % fname)
            patg.attach(da, i % 5, i // 5, 1, 1)
            patg_cells.append((da, i))
        patg_eb = Gtk.EventBox()
        patg_eb.add(patg)
        patg_eb.connect(
            "button-press-event",
            lambda w, ev: self._palette_grid_pick(
                w, ev, patg_cells,
                lambda slot, e: self._on_fill_slot_click(slot, e)))
        palbox.pack_start(patg_eb, False, False, 4)
        # fit/clip buttons retired 2026-08-22: View > fit (Ctrl+A)
        # and File > clip region… own them now
        nb = Gtk.Notebook()
        nb.append_page(self._minimap_event,
                       Gtk.Label(label="minimap"))
        nb.append_page(palbox, Gtk.Label(label="palette"))
        side.pack_start(nb, False, False, 4)
        if os.environ.get("FLOE_CLICK_DEBUG"):
            # presses that bubbled past the grids (or never reached
            # them) surface here - FLOE_CLICK_DEBUG=1 run + one
            # click per target tells where the chain breaks
            nb.connect(
                "button-press-event",
                lambda _w, ev: bool(sys.stderr.write(
                    "[click] notebook-level press at (%.1f, %.1f)"
                    "\n" % (ev.x, ev.y))) and False)

        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        paned.pack1(main, resize=True, shrink=True)
        self.overlay = Gtk.Overlay()
        # the image lives in a ScrolledWindow so the window can shrink:
        # a bare Gtk.Image's minimum size is its pixbuf, and since we
        # render pixbufs at allocation size that would ratchet the window
        # ever larger. EXACTLY flateyes' proven containment - AUTOMATIC
        # policy, image directly in the scroller, events on the scroller.
        # The earlier EXTERNAL policy + EventBox variant laid out fine but
        # displayed BLACK on remote X11 (conda GTK bundle over SSH
        # forwarding) while flateyes on the same display worked; the
        # EventBox's own X window / EXTERNAL viewport stacking never
        # brought the drawn pixels to the screen there.
        self.scroller = Gtk.ScrolledWindow()
        self.scroller.set_policy(Gtk.PolicyType.AUTOMATIC,
                                 Gtk.PolicyType.AUTOMATIC)
        # the canvas is the keyboard home: key commands are handled on
        # the window, but a deterministic non-entry focus widget keeps
        # menus/dialogs from parking focus somewhere that swallows keys
        self.scroller.set_can_focus(True)
        self.image = Gtk.Image()
        self.image.set_halign(Gtk.Align.START)
        self.image.set_valign(Gtk.Align.START)
        self.scroller.add(self.image)
        self.overlay.add(self.scroller)
        # loading banner (user call 2026-09-15): centred over the
        # canvas while a deck loads or a jobdeck view switches; shown
        # and hidden by _loading_show / _loading_hide only
        self._loading = Gtk.Label(label="")
        self._loading.set_halign(Gtk.Align.CENTER)
        self._loading.set_valign(Gtk.Align.CENTER)
        self._loading.set_no_show_all(True)
        self._loading.get_style_context().add_class("floe-loading")
        self.overlay.add_overlay(self._loading)
        self.overlay.set_overlay_pass_through(self._loading, True)
        # the occupancy summary banner (DIRECT_READ_PLAN L6, user decision
        # section 10 4): over the top of the canvas while a frame's deck
        # passes wait for the summary of their light sources (the wide
        # view of those sources stays empty until it is built; near views
        # draw) - shown and hidden by _summary_banner_update
        self._summary_banner = Gtk.Label(label="")
        self._summary_banner.set_halign(Gtk.Align.CENTER)
        self._summary_banner.set_valign(Gtk.Align.START)
        self._summary_banner.set_margin_top(8)
        self._summary_banner.set_no_show_all(True)
        self._summary_banner.get_style_context().add_class("floe-loading")
        self.overlay.add_overlay(self._summary_banner)
        self.overlay.set_overlay_pass_through(self._summary_banner, True)
        self._summary_waiting = 0
        self._summary_poll_timer = None
        main.pack_start(self.overlay, True, True, 0)

        # Two-tier status area. Upper: cursor/interaction plus persistent
        # view/depth/cut/cov state. Lower: retained render/performance
        # plus live rendering/refinement progress. Mouse motion only
        # replaces the upper-left text, never the lower render details.
        sbars = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        livebar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        infobar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.status = Gtk.Label(label="")
        self.status.set_xalign(0.0)
        self.status.set_margin_start(8)
        # long texts (selection info with long cell names) must not widen
        # the window: ellipsize into the allocated width, full text in the
        # tooltip (same treatment as the layer panel labels)
        self.status.set_ellipsize(Pango.EllipsizeMode.END)
        self.status.set_max_width_chars(1)
        self.rstatus = Gtk.Label(label="")
        self.rstatus.set_margin_end(10)
        self.pstatus = Gtk.Label(label="")
        self.pstatus.set_xalign(0.0)
        self.pstatus.set_margin_start(8)
        self.pstatus.set_ellipsize(Pango.EllipsizeMode.END)
        self.pstatus.set_max_width_chars(1)
        self.dstatus = Gtk.Label(label="depth: full")
        self.dstatus.set_margin_end(14)
        self.vstatus = Gtk.Label(label="")
        self.vstatus.set_margin_end(14)
        livebar.pack_start(self.status, True, True, 0)
        livebar.pack_end(self.dstatus, False, False, 0)
        livebar.pack_end(self.vstatus, False, False, 0)
        infobar.pack_start(self.pstatus, True, True, 0)
        infobar.pack_end(self.rstatus, False, False, 0)
        # a row of the status area keeps its height whatever its labels
        # say: in the viewer's font an empty label is a pixel lower than
        # one with text (seen on macOS, 0.12.477: 12 px against 13; text
        # of a fallback font differs too), and the row that grew when the
        # perf line got its first text took that pixel from the canvas -
        # one more allocation and one more render at every start, and at
        # every later change between a line with text and one without
        row_height = _ui_glyph_size()[1]
        livebar.set_size_request(-1, row_height)
        infobar.set_size_request(-1, row_height)
        sbars.pack_start(livebar, False, False, 0)
        sbars.pack_start(infobar, False, False, 0)
        # full-width status strip UNDER both the view and the panel
        outer.pack_start(sbars, False, False, 2)

        self.scroller.add_events(
            Gdk.EventMask.BUTTON_PRESS_MASK |
            Gdk.EventMask.BUTTON_RELEASE_MASK |
            Gdk.EventMask.POINTER_MOTION_MASK |
            Gdk.EventMask.LEAVE_NOTIFY_MASK |
            Gdk.EventMask.SCROLL_MASK | Gdk.EventMask.SMOOTH_SCROLL_MASK)
        self.scroller.connect("button-press-event", self._on_press)
        self.scroller.connect("button-release-event", self._on_release)
        self.scroller.connect("motion-notify-event", self._on_motion)
        self.scroller.connect("leave-notify-event", self._on_canvas_leave)
        self.scroller.connect("scroll-event", self._on_scroll)
        # a modal dialog (or a broken pointer grab) swallows the button
        # release: without these, _drag survives forever and freezes
        # wheel zoom + render submission until the next canvas click
        self.scroller.connect("grab-broken-event",
                              lambda *_a: self._end_gesture())
        self.window.connect("focus-out-event",
                            lambda *_a: self._end_gesture() or False)
        self._alloc_size = None
        self.scroller.connect("size-allocate", self._on_allocate)
        self.scroller.connect("realize",
                              lambda w: self._set_cursor(self._idle_cursor()))

        if server_sock is not None:
            # (kept: the watch goes with its socket - _quit)
            self._server_watch = GLib.io_add_watch(
                server_sock.fileno(), GLib.IO_IN, self._on_incoming)
        GLib.timeout_add(POLL_MS, self._poll)

        # the load clock (see _load_note): from here to the first frame
        self._load_marks = {"t0": time.monotonic()} if cache is not None else None
        self._apply_cache(cache)
        if self._start_maximized:
            self._maximize_at_start()
        if show:
            self.window.show_all()

    def _maximize_at_start(self):
        """The viewer starts with its window at the screen's size (user
        2026-11-15: "뷰어가 시작할 때 창이 전체크기로 실행되게 수정해줘"):
        maximized, as the title bar's button does it - not the fullscreen
        mode, so the title bar and the desktop's own bars stay. Asked before
        the show: on X11 that is the state the window manager maps the
        window in. The quartz backend keeps no such state for a window that
        is not on screen yet, so it is asked once more when the window is
        mapped - the first time only, a window its user made small again and
        that is mapped anew (out of an icon) stays as they left it."""
        self.window.maximize()
        asked = []

        def mapped(window, _event):
            window.disconnect(asked.pop())
            if not window.is_maximized():
                window.maximize()
            return False
        asked.append(self.window.connect("map-event", mapped))

    # ---- cache binding / instance requests --------------------------------
    def _apply_cache(self, cache):
        # A layer toggle may have queued a render immediately before a
        # jobdeck mode switch. It must not fire against the replacement
        # worker before its open/style handshake (style_epoch=0).
        # Initial construction is fitted/goto'd by _on_allocate.  An in-place
        # layout load happens after allocation and needs a deferred fit unless
        # its caller immediately supplies a goto (goto() cancels this flag).
        self._fit_after_worker_start = bool(cache is not None and
                                            self._did_fit)
        previous = getattr(self, "cache", None)
        if previous is not None and previous is not cache \
                and hasattr(previous, "close"):
            previous.close()     # a jobdeck's spec work directory
        self.cache = cache
        self._jobdeck_menu_show()
        if cache is None:
            # EMPTY START (user call 2026-08-22): the viewer opens
            # with no layout - File > load layout… or a forwarded
            # `floe view <file>` attaches one via open_file. Every
            # render entry point (redraw/fit/_clamp_view/minimap/
            # canvas input) guards on cache None.
            self.meta = None
            self.dbu = 0.001
            self.cx = self.cy = 0
            self.visible = set()
            self._frontier_depths = []
            self._minimap_bases = {}
            self._border = None
        else:
            # a layout's pairs with nothing on them stay off the panel
            self.meta = listed_meta(cache)
            self.dbu = self.meta["dbu"]
            bb = self.meta["bbox"]
            self.cx = (bb[0] + bb[2]) / 2
            self.cy = (bb[1] + bb[3]) / 2
            self.visible = {(l["layer"], l["datatype"])
                            for l in self.meta["layers"]}
            # baked minimap frontier (per-depth structural boxes,
            # v0.11.2 caches; absent key = plain minimap) +
            # per-depth base cache
            self._frontier_depths = (self.meta.get("frontier")
                                     or {}).get("depths") or []
            self._minimap_bases = {}
            # the scale border is the source's (its dbu): asked again
            self._border = None
        # fill palette state: user-global edited bitmaps + the
        # effective layerprops (personal, else the design default
        # next to the source - already seeded by Cache.load)
        self._fill_patterns = fillpat.default_patterns()
        self._layer_patterns = {}
        self._layer_widths = {}
        # the design-default rows floe2 gtk-service read
        rows = [] if cache is None else cache.layer_props()
        for key, _color, fill, _name, _f1, f2 in rows:
            i = fillpat.fill_index(fill)
            if i is not None:
                self._layer_patterns[tuple(key)] = i
            try:
                w = int(f2)
                if w > 1:
                    self._layer_widths[tuple(key)] = w
            except ValueError:
                pass
        for w in self._fill_slots:
            w.refresh()
        self._refresh_row_fills()
        self.last_frame = None
        self._margin_frame = None
        self._frame_anchor = None
        self._depth_used = "?"
        self._clear_pending()
        self.rulers = []
        self._ruler_start = None
        self._auto_rulers = []
        self._drc_ruler = []
        self._snap_res = None
        self.selection = None
        self._sel_text = ""
        self._pick_px = None
        # a loaded DRC db belongs to the previous layout
        self._drc_lyr_saved = None   # new design = new layer table
        self._drc_release()
        self._cell_state_reset()
        # size + grid live in the WINDOW TITLE (user call
        # 2026-08-22: the side pane's floe/source header is gone)
        if cache is None:
            self._title_base = "%s - no layout (File > load layout…)" % APP
        elif self.meta.get("jobdeck"):
            jb = self.meta["jobdeck"]
            self._title_base = (
                "%s - %s · jobdeck %d CHIPs · %d placements · %s view%s%s"
                % (APP, self._title_name(getattr(cache, "src", None)
                                         or self.meta["src"]["path"]),
                   jb["chips"], jb["placements"],
                   {"layer": "source layer"}.get(jb["mode"], jb["mode"]),
                   " · levels %s of %d" % (
                       ",".join(str(i) for i in jb["levels"]),
                       len(jb.get("identifiers") or []))
                   if jb.get("levels") else "",
                   " · %d NOT DRAWN" % len(jb["skipped"])
                   if jb.get("skipped") else ""))
            if jb.get("skipped"):
                self._set_live_status(deck_skipped_note(jb["skipped"]))
        else:
            src = self.meta["src"]
            self._title_base = (
                "%s - %s · %.2f GB · grid %dx%d"
                % (APP, self._title_name(getattr(cache, "src", None)
                                         or src["path"]),
                   src["size"] / 1e9, self.meta["grid"]["nx"],
                   self.meta["grid"]["ny"]))
        self._title_show()
        self._build_layer_panel()
        self._apply_props_visibility(rows)
        # the layer properties a launch named for this layout (floe2 view
        # --layerprops): on the table before the view is made, so that its
        # first frame draws the layers the file shows - and before a deck's
        # own session choices, which stay the user's; the colours, fills
        # and widths go to the view once it is made (below)
        props_jobs = self._props_bound_apply(cache)
        if getattr(cache, "is_jobdeck", False):
            self.visible = cache.restore_visibility(self.visible)
            self._layers_batch = True
            try:
                for key, row in self._layer_rows.items():
                    row.set_active(key in self.visible)
            finally:
                self._layers_batch = False
            self._sync_jobdeck_groups()
        if self.worker is not None:
            self.worker.stop()
            self.worker = None
        self._worker_starting = False
        self._sync_label_font_capability()
        self._sync_density_capability()
        if cache is not None:
            marks = getattr(self, "_load_marks", None)
            if marks is not None and "cache" not in marks:
                # the cache, the layer panel: done; the service opens next
                marks["cache"] = time.monotonic()
            self.worker = self._make_view_worker(cache)
            if hasattr(self.worker, "start_async"):
                worker = self.worker
                self._worker_starting = True
                self._set_live_status("opening Rust render cache...")
                self._loading_update("opening render service…")
                worker.start_async(
                    lambda error: GLib.idle_add(
                        self._worker_start_finished, worker, error))
            else:
                self.worker.start()
                self._worker_start_finished(self.worker, None)
            # (a view that is still opening keeps them until it is open)
            for job in props_jobs:
                self.worker.submit(job)

    def _worker_start_finished(self, worker, error):
        if worker is not self.worker:
            return False
        self._worker_starting = False
        # the loading banner comes down here (a stub viewer in the
        # worker-contract gate has no banner: guard, never assume)
        hide = getattr(self, "_loading_hide", None)
        if hide is not None:
            hide()
        # (a stand-in viewer of the worker-contract gate has no note)
        note = getattr(self, "_props_note", None)
        self._props_note = None
        if error is not None:
            self._load_marks = None
            self._set_live_status("render service open failed: %s" % error)
            return False
        if note:
            # what became of the launch's layer properties file
            self._set_live_status(note)
        marks = getattr(self, "_load_marks", None)
        if marks is not None and "cache" in marks and "service" not in marks:
            marks["service"] = time.monotonic()
            marks["open"] = getattr(worker, "open_report", None) or {}
        self._sync_label_font_capability()
        self._sync_density_capability()
        if self._fit_after_worker_start:
            # The window was already sized before this layout was attached.
            # Do not key this off _did_fit alone: on a cold initial open GTK
            # can allocate first, apply --goto and then finish the Rust open;
            # an unconditional fit here used to erase that requested view.
            self._fit_after_worker_start = False
            self.fit()
        elif self._did_fit:
            # Allocation (and possibly CLI --goto) happened while the Rust
            # cache was opening. redraw() deliberately submitted nothing in
            # that state, so issue the preserved view now that it can run.
            self.redraw(immediate=True)
        # the cell tree's roots come from the daemon (one query; a stub
        # viewer of the worker-contract gate has no panel: guard)
        load_roots = getattr(self, "_cell_tree_load_roots", None)
        if load_roots is not None:
            load_roots()
        return False

    def _build_layer_panel(self):
        """Calibre-style panel: black background, rows of
        "<num>.<dt> <color-marker> NAME" in white, layer numbers
        ascending. Layers grouped by layer number:
        '+M1' = group parent (lowest datatype of a multi-datatype
        layer); its '+' expands/collapses the remaining datatypes
        below it (collapsed by default). Clicking selects rows,
        double-clicking toggles visibility, and a collapsed parent drags
        every child datatype with it. All names left-aligned via the
        marker column; hidden = strikethrough."""
        for child in self._layers_box.get_children():
            self._layers_box.remove(child)
        self._layer_rows = {}
        self._layer_groups = {}     # parent key -> [child keys]
        self._layer_expanded = set()  # parent keys currently expanded
        self._selected_layers = set()
        self._layer_select_anchor = None
        self._layer_order = []
        self._layers_batch = False
        # rows a jobdeck's view keeps out of the list, and the search's
        # text: a new table starts with every row of its own in the list
        self._layer_hidden = set()
        self._layer_search = ""
        entry = getattr(self, "_layer_search_entry", None)
        if entry is not None and entry.get_text():
            entry.set_text("")
        if self.meta is None:
            return   # empty start: no layers yet
        groups = {}
        for l in self.meta["layers"]:
            groups.setdefault(l["layer"], []).append(l)
        # the number column fits the LONGEST actual pair plus one
        # glyph of margin - a fixed width broke the swatch column
        # whenever a real pair outgrew it (field report: 63.63 era)
        num_width = max(
            [LAYER_NUM_WIDTH] +
            [len("%d.%d" % (l["layer"], l["datatype"])) + 1
             for l in self.meta["layers"]])

        def add_row(l, marker, tooltip, on_expand=None):
            if l.get("tooltip"):
                tooltip = l["tooltip"] + "\n" + tooltip
            row = LayerRow(l, marker, num_width, tooltip,
                           self._on_layer_toggled, self._on_layer_clicked,
                           on_expand)
            self._layers_box.pack_start(row.widget, False, False, 0)
            self._layer_rows[row.key] = row
            self._layer_order.append(row.key)
            return row.key

        # Calibre ordering: layer numbers ascend down the panel
        for lnum in sorted(groups):
            ls = groups[lnum]
            if len(ls) == 1:
                l = ls[0]
                add_row(l, " ", "%d.%d  %s\nclick: select; "
                        "double-click: show/hide; right-click: actions"
                        % (lnum, l["datatype"], l["name"]))
                continue
            ls = sorted(ls, key=lambda e: e["datatype"])
            head, rest = ls[0], ls[1:]
            jobdeck_head = head.get("jobdeck_head")
            hidden = jobdeck_head and all(l.get("jobdeck_hidden") for l in rest)
            pkey = add_row(
                head, "+",
                "%d.%d  %s\n+/-: expand/collapse %d children\n"
                "click: select; double-click: show/hide layer %d group; "
                "right-click: actions"
                % (lnum, head["datatype"], head["name"], len(rest), lnum),
                None if hidden else self._on_group_expand)
            if hidden:
                self._layer_rows[pkey].set_marker(" ")
            self._layer_groups[pkey] = [
                add_row(l, " ", "%d.%d  %s\nclick: select; "
                        "double-click: show/hide; right-click: actions"
                        % (lnum, l["datatype"], l["name"]))
                for l in rest]
        self._layers_box.show_all()
        # groups start EXPANDED (field request); no_show_all is
        # still set so a later window-level show_all cannot reveal
        # children the user collapses
        hidden = {(l["layer"], l["datatype"])
                  for l in self.meta["layers"] if l.get("jobdeck_hidden")}
        self._layer_hidden = hidden
        for pkey, ckeys in self._layer_groups.items():
            if not all(k in hidden for k in ckeys):
                self._layer_expanded.add(pkey)
                self._layer_rows[pkey].set_marker("-")
            for k in ckeys:
                self._layer_rows[k].widget.set_no_show_all(True)
                if k in hidden:
                    self._layer_rows[k].widget.hide()
        self._refresh_row_fills()

    def _on_group_expand(self, row):
        """'+'/'-' marker click on a group parent."""
        if any(l.get("jobdeck_hidden") and l["layer"] == row.key[0]
               for l in self.meta["layers"]):
            return  # level view deliberately lists only the level heads
        expand = row.key not in self._layer_expanded
        if expand:
            self._layer_expanded.add(row.key)
        else:
            self._layer_expanded.discard(row.key)
        row.set_marker("-" if expand else "+")
        # (the rows a search leaves out stay out: _layer_row_shown)
        for k in self._layer_groups[row.key]:
            w = self._layer_rows[k].widget
            if self._layer_row_shown(k):
                w.show()
            else:
                w.hide()

    def _layer_row_shown(self, key):
        """Whether a layer's row is in the list now. Without a search: a
        group's children while the group is open, every other row - but
        the rows a jobdeck's view keeps out (the level view lists the
        level heads alone). With one (_on_layer_search): the rows whose
        number or name holds the text, a group's children whether the
        group is open or not - the view's kept-out rows stay out."""
        if key in getattr(self, "_layer_hidden", ()):
            return False
        text = getattr(self, "_layer_search", "")
        if text:
            return self._layer_row_matches(key, text)
        for parent, children in self._layer_groups.items():
            if key in children:
                return parent in self._layer_expanded
        return True

    def _layer_row_matches(self, key, text):
        """Whether `text` (lower case) is in a row's number - `31.5` as
        the row writes it, `31/5` as a layer is written elsewhere, a
        datatype 0 both bare and written out - or in its name."""
        row = self._layer_rows.get(key)
        name = (getattr(row, "_name", "") or "").lower()
        numbers = ("%d.%d" % key, "%d/%d" % key) + (("%d" % key[0],) if key[1] == 0 else ())
        return text in name or any(text in number for number in numbers)

    def _on_layer_search(self, entry):
        """The layer search box: empty = the list as its groups stand; a
        text = the rows whose number or name holds it (case-insensitively),
        in the list's order. Nothing of the layers changes - what is shown,
        selected or picked stays; a row the search leaves out is out of
        the selection's reach until the box is emptied (a range selected
        with Shift runs over the rows in the list alone)."""
        was = getattr(self, "_layer_search", "")
        self._layer_search = entry.get_text().strip().lower()
        shown = 0
        for key in self._layer_order:
            row = self._layer_rows[key]
            if self._layer_row_shown(key):
                row.widget.show()
                shown += 1
            else:
                row.widget.hide()
        if self._layer_search:
            self._set_live_status("layers: %d of %d match %r" % (
                shown, len(self._layer_order), entry.get_text().strip()))
        elif was:
            self._set_live_status("layer search cleared")

    def _expand_all(self, expand=True):
        for pkey in self._layer_groups:
            if (pkey in self._layer_expanded) != expand:
                self._on_group_expand(self._layer_rows[pkey])

    def _collapse_all(self):
        self._expand_all(False)

    def open_file(self, path, ids=None, props=None):
        """Open another OASIS file (instance-forwarded request or
        File > load layout…; also the FIRST layout of an empty
        start). `ids`: a jobdeck's mask levels to load (None = all).
        `props`: the layer properties file the launch names for it (floe2
        view --layerprops) - on the layer table this open builds, or, for
        the layout already shown, applied in place (_props_request)."""
        path = os.path.abspath(path)
        if self.cache is not None and path == self.cache.src \
                and not self.cache.is_stale() \
                and getattr(self.cache, "ids", None) == ids:
            if props:
                self._props_request(props)
            return None
        # the load clock (see _load_note): from the file's selection
        self._load_marks = {"t0": time.monotonic()}
        # the loading banner from the first blocking step until the
        # render service has opened (_worker_start_finished); a
        # refusal or an exception before that takes it down here
        self._loading_show("loading %s%s…" % (
            "jobdeck " if _is_deck_path(path) else "",
            os.path.basename(path)))
        applied = False
        # the launch's layer properties, for the table _apply_cache builds
        # (the file as the command line read it through a link: one name
        # for it, whichever way it was written)
        self._props_next = os.path.realpath(props) if props else None
        try:
            err = self._open_file_load(path, ids)
            applied = err is None
            return err
        finally:
            self._props_next = None
            if not applied:
                self._loading_hide()

    def _open_file_load(self, path, ids):
        """open_file's loading half: the cache (a DeckCache plans the
        deck and writes its spec), then _apply_cache (layer panel,
        render service); an error string for the known refusals.
        floe2 gtk-service (floe/gtkservice.py, the shared Rust app layer)
        answers both."""
        from .gtkservice import ServiceCache, ServiceError
        c = ServiceCache(path, ids=ids)
        try:
            c.load()
        except ServiceError as exc:
            if c.is_jobdeck and exc.kind in ("input", "cache"):
                return "ERR %s; run: %s index %s" % (exc, APP, path)
            return "ERR %s" % exc
        if c.is_jobdeck:
            # the deck is the thing viewed: full depth, or a source whose
            # shapes live in child cells shows nothing (review 2026-09-09
            # P1-3)
            self._set_depth(999, redraw=False)
        self._apply_cache(c)
        # the rebuilt layer panel and the restarted worker must not
        # leave the keyboard parked away from the canvas (field
        # 2026-09-05: after a load, d/g beeped instead of acting)
        self._restore_keys()
        return None

    def _index_ready(self, path, ids=None):
        """Whether `path` can be opened as is: a layout with a VFS cache,
        or a jobdeck whose sources (of the levels `ids`, None = all)
        all have one AND their occupancy summary (floe2 gtk-service's
        answer; user 2026-10-22: what the viewer opens is opened again,
        so its summaries are built before the open - a capture's caches
        lack them - in the modal index, not behind the open)."""
        from .gtkservice import ServiceError, readiness
        try:
            answer = readiness(path, ids)
        except ServiceError:
            return False
        if not answer.get("ready"):
            return False
        return not (_is_deck_path(path)
                    and int(answer.get("summary_missing") or 0) > 0)

    def _index_question(self, path, ids=None):
        """The consent question for `path`: its sources' index, or the
        occupancy summaries alone when the index is there."""
        name = os.path.basename(path)
        if _is_deck_path(path):
            from .gtkservice import ServiceError, readiness
            try:
                answer = readiness(path, ids)
            except ServiceError:
                answer = {}
            if answer.get("ready"):
                missing = int(answer.get("summary_missing") or 0)
                return ("%d source%s of\n%s\n%s no occupancy summary "
                        "(a capture's index leaves it out).\n\n"
                        "Build it now? (wide views of those sources are "
                        "empty without it)"
                        % (missing, "" if missing == 1 else "s", name,
                           "has" if missing == 1 else "have"))
            return ("Not every source of\n%s\nhas a VFS index.\n\n"
                    "Index them now?" % name)
        return "No VFS index for\n%s\n\nBuild it now?" % name

    @staticmethod
    def _index_busy(path):
        """Why a layout cannot be opened now: another run rebuilds its
        cache whole (the index locks, floe_vfs::lock) - the refusal naming
        who, else None. A jobdeck's sources are judged one by one when it
        opens."""
        if _is_deck_path(path):
            return None
        from .gtkservice import ServiceError, readiness
        try:
            return readiness(path)["busy"]
        except ServiceError:
            return None

    def _jobdeck_pick_levels(self, path, current=None, force=False):
        """Which mask levels to load (user call 2026-09-10: Calibre
        asks this when a jobdeck is loaded). Returns a sorted list of
        levels, None for every level, or False when the user cancelled.
        FLOE_JOBDECK_LEVELS=all|ask|N[,N...] answers for scripts and the
        gate (default ask); `force` shows the dialog regardless (the
        Jobdeck menu's re-selection). A deck with one level asks
        nothing."""
        if not force:
            policy = os.environ.get("FLOE_JOBDECK_LEVELS", "ask").strip()
            if policy.lower() == "all":
                return None
            if policy and policy.lower() != "ask":
                try:
                    return sorted({int(t) for t in policy.split(",")
                                   if t.strip()}) or None
                except ValueError:
                    self._set_live_status(
                        "FLOE_JOBDECK_LEVELS must be all, ask or "
                        "N[,N...]: %r ignored" % policy)
                    return None
        try:
            from .gtkservice import level_rows
            rows = level_rows(path)
        except (OSError, ValueError, RuntimeError) as exc:
            self._set_live_status("jobdeck: %s" % exc)
            return False
        if len(rows) <= 1:
            return None
        return self._jobdeck_levels_dialog(path, rows, current)

    def _jobdeck_levels_dialog(self, path, rows, current):
        """The level-selection dialog: one check row per mask level
        (`level N` and its MTITLE name - user call 2026-10-26, it read
        `$N` -, CHIPs, instances, sources), all / none buttons, Open /
        Cancel. Returns the selection (None = all levels) or False for
        Cancel."""
        dlg = Gtk.Dialog(title="load jobdeck levels", transient_for=self.window,
                         modal=True)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                        "Open", Gtk.ResponseType.OK)
        # a bounded width whatever the deck names (review 2026-09-10
        # (9th) P2-2: 250 source names made the dialog 26,000 px wide)
        dlg.set_default_size(640, -1)
        dlg.set_default_response(Gtk.ResponseType.OK)
        box = dlg.get_content_area()
        box.set_spacing(6)
        box.set_border_width(8)
        head = Gtk.Label()
        head.set_markup("<b>%s</b>\nmask levels to load (%d)" % (
            GLib.markup_escape_text(os.path.basename(path)), len(rows)))
        head.set_xalign(0.0)
        box.pack_start(head, False, False, 0)
        want = None if current is None else set(current)
        checks = []
        grid = Gtk.Grid(column_spacing=12, row_spacing=2)
        for r, row in enumerate(rows):
            label = "level %d" % row["level"]
            if row["name"]:
                label += " " + row["name"]
            chk = Gtk.CheckButton(label=label)
            chk.set_active(want is None or row["level"] in want)
            checks.append((row["level"], chk))
            grid.attach(chk, 0, r, 1, 1)
            summary, full = _level_row_text(row)
            info = Gtk.Label(label=summary)
            info.set_xalign(0.0)
            info.set_ellipsize(Pango.EllipsizeMode.END)
            info.set_max_width_chars(56)
            info.set_tooltip_text(full)   # the whole source list
            info.get_style_context().add_class("dim-label")
            grid.attach(info, 1, r, 1, 1)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_min_content_height(min(400, 26 * len(rows) + 8))
        scroller.add(grid)
        box.pack_start(scroller, True, True, 0)
        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        ok_button = dlg.get_widget_for_response(Gtk.ResponseType.OK)

        def refresh(*_):
            ok_button.set_sensitive(any(c.get_active() for _, c in checks))
        for _, chk in checks:
            chk.connect("toggled", refresh)
        for label, state in (("all", True), ("none", False)):
            b = Gtk.Button(label=label)
            b.connect("clicked", lambda _b, state=state: [
                c.set_active(state) for _, c in checks])
            buttons.pack_start(b, False, False, 0)
        box.pack_start(buttons, False, False, 0)
        refresh()
        self._center_on_parent(dlg)
        # over the parent whatever presents it meanwhile (a deferred
        # _restore_keys from the load dialog, a forwarded open's
        # present): a modal dialog hidden behind the window would
        # look like "no dialog" with every key dead
        dlg.set_keep_above(True)
        dlg.show_all()
        dlg.present()
        resp = dlg.run()
        picked = sorted(lv for lv, c in checks if c.get_active())
        dlg.destroy()
        # quartz does not hand the keys back by itself (same as the
        # load dialog): restore now; the open restores again
        self._restore_keys()
        if resp != Gtk.ResponseType.OK:
            return False
        return None if len(picked) == len(checks) else picked

    def _index_consent(self, question):
        """Whether an index may be built now: FLOE_INDEX_ON_OPEN=yes|no
        answers for scripts and the GUI smoke gate, anything else asks
        the user (default). One policy for layouts, jobdecks and DRC
        packs (review 2026-09-09 (4th) P2-2)."""
        policy = os.environ.get("FLOE_INDEX_ON_OPEN", "ask").strip().lower()
        if policy == "yes":
            return True
        if policy == "no":
            return False
        return self._ask_yes_no(question)

    def _open_or_index(self, path, fields=(), then=None, ids=None,
                       ask_levels=True):
        """Open a layout or a jobdeck; when its index is missing ASK
        the user first (user call 2026-09-09: floe2 too), build it in
        the modal log, then open, then apply the CLI/forwarded options
        in `fields` (goto=, detail=, depth=, ...), then call `then()`
        - what must follow a successful open, such as a --drc load
        that an in-place open would otherwise reset (review 2026-09-09
        (4th) P2-1). A jobdeck first asks which mask levels to load
        (user call 2026-09-10, Calibre-style) unless `ids` or a
        `levels=` field (floe2 view --level) says, or `ask_levels` is
        False (the menu's re-selection passes its answer, where None
        means EVERY level - review 2026-09-10 (9th) P2-1: None stood for
        "not asked yet" too, so choosing all levels asked again or fell
        back to the environment's list); only those levels' sources are
        indexed and opened. Returns False (usable from GLib.idle_add)."""
        path = os.path.abspath(path)
        fields = [f for f in fields if f]
        if ids is not None:
            ask_levels = False
        props = None
        for f in fields:
            if f.startswith("levels="):
                ids = sorted({int(t) for t in f[7:].split(",")
                              if t.strip()}) or None
                ask_levels = False
            elif f.startswith("layerprops="):
                # the launch's layer properties file (--layerprops)
                props = f[11:] or None
        fields = [f for f in fields
                  if not f.startswith(("levels=", "layerprops="))]
        if _is_deck_path(path) and ask_levels:
            ids = self._jobdeck_pick_levels(path)
            if ids is False:
                self._set_live_status("jobdeck load cancelled")
                self._restore_keys()
                return False

        def after_open(err):
            if err:
                msg = err[4:] if err.startswith("ERR ") else err
                self._set_live_status(msg)
                return
            changed = self._forwarded_view_options(fields)
            jumped = self._forwarded_goto(fields)
            if changed and not jumped:
                self.redraw(immediate=True)
            self._present()
            if then is not None:
                then()

        if self._index_ready(path, ids):
            try:
                err = self.open_file(path, ids, props=props)
            except Exception as exc:
                err = "ERR %s" % exc
            after_open(err)
            return False
        busy = self._index_busy(path)
        if busy is not None:
            # another run builds this cache: no second build (user
            # 2026-10-09 - it would delete that run's files)
            self._set_live_status(str(busy))
            self._restore_keys()
            return False
        name = os.path.basename(path)
        if not self._index_consent(self._index_question(path, ids)):
            self._set_live_status("VFS index needed: %s index %s"
                                  % (APP, name))
            self._restore_keys()
            return False
        if _is_deck_path(path):
            self._jobdeck_index_and_load(path, after=after_open, ids=ids,
                                         props=props)
        else:
            self._vfs_index_and_load(path, after=after_open, props=props)
        return False

    # what a forwarded launch asks for beside its layout and view options
    # (floe/viewcli.py cmd_view): the DRC results, the rules metadata named
    # for them, whose review it is, the file loads turned off, the rule and
    # the error of it to select in the results (0.12.461)
    REQUEST_KEYS = ("drc", "rules", "userid", "noload", "drcrule", "drcerr",
                    "role", "debug")

    def _drc_role_kw(self):
        """The role the DRC opens are made with, as their keyword: none
        for a launch that said no role (the opens are a reviewer's, as
        before the roles)."""
        role = getattr(self, "_role", "")
        return {"role": role} if role else {}

    @staticmethod
    def _request_pick(opts):
        """The rule, and the error of it, a launch names with its results
        (--drc-rule NAME, --drc-err N): (name, N or None), or None."""
        rule = opts.get("drcrule")
        if not rule:
            return None
        try:
            err = int(opts["drcerr"]) if opts.get("drcerr") else None
        except ValueError:
            err = None
        return (rule, err)

    @staticmethod
    def _request_opts(fields):
        opts = {}
        for field in fields:
            if "=" in field:
                key, value = field.split("=", 1)
                opts[key] = value
        return opts

    def _on_incoming(self, _source, _cond):
        """A later launch on this display hands its request to this window
        (floe/instance.py): `path[\tkey=value...]`, answered `OK` or
        `ERR ...`. The window switches to it, nothing asked (user
        2026-11-11: "자동저장 방식이라면 전환 확인을 물을 필요는 없음.
        DISPLAY가 동일할 경우 전환하는 flateyes 방식"): the layout when it is
        another one, then the DRC results as --drc opens them at a start
        (_request_run). A plain indexed layout is opened before the answer,
        so the sender is told when it cannot be; whatever needs a question,
        an index or the results is done after it. While a dialog is open or
        a review write runs the request waits (_request_hold)."""
        if getattr(self, "_quitting", False):
            # (the window is going and its socket is closed: the watch ends
            # here where _quit did not take it)
            return False
        # like _poll: any exception here would make GLib drop the watch,
        # silently killing single-instance forwarding for the session
        try:
            conn, _ = self.server_sock.accept()
        except OSError:
            return True
        conn.settimeout(2.0)
        try:
            data = b""
            while b"\n" not in data and len(data) < 65536:
                chunk = conn.recv(4096)
                if not chunk:
                    break
                data += chunk
            # (the line's end alone is cut: a launch without a layout
            # sends an empty first field, and a strip() of the whole line
            # took its first option for a path - a bare `floe2` beside a
            # running window asked to index "detail=medium")
            line = data.decode("utf-8", "replace").rstrip("\r\n")
            fields = line.split("\t")
            path = fields[0].strip()
            opts = self._request_opts(fields[1:])
            if opts.get("noload") == "1":
                # whatever becomes of the request: a launch with its file
                # loads off never leaves this window loading files
                self._file_load_latch()
            if opts.get("debug") == "1":
                # a launch with --debug: this window's debug parts come on
                self._debug_latch()
            error, kind = None, "present"
            props = opts.get("layerprops") or None
            if props and path:
                # a layer properties file that cannot be read: the sender
                # is told, and the window stays as it is
                error = self._props_refusal(props)
            if error is None and (path or opts.get("drc")):
                # the newest request is the one the window turns to
                self._request_waiting = None
                if self._request_busy() is not None:
                    kind = "wait"
                elif opts.get("drc") or _is_deck_path(path) \
                        or not self._index_ready(os.path.abspath(path)):
                    # the results (a pack to ask about, a review to open),
                    # an index to ask about and build, a deck's levels:
                    # answer the sender now (its wait is short) and do it
                    # in the window
                    kind = "idle"
                else:
                    kind = "now"
                    self._reviewer_set(opts.get("userid"))
                    self._role = opts.get("role") or ""
                    try:
                        error = self.open_file(path, props=props)
                    except Exception as exc:
                        error = "ERR %s" % exc
            # (a bare launch with an instance running - no layout, no
            # results: present the window, change nothing else; the
            # request's option fields are only the sender's defaults)
            try:
                conn.sendall((error or "OK").encode("utf-8") + b"\n")
            except OSError:
                pass
            if kind == "wait":
                self._request_hold(path, fields[1:])
                self._present()
            elif kind == "idle":
                self._present()
                GLib.idle_add(self._request_run, path, fields[1:])
            elif not error:
                if kind == "now":
                    # (the layout shown is not opened again for a request
                    # that names it: its view root goes back to the top
                    # cell before the request's options and goto)
                    self._request_root_top()
                    changed = self._forwarded_view_options(fields[1:])
                    jumped = self._forwarded_goto(fields[1:])
                    if changed and not jumped:
                        self.redraw(immediate=True)
                self._present()
        except Exception:
            import traceback
            traceback.print_exc()
        finally:
            conn.close()
        return True

    def _request_busy(self):
        """Why a forwarded request has to wait, else None. A dialog or a
        menu is open (GTK's grab): what is typed there belongs to what the
        window shows now - a note written under results that were swapped
        meanwhile would land on the new results' errors of the same numbers.
        A review write runs: it ends on the results it was asked for (the
        service finishes it either way; the window says how it ended)."""
        if Gtk.grab_get_current() is not None:
            return "a dialog or a menu is open"
        if getattr(self, "_drc_review_job", None) is not None \
                or getattr(self, "_drc_team_write", None) is not None \
                or getattr(self, "_drc_verdict_job", None) is not None:
            return "a review update is running"
        return None

    def _request_hold(self, path, fields):
        """Keep a forwarded request until the window is free (the newest
        one alone: a launcher asks for one thing at a time)."""
        self._request_waiting = (path, list(fields))
        what = self._request_opts(fields).get("drc") or path
        self._set_live_status("open request waiting (%s): %s" % (
            self._request_busy() or "busy", os.path.basename(what)))
        if self._request_timer is None:
            self._request_timer = GLib.timeout_add(250, self._request_poll)

    def _request_poll(self):
        waiting = self._request_waiting
        if waiting is None or self._quitting:
            self._request_timer = None
            return False
        if self._request_busy() is not None:
            return True
        self._request_waiting = None
        self._request_timer = None
        self._request_run(*waiting)
        return False

    def _request_run(self, path, fields):
        """Do a forwarded launch's request in the window: the reviewer it
        states is the one the results that follow are opened as; the
        layout is opened unless it is the one shown (asked about and
        indexed first when it has no index, a deck's levels chosen), its
        view options applied; then the DRC results (_drc_request). A layout
        that cannot be opened leaves the window as it is, results and all.
        Returns False (GLib.idle_add)."""
        opts = self._request_opts(fields)
        view = [f for f in fields
                if f.split("=", 1)[0] not in self.REQUEST_KEYS]
        self._reviewer_set(opts.get("userid"))
        # (the role is the launch's too: a request without --role opens
        # its results as a reviewer's)
        self._role = opts.get("role") or ""
        drc, rules = opts.get("drc"), opts.get("rules")
        pick = self._request_pick(opts)
        then = (lambda: self._drc_request(drc, rules, pick)) if drc else None
        if path:
            self._request_root_top(path)
            self._open_or_index(path, view, then=then)
        elif then is not None:
            # results alone: onto the layout shown, from its top cell
            self._request_root_top()
            then()
        return False

    def _request_root_top(self, path=None):
        """A later launch's request the window turns to shows its layout
        from the top cell (user 2026-11-15: "같은 DISPLAY로 floe2를 중복
        실행해서 대체될때 top cell로 복귀도 추가해줘"). The layout shown is
        not opened again for a request that names it, or names results
        alone, so a cell made the view root (Cell > selected cell as view
        root) stayed the root under the new request - whose goto and whose
        results' errors are in the top cell's coordinates. As Ctrl+Shift+T
        does: the root is dropped and the view fits the top cell, before
        the request's view options and goto are applied. A bare launch
        changes nothing, this neither. `path`: the layout the request
        names, before its open - another one than the one shown (or one
        whose source changed) starts at its top by the open itself
        (_apply_cache), and one that cannot be opened leaves the window as
        it is, its view root too. Returns whether the root went back."""
        if getattr(self, "_view_root", None) is None:
            return False
        if path is not None:
            cache = self.cache
            if cache is None or os.path.abspath(path) != cache.src \
                    or cache.is_stale():
                return False
        self._view_root = None
        self._root_changed()
        self._set_live_status("view root: the top cell")
        return True

    def _drc_request(self, path, rules=None, pick=None):
        """The DRC results a forwarded launch names, opened as --drc opens
        them at a start, in place of the results shown - nothing asked: the
        review of those is on the disk as it stands (every waive, visit,
        exclusion and note is written when it is made; the service ends a
        write in progress and its queued visits before it lets the old
        results go). Results already open - the same file, its pack still
        the current one, the same reviewer - stay as they are: the window
        comes forward, and rules metadata named with them is attached.
        `pick`: the rule, and the error of it, the launch names
        (_drc_launch_pick) - selected in the results once they are open, and
        in the ones already open without opening them again. The rule list
        follows the launch (_drc_list_only): the named rule's alone, and
        every rule's again for a launch that names none."""
        path = os.path.abspath(path)
        db = self._drc
        # the same reviewer: asked for as these results were, or the id
        # their review is kept under (a window started with --userid serves
        # its own id's request without opening the review again)
        same = db is not None and (
            self._reviewer == self._drc_reviewer
            or (self._reviewer is not None
                and self._reviewer == getattr(db, "_reviewer", None)))
        # (... and the same roles: results open as a reviewer's are opened
        # again for a launch that confirms, and the other way round)
        same = same and (getattr(self, "_role", "") or "") == (getattr(db, "role", "") or "")
        if (same and self._drc_source is not None
                and os.path.realpath(path) == os.path.realpath(self._drc_source)):
            try:
                side = gtkservice.drc_find(path)
            except gtkservice.ServiceError:
                side = None
            held = getattr(db, "path", None)
            if side and held and os.path.realpath(side) == os.path.realpath(held):
                self._left_show("drc")
                if rules:
                    self._drc_rules_load(rules)
                if pick is not None:
                    self._drc_launch_pick(*pick)
                else:
                    # a launch that names no rule lists them all again
                    whole = " · all rules listed" if self._drc_list_only(None) else ""
                    if not rules:
                        self._set_live_status(
                            "DRC %s: already open%s" % (os.path.basename(path), whole))
                    elif whole:
                        self._set_live_status(self.status.get_text() + whole)
                return
        self._drc_open_db(path, rules=rules, pick=pick)

    def _forwarded_view_options(self, fields):
        """Apply request-scoped CLI controls without intermediate renders.

        A forwarded goto follows immediately and owns the one redraw.  A
        path-only request is redrawn once by _on_incoming when this method
        reports a state change.
        """
        opts = {}
        for field in fields:
            if "=" in field:
                key, value = field.split("=", 1)
                opts[key] = value
        before = (self.detail, getattr(self, "cut_custom", None),
                  self.depth_value, self.lod_on,
                  self.frames_on, self.labels_on, self.label_font_px,
                  getattr(self, "thin_mode", "auto"),
                  getattr(self, "density_on", None),
                  getattr(self, "occupancy_on", None))
        detail = opts.get("detail")
        if detail in DETAIL_LEVELS:
            self._set_detail(DETAIL_LEVELS.index(detail), redraw=False)
        depth = opts.get("depth")
        if depth is not None:
            try:
                self._set_depth(int(depth), redraw=False)
            except ValueError:
                pass
        if opts.get("thin") in ("auto", "keep", "cull"):
            self._set_thin(opts["thin"], redraw=False)
        # --density / a forwarded density= (2026-10-05); on needs the
        # cache's design.ovs (0.12.401, user 2026-10-25: refused and said)
        if opts.get("density") in ("on", "off"):
            if opts["density"] == "on" and not self._density_available():
                print("[%s] --density on refused: %s" % (APP, self.DENSITY_REFUSED),
                      file=sys.stderr, flush=True)
                self.rstatus.set_text("--density on refused: " + self.DENSITY_REFUSED)
                self.density_on = False
            else:
                self.density_on = opts["density"] == "on"
        # --occupancy / a forwarded occupancy= (2026-10-20); on needs the
        # layout cache's design.ovo (0.12.401)
        if opts.get("occupancy") in ("on", "off"):
            if opts["occupancy"] == "on" and not self._occupancy_available():
                print("[%s] --occupancy on refused: %s" % (APP, self.OCCUPANCY_REFUSED),
                      file=sys.stderr, flush=True)
                self.rstatus.set_text("--occupancy on refused: " + self.OCCUPANCY_REFUSED)
                self.occupancy_on = None
            else:
                self.occupancy_on = opts["occupancy"] == "on"
        frames = opts.get("frames")
        labels = opts.get("labels")
        if frames in ("on", "off"):
            label_override = None if labels not in ("on", "off") \
                else labels == "on"
            self._set_frames(frames == "on", labels=label_override,
                             redraw=False)
        elif labels in ("on", "off"):
            enabled = self.frames_on and labels == "on"
            self.labels_on = enabled
        label_px = opts.get("labelpx")
        if label_px is not None:
            try:
                label_px = int(label_px)
            except ValueError:
                label_px = None
            if label_px is not None and \
                    MIN_LABEL_FONT_PX <= label_px <= MAX_LABEL_FONT_PX:
                self._set_label_font_px(label_px, redraw=False)
        changed = before != (
            self.detail, getattr(self, "cut_custom", None),
            self.depth_value, self.lod_on,
            self.frames_on, self.labels_on, self.label_font_px,
            getattr(self, "thin_mode", "auto"),
            getattr(self, "density_on", None),
            getattr(self, "occupancy_on", None))
        if changed:
            self.dstatus.set_text(self._depth_label())
        return changed

    def _forwarded_goto(self, fields):
        """Apply a 'goto=X,Y[,W]' option (um) from a forwarded request.
        The sender already validated it, so parse leniently. Return whether
        a jump supplied the render owned by this forwarded request."""
        for f in fields:
            if not f.startswith("goto="):
                continue
            try:
                vals = [float(t) for t in
                        f[len("goto="):].replace(",", " ").split()]
            except ValueError:
                return False
            if len(vals) >= 2:
                self.goto(vals[0], vals[1],
                          vals[2] if len(vals) > 2 else None)
                return True
            return False
        return False

    @staticmethod
    def _title_name(path):
        """A file as the title names it: with its folder (user 2026-11-11,
        after a second launch opened /path/2/layout.oas in the window that
        showed /path/1/layout.oas and the title read `layout.oas` both
        times: "창 제목에 폴더도 함께 표시해줘") - `2/layout.oas`, as the
        results' part has said `run2/sample.db` since 0.12.446."""
        path = os.path.abspath(path)
        return os.path.join(os.path.basename(os.path.dirname(path)),
                            os.path.basename(path))

    def _title_user(self):
        """The user id the title names after the application (0.12.504,
        user 2026-11-16: "userid가 앱 상단에 floe2 (<id>) - <layout>.oas 이런
        형태로 들어가면 좋겠어" - the id and the file of the user's example
        left out here): the id a launch stated - `floe2 view --userid ID`
        or FLOE_REVIEWER, or the later launch this window serves, as whose
        review the results that follow are opened (_reviewer_set). None
        when no launch stated one: the reviews are then kept under where
        the viewer runs, which is no person's id - a load's status line
        says so -, and the title is as it was."""
        stated = getattr(self, "_reviewer", None)
        if not stated:
            stated = (os.environ.get("FLOE_REVIEWER") or "").strip()
        return stated or None

    def _reviewer_set(self, userid):
        """The reviewer a forwarded launch stated is the window's from now
        (None: the window's own again - this process' FLOE_REVIEWER, else
        where it runs), and the title says whose window it is."""
        self._reviewer = userid or None
        if getattr(self, "window", None) is not None:
            self._title_show()

    def _title_show(self):
        """The window's title: the application and - where a launch stated
        one - the user id (`floe2 (kim) - …`, _title_user), the layout
        (_title_base), the DRC results loaded - one window shows one
        results file after another when a launcher's requests switch it,
        and what is being reviewed must be in sight (user 2026-11-11; the
        panel keeps no line of it) - and the view root."""
        base = getattr(self, "_title_base", APP)
        who = Viewer._title_user(self)
        if who and base.startswith(APP + " - "):
            base = "%s (%s)%s" % (APP, who, base[len(APP):])
        title = base + getattr(self, "_title_drc", "")
        root = getattr(self, "_view_root", None)
        if root is not None:
            title += " · root %s" % root["name"]
        self.window.set_title(title)

    def _present(self):
        self.window.deiconify()
        self.window.present()
        self.window.set_urgency_hint(True)

    # ---- geometry ----------------------------------------------------------
    def _viewport_size(self):
        alloc = self.scroller.get_allocation()
        w = alloc.width if alloc.width >= 50 else 1200
        h = alloc.height if alloc.height >= 50 else 800
        return w, h

    def view_bbox(self):
        w, h = self._viewport_size()
        return (self.cx - w / 2 * self.spp, self.cy - h / 2 * self.spp,
                self.cx + w / 2 * self.spp, self.cy + h / 2 * self.spp)

    def tiles_spanned(self, bbox):
        g = self.meta["grid"]
        c0 = max(0, int((bbox[0] - g["x0"]) // g["tile_w"]))
        c1 = min(g["nx"] - 1, int((bbox[2] - g["x0"]) // g["tile_w"]))
        r0 = max(0, int((bbox[1] - g["y0"]) // g["tile_h"]))
        r1 = min(g["ny"] - 1, int((bbox[3] - g["y0"]) // g["tile_h"]))
        if c1 < c0 or r1 < r0:
            return 0
        return (c1 - c0 + 1) * (r1 - r0 + 1)

    def _visible_list(self):
        heads = {(l["layer"], l["datatype"]) for l in
                 (self.meta or {}).get("layers", []) if l.get("jobdeck_head")}
        # A head in the wire selection means ALL its children; omit it
        # here to retain exact partial selections in either panel mode.
        return sorted(self.visible - heads)

    def _layers_arg(self):
        if len(self.visible) != len(self._layer_rows):
            return self._visible_list()
        return None

    # ---- display composition (no cairo: pixbuf ops only) -------------------
    def _render_key(self, scope="live"):
        """Identity of a frame: what state it was rendered for - the view
        controller's render key (its frames carry it)."""
        snap = self.worker.snapshot if self._ctl() else None
        return ("ctl", None if snap is None else snap["render_key"])

    def _density_key(self):
        """Render-key component: the density toggle where the renderer
        has one (the Rust renderer's density stack), None elsewhere - a
        frame drawn with the density never covers a view without it."""
        if not getattr(getattr(self, "worker", None), "supports_density",
                       False):
            return None
        return bool(getattr(self, "density_on", False))

    def _occupancy_key(self):
        """Render-key component: the occupancy summary toggle where the
        renderer draws the summary (the Rust renderer), None elsewhere."""
        if not getattr(getattr(self, "worker", None), "supports_occupancy",
                       False):
            return None
        return bool(self._occupancy_effective())

    def _occupancy_effective(self):
        """The occupancy summary in force: the user's choice, else
        renderd's rule - a jobdeck's passes draw it unless
        FLOE_RUST_OCCUPANCY=off (the kill switch), a plain layout's frames
        do not unless FLOE_RUST_OCCUPANCY=on (user decision 2026-09-24)."""
        on = getattr(self, "occupancy_on", None)
        if on is not None:
            return bool(on)
        env = os.environ.get("FLOE_RUST_OCCUPANCY")
        if getattr(getattr(self, "cache", None), "is_jobdeck", False):
            return env != "off"
        return env == "on"

    def _effective_cut_px(self):
        """Screen-space detail cut is independent of merged LOD: the
        user's own (the `d` dialog's entry) or the level's."""
        custom = getattr(self, "cut_custom", None)
        return self.cut_px if custom is None else custom

    def _detail_text(self):
        """The detail the status line names: the level, or the user's own
        cut as `0.1px`."""
        custom = getattr(self, "cut_custom", None)
        if custom is not None:
            return "%gpx" % custom
        return DETAIL_LEVELS[self.detail]

    def _structure_visible(self):
        """A finite VFS depth has a hierarchy frontier of its own."""
        return bool(self.meta.get("vfs") and self.frames_on
                    and self._depth() is not None)

    def _frame_compatible(self, frame):
        """A stale frame stays displayable rescaled until the fresh
        frame lands - across pans, zooms of any ratio, layer and depth
        changes alike (briefly stale content beats a black flash).
        A finite-depth hierarchy frame remains useful with every design
        layer hidden (and a degenerate frame is never displayable)."""
        return (frame[3] is not None and frame[2] > 0 and
                (bool(self.visible) or self._structure_visible()))

    def _margin_base(self):
        """The landed margin frame when it can serve as the display
        base right now: same render state and scale as the live view,
        and not already the frame being shown (labels off adopts the
        margin as last_frame itself)."""
        margin = getattr(self, "_margin_frame", None)
        if margin is None or margin[2] <= 0:
            return None
        if margin[3] != self._render_key("live") \
                or abs(self.spp / margin[2] - 1.0) >= 0.001:
            return None
        if self.last_frame is not None and margin[0] is self.last_frame[0]:
            return None
        return margin

    def _display(self):
        w, h = self._viewport_size()
        disp = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, False, 8, w, h)
        disp.fill(BLACK)
        bbox = self.view_bbox()
        base = self._margin_base()
        if base is not None:
            # §F2R-21 (field 2026-09-05): with labels on the landed
            # margin never becomes last_frame, yet its label-free
            # geometry is exactly what belongs under the strip a pan
            # uncovers - that strip used to stay BLACK for the debounce
            # plus the render round trip (50% of the screen on an
            # arrow step). Blit the margin first at the live center;
            # the labelled frame paints over its overlap and the
            # fast-path frame replaces everything moments later.
            self._composite_world(disp, base[0], base[1], bbox, self.spp)
        if self.last_frame is not None and \
                self._frame_compatible(self.last_frame):
            # the stale frame is never rescaled (a blurry zoomed base
            # reads as a glitch): it stays frozen at its own resolution
            # until the fresh frame lands. While the scale matches, the
            # anchor tracks the center so pans move 1:1; once a zoom
            # changes the scale the anchor stays put - zoom-at-cursor
            # center compensation must not slide the frozen image.
            frame, fb, fspp, _key = self.last_frame
            if self._frame_anchor is None or \
                    abs(self.spp / fspp - 1.0) < 0.001:
                self._frame_anchor = (self.cx, self.cy)
            ax, ay = self._frame_anchor
            vb = (ax - w / 2 * fspp, ay - h / 2 * fspp,
                  ax + w / 2 * fspp, ay + h / 2 * fspp)
            self._composite_world(disp, frame, fb, vb, fspp)
            # world-anchored overlays (rulers, selection, snap) stay
            # glued to the frozen base and jump together with it when
            # the fresh frame lands; the minimap keeps the real view
            obox, ospp = vb, fspp
        else:
            obox, ospp = bbox, self.spp
        self._draw_overlays(disp, obox, ospp)
        if self.dump:
            # diagnosis: exactly what is handed to the screen widget, plus
            # whether the widget itself is sized/mapped (a 0-sized or
            # unmapped Gtk.Image displays nothing without any error)
            disp.savev("/tmp/%s_disp.png" % APP, "png", [], [])
            ia = self.image.get_allocation()
            sys.stderr.write(
                "[dump] disp %dx%d | image alloc %dx%d at (%d,%d) "
                "mapped=%s visible=%s\n"
                % (disp.get_width(), disp.get_height(),
                   ia.width, ia.height, ia.x, ia.y,
                   self.image.get_mapped(), self.image.get_visible()))
        # labels place BEFORE the pixbuf is handed over: their dotted
        # leaders are stamped into this frame
        self._update_labels(obox, ospp, disp)
        self._update_note_labels(obox, ospp)
        self._update_border_labels(getattr(self, "_border_shown", None))
        self.image.set_from_pixbuf(disp)
        # the markers may have moved with the frame: the one under the
        # pointer is looked for again on what was just composed
        self._drc_hover_update()
        self._update_minimap(bbox)

    def _composite_world(self, disp, src, src_bbox, bbox, spp=None):
        spp = spp or self.spp
        sw = src.get_width()
        if sw < 1 or src_bbox[2] <= src_bbox[0]:
            return
        sppd = sw / (src_bbox[2] - src_bbox[0])   # src px per dbu
        scale = (1.0 / spp) / sppd                # view px per src px
        if scale <= 0:
            return
        off_x = (src_bbox[0] - bbox[0]) / spp
        off_y = (bbox[3] - src_bbox[3]) / spp
        dx0 = max(0, int(math.floor(off_x)))
        dy0 = max(0, int(math.floor(off_y)))
        dx1 = min(disp.get_width(), int(math.ceil(off_x + sw * scale)))
        dy1 = min(disp.get_height(),
                  int(math.ceil(off_y + src.get_height() * scale)))
        if dx1 <= dx0 or dy1 <= dy0:
            return
        interp = GdkPixbuf.InterpType.BILINEAR if scale < 1 \
            else GdkPixbuf.InterpType.NEAREST
        src.composite(disp, dx0, dy0, dx1 - dx0, dy1 - dy0,
                      off_x, off_y, scale, scale, interp, 255)

    def _draw_overlays(self, disp, obox, ospp):
        self._drc_point_hits = None
        self._drc_marker_view = (tuple(obox), ospp,
                                 disp.get_width(), disp.get_height())
        self._border_shown = None

        def sx(v):
            return (v - obox[0]) / ospp

        def sy(v):
            return (obox[3] - v) / ospp

        if self.overlay_mode == 2:
            # Tab state 2 (flateyes parity): overlays hidden -
            # rulers, marks, markers, selections and the scale border
            # all skip; only the live zoom band stays interactive. Stale
            # marker hits must not pick invisible markers.
            self._drc_hits = []
            if self._zoomdrag is not None \
                    and self._band_cur is not None:
                x0, y0 = self._zoomdrag
                x1, y1 = self._band_cur
                color = BAND_IN if x1 >= x0 else BAND_OUT
                rect_outline(disp, x0, y0, x1, y1, None, color,
                             px=1)
            return

        for sel in self.selections:
            if not sel.get("points"):
                continue
            pts = [(sx(x), sy(y)) for x, y in sel["points"]]
            for a, b in zip(pts, pts[1:] + pts[:1]):
                stamp_segment(disp, a, b, BLACK, SEL_CORE)
        segs = list(self.rulers)
        if self.mode == "ruler" and self._ruler_start is not None:
            segs.append((*self._ruler_start, *self._ruler_end_preview()))
        for seg in segs:
            if isinstance(seg, _DrcAreaLabel):
                continue  # a text chip alone: no line, no arrowheads
            x0, y0, x1, y1 = seg
            a, b = (sx(x0), sy(y0)), (sx(x1), sy(y1))
            if isinstance(seg, _DrcOffsetRuler):
                edge_a, edge_b = a, b
                a, b = offset_screen_segment(a, b)
                # Extension lines expose the error edge underneath while
                # tying both endpoints to its parallel dimension line.
                stamp_dotted(disp, edge_a, a, None, RULER_CORE)
                stamp_dotted(disp, edge_b, b, None, RULER_CORE)
            stamp_segment(disp, a, b, None, RULER_CORE, px=1)
            ang = math.atan2(b[1] - a[1], b[0] - a[0])
            stamp_arrow(disp, b, ang, None, RULER_CORE)       # outward
            stamp_arrow(disp, a, ang + math.pi, None, RULER_CORE)
        if self.mode == "ruler" and self.snap_on and self._snap_res \
                and self._snap_res.get("found"):
            mx, my = sx(self._snap_res["x"]), sy(self._snap_res["y"])
            color = SNAP_VERTEX if self._snap_res["snap"] == "vertex" \
                else SNAP_EDGE
            rect_outline(disp, mx - 5, my - 5, mx + 5, my + 5, None, color)
            fill_rect(disp, mx - 9, my, 19, 1, color)
            fill_rect(disp, mx, my - 9, 1, 19, color)
        # screen-space marker hit list rebuilt every frame by
        # _drc_stamp_errs (hover tooltip + canvas pick)
        self._drc_hits = []
        if self.drc_mark is not None:
            # solid 2px lines, polygon interiors = solid 50%-alpha
            # wash (2026-08-22, replaced the opaque checker that
            # could phase-align with the design speckle and hide
            # the layers underneath at some zooms); spans below the
            # marker size collapse to the marker square (user call
            # 2026-08-16: no in-between zoom range where the shape
            # paints smaller than the marker)
            pts = [(sx(x), sy(y)) for x, y in self.drc_mark["pts"]]
            mcol = self.drc_mark.get("color", DRC_RED)
            mxs = [p[0] for p in pts]
            mys = [p[1] for p in pts]
            if (max(mxs) - min(mxs) < DRC_MARK_PX
                    and max(mys) - min(mys) < DRC_MARK_PX):
                cxp = (min(mxs) + max(mxs)) / 2.0
                cyp = (min(mys) + max(mys)) / 2.0
                stamp_drc_circle(disp, cxp, cyp, DRC_MARK_PX // 2,
                                 mcol, solid=True)
            elif self.drc_mark["kind"] == "p":
                self._drc_fill_translucent(disp, pts, mcol)
                for a, b in zip(pts, pts[1:] + pts[:1]):
                    stamp_segment(disp, a, b, None, mcol)
                self._drc_visit_drawn(self.drc_mark, pts,
                                      disp.get_width(), disp.get_height())
            else:
                # edge records: consecutive point pairs are segments
                for j in range(0, len(pts) - 1, 2):
                    stamp_segment(disp, pts[j], pts[j + 1], None,
                                  mcol)
                self._drc_visit_drawn(self.drc_mark, pts,
                                      disp.get_width(), disp.get_height())
        if self.overlay_mode == 0 and self._drc is not None \
                and self._drc_open is not None:
            # All matching errors of the rule, cluster or delta group,
            # independently of list pages (feature/jobdeck-drc
            # 2026-10-08): the service paints individual centres into
            # one bounded picture. Tab state 1 hides these: only the
            # jumped error above stays (user call 2026-08-21); the pixel
            # hit map then stays empty so hidden markers cannot be picked.
            if self._drc_hl and hasattr(self._drc, "query_rect"):
                # keeps the in-view filter grid following the view
                self._drc_hl_list()
            with _dprof("paint: rule errors"):
                self._drc_stamp_markers(disp, obox, ospp)
            # Focus remains visible above the full-scope marker image.
            focus = self._drc_focus
            if focus is not None and focus[0] == self._drc_open:
                self._drc_stamp_errs(disp, sx, sy, [focus],
                                     self._drc_focus_color(focus[0], focus[1]))
        if self.overlay_mode == 0 and self._cell_hl is not None \
                and self._cell_hl_on:
            # the cell tree's selected cell: its instances in the view
            # (renderd cell_insts), outlined; a tiny one is a marker
            # square like a DRC mark so it stays visible at wide zooms
            width, height = disp.get_width(), disp.get_height()
            for x0, y0, x1, y1 in self._cell_hl["boxes"]:
                ax, ay, bx, by = sx(x0), sy(y1), sx(x1), sy(y0)
                if bx < -2 or by < -2 or ax > width + 2 or ay > height + 2:
                    continue
                if bx - ax < CELL_MARK_PX and by - ay < CELL_MARK_PX:
                    fill_rect(disp, (ax + bx) / 2 - CELL_MARK_PX // 2,
                              (ay + by) / 2 - CELL_MARK_PX // 2,
                              CELL_MARK_PX, CELL_MARK_PX, CELL_HL)
                else:
                    rect_outline(disp, ax, ay, bx, by, None, CELL_HL)
        if self.mode == "esel" and self._esel_start is not None:
            # Keep the live selection boundary above dense marker rasters,
            # focused errors and cell highlights, with contrast on either.
            ax, ay = self._esel_start
            bx, by = self._cursor
            rect_outline(disp, sx(ax), sy(ay), sx(bx), sy(by),
                         BLACK, RULER_CORE, px=1)
        border = self._border_for(obox, ospp)
        if border is not None:
            # the scale border lies over the frame and the marks along its
            # edges; the live zoom band alone paints over it
            self._draw_border(disp, border)
            self._border_shown = border
        if self._zoomdrag is not None and self._band_cur is not None:
            x0, y0 = self._zoomdrag
            x1, y1 = self._band_cur
            color = BAND_IN if x1 >= x0 else BAND_OUT
            rect_outline(disp, x0, y0, x1, y1, None, color, px=1)

    # ---- the scale border (user 2026-10-13) --------------------------------
    def _border_for(self, obox, ospp):
        """The scale border of the view shown - the band's segments in px,
        the reference length, the corners' text - from the view's service
        (app-core view::border, the web's too), kept for the view until it
        moves: a frame landing, a hover's marker or a toggle redraws the
        same view. None when there is none to draw: off, Tab's clean look,
        no layout, the view still opening (the viewer's own loop never
        draws it)."""
        # (getattr: the contract tests draw with viewers built by hand)
        if not getattr(self, "border_on", False) or self.overlay_mode == 2 \
                or self.meta is None or not self._ctl() \
                or self.worker.snapshot is None:
            return None
        w, h = self._viewport_size()
        key = (tuple(obox), ospp, w, h)
        kept = getattr(self, "_border", None)
        if kept is not None and kept[0] == key:
            return kept[1]
        got = self.worker.border(obox, w, h)
        if not isinstance(got, dict):
            return None
        self._border = (key, got)
        return got

    def _draw_border(self, disp, border):
        """The band along the frame's four edges: the service's segments in
        the two tones (whole pixels: a segment ends where the next begins),
        the corner squares, the rule between the band and the layout."""
        w, h = disp.get_width(), disp.get_height()
        band = BORDER_PX - 1
        for seg in border["x"]:
            colour = BORDER_EVEN if seg["even"] else BORDER_ODD
            x0, x1 = int(round(seg["from"])), int(round(seg["to"]))
            if x1 > x0:
                fill_rect(disp, x0, 0, x1 - x0, band, colour)
                fill_rect(disp, x0, h - band, x1 - x0, band, colour)
        for seg in border["y"]:
            colour = BORDER_EVEN if seg["even"] else BORDER_ODD
            y0, y1 = int(round(seg["from"])), int(round(seg["to"]))
            if y1 > y0:
                fill_rect(disp, 0, y0, band, y1 - y0, colour)
                fill_rect(disp, w - band, y0, band, y1 - y0, colour)
        for x, y in ((0, 0), (w - band, 0), (0, h - band),
                     (w - band, h - band)):
            fill_rect(disp, x, y, band, band, BORDER_ODD)
        fill_rect(disp, 0, band, w, 1, BORDER_RULE)
        fill_rect(disp, 0, h - BORDER_PX, w, 1, BORDER_RULE)
        fill_rect(disp, band, 0, 1, h, BORDER_RULE)
        fill_rect(disp, w - BORDER_PX, 0, 1, h, BORDER_RULE)

    def _update_border_labels(self, border):
        """The border's text: each corner's coordinates (um) at its corner
        and the reference length over the top band - Gtk.Labels on the
        overlay as the ruler chips are (no pycairo: the frame carries no
        text), taking no clicks; hidden with the border."""
        labels = getattr(self, "_border_labels", None)
        if border is None:
            if labels is not None:
                for lbl in labels.values():
                    lbl.hide()
            return
        if labels is None:
            labels = self._border_labels = {}
            for key, halign, valign in (
                    ("top_left", Gtk.Align.START, Gtk.Align.START),
                    ("top_right", Gtk.Align.END, Gtk.Align.START),
                    ("bottom_left", Gtk.Align.START, Gtk.Align.END),
                    ("bottom_right", Gtk.Align.END, Gtk.Align.END),
                    ("scale", Gtk.Align.CENTER, Gtk.Align.START)):
                lbl = Gtk.Label()
                lbl.set_halign(halign)
                lbl.set_valign(valign)
                lbl.set_no_show_all(True)
                self.overlay.add_overlay(lbl)
                try:
                    self.overlay.set_overlay_pass_through(lbl, True)
                except AttributeError:  # GTK < 3.18
                    pass
                labels[key] = lbl
        for key in ("top_left", "top_right", "bottom_left", "bottom_right"):
            corner = border[key]
            labels[key].set_markup(
                '<span background="#101010" foreground="#ffffff"> %s, %s '
                '</span>' % (GLib.markup_escape_text(corner["x"]),
                             GLib.markup_escape_text(corner["y"])))
        labels["scale"].set_markup(
            '<span background="#101010" foreground="#ffffff"> scale %s '
            '</span>' % GLib.markup_escape_text(border["label"]))
        for lbl in labels.values():
            lbl.show()

    def _toggle_border(self):
        """`s` / View > scale border: the band along the frame's edges and
        its chips on or off; the status line says which."""
        self.border_on = not self.border_on
        self._set_live_status("scale border %s"
                              % ("on" if self.border_on else "off"))
        self._display()

    def _minimap_geom(self):
        """(scale, panel x0, panel y0, die px w, die px h) or None."""
        if self.meta is None:
            return None
        got = self._ctl_minimap(None)
        if got is not None:
            if got["die"] is None:
                return None
            x, y, w, h = got["die"]
            return (got["scale"], int(x), int(y), int(w), int(h))
        bb = self._die_bbox()
        bw, bh = bb[2] - bb[0], bb[3] - bb[1]
        if bw <= 0 or bh <= 0:
            return None
        # the die fits inside the MINIMAP_PAD border on every side
        inner = MINIMAP_PX - 2 * MINIMAP_PAD
        scale = inner / max(bw, bh)
        mw, mh = max(2, round(bw * scale)), max(2, round(bh * scale))
        return (scale, (MINIMAP_PX - mw) // 2,
                (MINIMAP_PX - mh) // 2, mw, mh)

    def _minimap_frontier_depth(self):
        """Bucket the minimap mirrors: the CURRENT semantic depth.
        None = no frontier layer (full depth, beyond the baked/
        folded range, or an old cache). The minimap is navigation
        chrome, so its frontier remains visible when main-view
        frames are off. Rev 46b: the frontier is baked at INDEX
        time through the real planner (canonical fit scale, medium
        detail) - the L9 gate holds it byte-equal to vfsd
        mode=frontier, so no runtime requests are needed."""
        if not getattr(self, "_frontier_depths", None):
            return None
        if getattr(self, "_view_root", None) is not None:
            return None   # the baked frontier is the top cell's
        d = self.depth_value
        if d >= 999 or d >= len(self._frontier_depths):
            return None
        return d

    def _minimap_world_point(self, px, py):
        """Map a panel pixel to world coordinates: inside the die as
        it is, in the MINIMAP_PAD border around it onto the nearest die
        edge (the border is part of the map); farther out None."""
        geom = self._minimap_geom()
        if geom is None:
            return None
        scale, x0, y0, mw, mh = geom
        if not (x0 - MINIMAP_PAD <= px <= x0 + mw - 1 + MINIMAP_PAD and
                y0 - MINIMAP_PAD <= py <= y0 + mh - 1 + MINIMAP_PAD):
            return None
        px = min(max(px, x0), x0 + mw - 1)
        py = min(max(py, y0), y0 + mh - 1)
        bb = self._die_bbox()
        return (bb[0] + (px - x0) / scale,
                bb[3] - (py - y0) / scale)

    def _on_minimap_click(self, _widget, event):
        if os.environ.get("FLOE_CLICK_DEBUG"):
            sys.stderr.write(
                "[click] minimap press at (%.1f, %.1f) cache=%s\n"
                % (event.x, event.y, self.cache is not None))
        if self.cache is None:
            return False
        if event.type != Gdk.EventType.BUTTON_PRESS or event.button != 1:
            return False
        # inside the notebook page the event box can be LARGER than
        # the 180px image, which centers within it - event coords
        # are box-relative, the world mapping is image-relative.
        # translate_coordinates handles the offset CORRECTLY across
        # the event box's own GdkWindow (raw allocation subtraction
        # mixed coordinate spaces and sent every click off the die
        # - field reports 2026-08-22 x2)
        off = self._minimap_image.translate_coordinates(
            self._minimap_event, 0, 0)
        ox, oy = off if off else (0, 0)
        point = self._minimap_world_point(event.x - ox, event.y - oy)
        if point is None:
            return True
        if self._ctl_navigate({"kind": "minimap",
                               "point": [float(event.x - ox),
                                         float(event.y - oy)]}):
            return True
        # §F2R-16: the minimap keeps the zoom, so round the jump onto
        # the 16-device-px grid of the current view - a same-scale
        # move within a viewport's reach then reuses the previous
        # frame's overlap (the <=8px placement shift is invisible at
        # minimap-jump scale).
        step = 16 * self.spp
        self.cx += round((point[0] - self.cx) / step) * step
        self.cy += round((point[1] - self.cy) / step) * step
        self.redraw(immediate=True)
        return True

    def _minimap_base(self, d):
        """Die background + the depth-d frontier boxes, rendered once
        per depth and cached: the minimap is stamped on every frame,
        and re-drawing up to a thousand boxes in python per display
        would drag pan/refine (the view box rides on a copy())."""
        base = self._minimap_bases.get(d)
        if base is not None:
            return base
        got = self._ctl_minimap(d)
        if got is not None:
            # the service's bake (palette digits): this panel's colours
            size = int(got["size"])
            colours = {ord(str(i)): bytes.fromhex("%06X" % (rgba >> 8))
                       for i, rgba in enumerate((BLACK, MINIMAP_BG,
                                                 MINIMAP_EDGE, MINIMAP_FRONT,
                                                 MINIMAP_VIEW))}
            data = b"".join(colours[c] for c in got["base"].encode("ascii"))
            disp = GdkPixbuf.Pixbuf.new_from_bytes(
                GLib.Bytes.new(data), GdkPixbuf.Colorspace.RGB, False, 8,
                size, size, size * 3)
            self._minimap_bases[d] = disp
            return disp
        disp = GdkPixbuf.Pixbuf.new(
            GdkPixbuf.Colorspace.RGB, False, 8, MINIMAP_PX, MINIMAP_PX)
        disp.fill(BLACK)
        geom = self._minimap_geom()
        if geom is not None:
            scale, x0, y0, mw, mh = geom
            bb = self._die_bbox()
            fill_rect(disp, x0, y0, mw, mh, MINIMAP_BG)
            frame_rect(disp, x0, y0, mw, mh, MINIMAP_EDGE)
            if d is not None:
                for row in self._frontier_depths[d]:
                    fx0, fy0, fx1, fy1 = row[0], row[1], \
                        row[2], row[3]
                    w = (fx1 - fx0) * scale
                    h = (fy1 - fy0) * scale
                    if w < 0.7 and h < 0.7:
                        continue  # sub-pixel dust stays off the map
                    frame_rect(disp,
                               x0 + (fx0 - bb[0]) * scale,
                               y0 + (bb[3] - fy1) * scale,
                               max(1, round(w)), max(1, round(h)),
                               MINIMAP_FRONT)
        self._minimap_bases[d] = disp
        return disp

    def _update_minimap(self, bbox):
        """Draw the die overview below the layer list: the cached
        per-depth base (die + always-visible structural frontier) plus
        the live view box."""
        if self.meta is None:
            return   # empty start: the minimap slot stays blank
        geom = self._minimap_geom()
        disp = self._minimap_base(
            None if geom is None else self._minimap_frontier_depth())
        disp = disp.copy()
        if geom is None:
            self._minimap_image.set_from_pixbuf(disp)
            return
        scale, x0, y0, mw, mh = geom
        bb = self._die_bbox()

        def mx(v):
            return x0 + (v - bb[0]) * scale

        def my(v):
            return y0 + (bb[3] - v) * scale

        vw = (bbox[2] - bbox[0]) * scale
        vh = (bbox[3] - bbox[1]) * scale
        if vw >= MINIMAP_DOT_MIN and vh >= MINIMAP_DOT_MIN:
            # the fit view overshoots the die by its margin: the box
            # runs into the MINIMAP_PAD border (so it no longer lies on
            # the die outline) and is clipped one pixel inside the
            # image, where it stays visible
            lo, hi = 1, MINIMAP_PX - 2
            rx0 = max(lo, mx(bbox[0]))
            ry0 = max(lo, my(bbox[3]))
            rx1 = min(hi, mx(bbox[2]))
            ry1 = min(hi, my(bbox[1]))
            frame_rect(disp, rx0, ry0, max(2, round(rx1 - rx0 + 1)),
                       max(2, round(ry1 - ry0 + 1)), MINIMAP_VIEW)
        else:
            px, py = mx(self.cx), my(self.cy)
            fill_rect(disp, px - 3, py - 3, 7, 7, BLACK)
            fill_rect(disp, px - 2, py - 2, 5, 5, MINIMAP_VIEW)
        self._minimap_image.set_from_pixbuf(disp)

    def _update_labels(self, obox, ospp, disp=None):
        """Ruler distance labels: a pool of Gtk.Labels on the overlay.
        A single on-screen ruler keeps the plain up-right readout;
        several spread out flateyes-style (anchors along each own
        line, off shared crossings, never covering another chip,
        leader or line) and each chip ties back to ITS line with a
        dotted leader stamped into the frame."""
        # Tab hides overlays: the distance chips are WIDGETS, not
        # pixbuf paint, so they need their own gate (field report
        # 2026-08-19: chips survived the toggle)
        segs = [] if self.overlay_mode == 2 else list(self.rulers)
        if self.overlay_mode != 2 and self.mode == "ruler" \
                and self._ruler_start is not None:
            segs.append((*self._ruler_start, *self._ruler_end_preview()))
        w, h = self._viewport_size()
        vis = []
        for seg in segs:
            x0, y0, x1, y1 = seg
            a = ((x0 - obox[0]) / ospp, (obox[3] - y0) / ospp)
            b = ((x1 - obox[0]) / ospp, (obox[3] - y1) / ospp)
            if isinstance(seg, _DrcOffsetRuler):
                a, b = offset_screen_segment(a, b)
            mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
            if -40 <= mx <= w and -20 <= my <= h:
                # five decimals, half up (an area label carries its text)
                text = (seg.text if isinstance(seg, _DrcAreaLabel) else
                        "%s um" % format_um5(
                            math.hypot(x1 - x0, y1 - y0) * self.dbu))
                vis.append((a, b, mx, my, text))
        while len(self._labels) < len(vis):
            lbl = Gtk.Label()
            lbl.set_halign(Gtk.Align.START)
            lbl.set_valign(Gtk.Align.START)
            self.overlay.add_overlay(lbl)
            self._labels.append(lbl)
        multi = len(vis) > 1
        lines = [(a, b) for a, b, _, _, _ in vis]
        placed = []    # chip rects already positioned this pass
        leaders = []   # leader segments already claimed
        for idx, (a, b, mx, my, text) in enumerate(vis):
            lbl = self._labels[idx]
            lbl.set_markup('<span background="#101010" foreground='
                           '"#ffffff"> %s </span>'
                           % GLib.markup_escape_text(text))
            lbl.show()   # a hidden label measures as zero
            # preferred size folds in the margins, which still hold
            # the previous position; subtract for the chip itself
            _, nat = lbl.get_preferred_size()
            tw = nat.width - lbl.get_margin_start()
            th = nat.height - lbl.get_margin_top()
            if multi:   # off the shared crossing, beside its own line
                others = lines[:idx] + lines[idx + 1:]
                x, y = pick_label_spot(a, b, tw, th, placed, leaders,
                                       others, w, h)
            else:
                x, y = shove_label(mx + 8, my - th - 6, tw, th,
                                   placed, w, h)
            lbl.set_margin_start(int(x))
            lbl.set_margin_top(int(y))
            rect = (x, y, x + tw, y + th)
            placed.append(rect)
            if multi:
                seg = leader_seg(a, b, rect)
                if seg is not None:
                    leaders.append(seg)
        if disp is not None:
            # with several rulers a bare readout no longer says which
            # line it measures (crossing rulers especially): dotted
            # leaders tie each chip back to its own line
            for end, foot in leaders:
                stamp_dotted(disp, end, foot, None, RULER_CORE)
        for lbl in self._labels[len(vis):]:
            lbl.hide()

    def _update_note_labels(self, obox, ospp):
        """The DOUBLE-CLICKED error's note as a translucent panel at
        the canvas top-left (flateyes note style). Shows while a jump
        mark is live (double-click / .,-step) and the jumped error is
        still on screen (overlay_mode 0/1); it disappears only when Tab
        turns ALL overlays off (mode 2) (user calls 2026-08-28)."""
        panel = self._note_panel
        db = self._drc
        note = None
        if db is not None and hasattr(db, "get_note") \
                and self.overlay_mode != 2 and self.drc_mark is not None \
                and self._drc_pos >= 0 and self._drc_cum:
            jci = bisect.bisect_right(self._drc_cum, self._drc_pos) - 1
            if 0 <= jci < len(db.checks):
                jei = self._drc_pos - self._drc_cum[jci]
                if 0 <= jei < len(db.checks[jci].errors):
                    note = db.get_note(jci, jei)
        if not note:
            if panel is not None:
                panel.hide()
            return
        if panel is None:
            panel = self._note_panel = Gtk.Label()
            panel.set_halign(Gtk.Align.START)
            panel.set_valign(Gtk.Align.START)
            panel.set_margin_start(10)
            panel.set_line_wrap(True)
            panel.set_max_width_chars(44)
            panel.set_xalign(0)
            panel.set_no_show_all(True)
            panel.get_style_context().add_class("floe-note-panel")
            self.overlay.add_overlay(panel)
            try:
                self.overlay.set_overlay_pass_through(panel, True)
            except AttributeError:  # GTK < 3.18
                pass
        # under the scale border's top-left chip when the border shows
        panel.set_margin_top(10 if getattr(self, "_border_shown", None) is None
                             else BORDER_PX + 24)
        panel.set_text(note)
        panel.show()

    # ---- drawing / rendering ------------------------------------------------
    def redraw(self, immediate=False):
        """Show the view and send what changed of it to the view
        controller, which decides what is drawn and when (docs/
        SHARED_APP_LAYER.ko.md §7; `immediate` is the controller's call
        now - a policy edit renders at once, a move once it settles)."""
        if self.cache is None:
            return   # empty start: nothing to render yet
        if self._worker_starting:
            self._display()
            self._set_live_status("opening Rust render cache...")
            return
        if self.worker is None or not self.worker.alive():
            self._display()
            self._set_live_status("render service is not available")
            return
        self._clamp_view()
        self._ctl_redraw()

    # ---- the view controller's loop (P4d; the only one since P4f) ------
    def _ctl(self):
        """The render loop is the shared Rust ViewController's."""
        return bool(getattr(getattr(self, "worker", None), "controller",
                            False))

    def _make_view_worker(self, cache):
        """The view channel's worker for `cache`, opened with the viewer's
        policy (and its view when it has one) so the first frame is the
        one asked for, not the controller's default."""
        self._ctl_shown_rev = None
        self._ctl_said = None
        w, h = self._viewport_size()
        deck = bool(getattr(cache, "is_jobdeck", False))
        patch = self._ctl_policy(deck=deck)
        if patch.get("root") is not None:
            # a root is resolved by the live view: the first sync sends it
            del patch["root"]
        self._ctl_sent = dict(patch)
        kept = getattr(self, "_ctl_open_view", None)
        if kept is not None:
            # a deck's mode switch keeps the view (_jobdeck_set_mode)
            dbu = self.dbu
            patch["navigation"] = {
                "kind": "goto", "center_um": [kept[0] * dbu, kept[1] * dbu],
                "width_um": kept[2] * w * dbu}
        elif self._did_fit and not self._fit_after_worker_start:
            patch["navigation"] = self._ctl_goto(w)
        return gtkservice.ViewWorker(
            cache, w, h, patch=patch,
            margin=bool(self.frame_cache_on) and bool(self.margin_on),
            frame_cache=bool(self.frame_cache_on))

    def _ctl_policy(self, deck=None):
        """What the viewer draws, as the controller's patch fields: the
        size, depth, detail, thin policy, layers, frames, labels, font,
        grayscale, density and root."""
        if deck is None:
            deck = bool(getattr(self.cache, "is_jobdeck", False))
        w, h = self._viewport_size()
        depth = self._depth()
        visible = self._layers_arg()
        cut = self._effective_cut_px()
        detail = min(zip(DETAIL_PX, DETAIL_LEVELS),
                     key=lambda d: abs(d[0] - cut))[1] if cut > 0 else "exact"
        patch = {
            "pixels": [int(w), int(h)],
            "depth": "full" if depth is None else int(depth),
            "detail": detail,
            "thin": self._effective_thin(),
            "layers": "all" if visible is None else
            ([[int(k[0]), int(k[1])] for k in visible] if visible
             else "none"),
            "frames": bool(self.frames_on),
            # a deck's composite has no labels (renderd's rule)
            "labels": bool(self.labels_on) and not deck,
            "mono": bool(self._mono),
            # the density is of what a cut drops: none at exact (it would
            # only take pass 2's reserve from pass 1's budget) and none in a
            # deck's frames (renderd's deck pass) - floe2 render's rule too
            "density": bool(getattr(self, "density_on", False)) and self._density_available()
            and cut > 0 and not deck,
        }
        # the user's own cut rides on the nearest level: the controller
        # takes the level, then the cut in its place
        if getattr(self, "cut_custom", None) is not None:
            patch["cut_px"] = float(self.cut_custom)
        # the occupancy summary (View > occupancy summary, `o`): the user's
        # choice once made, else nothing - renderd's rule (a jobdeck's
        # passes draw it, a plain layout's frames do not)
        if getattr(self, "occupancy_on", None) is not None:
            patch["occupancy"] = bool(self.occupancy_on)
        if not deck:
            # a deck has no label font and no root (renderd's rule)
            patch["font_px"] = int(self.label_font_px)
            root = getattr(self, "_view_root", None)
            patch["root"] = None if root is None else {
                "src": 0, "cell": int(root["cell"])}
        return patch

    def _ctl_goto(self, w):
        dbu = self.dbu
        return {"kind": "goto", "center_um": [self.cx * dbu, self.cy * dbu],
                "width_um": self.spp * w * dbu}

    def _ctl_same_view(self, viewport):
        """The controller's viewport is the viewer's (float noise aside:
        the goto's um round trip)."""
        w, h = self._viewport_size()
        if (viewport["width"], viewport["height"]) != (w, h):
            return False
        b = viewport["bbox"]
        spp = (b[2] - b[0]) / w
        return (abs(spp / self.spp - 1.0) < 1e-9
                and abs((b[0] + b[2]) / 2 - self.cx) < 1e-3 * self.spp
                and abs((b[1] + b[3]) / 2 - self.cy) < 1e-3 * self.spp)

    def _ctl_adopt(self, snapshot):
        """The view the controller holds becomes the viewer's when it is
        not the same (its clamp is the viewer's own; a root it fitted)."""
        v = snapshot["state"]["viewport"]
        if self._ctl_same_view(v):
            return
        b = v["bbox"]
        self.cx = (b[0] + b[2]) / 2
        self.cy = (b[1] + b[3]) / 2
        self.spp = (b[2] - b[0]) / v["width"]

    def _ctl_navigate(self, nav):
        """Under the view controller a navigation is its own (P4e: the
        shared view maths, Viewport::navigate - the web's too): the viewer
        takes the view it made and shows it. False when the viewer moves
        the view itself - the Python loop, the view still opening, a drag
        in progress, or the edit refused (said on the status line)."""
        if not self._ctl() or self.worker.snapshot is None \
                or self._drag is not None:
            return False
        # with what else changed (the size first: the controller applies
        # pixels, then the root, then the navigation); the viewer's own view
        # is not sent - the navigation moves the controller's
        policy, patch = self._ctl_policy_diff()
        patch["navigation"] = nav
        reply = self.worker.edit(**patch)
        if reply is None:
            return False        # the redraw after the viewer's maths resends
        self._ctl_sent = policy
        self._ctl_adopt(reply)
        self.redraw()
        return True

    def _ctl_minimap(self, d):
        """The overview from the view's service (P4e, app-core
        view::minimap - the bake the web shows): {base, die, scale, ...}
        for depth d (None: plain), kept with the bases (a cache or root
        change drops them); None to bake it here."""
        if not self._ctl() or self.worker.snapshot is None:
            return None
        key = ("ctl", d)
        got = self._minimap_bases.get(key)
        if got is None:
            root = getattr(self, "_view_root", None)
            got = self.worker.minimap(d, None if root is None
                                      else root["bbox"])
            if got is None:
                return None
            self._minimap_bases[key] = got
        return got

    def _ctl_sync(self):
        """Send what changed since the last edit: the policy fields that
        differ, and the view as a goto when it moved."""
        snap = self.worker.snapshot
        if snap is None:
            return              # the view still opens; its patch is sent
        policy, patch = self._ctl_policy_diff()
        if not self._ctl_same_view(snap["state"]["viewport"]):
            patch["navigation"] = self._ctl_goto(self._viewport_size()[0])
        if not patch:
            return
        # said once: a refused edit (on the status line) is not sent again
        self._ctl_sent = policy
        reply = self.worker.edit(**patch)
        if reply is not None:
            self._ctl_adopt(reply)

    def _ctl_snap_drag(self):
        """A drag ends an even number of pixels from the frame on screen:
        the fill speckle's 2x2 phase is the frame's own (the controller
        draws the viewport as it is, where the Python loop snapped each
        frame to a 2 px layout grid), so an odd step would flip it when
        the new frame lands (field 2026-08-09). Keys step 16 px."""
        lf = self.last_frame
        if lf is None or abs(lf[2] / self.spp - 1.0) > 1e-9:
            return              # zoomed since: a new frame anyway
        fb, vb = lf[1], self.view_bbox()
        dx = (vb[0] - fb[0]) / self.spp
        dy = (fb[3] - vb[3]) / self.spp
        self.cx += (2 * round(dx / 2) - dx) * self.spp
        self.cy -= (2 * round(dy / 2) - dy) * self.spp

    def _ctl_policy_diff(self):
        """(the policy now, its fields that differ from the last sent)."""
        sent = self._ctl_sent if self._ctl_sent is not None else {}
        policy = self._ctl_policy()
        diff = {k: v for k, v in policy.items()
                if k not in sent or sent[k] != v}
        # an own cut ends with its level sent again: the controller drops
        # cut_px on a detail, and a field left out is no change
        if "cut_px" in sent and "cut_px" not in policy:
            diff["detail"] = policy["detail"]
        return policy, diff

    def _ctl_redraw(self):
        """redraw() under the controller: the edit, then the frame on
        screen recomposed at the view (the controller settles a pan,
        renders and supersedes); mid-drag the view is sent on release."""
        if self.worker.snapshot is None:
            self._display()
            return
        if self._drag is None:
            self._ctl_sync()
        bbox = self.view_bbox()
        self._display()
        if not self.visible and not self._structure_visible():
            self._set_status(bbox, "no layers visible", log=False)
            return
        self._set_status(bbox, "hierarchy depth %d" % self._depth()
                         if not self.visible else
                         "live (%d tiles)" % self.tiles_spanned(bbox))

    def _ctl_events(self):
        worker = self.worker
        events = worker.events()
        for i, (kind, value) in enumerate(events):
            if worker is not self.worker:
                break           # a frame handler replaced the worker
            try:
                if kind == "frame":
                    # the service keeps the files of its last few frames and
                    # removes the ones before: a frame whose file is gone
                    # was replaced while this loop was away, and a newer
                    # one follows in what was read - that one is shown. (It
                    # was read all the same and failed: `error: frame event
                    # failed`, found 2026-11-13 once an error's detail asked
                    # the service one thing more between two view edits.) A
                    # missing file with no frame after it is still an error.
                    if (not os.path.exists(value.get("path") or "")
                            and any(k == "frame" for k, _ in events[i + 1:])):
                        continue
                    self._ctl_frame(value)
                elif kind == "view":
                    self._ctl_view(value)
            except Exception as exc:
                import traceback
                traceback.print_exc()
                self._clear_pending()
                self._set_live_status(
                    "error: %s event failed: %s (see terminal)"
                    % (kind, exc))

    def _ctl_frame(self, frame):
        data, fw, fh, fmt = gtkservice.read_frame(frame)
        if fmt == "raw":
            pix = GdkPixbuf.Pixbuf.new_from_bytes(
                GLib.Bytes.new(data), GdkPixbuf.Colorspace.RGB, True, 8,
                fw, fh, fw * 4)
        else:
            loader = GdkPixbuf.PixbufLoader.new_with_type("png")
            loader.write(data)
            loader.close()
            pix = loader.get_pixbuf()
        if self.dump:
            pix.savev("/tmp/%s_frame.png" % APP, "png", [], [])
        fb = frame["bbox"]
        fspp = (fb[2] - fb[0]) / max(1, pix.get_width())
        key = ("ctl", frame["render_key"])
        report = frame.get("report") or {}
        if isinstance(report.get("max_depth"), int):
            self.max_depth = max(0, report["max_depth"])
        if frame["purpose"] == "margin":
            # the base under a pan's incoming strip (_display); with its
            # labels whole it is the frame shown too, and pans inside it
            # are crops (the controller draws nothing)
            self._margin_frame = (pix, fb, fspp, key)
            if not frame.get("labels_truncated"):
                self.last_frame = (pix, fb, fspp, key)
                self.worker.shown = frame["id"]
            self._display()
            self._margin_debug("landed frame %d" % frame["id"])
            return
        first = frame["render_rev"] != self._ctl_shown_rev
        self._ctl_shown_rev = frame["render_rev"]
        self.last_frame = (pix, fb, fspp, key)
        self.worker.shown = frame["id"]
        self._display()
        if first:
            # content is on screen: the mouse no longer waits
            self._clear_pending()
        self._depth_used = frame.get("depth")
        self.dstatus.set_text(self._depth_label())
        mode, brief = frame.get("perf") or ("", "")
        load, load_brief = self._load_note(report)
        mode, brief = load + mode, load_brief + brief
        fields = frame.get("fields") or {}
        if frame["final"]:
            if getattr(self, "_refining", False) or first:
                self.rstatus.set_text("rendering done.")
            self._refining = False
            # the settled frame's line on the terminal is the renderer's
            # report too: printed with `floe2 view --debug` alone
            # (0.12.481, user 2026-11-15: "터미널의 perf 줄도 --debug
            # 옵션에서만 나오게 수정해줘")
            if getattr(self, "_debug", False):
                b = self.view_bbox()
                print("%s  view %.1f x %.1f um"
                      % (mode, (b[2] - b[0]) * self.dbu,
                         (b[3] - b[1]) * self.dbu), flush=True)
        else:
            self._refining = True
            if fields.get("density_round"):
                self.rstatus.set_text("drawing the density under the cut...")
            elif fields.get("light_pending") == "1":
                # a light cache's frame before its placement fills are
                # done (renderd's light attempts, DIRECT_READ_PLAN L6)
                self.rstatus.set_text(
                    "reading the source... (fill round %s)"
                    % (fields.get("light_rounds") or "?"))
            else:
                self.rstatus.set_text(
                    "refining %d pages..." % (report.get("refining") or 1))
        # renderd's word on the density file (0.12.401): `nofile` when the
        # density stack asked had no design.ovs - a view root's own file
        # too - and the frame came out without it
        self._density_nofile = fields.get("density_none") == "nofile"
        self._set_status(self.view_bbox(), mode, brief)
        self._summary_banner_update(fields)
        self._cell_hl_follow()

    def _ctl_view(self, snap):
        """The controller's state: rendering (the busy cursor, the
        ticker), a frame renderd refused, Esc's cancel."""
        if isinstance(snap.get("max_depth"), int):
            self.max_depth = max(0, snap["max_depth"])
        rev = snap["render_rev"]
        busy = (snap["phase"] in ("rendering", "cancelling")
                and rev != self._ctl_shown_rev
                and snap.get("cancelled_rev") != rev)
        if busy and self._pending is None:
            self._pending = rev
            self._pending_t0 = time.perf_counter()
            self.rstatus.set_text("rendering…")
            self._set_cursor("progress")
            if self._pending_timer is None:
                self._pending_timer = GLib.timeout_add(
                    400, self._pending_tick)
        elif not busy and self._pending is not None \
                and snap["phase"] != "rendering":
            self._clear_pending()
        failure = snap.get("render_failure")
        if failure and failure["render_rev"] == rev \
                and self._ctl_said != ("failure", rev):
            self._ctl_said = ("failure", rev)
            self._refining = False
            self._clear_pending()
            self._set_live_status("error: %s" % failure["message"])
        if snap.get("cancelled_rev") == rev \
                and self._ctl_said != ("cancelled", rev):
            self._ctl_said = ("cancelled", rev)
            self._refining = False
            self._clear_pending()
            self.rstatus.set_text("render cancelled")

    def _margin_debug(self, message):
        if os.environ.get("FLOE_MARGIN_DEBUG"):
            sys.stderr.write("[margin] %s\n" % message)

    def _pending_tick(self):
        if self._pending is None:
            self._pending_timer = None
            self.rstatus.set_text("")
            return False
        el = time.perf_counter() - self._pending_t0
        self.rstatus.set_text("rendering…" if el < 1.5
                              else "rendering… %.0fs (Esc cancels)" % el)
        return True

    def _cancel_render(self):
        """Esc on a render in flight (field 2026-09-30: a slow render
        could neither be cancelled nor superseded): the view controller
        stops the frame in progress (renderd drops it at its next step);
        the frozen picture stays, and the next pan, zoom or change renders
        (the controller does not draw the cancelled state again)."""
        cancel = getattr(self.worker, "cancel", None)
        if cancel is not None:
            cancel()
        self._refining = False
        self._clear_pending()
        self.rstatus.set_text("render cancelled")
        self._display()

    def _clear_pending(self):
        self._pending = None
        if self._pending_timer is not None:
            GLib.source_remove(self._pending_timer)
            self._pending_timer = None
        self.rstatus.set_text("")
        self._set_cursor("move" if self._drag is not None
                         else self._idle_cursor())

    def _sync_allocation(self):
        """Resize fallback (field 2026-09-08): a title-bar double-click
        zoom on macOS quartz can resize the window without a
        size-allocate reaching the canvas, leaving the old picture in
        the corner until the next pan. The poll compares the live
        allocation with the last one the signal path saw and runs the
        same handler on a real change (a redraw at the new size)."""
        try:
            alloc = self.scroller.get_allocation()
        except Exception:
            return False
        if alloc.width <= 1 or alloc.height <= 1:
            return False
        if (alloc.width, alloc.height) == self._alloc_size:
            return False
        self._on_allocate(self.scroller, alloc, source="poll")
        return True

    def _poll(self):
        if self._quitting:
            return False
        try:
            # (the garbage collector's turn, on this thread alone)
            _MainThreadGc.step()
        except Exception:
            pass
        try:
            self._sync_allocation()
        except Exception:
            pass
        # watchdog: a render-service child that died (spawn failure,
        # crash, OOM kill) would otherwise leave a silent black view
        # with "rendering…" forever. Guarded like everything else in this
        # callback - an exception here (seen live: a bundle running a new
        # gui.py against a stale service.py without alive()) would make
        # GLib drop the poll source and silently freeze the viewer.
        try:
            w = self.worker
            # NOT while start_async is still spawning the daemon: the
            # Rust worker has no process yet in that window, so this
            # check used to flash a false "died (exit None)" right
            # after loading a layout (field report 2026-08-28); a real
            # startup failure is reported by _worker_start_finished.
            if w is not None and not w.alive() \
                    and not getattr(self, "_worker_starting", False) \
                    and not getattr(w, "_died_reported", False):
                w._died_reported = True
                self._clear_pending()
                self._set_live_status(
                    "error: render service died (exit %s) - see terminal; "
                    "restart the viewer" % w.exitcode())
        except Exception as exc:
            if not getattr(self, "_watchdog_warned", False):
                self._watchdog_warned = True
                sys.stderr.write(
                    "%s: watchdog check failed (%s) - mixed product "
                    "versions in the bundle? overwrite the WHOLE floe/ "
                    "and floe2/ packages, not single files\n" % (APP, exc))
        if self._ctl():
            self._ctl_events()   # the view's frames and states
        try:
            while self.worker is not None:
                res = self.worker.res.get_nowait()
                try:
                    self._handle_result(res)
                except Exception as exc:
                    # One bad result must never kill this callback: GLib
                    # removes a raising timeout source, which would freeze
                    # the viewer on a stale (usually black) frame with no
                    # error anywhere but the terminal. Keep polling and put
                    # the failure where the user looks - the status bar.
                    import traceback
                    traceback.print_exc()
                    self._clear_pending()
                    self._set_live_status(
                        "error: %s result failed: %s (see terminal)"
                        % (res.get("kind"), exc))
        except queue.Empty:
            pass
        # the DRC analysis jobs' answers (gtk-service; feature/jobdeck-drc)
        for name, poll in (("marker", self._drc_marker_poll),
                           ("delta", self._drc_delta_poll),
                           ("delta_cached", self._drc_group_cache_poll),
                           ("conflict", self._drc_conflict_poll),
                           ("selection", self._drc_selection_poll),
                           ("review", self._drc_review_poll),
                           ("verdict", self._drc_verdict_poll),
                           ("in-view", self._drc_query_poll)):
            try:
                poll()
            except Exception as exc:
                sys.stderr.write("[drc] %s result failed: %s\n" % (name, exc))
        # push buffered X output to the server: with cairo's core-protocol
        # fallback (CAIRO_DEBUG=xrender-version=-1, the XQuartz black-image
        # workaround) drawn updates otherwise sit in Xlib's output buffer
        # until some input event flushes them - the viewer looked frozen at
        # "rendering…" until the mouse moved. A flush with an empty buffer
        # is free, so doing it every poll tick is harmless everywhere.
        try:
            Gdk.Display.get_default().flush()
        except Exception:
            pass
        return True

    def _handle_result(self, res):
        """An answer of the view channel (floe/gtkservice.py ViewWorker):
        the cell tree's, a snap, a pick, a clip, or a refusal. The frames
        and the view's state come as events (_ctl_events)."""
        kind = res.get("kind")
        if kind in CELL_QUERY_KINDS:
            self._on_cell_result(res)
        elif kind == "snap":
            if res["seq"] == self._snap_seq \
                    and self.mode == "ruler":
                self._snap_res = res if res.get("found") else None
                self._display()
        elif kind == "pick":
            if res["seq"] == self._pick_seq:
                self._on_pick_result(res)
        elif kind == "clip":
            self._set_live_status(
                "clip saved: %s (%.2f MB, %d ms)"
                % (res["path"], res["size_mb"], res["ms"]))
        elif kind == "error":
            # an edit or request the view channel refused
            self._clear_pending()
            self._set_live_status("error: %s" % res.get("msg"))

    def _load_note(self, res):
        """The first settled frame after a load: the time from the file's
        selection to this frame, split into the cache and layer panel, the
        render service's open (renderd's own cache open in brackets) and the
        first frame (field 2026-09-22: a 10 s service open showed as the
        frame's 52 ms). A pair like perf_status's: the log line's note and
        the bar's, the total alone; empty for every other frame."""
        marks = getattr(self, "_load_marks", None)
        if not marks or "service" not in marks or res.get("refining"):
            return "", ""
        self._load_marks = None
        now = time.monotonic()
        service = "service %.1f s" % (marks["service"] - marks["cache"])
        opened = (marks.get("open") or {}).get("renderd_open_ms")
        if opened is not None:
            service += " [renderd open %.1f s]" % (opened / 1000.0)
        return ("loaded in %.1f s (cache %.1f s + %s + first frame %.2f s) · " % (
            now - marks["t0"], marks["cache"] - marks["t0"], service,
            now - marks["service"]), "loaded in %.1f s · " % (now - marks["t0"]))

    def _set_status(self, bbox, mode, brief=None, log=True):
        """The view's size and the lower bar's line. `log`: the line is
        the renderer's report - a frame's perf line, the `live (N tiles)`
        of a view on its way - and is shown with `floe2 view --debug` alone
        (user 2026-11-15: "상태줄의 로그 ... --debug 옵션에서만 나오게"); what
        is said to everybody (`no layers visible`) passes False. The line
        is kept, so a window whose debug parts come on later shows it
        (_debug_show)."""
        self._perf_said = (bbox, mode, brief, log)
        if log and not getattr(self, "_debug", False):
            mode, brief = "", None
        w_um = (bbox[2] - bbox[0]) * self.dbu
        h_um = (bbox[3] - bbox[1]) * self.dbu
        # CD-zoom views are far below 0.1um: fixed %.1f showed them all
        # as "0.0 x 0.0"
        fmt = lambda v: ("%.4f" if v < 0.1 else
                         "%.3f" if v < 1 else "%.1f") % v
        self.vstatus.set_text("view %s x %s um" % (fmt(w_um), fmt(h_um)))
        # a frame's bar shows its brief line, the tooltip the full one
        # (perf_status); other states are short already
        self.pstatus.set_text(mode if brief is None else brief)
        self.pstatus.set_tooltip_text(mode)

    def _loading_show(self, text):
        """A centred banner over the canvas plus the wait cursor while
        a load blocks the main loop (planning a deck's placements,
        loading a cache, rebuilding the layer panel) and then while
        the render service opens; _worker_start_finished hides it.
        The main loop is pumped so the banner paints before the
        blocking work (user call 2026-09-15: a 667-source deck gave
        no sign of life while it loaded or switched to the chip
        view). A redraw debounce that fires during the pump submits
        against the current worker or, mid-open, nothing."""
        banner = getattr(self, "_loading", None)
        if banner is None:
            return
        banner.set_text(text)
        banner.show()
        self._set_live_status(text)
        self._set_cursor("wait")
        for _ in range(3):
            while Gtk.events_pending():
                Gtk.main_iteration_do(False)

    def _loading_update(self, text):
        """A later phase's text, only while the banner is up."""
        banner = getattr(self, "_loading", None)
        if banner is not None and banner.get_visible():
            self._loading_show(text)

    def _loading_hide(self):
        banner = getattr(self, "_loading", None)
        if banner is None or not banner.get_visible():
            return
        banner.hide()
        self._set_cursor("move" if self._drag is not None
                         else self._idle_cursor())

    # ---- the occupancy summary of a deck's light sources (L6)

    def _summary_banner_update(self, fields):
        """After a frame: its deck passes left empty because their light
        source has no occupancy summary (renderd `summary_building`,
        DIRECT_READ_PLAN section 5.5) show the banner; none hides it.
        While it shows, the view is drawn again every few seconds
        (_summary_poll_tick): a summary another run adds (`floe2 index
        deck.jb`) appears by itself. The viewer builds none behind the
        open since 0.12.388 (user 2026-10-22): the open's modal index
        builds them; a deck whose modal index could not add one (the
        index's [summary] lines say why) shows this banner. The summary
        pass keeps no placement cap since 0.12.398 (the placement store,
        DIRECT_READ_PLAN §8.21)."""
        banner = getattr(self, "_summary_banner", None)
        if banner is None:
            return
        try:
            waiting = int(fields.get("summary_building") or 0)
        except (TypeError, ValueError):
            waiting = 0
        self._summary_waiting = waiting
        if waiting <= 0:
            if banner.get_visible():
                banner.hide()
            return
        banner.set_text(
            "occupancy summary missing for %d pass%s - wide views of those "
            "sources are empty (%s index %s adds it)"
            % (waiting, "" if waiting == 1 else "es", APP,
               os.path.basename(getattr(self.cache, "src", "") or "deck.jb")))
        banner.show()
        if self._summary_poll_timer is None:
            self._summary_poll_timer = GLib.timeout_add(
                3000, self._summary_poll_tick)

    def _summary_poll_tick(self):
        banner = getattr(self, "_summary_banner", None)
        if banner is None or not banner.get_visible() \
                or self.cache is None or self.worker is None:
            self._summary_poll_timer = None
            return False
        if self._pending is None and not getattr(self, "_refining", False):
            self.redraw(immediate=True)
        return True

    def _set_live_status(self, text):
        """Upper-row message; cursor motion may replace it."""
        self.status.set_text(text)
        self.status.set_tooltip_text(text)

    # ---- interaction --------------------------------------------------------
    def fit(self):
        if self.cache is None:
            return
        self._fit_after_worker_start = False
        if self._ctl_navigate({"kind": "fit"}):
            return
        bb = self._die_bbox()
        self.cx = (bb[0] + bb[2]) / 2
        self.cy = (bb[1] + bb[3]) / 2
        self.spp = self._fit_spp()
        self.redraw()

    def _fit_spp(self):
        bb = self._die_bbox()
        w, h = self._viewport_size()
        return max((bb[2] - bb[0]) / w, (bb[3] - bb[1]) / h) * 1.05

    def _clamp_view(self):
        """Zooms and pans never lose the die: spp is capped at
        FIT_ZOOM_OUT x the fit-view scale and the viewport stays
        inside the die bbox grown by a 10% outer margin per side
        (user call 2026-08-18: pinned to the exact die edge there
        was no room to band-zoom around edge features). Centered
        on an axis the viewport is wider than."""
        if self.cache is None:
            return
        db = self._die_bbox()
        mx = (db[2] - db[0]) * 0.10
        my = (db[3] - db[1]) * 0.10
        bb = (db[0] - mx, db[1] - my, db[2] + mx, db[3] + my)
        self.spp = min(max(self.spp, MIN_SPP),
                       self._fit_spp() * FIT_ZOOM_OUT)
        w, h = self._viewport_size()
        hx, hy = w / 2 * self.spp, h / 2 * self.spp
        if 2 * hx >= bb[2] - bb[0]:
            self.cx = (bb[0] + bb[2]) / 2
        else:
            self.cx = min(max(self.cx, bb[0] + hx), bb[2] - hx)
        if 2 * hy >= bb[3] - bb[1]:
            self.cy = (bb[1] + bb[3]) / 2
        else:
            self.cy = min(max(self.cy, bb[1] + hy), bb[3] - hy)

    def _gui_debug(self, message):
        if os.environ.get("FLOE_GUI_DEBUG"):
            sys.stderr.write("[gui] %s\n" % message)

    def _repaint_canvas(self):
        """Force the canvas to paint now (remote-X belt, same family
        as _remote_x_scroll_repaint): queue_draw only schedules, and a
        dropped expose after a resize leaves the previous picture on
        screen until the next event."""
        for widget in (getattr(self, "image", None),
                       getattr(self, "scroller", None)):
            if widget is None:
                continue
            widget.queue_draw()
            win = widget.get_window()
            if win is not None:
                try:
                    win.process_updates(True)
                except AttributeError:
                    pass  # removed in some GTK3 builds; queue_draw stands
        return False

    def _schedule_repaint(self):
        # after GTK's own allocation pass has settled
        GLib.timeout_add(40, self._repaint_canvas)

    def _on_allocate(self, _w, alloc, source="signal"):
        # GTK emits size-allocate on every set_from_pixbuf; reacting to
        # all of them would loop redraw -> allocate -> redraw forever
        # (visible as an endlessly re-submitted render). Only a real
        # size change matters.
        size = (alloc.width, alloc.height)
        if size == self._alloc_size:
            return
        self._gui_debug("allocation %dx%d via %s (was %s)"
                        % (alloc.width, alloc.height, source,
                           self._alloc_size))
        self._alloc_size = size
        # field 2026-09-08 (Linux): redrawing INSIDE the size-allocate
        # handler put a new, bigger pixbuf on the image in the middle
        # of GTK's layout pass; that pass did not pick the new size
        # request up and the old picture stayed until the next event
        # (one click) re-laid the canvas. Run the fit/redraw after the
        # pass, from idle, keyed to this size so a newer allocation
        # supersedes it.
        self._defer_allocation(size)

    def _defer_allocation(self, size):
        GLib.idle_add(self._after_allocate, size)

    def _after_allocate(self, size):
        if size != self._alloc_size:
            return False   # a newer allocation took over
        if not self._did_fit and size[0] > 50:
            self._did_fit = True
            if self.cache is None:
                pass   # empty start: _apply_cache fits on first load
            elif self._start_goto is not None:
                # (made again at the size that comes after it, as the fit
                # is: a window that starts maximized gets the screen's size
                # a moment later, and the goto's width is the view's then)
                place, self._start_goto = self._start_goto, None
                self._start_again = lambda: self._start_goto_make(place)
                self._start_again()
                self._start_fit_keep()
            elif getattr(self, "_start_again", None) is not None:
                # a view made before the canvas had its size - the error a
                # launch jumps to, its results loaded before the first
                # allocation (floe2 view SRC --drc DB --drc-rule R --drc-err
                # N; user 2026-11-15: the window stayed at the fit) - is
                # made again at the size the canvas has, in the fit's place
                self._start_again()
                self._start_fit_keep()
            else:
                self.fit()
                self._start_fit_keep()
        elif self._start_fit_follows():
            # the start's view for the size that came: the fit, or what a
            # launch put in its place
            again = getattr(self, "_start_again", None)
            if again is not None:
                again()
            else:
                self.fit()
            self._start_fit_keep()
        else:
            self._start_again = None
            self.redraw()
        # remote-X belt: the server may still drop the expose of the
        # resized canvas - paint it explicitly a moment later
        self._schedule_repaint()
        return False

    def _start_fit_keep(self):
        """The view the start's fit made, kept for a window that was asked
        to start maximized: where a window manager maps the window, the
        canvas is allocated at the default size first - and fitted - and
        gets the screen's size after it; a view that only kept its scale
        then would show the layout small in the middle of the big canvas."""
        self._start_fit = ((self.cx, self.cy, self.spp)
                           if getattr(self, "_start_maximized", False)
                           and self.cache is not None else None)
        if self._start_fit is None:
            self._start_again = None   # no size to follow

    def _start_goto_make(self, place):
        """A launch's --goto as the start's view: the fit's scale where it
        names no width, then the place."""
        self.spp = self._fit_spp()  # zoom baseline if no window given
        self.goto(*place)

    def _start_view_follow(self, again):
        """A view a launch made while the window starts - `again` makes it
        for the canvas as it is then - takes the fit's place as the start's
        view: before the canvas has its size, the first allocation makes it
        instead of fitting (the fit used to come after it and take the
        view); while the start's view still follows the size (a window
        that starts maximized is allocated at its default size first), the
        next size makes it again, until someone moves the view. After that
        the launch's view is a view like any other."""
        if not getattr(self, "_did_fit", True):
            self._start_again = again
        elif getattr(self, "_start_fit", None) is not None:
            self._start_again = again
            self._start_fit_keep()

    def _start_fit_follows(self):
        """Whether a new size of the canvas is fitted again: the viewer
        started maximized and the view is still the one its start's fit
        made - nobody moved it (a pan, a zoom, a goto, a jump to an error:
        each leaves another centre or scale, and from then on a size change
        keeps the scale as it always did). Told from the view itself, so no
        way of moving it has to say so."""
        # (a viewer made without its constructor - the gates' stand-ins -
        # kept none)
        kept, self._start_fit = getattr(self, "_start_fit", None), None
        if kept is None or self.cache is None:
            return False
        cx, cy, spp = kept
        return (abs(self.spp - spp) <= spp * 1e-6
                and abs(self.cx - cx) <= spp * 1e-3
                and abs(self.cy - cy) <= spp * 1e-3)

    def _idle_cursor(self):
        # plain arrow at rest; the crosshair belongs to the ruler
        # and error-box-select tools
        return ("crosshair" if self.mode in ("ruler", "esel")
                else "default")

    def _set_cursor(self, name):
        win = self.scroller.get_window()  # flateyes' set_viewport_cursor
        if win is not None:
            try:
                win.set_cursor(Gdk.Cursor.new_from_name(
                    win.get_display(), name))
            except Exception:
                pass

    def _end_gesture(self):
        """Abandon any in-flight pan/band gesture and restore the idle
        cursor. Needed when the button release can never reach us: a
        modal dialog opened mid-drag takes the GTK grab (its window
        receives the release), leaving _drag set forever - wheel zoom
        dead and every redraw debounce cancelled by the mid-pan branch.
        Wired to the toplevel's focus-out and the canvas grab-broken."""
        if self._drag is None and self._zoomdrag is None:
            return
        band = self._band_cur is not None
        self._drag = None
        self._drag_origin = None
        self._drag_moved = False
        self._drag_btn = None
        self._zoomdrag = None
        self._band_cur = None
        self._band_ext = None
        self._set_cursor(self._idle_cursor())
        if band:
            self._display()  # erase the rubber band

    def _drag_threshold(self, ox, oy, x, y):
        """Click-vs-drag via GTK's gtk-dnd-drag-threshold (8px default,
        setting-driven): the old hardcoded 3px misread jittery remote-X
        pointers (Exceed/XQuartz/VNC) as pans, silently eating picks."""
        return self.scroller.drag_check_threshold(
            int(ox), int(oy), int(x), int(y))

    def _focus_view(self):
        """Put keyboard focus back on the canvas: deactivate the
        menubar (a menu item can stay selected after a click on some
        backends, taking every key) and focus the scroller so no entry
        holds the keys. Synchronous; see _restore_keys for the
        deferred form used after menus and dialogs."""
        menubar = getattr(self, "_menubar", None)
        if menubar is not None:
            menubar.deactivate()
        scroller = getattr(self, "scroller", None)
        if scroller is not None and scroller.get_can_focus():
            scroller.grab_focus()
        elif getattr(self, "window", None) is not None:
            self.window.set_focus(None)

    def _restore_keys(self):
        """Hand key commands back to the view after a menu closes or
        a transient dialog goes away (field 2026-09-05: after using a
        menu, g and the other keys stayed dead until a canvas click).
        Some backends - macOS quartz, XQuartz/remote X menu grabs -
        leave the menubar active or the window without a usable focus
        widget. Deferred to idle so GTK's own teardown runs first."""
        def _later():
            self.window.present()
            self._focus_view()
            return False
        GLib.idle_add(_later)

    def _on_press(self, _w, ev):
        if self.cache is None:
            return False
        self._focus_view()
        # a render in flight no longer holds the mouse (2026-09-30): the
        # next view supersedes it at the daemon's frontier, as the keys
        # always did
        if ev.type == Gdk.EventType.DOUBLE_BUTTON_PRESS \
                and ev.button == 1 \
                and self.mode not in ("ruler", "esel") \
                and self._drc is not None \
                and not (ev.state & (Gdk.ModifierType.CONTROL_MASK
                                     | Gdk.ModifierType.SHIFT_MASK)):
            # canvas double-click ON a marker = grid-number double-
            # click (full jump). Checked BEFORE the drag guard: the
            # paired single press has already re-armed a pan drag,
            # which used to swallow the double event - disarm it.
            hit = self._drc_hit_at(ev.x, ev.y)
            if hit is not None:
                self._drag = None
                self._drag_origin = None
                self._drag_moved = False
                self._drag_btn = None
                self._set_cursor(self._idle_cursor())
                ci, ei = hit
                if self._drcwin is not None:
                    self._drc_goto_cell(ci, ei)
                self._drc_jump(ci, ei, isolate=True)
                return True
        if self._drag is not None or self._zoomdrag is not None:
            # one gesture at a time: a second button pressed mid-pan
            # must not clobber the drag state (spurious pick on
            # release) or arm an invisible rubber band (chord zoom)
            return True
        if ev.button == 1:
            if self.mode == "ruler":
                self._ruler_free = bool(ev.state &
                                        Gdk.ModifierType.SHIFT_MASK)
                # Defer the measurement click until release. The same
                # button is a pan gesture once it crosses the normal drag
                # threshold, so ruler mode does not lose navigation.
            self._drag = (ev.x, ev.y)
            self._drag_origin = self._drag
            self._drag_moved = False
            self._drag_btn = 1
            self._set_cursor("move")
        elif ev.button == 2:
            self._drag = (ev.x, ev.y)
            self._drag_origin = self._drag
            self._drag_moved = False
            self._drag_btn = 2
            self._set_cursor("move")
        elif ev.button == 3:
            self._zoomdrag = (ev.x, ev.y)
            self._band_cur = None
            self._band_ext = (ev.x, ev.x)
        return True

    def _on_release(self, _w, ev):
        if self.cache is None:
            return False
        if ev.button in (1, 2):
            if self._drag is not None and ev.button != self._drag_btn:
                return True  # not the button that started the pan
            was_drag = self._drag is not None
            panned = was_drag and self._drag_moved
            self._drag = None
            self._drag_origin = None
            self._drag_moved = False
            self._drag_btn = None
            self._set_cursor("progress" if self._pending is not None
                             else self._idle_cursor())
            if panned:
                if self._ctl():
                    self._ctl_snap_drag()
                self.redraw()   # pan ended: render the final position
            elif was_drag and ev.button == 1:
                # A stationary left click keeps its mode-specific action;
                # movement is exclusively a pan gesture in both modes.
                if self.mode == "ruler":
                    self._ruler_click(ev)
                elif self.mode == "esel":
                    self._esel_click(ev)
                else:
                    self._pick_click(ev)
            return True
        if ev.button != 3 or self._zoomdrag is None:
            return True
        x0, y0 = self._zoomdrag
        bmin, bmax = self._band_ext or (x0, x0)
        self._zoomdrag = None
        self._band_cur = None
        self._band_ext = None
        # Direction from the DOMINANT excursion of the whole gesture,
        # not the release-point sign: a zoom-out drag that wobbles back
        # past the anchor used to fit the residual sliver box to the
        # viewport - a runaway ~100x zoom-in.
        forward = (bmax - x0) >= (x0 - bmin)
        dx = (ev.x - x0) if forward else (x0 - ev.x)
        dy = abs(ev.y - y0)
        if dx < 5 and dy < 5:
            # a plain right click stays inert; a visibly drawn band
            # that collapsed must not vanish without a word
            if max(bmax - x0, x0 - bmin) >= 5:
                self._set_live_status("zoom band cancelled")
            self._display()
            return True
        w, h = self._viewport_size()
        # the controller's band: fractions of the view from its top-left,
        # the axes the gesture spanned, its direction (at most a view away)
        start = [min(1.0, max(0.0, x0 / w)), min(1.0, max(0.0, y0 / h))]
        end = [min(start[0] + 1.0, max(start[0] - 1.0, ev.x / w)),
               min(start[1] + 1.0, max(start[1] - 1.0, ev.y / h))]
        if self._ctl_navigate({"kind": "band", "start": start, "end": end,
                               "axes": [dx >= 5, dy >= 5],
                               "outward": not forward}):
            return True
        bbox = self.view_bbox()
        lx0 = bbox[0] + min(x0, ev.x) * self.spp
        lx1 = bbox[0] + max(x0, ev.x) * self.spp
        ly0 = bbox[3] - max(y0, ev.y) * self.spp
        ly1 = bbox[3] - min(y0, ev.y) * self.spp
        w, h = self._viewport_size()
        self.cx = (lx0 + lx1) / 2
        self.cy = (ly0 + ly1) / 2
        # Only the axes the user actually spanned take part in the
        # fit: a long, thin band (routine on wires) zooms by its long
        # axis instead of dying silently or exploding on the sliver.
        if forward:  # the box fills the viewport
            scale = [s for s, d in (((lx1 - lx0) / w, dx),
                                    ((ly1 - ly0) / h, dy)) if d >= 5]
            self.spp = max(scale)
        else:        # zoom out by the viewport/box ratio
            fac = [f for f, d in ((w / max(dx, 1.0), dx),
                                  (h / max(dy, 1.0), dy)) if d >= 5]
            self.spp *= max(fac)
        self.redraw()
        return True

    def _on_motion(self, _w, ev):
        if self.cache is None:
            return False
        self._update_cursor(ev)
        self._pointer = (ev.x, ev.y)
        # (a render in flight no longer freezes the view, 2026-09-30:
        # the pan moves it live over the frozen frame, and the render
        # of the new position supersedes the old one)
        if self._drag is not None and ev.state & (
                Gdk.ModifierType.BUTTON1_MASK |
                Gdk.ModifierType.BUTTON2_MASK):
            # (no marker grows under the pointer while a button drags)
            self._drc_hover_set(None)
            if not self._drag_moved and self._drag_origin is not None:
                ox, oy = self._drag_origin
                if not self._drag_threshold(ox, oy, ev.x, ev.y):
                    return True
                self._drag_moved = True
            ddx, ddy = ev.x - self._drag[0], ev.y - self._drag[1]
            self._drag = (ev.x, ev.y)
            self.cx -= ddx * self.spp
            self.cy += ddy * self.spp
            self.redraw()
            return True
        if self._zoomdrag is not None and \
                ev.state & Gdk.ModifierType.BUTTON3_MASK:
            self._drc_hover_set(None)
            self._track_band(ev)
            self._display()
            return True
        self._drc_tooltip(ev)
        self._drc_hover_update()
        self._hover(ev)
        return True

    def _on_canvas_leave(self, _w, ev):
        """The pointer left the canvas: no marker is under it."""
        if getattr(ev, "detail", None) == Gdk.NotifyType.INFERIOR:
            return False   # (into a window of the canvas' own)
        self._pointer = None
        self._drc_hover_set(None)
        return False

    def _drc_hover_update(self):
        """The marker under the pointer (0.12.526, user 2026-11-18: "마커위에
        마우스 커서가 hover하면 조금 더 커지게"): the nearest marker painted
        within the pick's reach of the pointer - the one a click there
        picks -, as the frame on the canvas has it; looked for at each
        motion and after each frame composed. None while the pointer is out
        of the canvas, a button drags or the markers are hidden (Tab)."""
        # (getattr: the contract tests compose with viewers built by hand)
        p = getattr(self, "_pointer", None)
        hit = None
        if (p is not None and getattr(self, "overlay_mode", 0) == 0
                and getattr(self, "_drag", None) is None
                and getattr(self, "_zoomdrag", None) is None):
            hit = self._drc_hit_near(p[0], p[1])
        self._drc_hover_set(hit)

    def _drc_hover_set(self, hit):
        """Show the marker under the pointer - `hit` from _drc_hit_near -
        as a DRC_HOVER_PX circle in its colour over it; None hides it. It
        is a small widget over the canvas, as the rulers' labels are: the
        canvas is not composed again and only the circle's spot is drawn
        anew, so a pointer crossing a field of markers costs a move of the
        widget each time the marker under it changes and nothing while it
        stays on one (an overlay's redraw was 5-14 ms on the gate's Mac
        with 150,000 errors and a cell's 4,096 instances, and a remote
        display gets the whole canvas each time)."""
        if hit is None:
            if getattr(self, "_drc_hover", None) is not None:
                self._drc_hover = None
                if self._drc_hover_img is not None:
                    self._drc_hover_img.hide()
            return
        ci, ei, x, y, color = hit
        r = DRC_HOVER_PX // 2
        side = 2 * r + 1
        w, h = self._viewport_size()
        ox, oy = int(round(x)) - r, int(round(y)) - r
        # (the part on the canvas: a margin is never negative, and a widget
        # past the overlay's edge would be squeezed into it)
        left, top = max(0, ox), max(0, oy)
        right, bottom = min(w, ox + side), min(h, oy + side)
        if right <= left or bottom <= top:
            self._drc_hover_set(None)
            return
        shown = (ci, ei, left, top, right, bottom, color)
        if shown == self._drc_hover:
            return
        self._drc_hover = shown
        sprite = self._drc_hover_sprites.get(color)
        if sprite is None:
            sprite = self._drc_hover_sprites[color] = GdkPixbuf.Pixbuf.new_from_bytes(
                GLib.Bytes.new(circle_rgba(r, color, solid=True)),
                GdkPixbuf.Colorspace.RGB, True, 8, side, side, side * 4)
        if (left, top, right, bottom) != (ox, oy, ox + side, oy + side):
            sprite = sprite.new_subpixbuf(left - ox, top - oy, right - left, bottom - top)
        img = self._drc_hover_img
        if img is None:
            img = self._drc_hover_img = Gtk.Image()
            img.set_halign(Gtk.Align.START)
            img.set_valign(Gtk.Align.START)
            img.set_no_show_all(True)
            self.overlay.add_overlay(img)
            try:
                self.overlay.set_overlay_pass_through(img, True)
            except AttributeError:  # GTK < 3.18
                pass
        img.set_from_pixbuf(sprite)
        img.set_margin_start(left)
        img.set_margin_top(top)
        img.show()

    def _drc_tooltip(self, ev):
        """Hover tooltip over a painted DRC marker: rule name,
        #local(global) number and waive status (user call
        2026-08-18)."""
        tip = None
        if self._drc is not None:
            hit = self._drc_hit_at(ev.x, ev.y)
            if hit is not None:
                ci, ei = hit
                try:
                    e = self._drc.checks[ci].errors[ei]
                    noted = (hasattr(self._drc, "get_note")
                             and self._drc.get_note(ci, ei))
                    tip = "%s #%d(%d)%s%s" % (
                        self._drc.checks[ci].name, ei + 1, e.num,
                        " · waived"
                        if self._drc_waived(self._drc, ci, ei)
                        else "",
                        " · note" if noted else "")
                except Exception:
                    tip = None
        if tip != self._drc_tip:
            self._drc_tip = tip
            self.scroller.set_tooltip_text(tip)
            if tip:
                self.scroller.trigger_tooltip_query()

    def _track_band(self, ev):
        self._band_cur = (ev.x, ev.y)
        bmin, bmax = self._band_ext or (ev.x, ev.x)
        self._band_ext = (min(bmin, ev.x), max(bmax, ev.x))

    def _on_scroll(self, _w, ev):
        if self.cache is None:
            return False
        # (a render in flight is superseded by the zoom, 2026-09-30)
        # some X setups (libinput button-scroll, Exceed pointer emulation)
        # synthesize wheel events while a button is held down - that must
        # never zoom in the middle of a pan or a rubber-band drag
        if self._drag is not None or self._zoomdrag is not None:
            return True
        if ev.state & (Gdk.ModifierType.BUTTON1_MASK |
                       Gdk.ModifierType.BUTTON2_MASK |
                       Gdk.ModifierType.BUTTON3_MASK):
            return True
        delta = 0.0
        if ev.direction == Gdk.ScrollDirection.UP:
            delta = 1.0
        elif ev.direction == Gdk.ScrollDirection.DOWN:
            delta = -1.0
        elif ev.direction == Gdk.ScrollDirection.SMOOTH:
            ok, _dx, dy = ev.get_scroll_deltas()
            if ok:
                # Trackpads can report a large accumulated delta in one
                # event. Never turn that into a multi-step zoom jump.
                delta = max(-1.0, min(1.0, -dy))
        if delta:
            self._zoom_at(ev.x, ev.y, WHEEL_ZOOM_STEP ** delta)
        return True

    def _zoom_at(self, x, y, factor):
        w, h = self._viewport_size()
        if self._ctl_navigate({"kind": "zoom", "factor": factor, "anchor": [
                min(1.0, max(0.0, x / w)), min(1.0, max(0.0, y / h))]}):
            return
        bbox = self.view_bbox()
        px = bbox[0] + x * self.spp
        py = bbox[3] - y * self.spp
        self.spp *= factor
        nb = self.view_bbox()
        self.cx += px - (nb[0] + x * self.spp)
        self.cy += py - (nb[3] - y * self.spp)
        self.redraw()

    def _zoom_center(self, factor):
        if self._ctl_navigate({"kind": "zoom", "factor": factor,
                               "anchor": [0.5, 0.5]}):
            return
        self.spp *= factor
        self.redraw()

    def _snap_pan_px(self, pixels):
        """§F2R-16: pan deltas snap to multiples of 16 device pixels -
        the renderer's fill-phase period - so the service can reuse
        the previous frame's overlap byte-exactly. The step changes by
        at most 8px (<1% of a viewport), never below one period."""
        return max(16, int(round(pixels / 16.0)) * 16)

    def _pan_view(self, direction, frac=KEY_PAN_FRACTION):
        """Move the viewport by a fraction of its visible extent
        (arrows: half; Shift+arrows: the fine tenth - user call
        2026-09-04, moved off Ctrl)."""
        width, height = self._viewport_size()
        px = self._snap_pan_px(width * frac)
        py = self._snap_pan_px(height * frac)
        # the controller's pan takes the step as a fraction of the view
        # (snap: the 16 px period - this one is on it already)
        step = {"Left": (-px / width, 0.0), "Right": (px / width, 0.0),
                "Up": (0.0, py / height), "Down": (0.0, -py / height)}
        if direction in step and self._ctl_navigate({
                "kind": "pan", "x": step[direction][0],
                "y": step[direction][1], "snap": True}):
            return
        dx = px * self.spp
        dy = py * self.spp
        if direction == "Left":
            self.cx -= dx
        elif direction == "Right":
            self.cx += dx
        elif direction == "Up":
            self.cy += dy
        elif direction == "Down":
            self.cy -= dy
        self.redraw()

    # ---- keys ----------------------------------------------------------------
    def _command_key(self, ev):
        """Key name for shortcut matching. When a non-Latin layout owns
        the keyboard (e.g. the OS IME in hangul mode) the keyval is a
        jamo and "d"/"f"/... would go dead - re-translate the hardware
        keycode against the keymap's groups and take the first Latin
        result (flateyes' command_key). Special keys (Escape, arrows:
        no unicode) keep their name as is."""
        name = Gdk.keyval_name(ev.keyval) or ""
        uni = Gdk.keyval_to_unicode(ev.keyval)
        if not uni or uni < 0x80:
            return name  # ASCII or a special key: usable as is
        try:
            keymap = Gdk.Keymap.get_for_display(self.window.get_display())
            shift = ev.state & Gdk.ModifierType.SHIFT_MASK
            for group in range(4):
                res = keymap.translate_keyboard_state(
                    ev.hardware_keycode, shift, group)
                if res[0] and 0 < Gdk.keyval_to_unicode(res[1]) < 0x80:
                    return Gdk.keyval_name(res[1])
        except (AttributeError, TypeError):
            pass  # keymap API surprises: fall back to the raw name
        return name

    def _on_key(self, _w, ev):
        if self._gdlg is not None:
            # the goto dialog owns keyboard input, but some backends
            # (macOS quartz) still deliver its keys to the main window
            # too. The Entry guard below only checks the *main* window's
            # focus, so a coordinate typed into the dialog would walk the
            # depth shortcut (e.g. "5240" -> depth 5,2,4,0). Yield to it.
            return False
        focus = self.window.get_focus()
        if isinstance(focus, Gtk.Entry):
            return False  # typing in the depth spinbox etc.
        name = self._command_key(ev)
        # the DRC pane's lists take the cursor keys while one of them has
        # the keys (user 2026-11-15: "drc 룰 목록, CD 그룹, 에러 목록에
        # 포커스가 가 있을 경우 커서키로 이동할 수 있게 수정해줘"; until
        # 0.12.496 the arrows panned the view wherever the keys were)
        if focus is not None and self._drc_list_key(focus, name):
            return True
        ctrl = bool(ev.state & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(ev.state & Gdk.ModifierType.SHIFT_MASK)
        # Calibre-parity chords first, so Ctrl+A never falls through
        # to the plain-letter branches below
        if ctrl and name in ("z", "Z"):
            self._zoom_center(CAL_ZOOM_IN)     # zoom in 50%
        elif name == "Z":
            self._zoom_center(1 / CAL_ZOOM_IN)  # Shift+Z: out 50%
        elif ctrl and name in ("a", "A"):
            self.fit()                          # zoom all
        elif ctrl and name == "period":
            self._goto_dialog()                 # Ctrl+.
        elif ctrl and name == "comma":
            self._jobdeck_toggle_view()         # Ctrl+, level <-> chip
        elif ctrl and name in ("c", "C"):
            self._copy_view()                   # view -> clipboard
        elif ctrl and name == "T":
            self._cell_root_top()               # Ctrl+Shift+T: back to top
        elif name == "f":
            self._set_frames(not self.frames_on)
        elif name in ("Left", "Right", "Up", "Down"):
            self._pan_view(name, KEY_PAN_FRACTION_FINE if shift
                           else KEY_PAN_FRACTION)
        elif name in ("KP_Left", "KP_Right", "KP_Up", "KP_Down"):
            self._pan_view(name[3:], KEY_PAN_FRACTION_FINE if shift
                           else KEY_PAN_FRACTION)
        elif name in ("plus", "equal", "KP_Add"):
            self._zoom_center(1 / 1.25)
        elif name in ("minus", "KP_Subtract"):
            self._zoom_center(1.25)
        elif name == "r":
            self._toggle_ruler()
        elif name == "m":
            self._toggle_snap()
        elif name == "C":
            # Shift+C: frame (cell reference outline) toggle,
            # Calibre parity; plain c stays unbound (user call)
            self._set_frames(not self.frames_on)
        elif name == "k":
            self._ruler_pop()
        elif name == "K":
            self._rulers_clear()
        elif name == "Escape":
            self._esc()
        elif name in ("Tab", "ISO_Left_Tab"):
            self._toggle_overlays()
        elif name == "d":
            self._detail_dialog()
        elif name == "g":
            self._goto_dialog()
        elif name == "t" and not ctrl:
            # (Ctrl+T - the view root - was removed, user 2026-09-30: the
            # Cell menu and a double-click in the cell tree set it; Ctrl+T
            # does nothing, it does not fall through to the tree's focus)
            self._cell_tree_focus()
        elif name == "less":
            self._depth_step(-1)
        elif name == "greater":
            self._depth_step(1)
        elif name == "v":
            self._toggle_density()
        elif name == "o":
            self._toggle_occupancy()
        elif name == "s":
            self._toggle_border()
        elif name == "b":
            self._set_mono(not self._mono)
        elif name == "e":
            self._esel_toggle()
        elif name == "i":
            self._drc_svrf_dialog(toggle=True)
        elif name == "w":
            self._drc_waive_key()
        elif name == "n":
            self._drc_note_key()
        elif name in ("period", "KP_Decimal"):
            self._drc_step(1)     # next error (n freed for notes)
        elif name == "comma":
            self._drc_step(-1)    # previous error
        elif name == "q":
            self._confirm_quit()
        elif len(name) == 1 and name.isdigit():
            self._depth_digit(int(name))
        elif name.startswith("KP_") and name[3:].isdigit():
            self._depth_digit(int(name[3:]))
        else:
            return False
        return True

    # ---- depth -----------------------------------------------------------------
    def _depth_digit(self, n):
        """Digit keys set the depth directly. A quick '9 9' (typing
        99) means FULL depth (999 internally): 'full' never had a
        key of its own (user call 2026-08-10)."""
        now = time.time()
        if n == 9 and self._digit_last == 9 \
                and now - self._digit_t < 1.0:
            self._digit_last = None
            self._set_depth(999)
            return
        self._digit_last = n
        self._digit_t = now
        self._set_depth(n)

    def _depth(self):
        d = self.depth_value
        return None if d >= 999 else max(0, d)

    def _depth_key(self):
        """Render-key component of the frame identity."""
        return self._depth()

    def _depth_note(self, used):
        """Status-line suffix naming the depth a frame rendered at."""
        return "" if used is None else ", depth %d" % used

    def _max_depth(self):
        """The deepest level the view holds: the view root's height under
        a root (depth counts from the root - SPEC-VIEWER §8c; the planner
        always did, the viewer kept the file top's), else the file top's
        height the daemon reports; None while unknown."""
        root = getattr(self, "_view_root", None)
        if root is not None and isinstance(root.get("height"), int):
            return max(0, root["height"])
        return self.max_depth

    def _depth_label(self):
        if self.meta is None:
            return "depth: -"
        d = self._depth()
        cap = self._max_depth()
        # at or past the deepest level the view is whole: `*`, as full
        current = "*" if d is None or (cap is not None and d >= cap) \
            else str(d)
        maximum = "?" if cap is None else str(cap)
        lbl = "depth: %s/%s" % (current, maximum)
        if self.meta.get("bands") or self.meta.get("vfs"):
            lbl += " · detail: %s" % self._detail_text()
        if self.meta.get("vfs"):
            # the renderer's switches - the page hairline policy, the
            # density under the cut, the occupancy summary - are named
            # with `floe2 view --debug` alone (user 2026-11-15: "thin:keep,
            # density:on occupancy:off 도 --debug 옵션에서만 나오게")
            debug = getattr(self, "_debug", False)
            # the page hairline policy in force: cull = thin shapes
            # may be omitted at wide views (plain layout default)
            if debug:
                lbl += " · thin:%s" % self._effective_thin()
            lbl += " · frame:%s" % (
                "on" if self.frames_on else "off")
            # the density under the cut (View > density, `v`): none where
            # the cache has no design.ovs (0.12.401; the default on holds
            # only with the file)
            if debug and self._density_key() is not None:
                if self.density_on and (not self._density_available()
                                        or getattr(self, "_density_nofile", False)):
                    lbl += " · density:none (no design.ovs)"
                else:
                    lbl += " · density:%s" % (
                        "on" if self.density_on else "off")
            # the occupancy summary (View > occupancy summary, `o`)
            if debug and self._occupancy_key() is not None:
                lbl += " · occupancy:%s" % (
                    "on" if self._occupancy_effective() else "off")
            # the kind of cache (DIRECT_READ_PLAN L6): a layout opened from
            # a light cache (its geometry read from the source), a deck's
            # light sources
            if self.meta.get("cache") == "light":
                lbl += " · cache:light"
            else:
                deck = self.meta.get("jobdeck") or {}
                if deck.get("light_sources"):
                    lbl += " · light:%d/%d" % (deck["light_sources"],
                                               deck.get("sources") or 0)
        return lbl

    def _depth_step(self, delta):
        """< / > step the depth by one, clamped to [0, the view's deepest
        level] (the view root's height under a root, 2026-09-30).
        'full' (999) - or any depth past that level - is treated as the
        deepest explicit level so a step down lands on real geometry
        rather than walking through levels that change nothing."""
        cap = self._max_depth()
        cap = cap if cap is not None else 999
        cur = min(self.depth_value, cap)
        self._set_depth(max(0, min(cap, cur + delta)))

    def _set_depth(self, n, redraw=True):
        value = max(0, min(999, int(n)))
        changed = value != self.depth_value
        self.depth_value = value
        if self._ddlg is not None:
            spin = getattr(self._ddlg, "_spin", None)
            if spin is not None and \
                    int(spin.get_value()) != self.depth_value:
                spin.set_value(self.depth_value)
        if changed and redraw:
            self._on_depth()

    def _set_detail(self, n, redraw=True):
        self.detail = max(0, min(len(DETAIL_PX) - 1, int(n)))
        self.cut_px = DETAIL_PX[self.detail]
        self.cut_custom = None
        if redraw:
            self._on_depth()  # same refresh: status label + re-render

    def _set_cut_px(self, text, redraw=True):
        """The `d` dialog's own cut: a number of screen px in
        (0, MAX_CUT_PX]. Returns None when set, else why it was refused."""
        try:
            px = float(str(text).strip())
        except ValueError:
            return "not a number: %r" % (text,)
        if not (0.0 < px <= MAX_CUT_PX):
            return "a cut is over 0 and at most %g px" % MAX_CUT_PX
        self.cut_custom = px
        if redraw:
            self._on_depth()
        return None

    def _density_available(self):
        """The occupancy density file the density stack draws by:
        design.ovs in the cache (user 2026-10-25: without it the density is
        refused, not planned from the pages; a light cache has none, a
        jobdeck draws no density)."""
        cache = getattr(self, "cache", None)
        if cache is None or getattr(cache, "is_jobdeck", False):
            return False
        d = getattr(cache, "dir", None)
        return bool(d) and os.path.isfile(os.path.join(d, "design.ovs"))

    def _occupancy_available(self):
        """The occupancy summary file: design.ovo in a layout's cache
        (user 2026-10-25: without it the summary is refused); a jobdeck's
        passes are renderd's rule (DeckSource::summary_pending)."""
        cache = getattr(self, "cache", None)
        if cache is None:
            return False
        if getattr(cache, "is_jobdeck", False):
            return True
        d = getattr(cache, "dir", None)
        return bool(d) and os.path.isfile(os.path.join(d, "design.ovo"))

    DENSITY_REFUSED = ("density needs design.ovs in the cache (floe-index ovs "
                       "CACHE adds it to a full index; a light cache has none)")
    OCCUPANCY_REFUSED = ("occupancy summary needs design.ovo in the cache "
                         "(floe2 index SRC --occupancy-only adds it)")

    def _toggle_density(self):
        """`v` / View > density under the cut (user 2026-10-05: "a density
        on/off option in the viewer"): the shapes the detail's cut drops,
        drawn as the density of the area they cover (renderd's density
        stack, CUT_DENSITY_DESIGN §10.12) - on or off from the next frame;
        the status line says which. The Rust renderer only. Without the
        cache's design.ovs the toggle on is refused (0.12.401, user
        2026-10-25) and the status line says what makes the file.
        A toggle of `floe2 view --debug` alone (user 2026-11-15: "density
        on/off 토글 기능도 --debug 옵션에서만 동작하게"): without the option
        the key does nothing and the command is in no menu - --density (and
        a forwarded density=) still sets the start."""
        if not getattr(self, "_debug", False):
            return
        if self._density_key() is None:
            return
        if not self.density_on and not self._density_available():
            self.rstatus.set_text(self.DENSITY_REFUSED)
            return
        self.density_on = not self.density_on
        self._on_depth()

    def _toggle_occupancy(self):
        """`o` / View > occupancy summary at wide views (user 2026-10-20:
        "an option to see the occupancy when a jobdeck-indexed layout is
        opened in the plain layout mode"): the wide views drawn from the
        cache's design.ovo - a jobdeck's passes have it by renderd's rule,
        a plain layout's frames do not (user decision 2026-09-24) even
        with the file there (a source a jobdeck indexed, opened on its
        own) - on or off from the next frame, the opposite of what is in
        force; the status line says which, the perf line says `summary:
        none (nofile)` where the cache has no design.ovo. The Rust
        renderer only. A toggle of `floe2 view --debug` alone (user
        2026-11-15: "occupancy on/off 토글기능 ... --debug 옵션에서만
        동작하게"): without the option the key does nothing and the command
        is in no menu - --occupancy (and a forwarded occupancy=) still
        sets the start."""
        if not getattr(self, "_debug", False):
            return
        if self._occupancy_key() is None:
            return
        if not self._occupancy_effective() and not self._occupancy_available():
            # (0.12.401, user 2026-10-25: the file refuses the summary)
            self.rstatus.set_text(self.OCCUPANCY_REFUSED)
            return
        self.occupancy_on = not self._occupancy_effective()
        self._on_depth()

    def _sync_density_capability(self):
        item = getattr(self, "_density_menu_item", None)
        if item is not None:
            item.set_sensitive(self._density_key() is not None)
        # the occupancy summary toggle: the same renderer's (2026-10-20)
        item = getattr(self, "_occupancy_menu_item", None)
        if item is not None:
            item.set_sensitive(self._occupancy_key() is not None)

    def _effective_thin(self):
        """The page hairline policy in force: the explicit mode, or
        for auto keep - a jobdeck's all-thin pages (mask data is
        hairlines) and, since 2026-09-23 (user decision), a plain
        layout's too; cull (all-thin pages dropped at wide views, the
        former layout policy) only when asked for."""
        mode = getattr(self, "thin_mode", "auto")
        if mode in ("keep", "cull"):
            return mode
        return "keep"

    def _set_thin(self, mode, redraw=True):
        """View > keep thin shapes / --thin / a forwarded thin=: switch
        the page hairline policy for this source (review 2026-09-11: a
        mask OASIS opened on its own can ask for the mask policy)."""
        if mode not in ("auto", "keep", "cull"):
            return
        before = self._effective_thin()
        self.thin_mode = mode
        if before != self._effective_thin():
            self.dstatus.set_text(self._depth_label())
            if redraw:
                self._on_depth()

    def _set_frames(self, enabled, labels=None, redraw=True):
        """Set hierarchy frames and their text as one normal UI state.

        `labels` is reserved for an explicit CLI/forwarded-request override.
        Frames off still forces text off; the `f` shortcut passes no override
        and therefore always toggles both together.
        """
        enabled = bool(enabled)
        labels_enabled = enabled if labels is None \
            else enabled and bool(labels)
        changed = (enabled != self.frames_on or
                   labels_enabled != self.labels_on)
        self.frames_on = enabled
        self.labels_on = labels_enabled
        if changed and redraw:
            self._on_depth()

    def _set_label_font_px(self, value, redraw=True):
        value = max(MIN_LABEL_FONT_PX,
                    min(MAX_LABEL_FONT_PX, int(value)))
        changed = value != self.label_font_px
        self.label_font_px = value
        if self._fontdlg is not None:
            spin = getattr(self._fontdlg, "_spin", None)
            if spin is not None and int(spin.get_value()) != value:
                spin.set_value(value)
        if changed and redraw and self.worker is not None and \
                getattr(self.worker, "supports_label_font_px", False):
            self.redraw(immediate=True)

    def _sync_label_font_capability(self):
        item = getattr(self, "_label_font_menu_item", None)
        if item is not None:
            item.set_sensitive(bool(
                self.worker is not None and
                getattr(self.worker, "supports_label_font_px", False)))

    def _on_depth(self):
        self.dstatus.set_text(self._depth_label())
        self.redraw(immediate=True)

    def _only_close_button(self, dlg):
        """Leave only the window-close button in the title bar - no
        minimize/maximize. The GdkWindow functions drive the macOS
        traffic-light buttons; restrict them once the window realizes."""
        dlg.set_type_hint(Gdk.WindowTypeHint.DIALOG)

        def _restrict(_w):
            win = dlg.get_window()
            if win is not None:
                try:
                    win.set_functions(
                        Gdk.WMFunction.CLOSE | Gdk.WMFunction.MOVE)
                except Exception:
                    pass  # backend without WM-function support: harmless
        dlg.connect("realize", _restrict)

    def _center_on_parent(self, dlg):
        """Center the dialog on the main window. GTK's CENTER_ON_PARENT
        leans on the WM and miscomputes on some of them - X11 via XQuartz
        pins the dialog to the top (only horizontally centered) because it
        positions before the height is known. Instead move() explicitly
        from the parent geometry and the dialog's own size, at realize
        (before map, so the WM honors it as it did the GTK centering) and
        again on map as a correction."""
        dlg.set_position(Gtk.WindowPosition.NONE)

        def _place(*_a):
            par = self.window
            if not (par.get_realized() and dlg.get_realized()):
                return False
            pw, ph = par.get_size()
            px, py = par.get_position()
            req = dlg.get_preferred_size()[1]     # natural GtkRequisition
            dw = dlg.get_allocated_width()
            dh = dlg.get_allocated_height()
            if dw <= 1:                           # not allocated yet
                dw = req.width
            if dh <= 1:
                dh = req.height
            dlg.move(px + max(0, (pw - dw) // 2),
                     py + max(0, (ph - dh) // 2))
            return False
        dlg.connect("realize", _place)
        dlg.connect("map", _place)

    def _dialog_setup(self, dlg):
        """Shared chrome for the tool dialogs (depth, goto): transient and
        modal (macOS quartz denies a non-modal secondary window keyboard
        focus, so its keys leaked to the main window), centered on the
        parent, non-resizable, close button only."""
        dlg.set_transient_for(self.window)
        dlg.set_modal(True)
        self._center_on_parent(dlg)
        dlg.set_resizable(False)
        self._only_close_button(dlg)

    def _grab_focus_once(self, dlg, target):
        """Present `dlg` and grab keyboard focus on `target` exactly once
        it is mapped. quartz does not focus a freshly shown dialog - even
        a modal one - until then; one-shot so a later map does not re-grab
        (which would reselect an entry and trap focus there). `target` is a
        widget or a zero-arg callable returning one (deferred so a run()
        dialog's response buttons, built lazily, resolve after show)."""
        def _grab(*_a):
            if getattr(dlg, "_focused", False):
                return False
            dlg._focused = True
            dlg.present()
            w = target() if callable(target) else target
            if w is not None:
                w.grab_focus()
            return False
        dlg.connect("map-event", _grab)
        GLib.idle_add(_grab)

    def _dialog_show(self, dlg, focus):
        """Grab focus once mapped, then show. See _grab_focus_once."""
        self._grab_focus_once(dlg, focus)
        dlg.show_all()

    def _depth_dialog(self):
        if self._ddlg is not None:
            self._ddlg.present()
            return
        dlg = Gtk.Window(title="hierarchy depth")
        self._dialog_setup(dlg)
        self._ddlg = dlg
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(14)
        box.set_margin_end(14)
        dlg.add(box)
        box.pack_start(Gtk.Label(
            label="hierarchy depth (0 = %s only, 999 = full)" % (
                "the view root" if getattr(self, "_view_root", None)
                else "top")),
            False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        box.pack_start(row, False, False, 0)
        spin = Gtk.SpinButton.new_with_range(0, 999, 1)
        spin.set_value(self.depth_value)
        spin.connect("value-changed",
                     lambda s: self._set_depth(int(s.get_value())))
        spin.connect("activate", lambda *_: dlg.destroy())  # Enter = ok
        dlg._spin = spin
        row.pack_start(spin, False, False, 0)
        for preset in (0, 1, 2, 3, 999):
            b = Gtk.Button(label="full" if preset == 999 else str(preset))
            b.connect("clicked", lambda _w, p=preset: self._set_depth(p))
            row.pack_start(b, False, False, 0)
        note = Gtk.Label()
        note.set_markup(
            "<small>cells beyond the limit are drawn as outline frames"
            "\nwith names - keys: 0-9 = depth, &lt; / &gt; = step</small>")
        note.set_xalign(0.0)
        box.pack_start(note, False, False, 0)
        # depth applies live (spin/presets); ok just closes
        ok = Gtk.Button(label="ok")
        ok.connect("clicked", lambda *_: dlg.destroy())
        box.pack_start(ok, False, False, 0)

        def on_dialog_key(_w, ev):
            # Esc closes even when the focus sits in the spinbox, whose
            # input method would swallow the key first (flateyes trick)
            if Gdk.keyval_name(ev.keyval) == "Escape":
                dlg.destroy()
                return True
            return False
        dlg.connect("key-press-event", on_dialog_key)

        def _gone(*_a):
            self._ddlg = None
            # hand the keyboard back: some backends (macOS quartz
            # notably) fail to refocus the parent when a transient
            # closes, leaving every key command dead until a click
            self._restore_keys()
        dlg.connect("destroy", _gone)
        self._dialog_show(dlg, spin)

    def _detail_dialog(self):
        """Runtime control of the detail level (low/medium/high). The
        VFS daemon applies the matching screen-px cut in its page plan,
        showing dropped subtrees as outline frames."""
        if self._cdlg is not None:
            self._cdlg.present()
            return
        dlg = Gtk.Window(title="detail")
        self._dialog_setup(dlg)
        self._cdlg = dlg
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(14)
        box.set_margin_end(14)
        dlg.add(box)
        box.pack_start(Gtk.Label(
            label="detail level (higher = finer, heavier wide views)"),
            False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        box.pack_start(row, False, False, 0)
        btns = []
        for lvl, nm in enumerate(DETAIL_LEVELS):
            b = Gtk.ToggleButton(label=nm)

            def _apply(w, n=lvl):
                if not w.get_active():   # ignore the untoggle event
                    return
                for i, other in enumerate(btns):
                    if i != n and other.get_active():
                        other.set_active(False)
                self._set_detail(n)
            b.set_active(lvl == self.detail and self.cut_custom is None)
            b.connect("toggled", _apply)
            btns.append(b)
            row.pack_start(b, False, False, 0)
        # a cut of one's own, px (user 2026-10-28: for a test down to
        # 0.1 px): Enter or `set` applies it, a level button ends it
        own = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        box.pack_start(own, False, False, 0)
        own.pack_start(Gtk.Label(label="cut px"), False, False, 0)
        entry = Gtk.Entry()
        entry.set_width_chars(8)
        entry.set_text("%g" % self._effective_cut_px())
        own.pack_start(entry, False, False, 0)
        set_btn = Gtk.Button(label="set")
        own.pack_start(set_btn, False, False, 0)
        why = Gtk.Label()
        why.set_xalign(0.0)
        # (named for the gtk_view gate, which types in the entry)
        entry.set_name("detail-cut")
        why.set_name("detail-cut-why")
        box.pack_start(why, False, False, 0)

        def _own(*_a):
            refused = self._set_cut_px(entry.get_text())
            why.set_text(refused or "")
            if refused is None:
                for b in btns:
                    if b.get_active():
                        b.set_active(False)
        entry.connect("activate", _own)
        set_btn.connect("clicked", _own)
        note = Gtk.Label()
        note.set_markup(
            "<small>lower detail hides finer features from live "
            "renders;\nshapes below the cut are not drawn. snap/pick/clip "
            "stay exact.\nthe status line shows the physical cut "
            "(cut&lt;0.35um).\nlow/medium/high = 5/3/1 px; cut px sets "
            "one of your own.\nkeys: d = this dialog</small>")
        note.set_xalign(0.0)
        box.pack_start(note, False, False, 0)
        ok = Gtk.Button(label="ok")
        ok.connect("clicked", lambda *_: dlg.destroy())
        box.pack_start(ok, False, False, 0)

        def on_dialog_key(_w, ev):
            if Gdk.keyval_name(ev.keyval) == "Escape":
                dlg.destroy()
                return True
            return False
        dlg.connect("key-press-event", on_dialog_key)

        def _gone(*_a):
            self._cdlg = None
            self._restore_keys()
        dlg.connect("destroy", _gone)
        self._dialog_show(dlg, btns[self.detail])

    def _label_font_dialog(self):
        """Set the bundled Rust renderer font size in integer pixels."""
        if self.worker is None or not getattr(
                self.worker, "supports_label_font_px", False):
            return
        if self._fontdlg is not None:
            self._fontdlg.present()
            return
        dlg = Gtk.Window(title="label size")
        self._dialog_setup(dlg)
        self._fontdlg = dlg
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(14)
        box.set_margin_end(14)
        dlg.add(box)
        box.pack_start(Gtk.Label(
            label="Rust label font size (screen pixels)"),
            False, False, 0)
        spin = Gtk.SpinButton.new_with_range(
            MIN_LABEL_FONT_PX, MAX_LABEL_FONT_PX, 1)
        spin.set_value(self.label_font_px)
        spin.connect("value-changed", lambda s: self._set_label_font_px(
            int(s.get_value())))
        spin.connect("activate", lambda *_: dlg.destroy())
        dlg._spin = spin
        box.pack_start(spin, False, False, 0)
        note = Gtk.Label()
        note.set_markup(
            "<small>applies live without rebuilding the index; "
            "integer 6..96 px\nrotation and antialiasing remain "
            "deterministic</small>")
        note.set_xalign(0.0)
        box.pack_start(note, False, False, 0)
        ok = Gtk.Button(label="ok")
        ok.connect("clicked", lambda *_: dlg.destroy())
        box.pack_start(ok, False, False, 0)

        def on_dialog_key(_w, ev):
            if Gdk.keyval_name(ev.keyval) == "Escape":
                dlg.destroy()
                return True
            return False
        dlg.connect("key-press-event", on_dialog_key)

        def _gone(*_a):
            self._fontdlg = None
            self._restore_keys()
        dlg.connect("destroy", _gone)
        self._dialog_show(dlg, spin)

    # ---- goto (Calibre-style jump to coordinates) ---------------------------
    GOTO_HINT = ("um coordinates. window = view width after the jump"
                 "\n(blank = keep zoom). a pasted \"x, y\" pair in one"
                 "\nfield works too. Esc clears the X marker.")

    def _goto_dialog(self):
        if self._gdlg is not None:
            self._gdlg.present()
            return
        dlg = Gtk.Window(title="goto position")
        self._dialog_setup(dlg)
        self._gdlg = dlg
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(14)
        box.set_margin_end(14)
        dlg.add(box)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        box.pack_start(row, False, False, 0)
        entries = []
        for label, chars, text in (
                ("x", 11, "%.3f" % (self.cx * self.dbu)),
                ("y", 11, "%.3f" % (self.cy * self.dbu)),
                ("window", 8, "")):
            row.pack_start(Gtk.Label(label=label), False, False, 0)
            e = Gtk.Entry()
            e.set_width_chars(chars)
            e.set_text(text)
            e.connect("activate", lambda *_: self._goto_apply())
            row.pack_start(e, False, False, 0)
            entries.append(e)
        dlg._entries = entries
        note = Gtk.Label()
        note.set_markup("<small>%s</small>" % self.GOTO_HINT)
        note.set_xalign(0.0)
        dlg._note = note
        box.pack_start(note, False, False, 0)
        brow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        box.pack_start(brow, False, False, 0)
        ok = Gtk.Button(label="ok")
        ok.connect("clicked", lambda *_: self._goto_apply())
        brow.pack_start(ok, True, True, 0)
        close = Gtk.Button(label="close")
        close.connect("clicked", lambda *_: dlg.destroy())
        brow.pack_start(close, True, True, 0)

        def on_dialog_key(_w, ev):
            if Gdk.keyval_name(ev.keyval) == "Escape":
                dlg.destroy()
                return True
            return False
        dlg.connect("key-press-event", on_dialog_key)

        def _gone(*_a):
            self._gdlg = None
            self._restore_keys()
        dlg.connect("destroy", _gone)
        self._dialog_show(dlg, entries[0])

    def _goto_apply(self):
        """Jump to the entered position: values fill x, y, window in
        order, so a DRC-report "x, y" pair pasted into any one field
        spreads across both coordinates."""
        dlg = self._gdlg
        if dlg is None:
            return
        try:
            part = [[float(t) for t in
                     e.get_text().replace(",", " ").split()]
                    for e in dlg._entries]
        except ValueError:
            dlg._note.set_markup("<small>not a number - %s</small>"
                                 % self.GOTO_HINT)
            return
        if len(part[0]) >= 2:
            part[1] = []  # pair pasted into x: the y field is stale
        vals = part[0] + part[1] + part[2]
        if len(vals) < 2:
            dlg._note.set_markup("<small>need both x and y - %s</small>"
                                 % self.GOTO_HINT)
            return
        self.goto(vals[0], vals[1], vals[2] if len(vals) > 2 else None)
        dlg.destroy()  # ok / Enter applied successfully: close

    def goto(self, x_um, y_um, window_um=None):
        """Center the view on (x, y) um; window is the resulting
        view width in um (None/0 = keep the current zoom). The old X
        marker is gone (user call 2026-08-09)."""
        # A user/CLI target always wins over the deferred auto-fit used when a
        # new layout is attached to an already allocated window.
        self._fit_after_worker_start = False
        if self._ctl_navigate({
                "kind": "goto", "center_um": [float(x_um), float(y_um)],
                "width_um": float(window_um)
                if window_um and window_um > 0 else None}):
            return
        self.cx = x_um / self.dbu
        self.cy = y_um / self.dbu
        if window_um and window_um > 0:
            w, _h = self._viewport_size()
            self.spp = (window_um / self.dbu) / w
        self.redraw(immediate=True)

    # ---- DRC results browser -------------------------------------------------
    def _drc_window(self):
        """The browser lives in the LEFT pane - load a db when none
        is open, else focus it (open .db button equivalent)."""
        if self._drc is None:
            self._drc_open_dialog()
        else:
            self._left_show("drc")
            self._drcwin._rules.grab_focus()

    def _esel_toggle(self):
        """'e': error box-select mode for the OPEN rule (user call
        2026-08-14) - two clicks span a box, every error of that
        rule inside it gets selected; works with highlight mode on
        or off."""
        if self.mode == "esel":
            self.mode = "normal"
            self._esel_start = None
            self._set_cursor(self._idle_cursor())
            self._set_live_status("error select off")
            self._display()
            return
        db, ci = self._drc, self._drc_sel_check()
        if db is None or ci is None:
            self._set_live_status(
                "error select: open a DRC db and select a rule first")
            return
        self.mode = "esel"
        self._esel_start = None
        self._set_cursor(self._idle_cursor())
        self._set_live_status(
            "error select %s: click the 1st box corner (Esc quits)"
            % db.checks[ci].name)

    def _esel_click(self, ev):
        # Use the same transform as the displayed markers, including a
        # frozen base while a new zoom frame is still being rendered.
        bounds, spp = self._drc_display_view()
        point = (bounds[0] + ev.x * spp, bounds[3] - ev.y * spp)
        if self._esel_start is None:
            self._esel_start = point
            self._set_live_status(
                "error select: click the opposite corner "
                "(Shift = add, Ctrl = toggle)")
            self._display()
            return
        a = self._esel_start
        b = point
        self._esel_start = None
        # like ruler mode the tool STAYS ARMED for the next box
        # until Esc (or 'e') leaves it - user call 2026-08-15
        state = getattr(ev, "state", 0)
        mode = ("toggle" if state & Gdk.ModifierType.CONTROL_MASK
                else "add" if state & Gdk.ModifierType.SHIFT_MASK
                else "replace")
        self._esel_apply(a, b, mode)

    def _esel_apply(self, a, b, mode="replace"):
        """Select every exact bbox hit in the displayed scope - the whole
        rule, cluster or delta group, not a list page - with no count
        limit (feature/jobdeck-drc 2026-10-08; the service's select job).
        mode: replace (plain), add (Shift), toggle (Ctrl) - the grid's
        second-click modifiers (user call 2026-08-15)."""
        db, ci = self._drc, self._drc_sel_check()
        if db is None or ci is None:
            return
        if self.overlay_mode != 0:
            self._set_live_status("show DRC markers before selecting errors")
            return
        x0, x1 = sorted((a[0], b[0]))
        y0, y1 = sorted((a[1], b[1]))
        view, _spp = self._drc_display_view()
        bounds = (max(x0, view[0]), max(y0, view[1]),
                  min(x1, view[2]), min(y1, view[3]))
        membership = self._drc_active_members()
        if self._drc_show_sel:
            sel = self._drc_sel
            membership = gtkservice.intersect(
                sel[1] if sel is not None and sel[0] == ci
                else gtkservice.DrcScope(db, ci, {"empty": True}),
                membership)
        self._drc_selection_submit(ci, tuple(v * self.dbu for v in bounds),
                                   membership, mode)

    def _drc_selection_cancel(self, close=False):
        worker = getattr(self, "_drc_selection_worker", None)
        if worker is not None:
            if close:
                worker.close()
                self._drc_selection_worker = None
            else:
                worker.cancel()
        self._drc_selection_key = None
        self._drc_selection_then = None
        self._drc_selection_after = None

    def _drc_selection_submit(self, ci, bounds, membership, mode="replace",
                              then=None):
        """Ask the service for a selection of the scope. `then` (an
        action, on) makes it the first half of a command on every error
        of the scope (_drc_scope_all): the errors are collected whatever
        the waive filter lists, and the result is that command's target,
        not the selection in the grid."""
        if (getattr(self, "_drc_review_job", None) is not None or
                getattr(self, "_drc_team_write", None) is not None or
                getattr(self, "_drc_verdict_job", None) is not None):
            self._set_live_status("review update in progress; select after it finishes")
            return
        if mode != "replace" and getattr(self, "_drc_selection_key", None) is not None:
            self._set_live_status("error selection is still being updated (Esc cancels)")
            return
        db = self._drc
        if db is None or ci != self._drc_sel_check():
            return
        conflict_only = getattr(self, "_drc_conflict_only", False)
        if conflict_only:
            active = self._drc_active_members()
            if active is None or not active:
                self._set_live_status("Conflict only: no prepared matching errors to select.")
                return
            if membership is None:
                membership = active
            elif membership is not active:
                membership = gtkservice.intersect(membership, active)
        sel = self._drc_sel
        previous = sel[1] if sel is not None and sel[0] == ci else None
        worker = getattr(self, "_drc_selection_worker", None)
        if worker is None:
            worker = self._drc_selection_worker = gtkservice.SelectionWorker()
        key = (object(), id(db), self._drc_scope_key(), self._drc_wfilter)
        self._drc_selection_key = key
        self._drc_selection_then = then
        worker.submit(key, db, ci, bounds, membership=membership,
                      waived=(None if then is not None or conflict_only
                              or self._drc_wfilter == "all" else
                              self._drc_wf_class()),
                      previous=None if then is not None else previous, mode=mode)
        self._set_live_status("%s… (Esc cancels)" % (
            "error select: selecting" if then is None else
            "%s: collecting the errors" % self._drc_scope_said(*then)))

    def _drc_selection_poll(self):
        worker = getattr(self, "_drc_selection_worker", None)
        reply = worker.poll() if worker is not None else None
        if reply is None:
            return
        key, selected, error = reply
        if key != getattr(self, "_drc_selection_key", None):
            return
        if (key[1:] != (id(self._drc), self._drc_scope_key(), self._drc_wfilter)):
            self._drc_selection_cancel()
            return
        if isinstance(selected, gtkservice.SelectionProgress):
            then = getattr(self, "_drc_selection_then", None)
            self._set_live_status("%s: %d / %d processed · %d matches (Esc cancels)" % (
                "error select" if then is None else self._drc_scope_said(*then),
                selected.processed, selected.total, selected.count))
            return
        self._drc_selection_key = None
        then = getattr(self, "_drc_selection_then", None)
        self._drc_selection_then = None
        if error:
            self._set_live_status("error selection failed: %s" % error)
            return
        ci = self._drc_sel_check()
        if then is not None:
            self._drc_scope_apply(ci, selected, *then)
            return
        after = getattr(self, "_drc_selection_after", None)
        self._drc_set_sel((ci, selected, (), selected) if selected else None)
        self._drc_focus = None
        self._drc_grid_fill(ci)
        # (the recheck that follows a verdict leaves the verdict's line)
        self._set_live_status(after or "error select %s: %d selected%s" % (
            self._drc.checks[ci].name, len(selected),
            self._drc_group_said(getattr(selected, "group", None))))
        self._display()

    def _drc_group_said(self, group):
        """The end of a selection's status line when the selection is the
        errors marked with one (_drc_group_select): whose marks, and why as
        they said - and how to list them alone."""
        if not group:
            return ""
        text = group.get("text") or ""
        return " - %s by %s%s%s" % (
            "requested" if group.get("stage") == "request" else "waived",
            group.get("reviewer") or "?",
            " (%s)" % (text if len(text) <= 60 else text[:59] + "…") if text
            else " with no reason",
            "" if self._drc_show_sel else " · check `selected` to list them alone")

    def _drc_group_stage(self, db, ci, ei):
        """Whether rule `ci`'s error `ei` has a mark it was made with -
        "waived" (somebody's waive, counting or sent back), "requested"
        (somebody's request) - or None, as this session reads its state."""
        if not hasattr(db, "waive_ask"):
            return None
        state = self._drc_state(db, ci, ei)
        if state in (gtkservice.STATE_WAIVED, gtkservice.STATE_CONFIRMED,
                     gtkservice.STATE_REJECTED):
            return "waived"
        if state in (gtkservice.STATE_REQUESTED, gtkservice.STATE_DECLINED):
            return "requested"
        return None

    def _drc_group_select(self, ci, ei):
        """Select the errors that were waived - or asked for - with rule
        `ci`'s error `ei`: the same reviewer's, in one action (user
        2026-11-14: "그룹으로 한번에 waive된 것을 하나씩 확인하기는 매우 어려울
        것으로 예상되므로 해당 그룹도 한번에 확인하고 confirm 할 수 있는
        필터등이 필요"). What a waiver waived at once - a box selection, a
        cluster, a CD group, with one reason - is one line of their reasons
        file whatever its size; the service makes a selection of it, and the
        selection is this viewer's as a box selection is: gold on the
        canvas and in the grid, listed alone with `selected`, and the
        target of the menu's commands - `confirm N selected`."""
        if (getattr(self, "_drc_review_job", None) is not None or
                getattr(self, "_drc_team_write", None) is not None or
                getattr(self, "_drc_verdict_job", None) is not None):
            self._set_live_status("review update in progress; select after it finishes")
            return
        db = self._drc
        if db is None or ci != self._drc_sel_check():
            return
        worker = getattr(self, "_drc_selection_worker", None)
        if worker is None:
            worker = self._drc_selection_worker = gtkservice.SelectionWorker()
        key = (object(), id(db), self._drc_scope_key(), self._drc_wfilter)
        self._drc_selection_key = key
        self._drc_selection_then = None
        worker.submit_group(key, db, ci, ei)
        self._set_live_status("error select: the errors marked with #%d… (Esc cancels)"
                              % (ei + 1))

    def _drc_selection_restore(self):
        """Recheck a saved selection against the current scope and waive
        filter in the service; until then it is not the active one."""
        members = self._drc_active_members()
        sel = self._drc_sel
        if sel is None:
            return
        want = (None if getattr(self, "_drc_conflict_only", False)
                or self._drc_wfilter == "all" else self._drc_wf_class())
        if members is None and want is None:
            return
        # A saved status snapshot is not a valid active selection until
        # rechecked. Keep its scope entry for later retries, but don't page
        # or review stale IDs if the recheck is cancelled or fails.
        self._drc_sel = None
        self._drc_selection_submit(sel[0], None,
                                   gtkservice.intersect(sel[1], members))

    def _build_menubar(self):
        """Top menu bar (user call 2026-08-22): the key-bound
        commands, the panel buttons (fit/clip/open .db/rules) and
        the ruler tools grouped under File/View/Ruler/DRC. Every
        item calls the SAME handler as its key, with the key shown
        in the label; check items re-sync from live state each time
        their menu opens (guard flag so set_active cannot fire the
        handler back)."""
        mb = Gtk.MenuBar()
        self._menu_checks = []   # (CheckMenuItem, live-state getter)
        self._menu_guard = False
        self._load_items = []
        self._load_why = {}
        self._menu_hidden = []
        self._debug_items = []

        def item(menu, label, cb):
            it = Gtk.MenuItem(label=label)
            it.connect("activate", lambda *_: cb())
            menu.append(it)
            return it

        def load(menu, label, cb, why=None):
            # a command that loads a file picked in the viewer: insensitive
            # with the file loads off (_file_load_show; its handler refuses
            # too). `why`: the reason of a command the switch turns off
            # that loads nothing (clip region…) - its tooltip then
            it = item(menu, label, cb)
            self._load_items.append(it)
            if why is not None:
                self._load_why[it] = why
            return it

        def check(menu, label, cb, state):
            it = Gtk.CheckMenuItem(label=label)

            def on_toggle(_i):
                if not self._menu_guard:
                    cb()
            it.connect("toggled", on_toggle)
            menu.append(it)
            self._menu_checks.append((it, state))
            return it

        def sep(menu):
            menu.append(Gtk.SeparatorMenuItem())

        def hidden(it):
            # a command made and wired, in no menu on screen (user
            # 2026-11-15: "DRC 메뉴에서 save waive as..., load waive as...,
            # reviewers..., team waives..., review from previous run..., save
            # notes as..., load notes...를 모두 숨겨줘"): its handler, its
            # window and the load switch's hold on it stay as they are
            it.set_no_show_all(True)
            it.hide()
            self._menu_hidden.append(it)
            return it

        def debug_only(it):
            # a command of `floe2 view --debug` (user 2026-11-15): in its
            # menu while the viewer's debug parts are on (_debug_show),
            # in none without - the window's show_all passes it by
            it.set_no_show_all(True)
            self._debug_items.append(it)
            return it

        def top(label):
            root = Gtk.MenuItem(label=label)
            menu = Gtk.Menu()
            root.set_submenu(menu)
            menu.connect("show", lambda *_: self._menu_sync())
            # keys go back to the canvas whenever a menu closes
            menu.connect("deactivate", lambda *_: self._restore_keys())
            mb.append(root)
            return menu

        m = top("File")
        load(m, "load layout…", self._load_layout_dialog)
        load(m, "load jobdeck…", self._load_jobdeck_dialog)
        load(m, "clip region…", self._clip_dialog, why=NO_CLIP)
        item(m, "copy view to clipboard\tCtrl+C", self._copy_view)
        sep(m)
        item(m, "quit\tq", self._confirm_quit)

        m = top("View")
        item(m, "fit (zoom all)\tCtrl+A", self.fit)
        item(m, "zoom in 50%\tCtrl+Z",
             lambda: self._zoom_center(CAL_ZOOM_IN))
        item(m, "zoom out 50%\tShift+Z",
             lambda: self._zoom_center(1 / CAL_ZOOM_IN))
        item(m, "goto position…\tg", self._goto_dialog)
        sep(m)
        item(m, "detail…\td", self._detail_dialog)
        self._label_font_menu_item = item(
            m, "label size… (Rust renderer)", self._label_font_dialog)
        self._label_font_menu_item.set_sensitive(False)
        item(m, "depth +1\t>", lambda: self._depth_step(1))
        item(m, "depth -1\t<", lambda: self._depth_step(-1))
        item(m, "depth full\t9 9", lambda: self._set_depth(999))
        sep(m)
        check(m, "hierarchy frames\tf",
              lambda: self._set_frames(not self.frames_on),
              lambda: self.frames_on)
        # the density under the cut (user 2026-10-05): the Rust
        # renderer's density stack, on or off live
        self._density_menu_item = debug_only(check(
            m, "density under the cut\tv", self._toggle_density,
            lambda: self._density_key() is True))
        self._density_menu_item.set_sensitive(False)
        # the occupancy summary at wide views (user 2026-10-20): the Rust
        # renderer draws a jobdeck's passes from design.ovo; this lets a
        # plain layout's frames use the file too (a source a jobdeck
        # indexed, opened on its own), or a deck's passes go without it
        self._occupancy_menu_item = debug_only(check(
            m, "occupancy summary at wide views\to", self._toggle_occupancy,
            lambda: self._occupancy_effective()))
        self._occupancy_menu_item.set_sensitive(False)
        # the page hairline policy (review 2026-09-11): a plain layout
        # may omit thin shapes at wide views for speed; the mask
        # policy keeps them (a jobdeck's default)
        # thin shapes at wide views (user call 2026-09-15: a menu
        # command for the policy): auto = the source's default
        # (jobdeck keep, layout cull), keep = the mask policy (with an
        # occupancy summary, detail medium is enough), cull = the
        # layout policy (thin pages omitted at wide views, faster)
        thin_root = debug_only(
            Gtk.MenuItem(label="thin shapes at wide views"))
        thin_menu = Gtk.Menu()
        thin_root.set_submenu(thin_menu)
        thin_menu.connect("show", lambda *_: self._menu_sync())
        thin_menu.connect("deactivate", lambda *_: self._restore_keys())
        m.append(thin_root)
        for mode, label in (("auto", "auto (keep)"),
                            ("keep", "keep (thin shapes as hairlines)"),
                            ("cull", "cull (drop all-thin pages, faster)")):
            check(thin_menu, label,
                  (lambda mode=mode: self._set_thin(mode)),
                  (lambda mode=mode:
                   getattr(self, "thin_mode", "auto") == mode))
        # (the window's show_all passes the submenu of an item that is out
        # of its menu by: its entries are shown here)
        for it in thin_menu.get_children():
            it.show()
        check(m, "grayscale layers\tb",
              lambda: self._set_mono(not self._mono),
              lambda: self._mono)
        # the scale border (user 2026-10-13): the band along the frame's
        # edges that reads lengths, the corners' coordinates
        check(m, "scale border\ts", self._toggle_border,
              lambda: self.border_on)
        sep(m)
        item(m, "cycle overlays (all / errors / none)\tTab",
             self._toggle_overlays)

        m = top("Cell")
        item(m, "cell tree / find cell…\tt", self._cell_tree_focus)
        # (`zoom to selected cell` left the menu with the pane's `zoom`
        # button, user 2026-11-15: "cell의 zoom 버튼은 삭제해줘", "메뉴에서도
        # zoom to selected cell 삭제해줘" - Enter in the search box and a
        # jobdeck row's double-click zoom as before)
        check(m, "highlight instances",
              lambda: self._cell_hl_set(not self._cell_hl_on),
              lambda: self._cell_hl_on)
        item(m, "clear highlight\tEsc", self._cell_hl_clear)
        sep(m)
        item(m, "selected cell as view root", self._cell_set_root)
        item(m, "view root: back to the top cell\tCtrl+Shift+T",
             self._cell_root_top)
        # (`build cell index (design.ovh)…` left the menu, user 2026-11-15:
        # "Cell > build cell index (design.ovh)... 메뉴는 제거해줘" - the cells
        # pane's `build index…` button, there while a source lacks its
        # index, and the question at a load ask as before:
        # _cell_index_offer)

        m = top("Ruler")
        check(m, "ruler mode\tr", self._toggle_ruler,
              lambda: self.mode == "ruler")
        check(m, "edge/vertex snap\tm", self._toggle_snap,
              lambda: self.snap_on)
        sep(m)
        item(m, "delete last ruler\tk", self._ruler_pop)
        item(m, "clear rulers\tShift+K", self._rulers_clear)

        m = top("DRC")
        load(m, "open results .db…", self._drc_open_dialog)
        load(m, "load SVRF rules…", self._drc_rules_dialog)
        item(m, "SVRF info…\ti", self._drc_svrf_dialog)
        load(m, "load clusters…", self._drc_clusters_dialog)
        sep(m)
        item(m, "next error\t.", lambda: self._drc_step(1))
        item(m, "previous error\t,", lambda: self._drc_step(-1))
        # (the three commands below follow the session's roles each time
        # the menu opens - _drc_menu_roles)
        self._drc_menu_mark = item(m, self.DRC_MARK_ITEM["waive"], self._drc_waive_key)
        hidden(item(m, "save waives as…", self._drc_waive_save_dialog))
        hidden(load(m, "load waives…", self._drc_waive_load_dialog))
        hidden(item(m, "reviewers…", self._drc_team_dialog))
        hidden(item(m, "team waives…", self._drc_waives_dialog))
        hidden(load(m, "review from previous run…", self._drc_migration_dialog))
        self._drc_menu_aside = [
            item(m, "mark not for review", lambda: self._drc_not_required_key(True)),
            item(m, "clear not for review", lambda: self._drc_not_required_key(False))]
        sep(m)
        item(m, "note (add/edit)\tn", self._drc_note_key)
        item(m, "clear note of selection", self._drc_note_clear)
        hidden(item(m, "save notes as…", self._drc_note_save_dialog))
        hidden(load(m, "load notes…", self._drc_note_load_dialog))
        sep(m)
        check(m, "error box-select mode\te", self._esel_toggle,
              lambda: self.mode == "esel")

        m = top("Jobdeck")
        # in the menu bar while a jobdeck is loaded and not otherwise
        # (_jobdeck_menu_show)
        self._jobdeck_menu = m.get_attach_widget()
        self._jobdeck_menu.set_no_show_all(True)
        # MDPView's two jobdeck views (its manual: level view / chip
        # view) plus our source-layer view
        for mode, label in (("level", "level view (mask levels $n)"),
                            ("chip", "chip view (CHIP blocks, expand "
                                     "to levels)"),
                            ("layer", "source layer view (LY/DT)")):
            check(m, label,
                  (lambda mode=mode: self._jobdeck_set_mode(mode)),
                  (lambda mode=mode: self._jobdeck_mode() == mode))
        sep(m)
        item(m, "toggle level view / chip view\tCtrl+,",
             self._jobdeck_toggle_view)
        sep(m)
        item(m, "select levels to load…", self._jobdeck_reselect_levels)
        # the window's show_all passes a menu that is out of the bar by: its
        # commands are shown here, for the day a deck brings the menu in
        for it in m.get_children():
            it.show()

        m = top("Help")
        item(m, "About %s" % APP, self._about_dialog)
        item(m, "License Agreement", self._eula_dialog)
        item(m, "Open Source Licenses", self._licenses_dialog)
        self._menubar = mb
        self._file_load_show()
        self._jobdeck_menu_show()
        self._debug_show()
        return mb

    def _debug_show(self):
        """The viewer's debug parts as the switch stands (`floe2 view
        --debug`, user 2026-11-15: "View > thin shapes at wide views 메뉴,
        View > density under the cut 메뉴, occupancy summary at wide views
        메뉴 숨기고 --debug 옵션에서만 나오게 ... 상태줄의 로그, thin:keep,
        density:on occupancy:off 도"): the three commands of the View menu
        are in it with the option alone - hidden without, not insensitive,
        as the Jobdeck menu is for a layout -, and the status area follows:
        the depth label's thin / density / occupancy parts (_depth_label)
        and the lower bar's line (_set_status) are written again as the
        switch says."""
        on = bool(getattr(self, "_debug", False))
        for it in getattr(self, "_debug_items", ()):
            it.set_visible(on)
        if getattr(self, "dstatus", None) is not None:
            self.dstatus.set_text(self._depth_label())
        said = getattr(self, "_perf_said", None)
        if said is not None:
            self._set_status(*said)

    def _debug_latch(self):
        """A forwarded launch with --debug turns this window's debug parts
        on, and they stay on: a later launch without the option says
        nothing about them (the file loads' switch, the other way round)."""
        if getattr(self, "_debug", False):
            return
        self._debug = True
        self._debug_show()

    def _jobdeck_menu_show(self):
        """The Jobdeck menu is in the menu bar while a jobdeck is loaded
        (user 2026-11-15: "일반 레이아웃으로 시작할 경우 Jobdeck 메뉴를 사용불가
        상태로 만들거나 숨겨줘"): hidden for a layout and for a viewer with
        nothing loaded, back when File > load jobdeck… (or a later launch)
        brings a deck, gone again when a layout takes its place. Hidden
        rather than insensitive: a menu with nothing to offer is not shown
        (the panes' rule). Ctrl+, still says `not a jobdeck`."""
        menu = getattr(self, "_jobdeck_menu", None)
        if menu is not None:
            menu.set_visible(bool(getattr(getattr(self, "cache", None),
                                          "is_jobdeck", False)))

    def _file_load_show(self):
        """The menus' load commands as the switch stands: insensitive, the
        reason their tooltip, with the file loads off - and File > clip
        region… with them (0.12.479), under its own reason."""
        why = getattr(self, "_load_why", {})
        for it in self._load_items:
            it.set_sensitive(self._file_load)
            it.set_tooltip_text(None if self._file_load
                                else why.get(it, NO_FILE_LOAD))

    def _file_load_latch(self):
        """A forwarded launch with its file loads off (--no-file-load /
        FLOE_NO_FILE_LOAD) turns this window's off too, and they stay off:
        a launcher's request must not land in a window that loads anything,
        and a later launch without the option does not turn them on again.
        The reviewers window loses its load button, the window of a previous
        run - paths to read and nothing else - goes."""
        if not self._file_load:
            return
        self._file_load = False
        self._file_load_show()
        team = getattr(self, "_drc_team", None)
        if team is not None and not team.closed:
            team.file_load_off()
        migration = getattr(self, "_drc_migration", None)
        if migration is not None and not migration.closed:
            migration.window.destroy()

    def _load_refused(self, what, why=NO_FILE_LOAD):
        """Whether `what`, a command that loads a file picked in the viewer,
        is off: the viewer was started with `floe2 view --no-file-load`
        (FLOE_NO_FILE_LOAD; user 2026-11-11: "TeeBox에서 floe를 열 경우
        사용자가 임의의 파일을 로드할 수 없게 하려고 함"). Said in the status
        line. What the command line named - the source, --drc, --rules - and
        what follows those by name (a deck's levels, the rules metadata and
        the clusters beside the results, the design's layer properties) is
        loaded as ever; saving is not this switch's - but for the clip of
        the layout (File > clip region…, `why` NO_CLIP: user 2026-11-15),
        which a viewer that loads nothing of its user's choosing does not
        write either."""
        if self._file_load:
            return False
        self._set_live_status("%s: %s" % (what, why))
        return True

    def _load_jobdeck_dialog(self):
        """File > load jobdeck… (user call 2026-09-09): the load dialog
        with the jobdeck filter first."""
        self._load_layout_dialog(jobdeck=True)

    def _load_layout_dialog(self, jobdeck=False):
        """File > load layout… (user call 2026-08-22): open a source
        in place, the same open_file path an instance-forwarded
        `floe view <file>` takes. When the pick has no VFS cache it
        ASKS to build one and indexes on Yes (user call 2026-08-28).
        `jobdeck`: File > load jobdeck… - same dialog, .jb filter
        first (a .jb picked either way opens as a deck). The dialog is
        our own browser (user call 2026-09-10): GTK's file chooser
        lists every folder whatever the filter says, so a data
        directory showed each layout's cache folder and every
        DRC pack next to the layouts."""
        # initial base = the folder floe was launched from (user
        # call 2026-08-22); once a layout is loaded, its own folder
        # (sibling layouts live together, same as the DRC dialog)
        folder = (self._launch_dir if self.meta is None
                  else os.path.dirname(self.meta["src"]["path"]))
        filters = [("layouts (*.oas, *.gds)",
                    ("*.oas", "*.oas.gz", "*.gds", "*.gds.gz")),
                   ("jobdecks (*.jb)", ("*.jb",)),
                   ("all files", ("*",))]
        if jobdeck:
            filters[0], filters[1] = filters[1], filters[0]
        path = self._browse_file_dialog(
            "load jobdeck" if jobdeck else "load layout", folder, filters)
        # a modal run() on quartz does not hand the keys back to the
        # parent by itself: restore now, and again after the load
        # rebuilds the panels (open_file)
        self._restore_keys()
        if not path:
            return
        self._load_picked(path)

    def _browse_file_dialog(self, title, folder, filters, first=0):
        """A file browser of our own - every dialog that opens a file
        (load layout / jobdeck, DRC .db, clusters, rule metadata,
        notes, layer properties): folder list first, then the files and
        the symbolic links the current filter admits by name, in one
        name order (`browse_rows`); `list_browse_entries` hides
        dotfiles, pre-rename <src>.floe caches and .ice packs (user call
        2026-09-10 - GTK's chooser applies no filter to folders) and
        follows no link (user call 2026-10-21 - GTK's chooser stats
        every link's target, which a folder of links to other volumes
        turned into a wait per link); a link row reads `name@`, its own
        text `name -> target` the tooltip (user call 2026-10-26), and is
        followed, alone, when activated. Up / home buttons, an editable
        path (Enter navigates to a folder or accepts a file), type-ahead
        on the name column, a filter combo. Returns the picked path, or
        None. Saving (a name to type) and the reviewers' multi-pick keep
        GTK's chooser. In a viewer started with --no-file-load it opens
        nothing and returns None, whoever asks (_load_refused)."""
        if self._load_refused(title):
            return None
        dlg = Gtk.Dialog(title=title, transient_for=self.window, modal=True)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                        "Open", Gtk.ResponseType.OK)
        dlg.set_default_response(Gtk.ResponseType.OK)
        dlg.set_default_size(760, 520)
        box = dlg.get_content_area()
        box.set_spacing(4)
        box.set_border_width(6)
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        up = Gtk.Button(label="\u2191")
        up.set_tooltip_text("parent folder")
        home = Gtk.Button(label="~")
        home.set_tooltip_text("home folder")
        entry = Gtk.Entry()
        entry.set_hexpand(True)
        bar.pack_start(up, False, False, 0)
        bar.pack_start(home, False, False, 0)
        bar.pack_start(entry, True, True, 0)
        box.pack_start(bar, False, False, 0)
        # display, size, modified, is_dir, name, is_link, tooltip markup
        store = Gtk.ListStore(str, str, str, bool, str, bool, str)
        view = Gtk.TreeView(model=store)
        for j, (label, expand) in enumerate((("name", True), ("size", False),
                                             ("modified", False))):
            cell = Gtk.CellRendererText()
            if expand:
                cell.set_property("ellipsize", Pango.EllipsizeMode.MIDDLE)
            col = Gtk.TreeViewColumn(label, cell, text=j)
            col.set_expand(expand)
            view.append_column(col)
        view.set_enable_search(True)
        view.set_search_column(0)
        # the whole text behind an ellipsis; a link's own text
        view.set_tooltip_column(6)
        sc = Gtk.ScrolledWindow()
        # no sideways scrolling: the name column ellipsizes instead, so
        # size and modified stay in view
        sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sc.add(view)
        box.pack_start(sc, True, True, 0)
        combo = Gtk.ComboBoxText()
        for name, _pats in filters:
            combo.append_text(name)
        combo.set_active(max(0, min(first, len(filters) - 1)))
        box.pack_start(combo, False, False, 0)
        state = {"folder": os.path.abspath(folder or os.getcwd()),
                 "picked": None}

        def fill():
            store.clear()
            pats = filters[combo.get_active()][1]
            # a link is judged by its own name, as a file is, and reads
            # `name@`, never followed to tell a folder from a file (user
            # calls 2026-10-21, 2026-10-26); the tooltip is markup
            for row in browse_rows(state["folder"], pats):
                store.append(list(row[:6]) +
                             [GLib.markup_escape_text(row[6])])
            entry.set_text(state["folder"])
            if len(store):
                view.get_selection().select_path(Gtk.TreePath.new_first())
            view.grab_focus()

        def go(path):
            state["folder"] = os.path.abspath(path)
            fill()

        def selected():
            """(path, is_dir) of the selected row, or None. A link row
            is followed here - this one, now that the user chose it: a
            folder behind it is entered, a file picked, a dangling link
            is nothing."""
            model, it = view.get_selection().get_selected()
            if it is None:
                return None
            path = os.path.join(state["folder"], model[it][4])
            if not model[it][5]:
                return path, bool(model[it][3])
            if os.path.isdir(path):
                return path, True
            return (path, False) if os.path.isfile(path) else None

        def activate(*_args):
            row = selected()
            if row is None:
                return
            path, is_dir = row
            if is_dir:
                go(path)
            else:
                state["picked"] = path
                dlg.response(Gtk.ResponseType.OK)

        def on_entry(*_args):
            text = os.path.expanduser(entry.get_text().strip())
            if os.path.isdir(text):
                go(text)
            elif os.path.isfile(text):
                state["picked"] = os.path.abspath(text)
                dlg.response(Gtk.ResponseType.OK)

        view.connect("row-activated", activate)
        entry.connect("activate", on_entry)
        up.connect("clicked", lambda *_: go(os.path.dirname(state["folder"])
                                            or state["folder"]))
        home.connect("clicked", lambda *_: go(os.path.expanduser("~")))
        combo.connect("changed", lambda *_: fill())
        fill()
        self._center_on_parent(dlg)
        dlg.set_keep_above(True)
        dlg.show_all()
        dlg.present()
        try:
            while True:
                resp = dlg.run()
                if resp != Gtk.ResponseType.OK:
                    return None
                if state["picked"]:
                    return state["picked"]
                row = selected()
                if row is not None and row[1]:
                    go(row[0])           # Open on a folder enters it
                    continue
                if row is not None:
                    return row[0]
                text = os.path.expanduser(entry.get_text().strip())
                if os.path.isfile(text):
                    return os.path.abspath(text)
                if os.path.isdir(text):
                    go(text)
        finally:
            dlg.destroy()
            self.window.present()

    def _load_picked(self, path):
        """Open the file the load dialog picked. A jobdeck ALWAYS goes
        through _open_or_index - it asks which levels to load first
        (field 2026-09-10: an indexed deck picked from File > load
        jobdeck… opened straight away without the level dialog); so
        does a layout without an index (ask, build in the modal log,
        then load - the same path a `floe2 view <file>` without an
        index takes). An indexed layout opens in place."""
        if path and (_is_deck_path(path) or not self._index_ready(path)):
            self._open_or_index(path)
            return
        try:
            err = self.open_file(path)
        except Exception as exc:
            err = "ERR %s" % exc
        if err:
            msg = err[4:] if err.startswith("ERR ") else err
            self._set_live_status(msg)
            info = Gtk.MessageDialog(
                transient_for=self.window, modal=True,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.OK, text=msg)
            self._center_on_parent(info)
            info.run()
            info.destroy()
            self._restore_keys()

    def _vfs_index_and_load(self, src, after=None, props=None):
        """Build the VFS cache for `src` with its log in a modal dialog,
        then open it in place; `after(err)` runs once the open settled
        (err None on success): `floe2 index SRC`, the Rust command line,
        decides the cache, its options and its locks. `props`: the
        launch's layer properties file for it (open_file)."""
        from .vfsclient import find_floe2
        try:
            argv = [find_floe2(), "index", src, "--jobs", "12"]
        except RuntimeError as exc:
            self._set_live_status("VFS indexing failed: %s" % exc)
            return
        cur = getattr(self, "cache", None)
        if cur is not None and not getattr(cur, "is_jobdeck", False) and \
                os.path.abspath(getattr(cur, "src", "") or "") == \
                os.path.abspath(src):
            # this viewer has the source open (its cache folder was
            # removed by hand): its own render service's reader lock
            # would refuse the rebuild (floe/indexlock.py) - let go first
            self._apply_cache(None)

        def on_success():
            try:
                err = self.open_file(src, props=props)
            except Exception as exc:
                err = "ERR %s" % exc
            if after is not None:
                after(err)
            elif err:
                self._set_live_status(
                    err[4:] if err.startswith("ERR ") else err)

        # jobs 12 default, LOD off (retirement) - user call 2026-08-28;
        # no occupancy summary, like `floe2 index` on a layout
        # (2026-09-16; a jobdeck load gets it through `floe2 index
        # deck.jb`, whose sources default to the summary)
        self._index_modal("indexing layout…", argv, on_success,
                          "VFS indexing")

    def _jobdeck_index_and_load(self, path, after=None, ids=None,
                                props=None):
        """`<APP> index deck.jb [--level N,..]` (every source the deck's
        loaded levels name) with its log in the modal dialog, then
        open the deck in place; `after(err)` runs once the open
        settled. `props`: the launch's layer properties file for it."""
        def on_success():
            try:
                err = self.open_file(path, ids, props=props)
            except Exception as exc:
                err = "ERR %s" % exc
            if after is not None:
                after(err)
            elif err:
                self._set_live_status(
                    err[4:] if err.startswith("ERR ") else err)

        # a source that failed to index is a skipped placement: open
        # the deck with the rest (the log stays up with the error).
        # The command line is the Rust `floe2` (rust/floe2): the light
        # caches of the levels' sources and their occupancy summaries in
        # one modal run (user 2026-10-22: what the viewer opens is opened
        # again, so the summary is built before the open; 0.12.384-0.12.387
        # built it behind the open - `--no-occupancy` first, then a
        # background `floe2 index deck.jb` - which a deck of hundreds of GB
        # turned into hours of unasked work). The plan keeps what is there
        # and adds the summaries a capture's index left out
        from .vfsclient import find_floe2
        try:
            argv = [find_floe2(), "index", path, "--jobs", "12"]
        except RuntimeError as exc:
            self._set_live_status("jobdeck indexing failed: %s" % exc)
            return
        if ids:
            argv += ["--level", ",".join(str(i) for i in ids)]
        self._index_modal("indexing jobdeck sources…", argv,
                          on_success, "jobdeck indexing",
                          on_failure=lambda rc: on_success())

    def _jobdeck_reselect_levels(self):
        """Jobdeck > select levels to load… (user call 2026-09-10):
        the load dialog again on the open deck; the new selection is
        indexed as needed and opened in place, keeping the view."""
        cache = self.cache
        if not getattr(cache, "is_jobdeck", False):
            self._set_live_status(
                "not a jobdeck (File > load jobdeck… a .jb)")
            return
        ids = self._jobdeck_pick_levels(cache.src, current=cache.ids,
                                        force=True)
        if ids is False or ids == cache.ids:
            self._restore_keys()
            return
        view = (self.cx, self.cy, self.spp)

        def keep_view():
            self.cx, self.cy, self.spp = view
            self._fit_after_worker_start = False
            self.redraw(immediate=True)
        # the dialog's answer is final: None here means every level
        self._open_or_index(cache.src, then=keep_view, ids=ids,
                            ask_levels=False)

    def _jobdeck_mode(self):
        """The loaded jobdeck's colour mode, None for a layout."""
        cache = self.cache
        if getattr(cache, "is_jobdeck", False):
            return cache.mode
        return None

    def _jobdeck_toggle_view(self):
        """Ctrl+, (user call 2026-09-10): flip between MDPView's two
        jobdeck views - level view <-> chip view. From the source
        layer view it goes to the level view. Not a jobdeck: the same
        status note as the menu."""
        if not getattr(self.cache, "is_jobdeck", False):
            self._set_live_status(
                "not a jobdeck (File > load jobdeck… a .jb)")
            return
        self._jobdeck_set_mode(
            "chip" if self._jobdeck_mode() == "level" else "level")

    def _jobdeck_set_mode(self, mode):
        """Jobdeck > colour by …: re-plan the deck under the mode (the
        view layer table and the composite spec change), rebuild the
        layer panel and restart the worker on the new spec, keeping
        the current view."""
        cache = self.cache
        if not getattr(cache, "is_jobdeck", False):
            self._set_live_status(
                "not a jobdeck (File > load layout… a .jb)")
            self._restore_keys()
            return
        if cache.mode == mode:
            self._restore_keys()
            return
        view = (self.cx, self.cy, self.spp)
        cache.save_visibility(self.visible)
        self._loading_show("switching to %s view…" % {
            "layer": "source layer"}.get(mode, mode))
        try:
            cache.set_mode(mode)
        except Exception as exc:
            self._loading_hide()
            self._set_live_status("jobdeck colour mode: %s" % exc)
            self._restore_keys()
            return
        # the view controller opens the new spec at this view, not at a fit
        # it would draw first and then drop
        self._ctl_open_view = view
        try:
            self._apply_cache(cache)
        finally:
            self._ctl_open_view = None
        self.cx, self.cy, self.spp = view
        self._fit_after_worker_start = False
        self._set_live_status("jobdeck %s view" % mode)
        self._restore_keys()

    def _about_dialog(self):
        """Help > About (flateyes show_about parity): plain-text
        copyright with the URL shown, NOT clickable - a website
        link cannot open anything on the closed network."""
        dlg = Gtk.AboutDialog(transient_for=self.window, modal=True)
        dlg.set_keep_above(True)   # stay over a fullscreen parent
        dlg.set_program_name(APP)
        dlg.set_version(__version__)
        dlg.set_comments("\n".join(component_versions(self.worker)))
        dlg.set_copyright("2026 FLATIDE Inc.\nhttps://flatide.com")
        self._center_on_parent(dlg)
        dlg.run()
        dlg.destroy()
        # quartz fails to refocus the parent when a transient
        # closes (same as _confirm_quit)
        self._restore_keys()

    def _licenses_dialog(self):
        """Help > Open Source Licenses: the third-party components
        of the product with their licenses - the running bundle's own
        list where there is one, else the summary (oss_licenses_text)."""
        return self._text_window("Open Source Licenses", oss_licenses_text())

    def _eula_dialog(self):
        """Help > License Agreement: the product's own terms (eula_text),
        in Korean and in English. A line too wide for the window is
        wrapped: the Korean part's glyphs are the host's fonts', whose
        width is not the list font's."""
        return self._text_window("License Agreement", eula_text(), wrap=True)

    def _text_window(self, title, text, wrap=False):
        """A window with a text to read - the licenses, the agreement:
        scrolled, in the list's font, closed by its button or Escape."""
        dlg = Gtk.Window(title=title)
        dlg.set_transient_for(self.window)
        dlg.set_modal(True)
        # (the bundle's list is 78 columns wide: 546 px in the viewer's
        # font, and the margins and a scrollbar beside it)
        dlg.set_default_size(640, 520)
        self._center_on_parent(dlg)
        self._only_close_button(dlg)
        sw = Gtk.ScrolledWindow()
        tv = Gtk.TextView()
        tv.set_editable(False)
        tv.set_cursor_visible(False)
        tv.set_monospace(True)
        if wrap:
            tv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        for m in (tv.set_left_margin, tv.set_right_margin,
                  tv.set_top_margin, tv.set_bottom_margin):
            m(10)
        tv.get_buffer().set_text(text)
        sw.add(tv)
        dlg.add(sw)
        dlg.connect(
            "key-press-event",
            lambda _w, ev: (dlg.destroy() or True)
            if Gdk.keyval_name(ev.keyval) == "Escape" else False)
        dlg.show_all()
        dlg.present()
        return dlg

    def _menu_sync(self):
        """Reflect live state into the menu check items each time a
        menu opens (guarded: set_active must not call the toggle
        handlers back)."""
        self._menu_guard = True
        try:
            for it, state in self._menu_checks:
                it.set_active(bool(state()))
        finally:
            self._menu_guard = False
        self._drc_menu_roles()

    # the DRC menu's marking command as the session's mark makes it: a
    # requester's is a request (0.12.506)
    DRC_MARK_ITEM = {"waive": "waive/unwaive current error\tw",
                     "request": "request waive / take back request\tw"}

    def _drc_menu_roles(self):
        """The DRC menu's commands that are a role's, as the results open
        say (0.12.506, user 2026-11-16: the menus show what the role has):
        the marking command reads `request waive / take back request` in a
        requester's session and is not there in one that makes no mark (a
        confirmer's alone); `mark not for review` / `clear not for review`
        are there in a confirmer's session and in one without a role.
        Hidden, not insensitive - the Jobdeck menu's rule. With no results
        open the menu is as it always was."""
        db = getattr(self, "_drc", None)
        marks = getattr(db, "marks", "waive")
        mark = getattr(self, "_drc_menu_mark", None)
        if mark is not None:
            mark.set_label(self.DRC_MARK_ITEM.get(marks, self.DRC_MARK_ITEM["waive"]))
            mark.set_visible(marks != "none")
        for it in getattr(self, "_drc_menu_aside", ()):
            it.set_visible(bool(getattr(db, "sets_aside", True)))

    def _build_drc_panel(self):
        """DRC browser panel, embedded in the left pane (always
        available; formerly a separate window)."""
        win = _DrcPanel()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        # nothing above the lists (user 2026-11-10: the DRC UI is to be
        # plain). The info line, the reviewer line, the review statistics
        # with their export button and the conflict filter's state lines
        # left the panel: what a load has to say is in the status line
        # (_drc_loaded_text), and a load that did not happen or a review
        # moved aside is also written where the error details go, which is
        # empty until a rule is picked (_drc_not_loaded,
        # _drc_moved_aside_text).
        # top pane = rules list (left) | error-number grid (right);
        # bottom pane = per-error detail. Selecting a rule shows its
        # grid alone (one rule at a time = the accordion ask), and
        # the grid's own equal columns keep the numbers aligned
        # regardless of rule-title widths.
        # A rule with a cluster sidecar has selectable children. Parent
        # rows retain the complete rule, including unclassified errors.
        # Keep the rule/cluster identity columns stable; status is metadata only.
        rstore = Gtk.TreeStore(str, str, int, object, str, str)
        # raw name, count, ci, cluster, display name (optional ✓), tooltip
        # (the row's whole name: shown where the list cuts the name short)
        rules = Gtk.TreeView(model=rstore)
        for j, expand in ((4, True), (1, False)):
            cell = Gtk.CellRendererText()
            if j == 4:
                # long rule names truncate so the error count
                # column always stays visible
                cell.set_property("ellipsize",
                                  Pango.EllipsizeMode.END)
            col = Gtk.TreeViewColumn("", cell, text=j)
            col.set_expand(expand)
            rules.append_column(col)
            if j == 4:
                win._rule_name = (col, cell)
        rules.set_headers_visible(False)
        rules.set_enable_search(False)
        # a row's tooltip is its whole name, and comes for a row whose name
        # the list cuts short alone (user 2026-11-15: "drc 룰 목록에서 툴팁을
        # 이름이 줄어든 것에 대해서만 뜨게하고 내용도 전체 이름만 나오게
        # 수정해줘"; until 0.12.494 every row had one - the name, the SVRF
        # status' words and the CD groups' count)
        rules.set_has_tooltip(True)
        rules.connect("query-tooltip", self._on_drc_rule_tip)
        rules.get_selection().connect("changed",
                                      self._on_drc_rule_sel)
        rsc = Gtk.ScrolledWindow()
        # NO hscroll: at any pane width the name column ellipsizes
        # instead of the list panning/clipping sideways (user call
        # 2026-08-18 - shrunk panes must degrade to "…", never to
        # content cut off at the edge)
        rsc.set_policy(Gtk.PolicyType.NEVER,
                       Gtk.PolicyType.AUTOMATIC)
        rsc.add(rules)
        _remote_x_scroll_repaint(rsc)
        # rule search on TOP of the rules list (user call
        # 2026-08-18; GTK's built-in typeahead popup stays disabled)
        try:
            se = Gtk.SearchEntry()
            se.connect("search-changed", self._on_drc_search)
        except AttributeError:
            se = Gtk.Entry()
            se.connect("changed", self._on_drc_search)
        se.set_placeholder_text("find rule…")
        se.set_width_chars(8)   # keep the pane's width floor small
        win._search = se
        rbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                       spacing=2)
        rbox.pack_start(se, False, False, 0)
        rbox.pack_start(rsc, True, True, 0)
        # grid: DRC_GRID_W equal markup columns, NO row selection -
        # the clicked cell alone is marked (user call 2026-08-13)
        gstore = Gtk.ListStore(*([str] * DRC_GRID_W))
        grid = Gtk.TreeView(model=gstore)
        for j in range(DRC_GRID_W):
            col = Gtk.TreeViewColumn("", Gtk.CellRendererText(),
                                     markup=j)
            # every column expands: leftover pane width spreads
            # evenly instead of stacking up as a right margin
            col.set_expand(True)
            grid.append_column(col)
        grid.set_headers_visible(False)
        grid.set_enable_search(False)
        grid.get_selection().set_mode(Gtk.SelectionMode.NONE)
        # Some GTK3 versions replace markup underlines with NONE for a
        # prelit row. This grid owns its clicked/selected cell styles and
        # has no hover selection, drag or tooltip: keep its markup intact.
        grid.connect("enter-notify-event", lambda *_: True)
        grid.connect("motion-notify-event", lambda *_: True)
        grid.connect("button-press-event", self._on_drc_grid_click)
        # the number array REFLOWS to the pane width instead of
        # scrolling horizontally (user call 2026-08-13)
        grid.connect("size-allocate", self._on_drc_grid_alloc)
        gsc = Gtk.ScrolledWindow()
        # ALWAYS-on vscrollbar: its appearing/vanishing width made
        # the column reflow oscillate on big rules (field report
        # 2026-08-14 - the 120k rule "kept refreshing")
        gsc.set_policy(Gtk.PolicyType.NEVER,
                       Gtk.PolicyType.ALWAYS)
        gsc.add(grid)
        # (the least the divider over the grid leaves it: two rows, as the
        # group list's - the list starts DRC_GROUPS_PX high, which in a
        # short window would be the divider's whole height)
        gsc.set_size_request(-1, DRC_LIST_MIN_PX)
        _remote_x_scroll_repaint(gsc)
        pbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                       spacing=2)
        pbar.get_style_context().add_class("floe-drc-low")
        pprev = Gtk.Button(label="◀")
        pnext = Gtk.Button(label="▶")
        plabel = Gtk.Label(label="")
        for b, d in ((pprev, -1), (pnext, 1)):
            b.connect("clicked",
                      lambda _w, dd=d: self._drc_page_step(dd))
            b.set_sensitive(False)
        pbar.pack_start(pprev, False, False, 0)
        pbar.pack_start(plabel, True, True, 0)
        pbar.pack_start(pnext, False, False, 0)
        gbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                       spacing=2)
        # The pane's CD part - the basis and the step, the group list and
        # its pager - is in sight whenever a rule is in the grid (0.12.502;
        # from the user call of 2026-11-10 until then for a rule with CD
        # groups alone: _drc_delta_shown decides, _drc_delta_refresh shows
        # and hides). The two controls stand at the left at their
        # own widths, on one line (the same call: the three there were, in
        # a FlowBox that stretched each over the pane and wrapped them one
        # a line, took too much room each). On a pane narrower than the two
        # their texts shorten to "…" - the pane's content is never cut off
        # at its edge (user call 2026-08-18).
        delta_controls = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                                 spacing=4)
        delta_controls.get_style_context().add_class("floe-drc-low")
        delta_mode = Gtk.ComboBoxText()
        # (`same CD`, user 2026-11-15: "cd 그루핑을 cd값이 같은 것끼리 모으는
        # 것이 필요해" - the service's `value` basis: the errors of one CD
        # are a group, and there is no step to it)
        # (`reason`, user 2026-11-16: "CD 그룹쪽에 노트 기준 분류를 넣는 건 ...
        # 콤보에 note만 추가하면 될 것 같음" - the rule's reason groups in the list's
        # place: what its requests and waives say, _drc_reason_stages. The
        # entry was `note` in 0.12.502; the same day: "note를 reason으로
        # 변경해줘" - what the groups are made by is the reason of a request
        # or a waive, and a note is another thing here, an error's own)
        # (`absolute` and `ratio` stood before them until 0.12.524 - out of
        # the combo since, kept in the code: DRC_DELTA_BASES)
        for mid, label in DRC_DELTA_BASES:
            delta_mode.append(mid, label)
        for cell in delta_mode.get_cells():
            cell.set_property("ellipsize", Pango.EllipsizeMode.END)
        delta_mode.set_active_id(self._drc_delta_mode)
        # No control of this pane has a tooltip (0.12.509, user 2026-11-16:
        # "drc 패널에서 각종 버튼등에 툴팁으로 설명이 뜨는 것을 모두 제거해줘"):
        # the basis combo and the step button here, the two checks and the
        # two filter combos under the lists explained themselves in one
        # until then - a paragraph each over the pane, at every pause of
        # the pointer. What they said is in docs/DRC.ko.md. The lists' rows
        # keep theirs, which are the row's own - a rule's whole name where
        # the list cuts it short, a group's summary, a reason whole - and
        # the step in use is read there (`All errors`) and in the step's
        # dialog, which starts from it.
        delta_mode.connect("changed", self._on_drc_delta_mode)
        delta_controls.pack_start(delta_mode, False, False, 0)
        # the step is asked in a small modal (the same call: the pane kept
        # an entry and a `set step` button for it)
        delta_step = Gtk.Button(label="step")
        delta_step.get_child().set_ellipsize(Pango.EllipsizeMode.END)
        delta_step.connect("clicked", self._drc_step_dialog)
        delta_controls.pack_start(delta_step, False, False, 0)
        # (out of sight while no basis of the combo has a step to set: since
        # 0.12.525 none has - the two that had are out of it, DRC_DELTA_BASES.
        # The controls' show_all passes it by; it is still made and packed,
        # and in sight again when they are back)
        delta_step.set_no_show_all(
            all(mid in DRC_NO_STEP for mid, _label in DRC_DELTA_BASES))
        gbox.pack_start(delta_controls, False, False, 0)
        # Keep the group browser bounded as well as the 1,000-error grid.
        # A tiny step may produce one distinct group per error.
        delta_store = Gtk.ListStore(str, str, object, str)
        delta_tree = Gtk.TreeView(model=delta_store)
        for j in (0, 1):
            cell = Gtk.CellRendererText()
            if j == 0:
                cell.set_property("ellipsize", Pango.EllipsizeMode.END)
            col = Gtk.TreeViewColumn("", cell, text=j)
            col.set_expand(j == 0)
            delta_tree.append_column(col)
        delta_tree.set_headers_visible(False)
        delta_tree.set_enable_search(False)
        delta_tree.set_tooltip_column(3)
        delta_tree.get_selection().connect("changed", self._on_drc_delta_sel)
        delta_tree.connect("button-press-event", self._on_drc_delta_menu)
        delta_sc = Gtk.ScrolledWindow()
        delta_sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        # (the least the divider under the list leaves it: two rows)
        delta_sc.set_size_request(-1, DRC_LIST_MIN_PX)
        delta_sc.add(delta_tree)
        _remote_x_scroll_repaint(delta_sc)
        delta_list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        delta_list.pack_start(delta_sc, True, True, 0)
        # the group pager: there only when the groups fill more than one
        # page of 50, its arrows low, its text `page/pages` (user call
        # 2026-11-11; the line read `groups 1 / 1 · 5 groups · auto step
        # 0.00200 · …` for every rule - that is the `All errors` row's
        # tooltip now, _drc_delta_summary)
        delta_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        delta_bar.get_style_context().add_class("floe-drc-low")
        delta_label = Gtk.Label(label="")
        delta_label.set_ellipsize(Pango.EllipsizeMode.END)
        delta_prev, delta_next = Gtk.Button(label="◀"), Gtk.Button(label="▶")
        for button, direction in ((delta_prev, -1), (delta_next, 1)):
            button.set_sensitive(False)
            button.connect("clicked", lambda _w, d=direction:
                           self._drc_delta_page_step(d))
        delta_bar.pack_start(delta_prev, False, False, 0)
        delta_bar.pack_start(delta_label, True, True, 0)
        delta_bar.pack_start(delta_next, False, False, 0)
        delta_list.pack_start(delta_bar, False, False, 0)
        # the group list over the error grid, the line between them dragged
        # to give either more of the pane's height (user call 2026-11-11);
        # the error pager under its grid (the same call - it stood over it).
        # The list starts DRC_GROUPS_PX high (user 2026-11-16; 108 until
        # 0.12.504) - or as high as the grid's two rows and its pager
        # leave it, in a window too short for both: neither part is
        # dragged, or started, to nothing (the grid could be until then).
        ebox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        ebox.pack_start(gsc, True, True, 0)
        ebox.pack_start(pbar, False, False, 0)
        vsplit = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
        vsplit.pack1(delta_list, resize=False, shrink=False)
        vsplit.pack2(ebox, resize=True, shrink=False)
        vsplit.set_position(DRC_GROUPS_PX)
        gbox.pack_start(vsplit, True, True, 0)
        # out of sight until a rule is in the grid (and the pager until
        # there is a second page): the window's show_all
        # must not bring them up. With the list hidden the divider is the
        # grid's alone.
        for part in (delta_bar, delta_controls, delta_list):
            part.show_all()
            part.set_no_show_all(True)
            part.hide()
        win._delta_mode, win._delta_step = delta_mode, delta_step
        win._delta_store, win._delta_tree = delta_store, delta_tree
        win._delta_label = delta_label
        win._delta_prev, win._delta_next = delta_prev, delta_next
        win._delta_controls, win._delta_list = delta_controls, delta_list
        win._delta_bar, win._vsplit = delta_bar, vsplit
        hsplit = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        hsplit.pack1(rbox, resize=True, shrink=True)
        hsplit.pack2(gbox, resize=True, shrink=True)
        # PROPORTIONAL split (user report 2026-08-18: a fixed 220px
        # position swallowed the whole 196px startup pane, hiding
        # the grid with the handle stuck at the edge): the divider
        # keeps its FRACTION of the pane - drags update it, resizes
        # (like the auto-widen on db load) re-apply it
        # (the fraction is this one until the divider is dragged: GTK's
        # own first position - from the widths the two sides ask for,
        # which followed every change of the grid side's content - is not
        # taken for a drag. It is the share the rule list starts at beside
        # the group list, DRC_RULES_PX of the two - 0.44 until 0.12.504,
        # where GTK used to put it -, and the window's first results put
        # the divider at that width to the pixel: _hs_start, what
        # _drc_pane_room asks once the pane has the room)
        frac = [DRC_RULES_PX / float(DRC_RULES_PX + DRC_GROUPS_W_PX)]
        guard = [False]
        placed = [False]
        start = [None]      # the rule list's width asked for, until the next layout

        def _hs_pos(wdg, _pspec):
            w = wdg.get_allocated_width()
            if not guard[0] and placed[0] and w > 1 and start[0] is None:
                frac[0] = wdg.get_position() / float(w)

        def _hs_alloc(wdg, alloc):
            if alloc.width <= 1:
                return
            if start[0] is not None:
                # (a page too narrow for the width keeps its share)
                if alloc.width > start[0]:
                    frac[0] = start[0] / float(alloc.width)
                start[0] = None
            guard[0] = True
            try:
                wdg.set_position(int(round(alloc.width * frac[0])))
            finally:
                guard[0] = False
            placed[0] = True

        def _hs_start(px):
            # at the page's next layout - the pane's new width, where a
            # load has widened it; asked for where it has not
            start[0] = px
            hsplit.queue_resize()

        hsplit.connect("notify::position", _hs_pos)
        hsplit.connect("size-allocate", _hs_alloc)
        win._hsplit, win._hsplit_start = hsplit, _hs_start
        paned = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
        paned.pack1(hsplit, resize=True, shrink=True)
        detail = Gtk.TextView()
        detail.set_editable(False)
        detail.set_cursor_visible(False)
        detail.set_monospace(True)
        # narrow panes WRAP the detail text - no sideways clipping
        # or panning (user call 2026-08-18)
        detail.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        dsc = Gtk.ScrolledWindow()
        dsc.set_policy(Gtk.PolicyType.NEVER,
                       Gtk.PolicyType.AUTOMATIC)
        dsc.add(detail)
        # the error detail keeps a guaranteed slice of the pane
        # (user call 2026-08-22 - the minimap left, so the browser
        # owns the full height): shrink=False + a height floor
        # means neither the splitter nor a tall rules list can
        # squeeze it to nothing
        dsc.set_size_request(-1, 150)
        paned.pack2(dsc, resize=False, shrink=False)
        # it starts DRC_DETAIL_PX high, the lists over it with the rest of
        # the page (user 2026-11-16; until 0.12.504 the lists started 420
        # px high and the detail had what the window's first height left:
        # 286 px at the default size, more where the window came up larger)
        _start_size_after(paned, dsc, DRC_DETAIL_PX, vertical=True)
        box.pack_start(paned, True, True, 0)
        win._detail = detail.get_buffer()
        win._detail_box = dsc
        # a visible rule between the detail text and the buttons
        # (user call 2026-09-10)
        rule = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        rule.get_style_context().add_class("floe-drc-rule")
        box.pack_start(rule, False, False, 0)
        # the filters on ONE line (user call 2026-11-11): the two checks
        # and the two combos side by side at their own widths, from the
        # left. The row is a FlowBox that asks for the width of its four
        # in a line and is given no more (halign START), so nothing is
        # spread - left to fill, it shared the pane's spare width out
        # between its columns, and with a fifth control its second line's
        # combos widened the columns `in view` and `selected` stood in.
        # On a pane too narrow for the four it wraps, two a line, as
        # before - nothing shortened, nothing cut off at the pane's edge
        # (user call 2026-08-18) - and so asks the left pane for no more
        # than its two widest.
        nav = Gtk.FlowBox()
        nav.set_selection_mode(Gtk.SelectionMode.NONE)
        nav.set_min_children_per_line(2)
        nav.set_max_children_per_line(4)
        nav.set_column_spacing(6)
        nav.set_row_spacing(2)
        nav.set_halign(Gtk.Align.START)
        nav.get_style_context().add_class("floe-drc-low")
        box.pack_start(nav, False, False, 2)
        # (the four controls of this row have no tooltip, 0.12.509 - the
        # CD part's comment: `in view` lists the errors inside the current
        # view, `selected` the box- and Ctrl-selected ones)
        hl = Gtk.CheckButton(label="in view")
        hl.set_active(self._drc_hl)
        hl.connect("toggled", self._on_drc_hl)
        nav.add(hl)
        win._hl = hl
        selv = Gtk.CheckButton(label="selected")
        selv.connect("toggled", self._on_drc_selview)
        nav.add(selv)
        win._selv = selv
        # `Conflict only` is not offered yet (the same call: "우선 숨기고 -
        # 해당 기능 오픈은 추후에"): the check is made and wired as before -
        # the filter, its job and the reviewers window's snapshot are
        # untouched - and is in no row. To offer it: nav.add(conflict)
        # after `selected`.
        # (global judgement conflicts among visited reviewers in the last
        # Reviewers snapshot; it meets the current cluster, CD group and
        # waive filter, and the rule / group counts stay unfiltered)
        conflict = Gtk.CheckButton(label="Conflict only")
        conflict.connect("toggled", self._on_drc_conflict)
        win._conflict = conflict
        tf = Gtk.ComboBoxText()
        tf.append("all", "all types")
        tf.set_active_id("all")
        tf.set_sensitive(False)   # enabled once rules.json attaches
        # (by SVRF measurement type, or `CD grouped`: the rules with CD
        # groups made or prepared for the current basis and interval -
        # they come in as the background preparation ends)
        tf.connect("changed", self._on_drc_tfilter)
        nav.add(tf)
        win._tf = tf
        wf = Gtk.ComboBoxText()
        # an error's four states (user 2026-11-14: "메인 목록에서 상태
        # 4가지로 필터할 수 있어야 하고 reject 된 에러는 rejected로
        # 분류되어야"): the filter shows one, or all. A role's session has
        # two more, the requested and the declined (`_drc_wf_fit`)
        for wid, lbl in self.WF_ENTRIES:
            wf.append(wid, lbl)
        win._wf_role = False
        wf.set_active_id(self._drc_wfilter)
        wf.connect("changed", self._on_drc_wfilter)
        nav.add(wf)
        win._wf = wf
        for child in nav.get_children():
            child.set_can_focus(False)   # the controls take the focus
        win._rules, win._rstore = rules, rstore
        win._grid, win._gstore = grid, gstore
        win._plabel, win._pprev, win._pnext = plabel, pprev, pnext
        # the rules list and the error grid are black with white
        # text like the layer pane (PANEL_CSS `.floe-drc-list`; the
        # class sits on the tree views themselves, never on a
        # ScrolledWindow subtree - retina clip note) and their
        # scrollers share the layer pane's scrollbar look; the detail
        # text and the controls keep the theme (user call 2026-09-08)
        for tv, sc in ((rules, rsc), (grid, gsc), (delta_tree, delta_sc)):
            tv.get_style_context().add_class("floe-drc-list")
            sc.get_style_context().add_class("floe-layers-frame")
        self._drcwin = win
        return box

    # ---- cell tree (docs/SPEC-VIEWER.ko.md §8c) ---------------------------
    def _build_cell_panel(self):
        """Calibre-style cell tree in the left pane: a search box, the
        hierarchy (a row per distinct child with its placed member
        count, children loaded when a row opens) or - while the box
        holds a pattern - the matching cells in its place, a
        highlight/zoom row and an info line. Everything comes from
        renderd's hier thread (cell_sources / cells / cell_find /
        cell_bbox / cell_insts, rust_render.py) and the hierarchy index
        design.ovh next to the cache."""
        win = _CellPanel()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        try:
            se = Gtk.SearchEntry()
            se.connect("search-changed", self._on_cell_search)
        except AttributeError:
            se = Gtk.Entry()
            se.connect("changed", self._on_cell_search)
        se.set_placeholder_text("find cell… (* ? wildcards)")
        se.set_width_chars(8)   # keep the pane's width floor small
        se.connect("activate", lambda *_: self._cell_zoom_selected())
        box.pack_start(se, False, False, 2)
        # tree rows: name, count text, src, ci, loaded, kind (cell |
        # source | placeholder | more). The results list shares the
        # first four columns, so one selection handler serves both.
        store = Gtk.TreeStore(str, str, int, int, bool, str)
        results = Gtk.ListStore(str, str, int, int)
        tree = Gtk.TreeView(model=store)
        # whole names, a horizontal scrollbar when the tree is wider than
        # the pane (user call 2026-09-29: deep expansions indent the
        # rows - 30 levels are 570 px - and with hscroll NEVER that
        # width became the page's minimum, the pane clipped the page's
        # left side and nothing scrolled back; the DRC pane's
        # ellipsize-and-never-scroll rule stays its own)
        # the count follows its name, two spaces after it (user 2026-11-15:
        # "cell reference count 표시를 우측 정렬하지 않고 cell 이름 끝에 두 칸
        # 띄우고 표시하도록 변경해줘"; until 0.12.489 a column of its own,
        # right-aligned at the pane's edge): a row reads `NAME  ×8`, as a
        # jobdeck's source row reads `label  ×N`. One cell words both
        # (_cell_row_text) - two cells in a column are of one width in
        # every row, which would line the counts up after the longest name.
        name_cell = Gtk.CellRendererText()
        col = Gtk.TreeViewColumn("", name_cell)
        col.set_cell_data_func(name_cell, _cell_row_text)
        col.set_expand(True)
        tree.append_column(col)
        tree.set_headers_visible(False)
        tree.set_enable_search(False)
        # (no tooltip on the rows - user 2026-11-15: "cell tree에서 툴팁도
        # 삭제해줘", and again "cell tree 툴팁은 제거하는 걸로 하고 검색 결과도
        # 줄이지 않고 하단에 스크롤 바를 넣어줘"; until 0.12.491 a row's name
        # was its tooltip. Every row shows its whole name - the search's
        # results too since 0.12.493 - and the view scrolls sideways)
        tree.connect("test-expand-row", self._on_cell_expand)
        tree.connect("row-activated", self._on_cell_activate)
        tree.get_selection().connect("changed", self._on_cell_select)
        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sc.add(tree)
        _remote_x_scroll_repaint(sc)
        tree.get_style_context().add_class("floe-drc-list")
        sc.get_style_context().add_class("floe-layers-frame")
        box.pack_start(sc, True, True, 0)
        # the control row is a FlowBox: at a narrow pane the buttons wrap
        # into more rows instead of widening the page (field 2026-09-29:
        # one HBox of four buttons made the page 276 px wide against the
        # pane's 196 px start, and GtkPaned shrinks a too-wide first
        # child by clipping its LEFT side - the tabs went off screen;
        # the DRC page's filter row wraps the same way)
        row = Gtk.FlowBox()
        row.set_selection_mode(Gtk.SelectionMode.NONE)
        row.set_min_children_per_line(1)
        row.set_max_children_per_line(8)
        row.set_homogeneous(False)
        row.set_column_spacing(4)
        row.set_row_spacing(2)
        hl = Gtk.CheckButton(label="highlight")
        hl.set_active(self._cell_hl_on)   # off at a start (0.12.492)
        hl.connect("toggled", self._on_cell_hl)
        row.add(hl)
        # back to the top cell, where the `zoom` button was: what
        # Ctrl+Shift+T, Cell > view root: back to the top cell and a
        # double-click on the top cell's row do (_cell_root_top). User
        # 2026-11-15: "zooom 버튼 대신 view root를 버튼으로 만들고 이름은 root로
        # 해줘" (0.12.492: `root`, the selected cell as the view root), then
        # "root 버튼을 top으로 수정하고 Ctrl+Shift+T와 동일한 동작을 하도록
        # 수정해줘" (0.12.493). A cell is made the view root by a
        # double-click on its row or the menu's command, as before.
        # (A `root` and a `top` button were here until 2026-10-04.)
        top = Gtk.Button(label="top")
        top.connect("clicked", lambda *_: self._cell_root_top())
        row.add(top)
        for child in row.get_children():
            child.set_can_focus(False)   # the buttons take the focus
        box.pack_start(row, False, False, 0)
        # shown when a source's hierarchy index is missing (its own row:
        # a hidden widget inside the FlowBox would still hold a cell)
        build = Gtk.Button(label="build index…")
        build.connect("clicked",
                      lambda *_: self._cell_index_offer(None, ask=True))
        build.set_no_show_all(True)
        build_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        build_row.pack_start(build, False, False, 2)
        box.pack_start(build_row, False, False, 0)
        info = Gtk.Label(label="no layout")
        info.set_xalign(0.0)
        info.set_line_wrap(True)
        info.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        info.set_max_width_chars(20)
        box.pack_start(info, False, False, 2)
        win._search, win._tree = se, tree
        win._name_cell = name_cell
        win._store, win._results = store, results
        win._info, win._hl, win._top, win._build = info, hl, top, build
        self._cellwin = win
        return box

    def _drc_pane_room(self):
        """A load of results: the left pane as wide as the DRC page starts
        - the rule list DRC_RULES_PX, the group list beside it
        DRC_GROUPS_W_PX (user 2026-11-16; a load widened the pane to 420 px
        until 0.12.504, and the rule list had 44% of it). The pane is
        widened to that where it is narrower, at every load as before, and
        never narrowed - the user can still drag it back. The divider
        between the two lists is put at the rule list's width by the
        window's first results alone and is the user's from there (it
        keeps its share of the page as the pane's width changes)."""
        w = self._drcwin
        split = w._hsplit
        # the page's width: the two lists and the divider between them -
        # all a paned of two parts that shrink asks for at the least is
        # its divider -, and the pane's: what stands around the page too
        # (the notebook's border), read from the layout there is
        page = split.get_allocated_width()
        around = self._left_pane.get_allocated_width() - page if page > 1 else 0
        need = (DRC_RULES_PX + split.get_preferred_width()[0] + DRC_GROUPS_W_PX
                + max(0, around))
        if self._lpaned.get_position() < need:
            self._lpaned.set_position(need)
        if not getattr(self, "_drc_pane_started", False):
            self._drc_pane_started = True
            w._hsplit_start(DRC_RULES_PX)

    def _left_show(self, name):
        """Raise the left pane's cells or DRC page."""
        nb = getattr(self, "_left_nb", None)
        if nb is not None:
            nb.set_current_page(0 if name == "cells" else 1)

    def _cell_tree_focus(self):
        """'t' / Cell menu: raise the cell tree and put the keys in its
        search box (a canvas click hands them back)."""
        if self._cellwin is None:
            return
        self._left_show("cells")
        if self._lpaned.get_position() < LEFT_PANE_PX:
            self._lpaned.set_position(LEFT_PANE_PX)
        self._cellwin._search.grab_focus()

    def _cell_state_reset(self):
        """A new layout (or none): empty tree, no selection, no
        highlight, every query in flight forgotten."""
        self._cell_seq += 1
        self._cell_pending = {}
        self._cell_sources = None
        self._cell_sel = None
        self._cell_sel_text = ""
        self._cell_view_text = ""
        self._cell_hl = None
        self._cell_hl_key = None
        self._cell_nohier = set()
        self._cell_mode = "tree"
        self._cell_open_rows = []
        # a picked shape's cell in the tree (_cell_pick_show): the chain
        # being walked, its question, the cell the pick selected
        self._cell_reveal = None
        self._cell_path_seq = None
        self._cell_picked = None
        self._view_root = None
        w = getattr(self, "_cellwin", None)
        if w is None:
            return
        w._store.clear()
        w._results.clear()
        w._tree.set_model(w._store)
        # (a layout that comes while the results are shown: sized anew)
        self._cell_columns_size()
        w._search.set_text("")
        w._build.hide()
        w._info.set_text("no layout" if self.cache is None else "loading…")

    def _cell_query(self, kind, job, pending):
        """Submit one cell query to the render service; its answer
        (matched by seq) lands in _on_cell_result with `pending` =
        (what, row reference or key, src). None when no service runs."""
        worker = self.worker
        if worker is None or not getattr(worker, "alive", lambda: False)():
            return None
        self._cell_seq += 1
        seq = self._cell_seq
        self._cell_pending[seq] = pending
        worker.submit(dict(job, kind=kind, seq=seq))
        return seq

    def _cell_tree_load_roots(self):
        """Ask the service for the sources: a layout's top cell becomes
        the root and opens at once, a jobdeck's sources become the
        roots (their top cells' children load when a row opens)."""
        if self._cellwin is None or self.cache is None:
            return
        self._cell_query("cell_sources", {}, ("sources", None, -1))

    def _cell_source_label(self, source):
        """A jobdeck source's row label: the deck's identifier for the
        cache folder (the layer panel's leaf name), else the folder."""
        path = os.path.abspath(source.get("path", ""))
        label = None
        catalog = getattr(self.cache, "catalog", None)
        for tc, info in (getattr(catalog, "infos", None) or {}).items():
            cache_dir = getattr(info, "cache_dir", None)
            if cache_dir and os.path.abspath(cache_dir) == path:
                label = str(tc)
                break
        if label is None:
            label = os.path.basename(path.rstrip(os.sep))
            if label.startswith("."):
                label = label[1:]
            if label.endswith(".ice"):
                label = label[:-4]
        if source.get("placements", 1) > 1:
            label += "  ×%d" % source["placements"]
        return label

    def _on_cell_result(self, res):
        pending = self._cell_pending.pop(res.get("seq"), None)
        w = self._cellwin
        if pending is None or w is None:
            return   # a stale answer (new layout) or no panel
        what, ref, src = pending
        if not res.get("found"):
            code = res.get("code")
            if code == "superseded":
                return
            if what == "pick":
                # no cell of the picked shape's name in the index, or no
                # index: the tree stays as it is, nothing asked or said
                return
            if code == "nohier":
                self._cell_index_offer(src, res.get("err", ""))
            else:
                w._info.set_text("%s: %s" % (res.get("kind"),
                                             res.get("err") or "error"))
            return
        kind = res["kind"]
        if kind == "cell_sources":
            self._cell_sources = res["sources"]
            w._store.clear()
            if len(self._cell_sources) == 1:
                # a layout: its top cell is the root, opened at once
                self._cell_query("cells", {"src": 0}, ("root", None, 0))
            else:
                for s in self._cell_sources:
                    it = w._store.append(
                        None, [self._cell_source_label(s), "",
                               s["src"], -1, False, "source"])
                    w._store.append(it, ["…", "", s["src"], -1, False,
                                         "placeholder"])
                w._info.set_text("%d sources" % len(self._cell_sources))
        elif kind == "cells":
            if what == "root_set":
                self._apply_view_root(res)
            else:
                self._cell_fill(what, ref, res)
        elif kind == "cell_find":
            if res["seq"] != self._cell_find_seq:
                return
            w._results.clear()
            for m in res["matches"]:
                w._results.append([m["name"],
                                   fmt_count(m["insts"]) if m["insts"]
                                   else "0", m["src"], m["cell"]])
            if w._tree.get_model() is not w._results:
                # the results take the tree's place: the rows open in the
                # tree are kept for when the search ends (GTK closes every
                # row of a model it is handed)
                self._cell_open_rows = self._cell_tree_open_rows()
                w._tree.set_model(w._results)
            # the column as wide as these rows - a column only grows by
            # itself, and the tree's width, or a search before this one,
            # would stay - and the rows' start in sight
            self._cell_columns_size()
            w._tree.scroll_to_point(0, -1)
            self._cell_mode = "find"
            shown = len(res["matches"])
            total = res["total"]
            w._info.set_text("%s match%s%s" % (
                fmt_count(total), "" if total == 1 else "es",
                "" if shown >= total else " (showing %d)" % shown))
        elif kind == "cell_path":
            if what == "pick" and res["seq"] == getattr(self, "_cell_path_seq", None):
                self._cell_path_seq = None
                self._cell_reveal_start(res)
        elif kind == "cell_bbox":
            if what == "zoom":
                self._cell_frame(res)
        elif kind == "cell_info":
            if res["seq"] != self._cell_info_seq:
                return
            w._info.set_text(self._cell_info_text(res))
            self._cell_sel_text = res.get("text") or ""
            if ref:   # the selection asked; a root change says its own
                self._cell_status()
        elif kind == "cell_insts":
            if res["seq"] != self._cell_insts_seq:
                return
            # (the selection may be gone before its instances land - a pick
            # selects a cell and the next click on nothing takes it away:
            # no highlight for a cell that is not selected)
            sel = getattr(self, "_cell_sel", None)
            if sel is None or (res.get("src", sel[0]), res.get("cell", sel[1])) != (sel[0], sel[1]):
                return
            self._cell_hl = {"src": res["src"], "cell": res["cell"],
                             "boxes": res["boxes"], "more": res["more"],
                             "key": ref}
            # exact, with separators, as the facts before it count
            self._cell_view_text = "{:,} in view{}".format(
                len(res["boxes"]), " (more - zoom in)" if res["more"] else "")
            self._cell_status()
            self._display()

    def _cell_fill(self, what, ref, res):
        """Children rows under a tree row (or, for `root`, the layout's
        top as a new root, opened)."""
        w = self._cellwin
        store = w._store
        src = res["src"]
        expanded = False
        if what == "root":
            store.clear()
            it = store.append(None, [res["name"], "", src, res["cell"],
                                     True, "cell"])
        else:
            if ref is None or not ref.valid():
                return
            it = store.get_iter(ref.get_path())
            expanded = w._tree.row_expanded(ref.get_path())
            store[it][4] = True
            if store[it][5] == "source":
                store[it][3] = res["cell"]
        # the placeholder rows go AFTER the children are in: a row whose
        # last child is removed is collapsed by GTK, and the user just
        # opened this one (field 2026-09-29: the first expand closed at
        # once, later ones worked)
        stale = []
        child = store.iter_children(it)
        while child is not None:
            stale.append(child)
            child = store.iter_next(child)
        for c in res["children"]:
            cit = store.append(it, [
                c["name"],
                "" if c["members"] == 1 else "×%s" % fmt_count(c["members"]),
                src, c["cell"], bool(c["leaf"]), "cell"])
            if not c["leaf"]:
                store.append(cit, ["…", "", src, c["cell"], False,
                                   "placeholder"])
        missing = res["total"] - len(res["children"])
        if missing > 0:
            store.append(it, ["… %s more (find by name)" % fmt_count(missing),
                              "", src, -1, True, "more"])
        for old in stale:
            store.remove(old)
        if (what == "root" or expanded) and store.iter_has_child(it):
            w._tree.expand_row(store.get_path(it), False)
            w._info.set_text("%s: %s child%s" % (
                res["name"], fmt_count(res["total"]),
                "" if res["total"] == 1 else "ren"))
        # a picked shape's cell waits for these rows (_cell_reveal_step)
        if getattr(self, "_cell_reveal", None) is not None:
            self._cell_reveal_step()

    def _on_cell_expand(self, tree, it, path):
        """A row opens: load its children once (the placeholder row
        stands until the answer lands)."""
        store = self._cellwin._store
        if tree.get_model() is not store:
            return False
        row = store[it]
        if row[4] or row[5] not in ("cell", "source"):
            return False
        row[4] = True
        ref = Gtk.TreeRowReference.new(store, path)
        seq = self._cell_query(
            "cells", {"src": row[2],
                      "cell": None if row[5] == "source" else row[3]},
            ("children", ref, row[2]))
        if seq is None:
            row[4] = False
        return False

    def _on_cell_select(self, sel):
        """A cell row (tree or results): remember it, say its facts on the
        status line (user 2026-10-15: "셀 트리에서 셀을 선택하면 셀의
        관련정보(좌표등)을 상태줄에 표시해줘") and its instance count and
        extent in the panel, highlight its instances in the view."""
        model, it = sel.get_selected()
        w = self._cellwin
        if it is None or w is None:
            return
        src, ci = model[it][2], model[it][3]
        if ci < 0:
            return   # a source not loaded yet, a placeholder, "more"
        if model is w._store and model[it][5] not in ("cell", "source"):
            return
        self._cell_sel = (src, ci, model[it][0])
        self._cell_sel_text = ""
        self._cell_view_text = ""
        self._cell_status()   # the name until the facts come
        self._cell_info_query(announce=True)
        self._cell_hl_key = None
        self._cell_hl_query()

    def _cell_info_query(self, announce=True):
        """Ask for the selected cell's facts under the view root (renderd
        `cell_info`, worded by app-core view::cell_info): the panel's info
        line and the status line - said at once when `announce`, else kept
        for the cursor's line (a view root change says its own)."""
        if getattr(self, "_cell_sel", None) is None:
            return
        src, ci, _name = self._cell_sel
        self._cell_info_seq = self._cell_query(
            "cell_info", {"src": src, "cell": ci, "root": self._root_ci()},
            ("info", announce, src))

    def _cell_status_text(self):
        """The selected cell's part of the status line: its facts, then
        its instances in the view; empty without a selected cell."""
        sel = getattr(self, "_cell_sel", None)
        if sel is None:
            return ""
        parts = [getattr(self, "_cell_sel_text", "") or sel[2]]
        if getattr(self, "_cell_view_text", ""):
            parts.append(self._cell_view_text)
        return " · ".join(parts)

    def _cell_status(self):
        """Say the selected cell on the status line (the cursor's next
        move puts its coordinates in front)."""
        text = self._cell_status_text()
        if text:
            # (a picked shape's line stays in front of the cell's, as the
            # cursor's move words the line: a pick selects its cell here)
            picked = getattr(self, "_sel_text", "")
            self._set_live_status("%s   |   %s" % (picked, text) if picked else text)

    def _cell_pick_show(self, name):
        """A picked shape's cell in the cell tree (user 2026-11-15: "도형을
        picking할 경우 레이어 목록에서 해당 레이어에 표시를 해주고 있는데 cell
        tree에는 표시를 하지 않고 있어. cell tree에도 해당 cell을 마우스 클릭한
        상태로 만들어줘"): the row of the cell that holds the shape is
        selected as a click selects it - the rows above it opened, the row
        in sight, the cell's facts and its instances in the view as after a
        click (_on_cell_select). A pick names the cell alone and the tree
        loads a row's children when the row is opened, so the service is
        asked for the cells from the top down to it (`cell_path`, renderd
        0.12.483) and the rows on the way are loaded one after another
        (_cell_reveal_step). `name` None: the pick is gone - a selection a
        pick made goes with it, one made by hand stays. A jobdeck's tree
        is its sources': nothing is shown there."""
        self._cell_reveal = None
        self._cell_path_seq = None
        w = getattr(self, "_cellwin", None)
        if w is None or getattr(self, "cache", None) is None:
            return
        if name is None:
            picked, self._cell_picked = getattr(self, "_cell_picked", None), None
            sel = getattr(self, "_cell_sel", None)
            if picked is not None and sel is not None \
                    and (sel[0], sel[1]) == picked:
                self._cell_hl_clear(display=False)
            return
        if getattr(self.cache, "is_jobdeck", False):
            return
        self._cell_path_seq = self._cell_query(
            "cell_path", {"src": 0, "name": name}, ("pick", None, 0))

    def _cell_reveal_start(self, res):
        """`cell_path`'s answer for a picked shape's cell: the cells from
        the top down to it (none: the top does not reach the cell)."""
        path = [int(c) for c in res.get("path") or ()]
        if not path:
            return
        self._cell_reveal = {"src": int(res.get("src", 0)), "path": path}
        self._cell_reveal_step()

    def _cell_reveal_step(self):
        """Walk the tree's rows down the chain a pick asked for, as far as
        they are loaded. A row whose children are not there is asked for
        them once and the walk goes on when they land (_cell_fill); the
        chain's last row is selected - what a click on it does - with the
        rows above it open and the row in sight. While the search box shows
        its results the cell is selected among them when it is listed, and
        the tree is left as it is. A cell that is not among a row's listed
        children (more children than one answer carries) is not shown."""
        reveal = getattr(self, "_cell_reveal", None)
        w = getattr(self, "_cellwin", None)
        if reveal is None or w is None:
            return
        src, path = reveal["src"], reveal["path"]
        tree, store = w._tree, w._store
        if tree.get_model() is not store:
            self._cell_reveal = None
            results = w._results
            it = results.get_iter_first()
            while it is not None:
                if results[it][2] == src and results[it][3] == path[-1]:
                    self._cell_picked = (src, path[-1])
                    tree.get_selection().select_iter(it)
                    tree.scroll_to_cell(results.get_path(it), None, False, 0.0, 0.0)
                    self._cell_status()
                    break
                it = results.iter_next(it)
            return
        it = store.get_iter_first()
        if it is None:
            return   # the tree's top is on its way: its fill goes on
        if store[it][5] != "cell" or store[it][3] != path[0]:
            self._cell_reveal = None
            return
        for wanted in path[1:]:
            child, found, loading = store.iter_children(it), None, False
            while child is not None:
                kind = store[child][5]
                if kind == "cell" and store[child][3] == wanted:
                    found = child
                    break
                if kind == "placeholder":
                    loading = True
                child = store.iter_next(child)
            if found is None:
                if not loading and store[it][4]:
                    self._cell_reveal = None   # loaded, and not listed
                elif not store[it][4]:
                    store[it][4] = True
                    ref = Gtk.TreeRowReference.new(store, store.get_path(it))
                    if self._cell_query(
                            "cells", {"src": store[it][2], "cell": store[it][3]},
                            ("children", ref, store[it][2])) is None:
                        store[it][4] = False
                        self._cell_reveal = None
                return
            it = found
        self._cell_reveal = None
        at = store.get_path(it)
        if at.get_depth() > 1:
            above = at.copy()
            above.up()
            tree.expand_to_path(above)
        self._cell_picked = (store[it][2], store[it][3])
        tree.get_selection().select_iter(it)
        tree.scroll_to_cell(at, None, True, 0.5, 0.0)
        # (a row selected already says nothing by itself: the line again)
        self._cell_status()

    def _on_cell_activate(self, tree, path, _col):
        """Double-click / Enter on a cell row: draw that cell as the view
        root (SPEC-VIEWER §8c; user 2026-10-04: "double-clicking a cell in
        the cell tree makes it the root" - the panel's `root` and `top`
        buttons went); on the layout's top cell, back to the top. A
        jobdeck has no view root: its rows zoom, as every row did before.
        A placeholder or a `more` row does nothing."""
        w = self._cellwin
        if w is None:
            return
        model = tree.get_model()
        row = model[path]
        src, ci = row[2], row[3]
        kind = "cell" if model is w._results else row[5]
        if ci < 0 or kind not in ("cell", "source"):
            return
        self._cell_sel = (src, ci, row[0])
        if getattr(self.cache, "is_jobdeck", False):
            self._cell_zoom_selected()
        elif ci == self._cell_top_ci():
            self._cell_root_top()
        else:
            self._cell_set_root()

    def _cell_top_ci(self):
        """The layout's top cell as the tree shows it - its one root row -
        or None (a jobdeck's sources, no tree yet)."""
        w = self._cellwin
        if w is None or len(getattr(self, "_cell_sources", None) or ()) != 1:
            return None
        it = w._store.get_iter_first()
        if it is None or w._store[it][5] != "cell":
            return None
        return w._store[it][3]

    def _cell_info_text(self, res):
        name = self._cell_sel[2] if self._cell_sel else "cell"
        insts = res["insts"]
        under = ("the top cell" if self._view_root is None
                 else "the view root %s" % self._view_root["name"])
        if not insts:
            return "%s: not placed under %s" % (name, under)
        b = res["bbox"]
        if b is None:
            return "%s: %s instance%s, no shapes" % (
                name, fmt_count(insts), "" if insts == 1 else "s")
        return "%s: %s instance%s · %.2f × %.2f um%s" % (
            name, fmt_count(insts), "" if insts == 1 else "s",
            (b[2] - b[0]) * self.dbu, (b[3] - b[1]) * self.dbu,
            " (the blocks holding it)" if res["approx"] else "")

    def _cell_zoom_selected(self):
        """Zoom to the selected cell's instances (their extent)."""
        if self._cell_sel is None:
            self._set_live_status("select a cell in the tree first")
            return
        src, ci, _name = self._cell_sel
        self._cell_query("cell_bbox", {"src": src, "cell": ci,
                                       "root": self._root_ci()},
                         ("zoom", None, src))

    def _cell_frame(self, res):
        """Frame a cell's extent like a DRC jump: the box spans
        CELL_VIEW_FRACTION of the view on both axes."""
        name = self._cell_sel[2] if self._cell_sel else "cell"
        b = res.get("bbox")
        if b is None:
            self._set_live_status("%s: nothing to zoom to (%s)" % (
                name, "not placed under the top cell" if not res["insts"]
                else "no shapes"))
            return
        w_um = (b[2] - b[0]) * self.dbu
        h_um = (b[3] - b[1]) * self.dbu
        cx = (b[0] + b[2]) / 2.0 * self.dbu
        cy = (b[1] + b[3]) / 2.0 * self.dbu
        vw, vh = self._viewport_size()
        win = w_um / CELL_VIEW_FRACTION
        if vh > 0:
            win = max(win, h_um / CELL_VIEW_FRACTION * (vw / float(vh)))
        if win <= 0:
            win = 0.1
        self.goto(cx, cy, win)
        insts = res["insts"]
        self._set_live_status("%s: %s instance%s%s" % (
            name, fmt_count(insts), "" if insts == 1 else "s",
            " (zoomed to the blocks holding it)" if res["approx"] else ""))

    def _die_bbox(self):
        """The die the fit, the clamp and the minimap frame: the view
        root's recursive bbox (its coordinates) when one is set, else
        the layout's bbox (meta)."""
        root = getattr(self, "_view_root", None)
        if root is not None:
            return root["bbox"]
        return self.meta["bbox"]

    def _root_ci(self):
        """The view root's cell index for the render, clip and cell
        queries; None = the top cell."""
        root = getattr(self, "_view_root", None)
        return None if root is None else root["cell"]

    def _cell_set_root(self):
        """Cell menu / a double-click on a tree row: draw the selected
        cell as the view root (Calibre's cell tree: the selected cell
        becomes the displayed top). Its recursive bbox comes with a
        `cells` answer; the root is applied when it lands."""
        if self.cache is None:
            self._set_live_status("no layout")
            return
        if getattr(self.cache, "is_jobdeck", False):
            self._set_live_status(
                "a jobdeck has no view root: its sources' tops are its cells")
            return
        if self._cell_sel is None:
            self._set_live_status("select a cell in the tree first (t)")
            return
        src, ci, name = self._cell_sel
        root = self._view_root
        if root is not None and root["cell"] == ci:
            self._set_live_status("%s is the view root already" % name)
            return
        seq = self._cell_query("cells", {"src": src, "cell": ci},
                               ("root_set", None, src))
        if seq is None:
            self._set_live_status("no render service")

    def _apply_view_root(self, res):
        """A `cells` answer for the cell to become the view root: the
        picture restarts from it - every frame on screen belongs to
        another coordinate system, so the stale frame and the margin go,
        the minimap bases are rebuilt around its bbox, and the view fits
        it. The tree keeps showing the whole hierarchy."""
        bbox = res.get("bbox")
        if bbox is None:
            self._set_live_status("%s has no shapes: nothing to show as "
                                  "the view root" % res.get("name", "cell"))
            return
        self._view_root = {"cell": res["cell"], "name": res["name"],
                           "bbox": [float(v) for v in bbox],
                           "height": res.get("height", 0)}
        self._root_changed()
        self._set_live_status(
            "view root: %s (%s; back to the top: double-click the top cell "
            "or Ctrl+Shift+T)" % (res["name"], self._depth_label_for_root()))

    def _cell_root_top(self):
        """Ctrl+Shift+T / Cell menu / a double-click on the top cell's row:
        back to the file's top cell."""
        if self._view_root is None:
            self._set_live_status("the top cell is the view root already")
            return
        self._view_root = None
        self._root_changed()
        self._set_live_status("view root: the top cell")

    def _root_changed(self):
        """The view root moved: nothing on screen or in flight belongs to
        the new coordinates; fit the new die."""
        self._minimap_bases = {}
        self._border = None
        self.last_frame = None
        self._margin_frame = None
        self._frame_anchor = None
        self._clear_pending()
        self._cell_hl = None
        self._cell_hl_key = None
        root = self._view_root
        self._title_show()
        # the depth counts from the root: its deepest level is the root's
        # height (the depth itself is kept, so the top restores the view)
        dstatus = getattr(self, "dstatus", None)
        if dstatus is not None:
            dstatus.set_text(self._depth_label())
        self.fit()
        # the selected cell's facts and highlight follow it into the new
        # coordinates
        self._cell_sel_text = ""
        self._cell_view_text = ""
        self._cell_info_query(announce=False)
        self._cell_hl_query()

    def _depth_label_for_root(self):
        root = self._view_root
        if root is None:
            return "top"
        return "%d level%s below" % (root["height"],
                                     "" if root["height"] == 1 else "s")

    def _cell_hl_query(self):
        """Ask for the selected cell's instances in the current view
        (once per view: the key dedups the frame-landed follow-ups)."""
        if not self._cell_hl_on or self._cell_sel is None \
                or self.cache is None:
            return
        src, ci, _name = self._cell_sel
        b = self.view_bbox()
        root = self._root_ci()
        key = (src, ci, root, tuple(int(round(v)) for v in b))
        if key == self._cell_hl_key:
            return
        self._cell_hl_key = key
        self._cell_insts_seq = self._cell_query(
            "cell_insts", {"src": src, "cell": ci, "view": b,
                           "cap": CELL_INSTS_CAP, "root": root},
            ("insts", key, src))

    def _cell_hl_follow(self):
        """A frame landed: the highlight follows the view it shows."""
        if self._cell_hl_on and self._cell_sel is not None:
            self._cell_hl_query()

    def _cell_hl_set(self, on):
        """The highlight switch (menu / panel check)."""
        w = self._cellwin
        if w is not None and w._hl.get_active() != bool(on):
            w._hl.set_active(bool(on))   # its handler does the rest
            return
        self._cell_hl_on = bool(on)
        if not on:
            self._cell_hl = None
            self._cell_hl_key = None
            self._cell_view_text = ""
            self._display()
        else:
            self._cell_hl_query()

    def _on_cell_hl(self, btn):
        self._cell_hl_on = btn.get_active()
        if not self._cell_hl_on:
            self._cell_hl = None
            self._cell_hl_key = None
            self._cell_view_text = ""
            self._display()
        else:
            self._cell_hl_query()

    def _cell_hl_clear(self, display=True):
        """Esc / menu: drop the highlight and the tree selection it
        follows (the switch stays as it is), and the selected cell's
        status line."""
        selected = self._cell_sel is not None
        self._cell_hl = None
        self._cell_hl_key = None
        self._cell_sel = None
        self._cell_sel_text = ""
        self._cell_view_text = ""
        w = self._cellwin
        if w is not None:
            w._tree.get_selection().unselect_all()
        if selected:
            self._set_live_status("cell selection cleared")
        if display:
            self._display()

    def _on_cell_search(self, entry):
        """The search box: empty = the tree; a pattern (substring, or a
        whole-name glob with * ?) = the matching cells in its place,
        queried CELL_SEARCH_MS after the last keystroke."""
        txt = entry.get_text().strip()
        w = self._cellwin
        if self._cell_search_timer is not None:
            GLib.source_remove(self._cell_search_timer)
            self._cell_search_timer = None
        if not txt:
            if self._cell_mode != "tree":
                self._cell_tree_back()
            return

        def fire():
            self._cell_search_timer = None
            self._cell_find_seq = self._cell_query(
                "cell_find", {"pattern": txt, "limit": CELL_FIND_LIMIT},
                ("find", None, -1))
            if self._cell_find_seq is None:
                w._info.set_text("no render service")
            return False
        self._cell_search_timer = GLib.timeout_add(CELL_SEARCH_MS, fire)

    def _cell_tree_open_rows(self):
        """The tree's rows that are open, a parent before its children, as
        references into the tree's store."""
        w = self._cellwin
        rows = []
        w._tree.map_expanded_rows(
            lambda _tree, path, *_more: rows.append(
                Gtk.TreeRowReference.new(w._store, path)))
        return rows

    def _cell_columns_size(self):
        """The view's column sized anew for the rows it shows now. Every
        row shows its whole name, in the tree (2026-09-29: a deep row is
        indented) and in the search's results (0.12.493, user 2026-11-15:
        "검색 결과도 줄이지 않고 하단에 스크롤 바를 넣어줘" - 0.12.488 to
        0.12.492 cut a long result in its middle to the pane), and the view
        scrolls sideways: a scroll bar at its bottom where a row is wider
        than the pane. A GTK column only grows by itself, so the width a
        long row gave it would stay when other rows take its place - the
        tree after a search, a search after another: every such change
        sizes it again. (The count follows its name in the name's cell
        since 0.12.490, so a long row takes no other row's count out of
        sight.)"""
        self._cellwin._tree.columns_autosize()

    def _cell_tree_back(self):
        """The search box emptied: the tree in the results' place, as it
        was before the search. GTK closes every row of a model a view is
        handed, so the tree came back with its top cell closed (user
        2026-11-15: "검색을 마치면 top cell이 접힌채로 표시되는 버그"): the
        rows that were open are opened again, and a layout's top cell is
        open whatever came meanwhile (its children may have landed while
        the results were shown). The column goes back to the tree's own
        width."""
        w = self._cellwin
        self._cell_mode = "tree"
        w._tree.set_model(w._store)
        w._results.clear()
        self._cell_columns_size()
        for ref in getattr(self, "_cell_open_rows", ()):
            if ref.valid():
                w._tree.expand_row(ref.get_path(), False)
        self._cell_open_rows = []
        top = w._store.get_iter_first()
        if top is not None and w._store[top][5] == "cell" \
                and w._store.iter_has_child(top):
            w._tree.expand_row(w._store.get_path(top), False)
        w._info.set_text("")

    def _cell_index_offer(self, src, err="", ask=False):
        """A source without its hierarchy index (design.ovh): say so,
        show the build button and - once per source per load, or on
        the button (`ask`; the Cell menu's command for it is gone,
        0.12.483) - ask to run `floe-index hier <cache>` in the
        modal log, then reload the tree (FLOE_INDEX_ON_OPEN policy as
        for the VFS index and the DRC pack)."""
        w = self._cellwin
        if w is None or not self._cell_sources:
            self._set_live_status("no layout")
            return
        if src is None:
            missing = sorted(self._cell_nohier)
            if not missing:
                self._set_live_status("every source has its cell index")
                return
            src = missing[0]
        if src >= len(self._cell_sources):
            return
        first = src not in self._cell_nohier
        self._cell_nohier.add(src)
        w._build.show()
        w._info.set_text("cell tree: hierarchy index missing - "
                         "floe2 index --hier-only <src>, or build index…")
        if not first and not ask:
            return
        from .vfsclient import find_binary
        try:
            bin_ = find_binary()
        except RuntimeError as exc:
            self._set_live_status("hierarchy indexing failed: %s" % exc)
            return
        source = self._cell_sources[src]
        if not self._index_consent(
                "The cell tree needs the hierarchy index (design.ovh) of\n"
                "%s\n\nBuild it now?  (floe2 index --hier-only: one pass "
                "over the placement records)"
                % self._cell_source_label(source)):
            return

        def on_success():
            self._cell_nohier.discard(src)
            if not self._cell_nohier:
                w._build.hide()
            self._cell_tree_load_roots()

        self._index_modal("indexing cell hierarchy…",
                          [bin_, "hier", source["path"]],
                          on_success, "hierarchy indexing")

    def _on_drc_hl(self, btn):
        on = btn.get_active()
        if on and not (self._drc is not None
                       and hasattr(self._drc, "query_rect")):
            btn.set_active(False)
            self._set_live_status(
                "the in-view filter needs a packed index: "
                "floe-index drc <db>")
            return
        self._drc_hl = on
        self._drc_hl_res = None
        if self._drc_open is not None:
            self._drc_grid_fill(self._drc_open)
        self._display()

    def _set_mono(self, on, announce=True):
        """Grayscale all design layers ('b'; DRC visibility)."""
        on = bool(on)
        if on == self._mono or self.worker is None:
            return
        self._mono = on
        self.worker.submit({"kind": "mono", "on": on})
        self._color_epoch += 1
        if announce:
            self._set_live_status(
                "layers grayscale %s" % ("on" if on else "off"))
        self.redraw(immediate=True)

    def _drc_sel_check(self):
        """Check index the highlight applies to: the rule selected
        in the browser (grid owner), else the rule of the last
        jumped error, else None."""
        if self._drc_open is not None:
            return self._drc_open
        if self._drc_pos >= 0 and self._drc_cum:
            return bisect.bisect_right(self._drc_cum,
                                       self._drc_pos) - 1
        return None

    def _drc_hl_list(self):
        """The SELECTED rule's violations in the current view as
        [(kind, pts dbu)] - recomputed only when the view, db or
        selected rule changes (user call 2026-08-13: one rule at a
        time, cap DRC_HL_CAP)."""
        ci = self._drc_sel_check()
        # the viewport bbox keys the cache: it folds center, zoom
        # AND canvas size (cx/cy/spp alone served a stale list
        # after a window resize)
        bb = self.view_bbox()
        membership = self._drc_active_members()
        key = (bb, id(self._drc), ci, self._drc_wfilter,
               None if membership is None else tuple(sorted(membership.spec.items())))
        cached = self._drc_hl_res
        if cached is not None and cached[0] == key:
            return cached[1]
        conflict_only = getattr(self, "_drc_conflict_only", False)
        if conflict_only and (membership is None or not membership):
            self._drc_hl_res = (key, [])
            return []
        if ci is None:
            self._drc_hl_res = (key, [])
            self._set_live_status(
                "DRC filter: select a rule in the browser first")
            return []
        k = self.dbu
        if getattr(self._drc, "packed", False) and \
                len(self._drc.checks[ci].errors) >= DRC_LARGE_RULE:
            # a large rule's capped query runs as a service job: the
            # GTK thread never waits for its scan
            if key != getattr(self, "_drc_hl_key", None):
                self._drc_hl_key = key
                self._drc_hl_res = None
                worker = getattr(self, "_drc_query_worker", None)
                if worker is None:
                    worker = self._drc_query_worker = \
                        gtkservice.ExactQueryWorker()
                worker.submit(key, self._drc, ci, tuple(v * k for v in bb),
                              DRC_HL_CAP, membership,
                              None if conflict_only or self._drc_wfilter == "all"
                              else self._drc_wf_class())
                self._set_live_status("DRC filter: querying errors in view…")
            return []
        kw = {}
        if membership is not None:
            kw["members"] = {ci: membership}
        if not conflict_only and self._drc_wfilter != "all" \
                and hasattr(self._drc, "get_status"):
            # the waive filter runs INSIDE the query, before the
            # cap: a post-filter over a capped result dropped every
            # match hiding past `cap` non-matching errors
            kw["waived"] = self._drc_wf_class()
        with _dprof("hl_list: query_rect"):
            res = self._drc.query_rect(bb[0] * k, bb[1] * k,
                                       bb[2] * k, bb[3] * k,
                                       cap=DRC_HL_CAP, checks=(ci,),
                                       **kw)
        lst = [(rci, rei, e.kind,
                [(x / k, y / k) for x, y in e.pts])
               for rci, rei, e in res]
        self._drc_hl_res = (key, lst)
        if self._drc_hl:
            self._set_live_status(
                "DRC filter %s: %d in view%s"
                % (self._drc.checks[ci].name, len(lst),
                   " (capped)" if len(lst) >= DRC_HL_CAP else ""))
        # the browser grid lists exactly these in-view errors: let
        # it follow pans/zooms (idle: this runs inside the overlay
        # draw path; the refill re-reads the now-cached list)
        if self._drc_hl and self._drc_grid_ci == ci:
            GLib.idle_add(self._drc_grid_fill, ci)
        return lst

    def _drc_query_poll(self):
        worker = getattr(self, "_drc_query_worker", None)
        result = worker.poll() if worker is not None else None
        if result is None:
            return
        key, values, error = result
        if key != getattr(self, "_drc_hl_key", None):
            return
        # Only an in-flight query owns this key. Notes/toggle paths can
        # invalidate the completed result without changing the viewport.
        self._drc_hl_key = None
        # Coordinates are converted only for the bounded returned page.
        k = self.dbu
        items = [(ci, ei, kind, [(x / k, y / k) for x, y in points])
                 for ci, ei, kind, points in (values or ())]
        self._drc_hl_res = (key, items)
        if error:
            self._set_live_status("DRC in-view query failed: %s" % error)
        elif self._drc_hl:
            self._set_live_status("DRC filter: %d in view%s" % (
                len(items), " (capped)" if len(items) >= DRC_HL_CAP else ""))
        if self._drc_hl and self._drc_open is not None:
            self._drc_grid_fill(self._drc_open)
            self._display()

    def _drc_open_dialog(self):
        """DRC > open .db…: the viewer's own browser (user call
        2026-10-21: the file dialogs list a folder without following
        its symbolic links; GTK's chooser stats every target). Starts
        in the loaded layout's folder, else where floe was launched."""
        folder = (os.path.dirname(self.meta["src"]["path"])
                  if self.meta is not None else self._launch_dir)
        path = self._browse_file_dialog(
            "open DRC results (.db)", folder,
            [("Calibre DRC results (*.db)", ("*.db",)),
             ("all files", ("*",))])
        self._restore_keys()
        if path:
            self._drc_open_db(path)

    def _drc_release(self):
        """Drop the loaded DRC db and empty its browser, closing its pack
        (floe/indexlock.py: the reader's lock goes with it - an IcePack is
        a reference cycle, so the GC would release it at some later time,
        and a re-pack of it would be refused meanwhile)."""
        old = self._drc
        for window in (getattr(self, "_drc_team", None),
                       getattr(self, "_drc_migration", None),
                       getattr(self, "_drc_waives_win", None)):
            if window is not None:
                window.window.destroy()
        self._drc_conflict_reset(drop_source=True)
        self.drc_mark = None
        self._drc = None
        self._drc_source = None
        self._drc_reviewer = None
        if self._title_drc:
            self._title_drc = ""
            self._title_show()
        self._drc_marker_invalidate(drop_worker=True)
        self._drc_delta_reset(drop_worker=True)
        self._drc_clusters = None
        self._drc_cluster = None
        self._drc_rmeta = None
        self._drc_rmatch = (0, 0)
        self._drc_tfilter = "all"
        self._drc_rtypes = None
        self._drc_only = None
        self._drc_cum = []
        self._drc_total = 0
        self._drc_pos = -1
        self._drc_open = None
        self._drc_grid_ci = None
        self._drc_grid_rows = 0
        self._drc_cell = None
        self._drc_grid_map = []
        self._drc_grid_base = None
        self._drc_page = 0
        self._drc_page_marks = []
        self._drc_show_sel = False
        self._drc_sel = None
        self._drc_sels = {}
        self._esel_start = None
        self._drc_focus = None
        self._drc_hl = False
        self._drc_hl_res = None
        self._mono = False
        self._mono_saved = False
        w = self._drcwin
        if w is not None:
            w._hl.set_active(False)
            w._rstore.clear()
            w._gstore.clear()
            w._detail.set_text("")
            self._drc_detail_of = None
            self._drc_detail_at = None
            self._drc_svrf_show()
            self._drc_types_rebuild()   # empty+disable type combo
        close = getattr(old, "close", None)
        if close is not None:
            try:
                close()
            except Exception:
                pass

    def _drc_open_db(self, path, rules=None, pick=None):
        """Dialog flow (user call 2026-08-14): the user PICKS the
        ASCII .db, floe LOADS only its pack. When no usable
        pack exists (missing, stale or an old layout/v1 sidecar) it
        ASKS before building one (user call 2026-08-28). `pick`: what a
        launch asks to be selected once the results are open
        (_drc_launch_pick)."""
        # another run packs this db (floe_vfs::lock): say who - no open
        # of a pack being replaced, no second build beside it (the
        # decisions and the review are floe2 gtk-service's, P2b)
        try:
            busy = gtkservice.drc_busy(path)
            side = None if busy else gtkservice.drc_find(path)
        except gtkservice.ServiceError as exc:
            self._set_live_status("DRC: %s" % exc)
            return
        if busy is not None:
            self._set_live_status(str(busy))
            return
        if side is not None:
            try:
                db = gtkservice.drc_open_pack(
                    side, source=path, reviewer=self._reviewer,
                    **self._drc_role_kw())
            except gtkservice.ServiceError as exc:
                # busy: the pack is being indexed, or this reviewer's
                # review is open in another session; admission: a reviewer
                # ID is required here and none was given - none of them is
                # a pack to build again
                if exc.kind in ("busy", "admission"):
                    self._drc_refused(exc)
                    return
            else:
                # adopt the fresh pack
                self.load_drc(path, db=db, rules=rules, pick=pick)
                return
        if not self._index_consent(
                "No DRC index for\n%s\n\nBuild it now?"
                % os.path.basename(path)):
            self._set_live_status(
                "DRC index needed: floe-index drc %s"
                % os.path.basename(path))
            return
        self._drc_pack_and_load(path, rules=rules, pick=pick)

    def _drc_pack_and_load(self, path, rules=None, pick=None):
        """Run `floe-index drc <db>` with its log in a MODAL
        dialog, then load the pack."""
        from .vfsclient import find_binary
        try:
            bin_ = find_binary()
        except RuntimeError as exc:
            self._set_live_status("DRC indexing failed: %s" % exc)
            return
        held = getattr(self._drc, "path", None)
        try:
            side = gtkservice.drc_find(path)
        except gtkservice.ServiceError:
            side = None
        if held and side and os.path.realpath(held) == os.path.realpath(side):
            # this review holds the pack being re-packed (its .db ran
            # again): let go first - its own reader's lock would refuse
            # the re-pack (floe/indexlock.py)
            self._drc_release()
            self.redraw(immediate=True)

        def on_success():
            if not self.load_drc(path, rules=rules, pick=pick):
                return
            if not getattr(self._drc, "packed", False):
                # the indexer that just ran wrote a layout the reader
                # refuses: it is an OUTDATED binary
                self._set_live_status(
                    "DRC pack from %s is an old layout - rebuild it: "
                    "cd rust && cargo build --release" % bin_)

        self._index_modal("indexing DRC results…",
                          [bin_, "drc", path, "--jobs", "12"],
                          on_success, "DRC indexing")

    def _ask_yes_no(self, text, default_yes=True):
        """Modal Yes/No question, centered on the parent; returns
        True for Yes. Refocuses the parent on close (quartz)."""
        dlg = Gtk.MessageDialog(
            transient_for=self.window, modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO, text=text)
        self._center_on_parent(dlg)
        self._only_close_button(dlg)
        dlg.set_default_response(Gtk.ResponseType.YES if default_yes
                                 else Gtk.ResponseType.NO)
        resp = dlg.run()
        dlg.destroy()
        self.window.present()
        return resp == Gtk.ResponseType.YES

    def _index_modal(self, title, argv, on_success, fail, on_failure=None):
        """Run an indexer subprocess with its log streamed into a
        MODAL dialog (cancel terminates it); call on_success() on a
        clean exit, on_failure(rc) on a failed (not cancelled) one - a
        jobdeck opens with what did index. Shared by the DRC pack and
        the VFS index builds."""
        import subprocess
        import threading
        dlg = Gtk.Dialog(title=title, transient_for=self.window,
                         modal=True)
        dlg.set_default_size(600, 340)
        tv = Gtk.TextView()
        tv.set_editable(False)
        tv.set_cursor_visible(False)
        tv.set_monospace(True)
        buf = tv.get_buffer()
        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.AUTOMATIC,
                      Gtk.PolicyType.AUTOMATIC)
        sc.add(tv)
        dlg.get_content_area().pack_start(sc, True, True, 4)
        dlg.add_button("cancel", Gtk.ResponseType.CANCEL)
        self._center_on_parent(dlg)
        dlg.show_all()
        try:
            # its own process group: a cancel ends what it started too (a
            # jobdeck's per-source index runs), so their locks go with it
            proc = subprocess.Popen(
                argv, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, bufsize=1,
                start_new_session=True)
        except OSError as exc:
            dlg.destroy()
            self._set_live_status("%s failed: %s" % (fail, exc))
            return
        state = {"cancelled": False, "lock": None}

        def on_response(_d, _resp):
            state["cancelled"] = True
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except OSError:
                try:
                    proc.terminate()
                except OSError:
                    pass

        dlg.connect("response", on_response)

        def append(line):
            buf.insert(buf.get_end_iter(), line)
            buf.place_cursor(buf.get_end_iter())
            tv.scroll_mark_onscreen(buf.get_insert())
            return False

        def done(rc):
            if state["cancelled"] or rc != 0:
                # keep the log on screen (user call 2026-09-09: it
                # closed at once and the indexer's error could not be
                # read); the cancel button becomes close
                append("\n== %s %s\n" % (
                    fail, "cancelled" if state["cancelled"]
                    else "failed (rc %d) - see the message above" % rc))
                for button in dlg.get_action_area().get_children():
                    button.set_label("close")
                dlg.disconnect_by_func(on_response)
                dlg.connect("response", lambda *_: (dlg.destroy(),
                                                    self.window.present(),
                                                    self._restore_keys()))
                self._set_live_status(
                    "%s cancelled" % fail if state["cancelled"]
                    # refused: another run indexes it, or someone has it
                    # open - the [lock] line says who
                    else state["lock"] if (rc == BUSY_EXIT
                                           and state["lock"])
                    else "%s failed (rc %d)" % (fail, rc))
                if not state["cancelled"] and on_failure is not None:
                    on_failure(rc)
                return False
            dlg.destroy()
            self.window.present()
            on_success()
            return False

        def pump():
            for line in proc.stdout:
                if line.startswith("[lock] "):
                    state["lock"] = line[7:].strip()
                GLib.idle_add(append, line)
            rc = proc.wait()
            GLib.idle_add(done, rc)

        threading.Thread(target=pump, daemon=True).start()

    def load_drc(self, path, db=None, rules=None, pick=None):
        """Open a Calibre DRC db (.ice index-aware) and populate the
        browser. `db` = an already-opened backend to adopt (the
        dialog preflight verifies the pack by opening it - opening
        twice pays the block-table bbox scan twice). `pick`: the rule, and
        the error of it, a launch asks to be selected in the results
        (_drc_launch_pick) - without one a db opens with no rule selected."""
        rules_data = None
        if rules is not None:
            try:
                rules_data = gtkservice.svrf_rules(rules)
            except (OSError, ValueError) as exc:
                if db is not None and db is not self._drc:
                    close = getattr(db, "close", None)
                    if close is not None:
                        try:
                            close()
                        except Exception:
                            pass
                self._set_live_status("rules metadata load failed: %s" % exc)
                return False
        if db is None:
            try:
                db = gtkservice.drc_load(
                    path, reviewer=self._reviewer,
                    **self._drc_role_kw())
            except Exception as exc:
                # a pack another run re-packs says who (floe_vfs::lock); a
                # review open in another session, a reviewer ID required
                if getattr(exc, "kind", None) in ("busy", "admission"):
                    self._drc_refused(exc)
                    return False
                self._drc_not_loaded("DRC load failed: %s" % exc)
                return False
        old = self._drc
        for window in (getattr(self, "_drc_team", None),
                       getattr(self, "_drc_migration", None),
                       getattr(self, "_drc_waives_win", None)):
            if window is not None and window.db is not db:
                window.window.destroy()
        self._drc_conflict_reset(drop_source=True)
        self._drc = db
        # (the rule a launch names is the list's alone from its first fill;
        # results opened without one list every rule: _drc_list_only)
        self._drc_only = self._drc_pick_rule(db, pick)
        # what a forwarded request compares its own with (_drc_request),
        # and the title's part
        self._drc_source = os.path.abspath(path)
        self._drc_reviewer = self._reviewer
        # (with its folder: one run's results are named like the next's)
        self._title_drc = " · DRC %s" % self._title_name(self._drc_source)
        self._title_show()
        self._drc_marker_invalidate(drop_worker=True)
        self._drc_clusters = None
        self._drc_cluster = None
        self._drc_open = None
        self._drc_delta_reset(drop_worker=True)
        # the embedded browser needs elbow room: widen the left
        # pane once a db is loaded (user can still drag it back)
        self._drc_pane_room()
        self._left_show("drc")
        self._drc_cum = []
        total = 0
        for c in db.checks:
            self._drc_cum.append(total)
            total += len(c.errors)
        self._drc_total = total
        self._drc_pos = -1
        self.drc_mark = None
        self._drc_hl_res = None
        self._drc_sel = None
        self._drc_sels = {}
        self._esel_start = None
        self._drc_tfilter = "all"   # new db = new type census
        self._drc_wfilter = "notwaived"
        self._drc_lens_sync()
        if self._drcwin is not None:
            self._drc_wf_fit()
            self._drcwin._wf.set_active_id(self._drc_wfilter)
        if rules is None:
            self._drc_rules_auto(path)
        else:
            self._drc_rules_load(rules, silent=True, data=rules_data)
        cluster_error = self._drc_clusters_auto(path)
        self._drc_types_rebuild()   # no-sidecar case: combo empties
        if self._drcwin is not None:
            self._drc_fill()
            # a db opens with NO rule selected (user call
            # 2026-08-18). GTK can auto-select row 0 during the
            # model reattach while the busy guard swallows the
            # event - the row then LOOKS selected with an empty
            # grid; drop that phantom selection instead.
            self._drc_rules_busy = True
            try:
                self._drcwin._rules.get_selection().unselect_all()
            finally:
                self._drc_rules_busy = False
        said = self._drc_loaded_text(
            db, path, self._drc_rmatch if self._drc_rmeta is not None else None)
        self._set_live_status("%s · %s" % (cluster_error, said)
                              if cluster_error else said)
        # (the waives of this reviewer a confirmer has rejected: looked for
        # now and every couple of seconds from here on)
        self._drc_returned_start()
        moved = self._drc_moved_aside_text(db)
        if moved and self._drcwin is not None:
            # in sight until a rule is picked: cursor motion replaces the
            # status line, and the reviewer has to know where the review
            # of the run before went
            self._drcwin._detail.set_text(moved)
            self._drc_detail_of = None
        if old is not None and old is not db:
            # the db it replaces lets go of its pack now, not at some GC
            # (floe/indexlock.py: its reader's lock goes with it)
            close = getattr(old, "close", None)
            if close is not None:
                try:
                    close()
                except Exception:
                    pass
        if pick is not None and self._drc_launch_pick(*pick):
            # the jump's line took the load's place before anyone read it:
            # whose review this is stays said - and, after either line,
            # that the list is the named rule's alone
            more = self._drc_reviewer_text(db) if pick[1] is not None else ""
            only = self._drc_only_text()
            if only:
                more += " · " + only
            if more:
                self._set_live_status(self.status.get_text() + more)
        return True

    @staticmethod
    def _drc_pick_rule(db, pick):
        """The rule a launch's pick names (--drc-rule), as its index in the
        results, where they have it with errors: the one rule the list is
        then of. None without a pick, and for a name the results do not
        have or a rule without an error - _drc_launch_pick says which, and
        the list is every rule's, as without the option."""
        if pick is None:
            return None
        # (the first check of that name, as _drc_launch_pick reads it)
        ci = next((i for i, c in enumerate(db.checks) if c.name == pick[0]), None)
        return ci if ci is not None and len(db.checks[ci].errors) else None

    def _drc_listed(self, ci):
        """Whether the rule list has a place for rule `ci`: every rule
        has, or - in results a launch opened with --drc-rule - the named
        one alone (_drc_list_only). What the filters leave of it is the
        fill's to say."""
        only = getattr(self, "_drc_only", None)
        return only is None or ci == only

    def _drc_list_only(self, ci):
        """The rule list is rule `ci`'s alone (user 2026-11-16: "--drc-rule
        로 실행될 경우 룰 목록에 해당 룰만 나오게") - None: every rule's again.
        A launch says which: one that names a rule (--drc-rule NAME, at a
        start and handed to a window that is up) lists that rule alone,
        one that names results without a rule lists them all, and so does
        any other open of results. Nothing in the pane turns it: the
        search, the type filter and the waive filter work inside the list
        as it is, the type combo counts the rules it has, and the CD
        groups' counts are prepared for those. The rule that is open stays
        selected where it is still listed. True when the list changed."""
        if getattr(self, "_drc_only", None) == ci:
            return False
        self._drc_only = ci
        if self._drc is not None and self._drcwin is not None:
            self._drc_types_rebuild()
            self._drc_fill(preserve=True)
            self._drc_group_cache_sync()
            self._display()
        return True

    def _drc_only_text(self):
        """What a status line says of a rule list that is one rule's alone:
        `listing NAME alone (--drc-rule)`; nothing of a list of every
        rule."""
        db, only = getattr(self, "_drc", None), getattr(self, "_drc_only", None)
        if db is None or only is None:
            return ""
        return "listing %s alone (--drc-rule)" % db.checks[only].name

    def _drc_launch_pick(self, rule, err=None):
        """What a launch asks to be selected in the results it opens (floe2
        view --drc DB --drc-rule NAME [--drc-err N]; user 2026-11-12: "오픈과
        동시에 특정 룰이 선택되게 하거나 특정 룰의 특정 에러가 선택되게"). The rule's
        row is selected as a click on it selects it - its errors listed, its
        markers drawn; with N the rule's error N - the number its list shows,
        from 1 - is jumped to as a double-click on that number jumps: framed,
        its CD rulers drawn, the rule's layers alone on (Esc restores),
        visited once it is drawn. The rule list is that rule's alone from
        then on (0.12.510, _drc_list_only) - said in the status line -,
        until a launch names another rule, or results without one. What
        the list's filters hide is brought
        into it first - the search and the rule type cleared for a rule they
        leave out, the waive filter turned to All for a rule or an error it
        leaves out. A rule that has no errors is in no list, and is said so.
        A rule or an error the results do not have is said in
        the status line (and on stderr, where a launcher's log is) and the
        results stay as they opened - a rule that is there is selected, and
        the list its alone, even when its error is not; for a rule that is
        not there or has no errors the list is left as it is. True when
        done as asked."""
        db, win = self._drc, self._drcwin
        if db is None:
            return False
        name = os.path.basename(getattr(self, "_drc_source", None) or db.path)

        def refused(text):
            self._set_live_status(text)
            print("[%s] %s" % (APP, text), file=sys.stderr, flush=True)
            return False
        ci = next((i for i, c in enumerate(db.checks) if c.name == rule), None)
        if ci is None:
            return refused("DRC %s: no rule %s" % (name, rule))
        n = len(db.checks[ci].errors)
        # the list is the named rule's alone (a load made it so before its
        # first fill: nothing changes here then)
        narrowed = n > 0 and self._drc_list_only(ci)
        if win is not None:
            self._drc_page = 0
            if not self._drc_select_row(ci):
                if self._drc_search:
                    # (the entry's own handler comes later, and finds the
                    # text as it is here)
                    self._drc_search = ""
                    win._search.set_text("")
                    self._drc_fill(preserve=True)
                if self._drc_tfilter != "all":
                    win._tf.set_active_id("all")
                if not self._drc_select_row(ci) and self._drc_wfilter != "all":
                    win._wf.set_active_id("all")
                    self._drc_select_row(ci)
        if n == 0:
            # (a rule without an error is in no list, All's neither:
            # there is nothing of it to select)
            return refused("DRC %s: rule %s has no errors" % (name, rule))
        if err is None:
            if narrowed:
                self._set_live_status("DRC %s: %s" % (name, self._drc_only_text()))
            return True
        if not 1 <= err <= n:
            return refused("DRC %s: rule %s has %d error(s), no error %d" % (name, rule, n, err))
        ei = err - 1
        if win is not None and not self._drc_wf_shows(db, ci, ei):
            # the list as it stands leaves this error out
            win._wf.set_active_id("all")
        if win is not None:
            self._drc_goto_cell(ci, ei)
        self._drc_jump(ci, ei, isolate=True)
        if narrowed:
            self._set_live_status(self.status.get_text() + " · " + self._drc_only_text())
        # at a start the canvas gets its size after this - the results of a
        # launch load before the first allocation, and a window that starts
        # maximized is given the screen's size later still: the error is
        # framed again for the size that comes (_start_view_follow). In a
        # window that is up - a later launch's request - nothing follows.
        self._start_view_follow(lambda: self._drc_frame_again(db, ci, ei))
        return True

    def _drc_frame_again(self, db, ci, ei):
        """The frame of the error a launch jumped to, for the canvas as it
        is now: the jump's own framing (_drc_jump: the error over
        DRC_VIEW_FRACTION of the view on both axes), nothing else of the
        jump done again. The results or the error gone meanwhile: the fit."""
        mark = getattr(self, "drc_mark", None)
        if self._drc is not db or mark is None \
                or mark.get("review_target") != (db, ci, ei):
            self.fit()
            return
        e = db.checks[ci].errors[ei]
        b = e.bbox()
        w_um, h_um = b[2] - b[0], b[3] - b[1]
        cx, cy = e.center()
        vw, vh = self._viewport_size()
        win = w_um / DRC_VIEW_FRACTION
        if vh > 0:
            win = max(win, h_um / DRC_VIEW_FRACTION * (vw / float(vh)))
        if win <= 0:
            win = 0.1   # degenerate (point-like) violation
        self.goto(cx, cy, win)
        self._drc_jump_spp = self.spp

    def _drc_clusters_auto(self, db_path):
        """A visible <results.db>.clusters file also follows a direct pack
        (the service finds it by the database's name)."""
        try:
            self._drc_clusters = self._drc.load_clusters()
        except ValueError as exc:
            msg = "DRC clusters load failed: %s" % exc
            sys.stderr.write("[floe] %s\n" % msg)
            return msg
        return None

    def _drc_clusters_dialog(self):
        if self._drc is None:
            self._set_live_status("open a DRC .db first")
            return
        path = self._browse_file_dialog(
            "load DRC clusters",
            os.path.dirname(os.path.abspath(self._drc.path)),
            [("DRC clusters (*.clusters)", ("*.clusters",)),
             ("all files", ("*",))])
        self._restore_keys()
        if not path:
            return
        try:
            data = self._drc.load_clusters(path)
        except ValueError as exc:
            self._set_live_status("DRC clusters load failed: %s" % exc)
            return
        keep = self._drc_open
        self._drc_clusters = data
        self._drc_cluster = None
        self._drc_sel = None
        self._drc_sels = {}
        self._drc_hl_res = None
        self._drc_fill()
        self._drc_select_row(keep)
        self._display()
        self._set_live_status("DRC clusters loaded: %d rules (%s)"
                              % (len(data.rules), os.path.basename(path)))

    def _drc_rules_auto(self, db_path):
        """Auto-pick the `floe-index svrf` rule-metadata sidecar: the
        deck's Rule File Pathname is an absolute path from the
        CALIBRE RUN machine, so <deck basename>.rules.json NEXT TO
        THE DB is searched first, the recorded path second, <db>.rules.json
        third - and under a work directory (--workdir / FLOE_WORKDIR) the
        same three below it, where `floe-index svrf DECK` writes when the
        deck's folder is not to be written (user 2026-11-11). Before them
        all the sidecar `floe2 drc-prepare --svrf FILE` was given for these
        results, noted in their analysis folder (0.12.460, user 2026-11-12:
        everything prepared and the results opened without their rules - the
        sidecar lay at none of those places). The service
        says the places (gtkservice.rules_candidates, app-core
        svrf::rules_candidates - the DRC capture's list); one that cannot
        answer leaves the three beside the files."""
        self._drc_rmeta = None
        self._drc_rmatch = (0, 0)
        deck = None
        for c in self._drc.checks[:50]:
            for ln in (c.desc or "").split("\n"):
                if ln.startswith("Rule File Pathname:"):
                    deck = ln.split(":", 1)[1].strip()
                    break
            if deck:
                break
        try:
            cands = gtkservice.rules_candidates(db_path, deck)
        except (gtkservice.ServiceError, OSError, ValueError):
            dbdir = os.path.dirname(os.path.abspath(db_path))
            cands = []
            if deck:
                cands.append(os.path.join(
                    dbdir, os.path.basename(deck) + ".rules.json"))
                cands.append(deck + ".rules.json")
            cands.append(db_path + ".rules.json")
        for p in cands:
            if os.path.isfile(p):
                self._drc_rules_load(p, silent=True)
                return

    def _drc_rules_load(self, path, silent=False, data=None):
        """Attach a <deck>.rules.json metadata sidecar to the open
        db; each rule's match status is its check mark and tooltip, and
        the SVRF info window shows the constraint / measured / source
        layers per error."""
        db = self._drc
        if db is None:
            if not silent:
                self._set_live_status("open a DRC .db first")
            return False
        if data is None:
            try:
                data = gtkservice.svrf_rules(path)
            except (OSError, ValueError) as exc:
                if not silent:
                    self._set_live_status(
                        "rules metadata load failed: %s" % exc)
                return False
        meta = data.get("checks", {})
        matched = sum(1 for c in db.checks if c.name in meta)
        self._drc_rmeta = data
        self._drc_rmatch = (matched, len(db.checks))
        # A replaced deck may define different bounds under the same name.
        # Preserve parent/file-cluster picks, discard obsolete delta scopes.
        self._drc_sels = {key: value for key, value in self._drc_sels.items()
                          if len(key) == 2}
        self._drc_delta_reset(drop_worker=True)
        self._drc_delta_sync()
        if self._drc_open is not None:
            self._drc_delta_scope_refresh()
        self._drc_group_ui_refresh()
        self._drc_group_cache_sync()
        if not silent or matched:
            self._set_live_status(
                "rules metadata %s: %d/%d rules matched"
                % (os.path.basename(path), matched, len(db.checks)))
        return True

    def _drc_rules_dialog(self):
        """DRC > SVRF rules…: the viewer's own browser (user call
        2026-10-21), from the open db's folder, else the launch folder."""
        folder = (os.path.dirname(os.path.abspath(self._drc.path))
                  if self._drc is not None else self._launch_dir)
        path = self._browse_file_dialog(
            "open rule metadata (*.rules.json)", folder,
            [("rule metadata (*.rules.json)", ("*.rules.json",)),
             ("all files", ("*",))])
        self._restore_keys()
        if path:
            self._drc_rules_load(path)

    def _drc_select_row(self, ci, cluster=None):
        """Reselect a rule or a specific cluster after a model rebuild."""
        win = self._drcwin
        if ci is None or win is None:
            return False
        for row in win._rstore:
            if row[2] != ci:
                continue
            target = row if cluster is None else next(
                (child for child in row.iterchildren()
                 if child[3] is cluster), None)
            if target is None:
                return False
            if cluster is not None:
                win._rules.expand_row(row.path, False)
            win._rules.set_cursor(target.path, None, False)
            win._rules.scroll_to_cell(target.path, None, False, 0.0, 0.0)
            return True
        return False

    def _drc_svrf_status(self, name):
        """Whether this name has loaded metadata, not whether CD is measurable.

        Sidecars contain active checks only, without excluded-rule provenance.
        Missing names therefore cannot be labelled as definitely IFDEF-disabled.
        """
        meta = self._drc_rmeta
        if meta is None:
            return "", "SVRF: not loaded"
        checks = meta.get("checks") or {}
        if name not in checks:
            return ("", "SVRF: no matching rule in loaded metadata\n"
                    "Possible causes: #IFDEF/#IFNDEF settings, a different deck, "
                    "or unsupported syntax. The exclusion reason is not recorded.")
        detail = "SVRF: applied (rule name matched)"
        if not (checks[name] or {}).get("constraints"):
            detail += "\nCD: no parsed measurement constraints"
        return "✓", detail

    def _drc_svrf_refresh(self):
        """Update visible statuses without changing selection, counts or scopes."""
        win, db = self._drcwin, self._drc
        if win is None:
            return
        if db is None:
            return
        for row in win._rstore:
            # Auto-loading a new DB's metadata may precede rebuilding this tree.
            name = row[0]
            ci = row[2]
            if ci >= len(db.checks) or db.checks[ci].name != name:
                ci = None
            # (the row's label carries the status and the CD groups' count;
            # its tooltip is the whole name alone, 0.12.495)
            row[4] = self._drc_rule_label(name, ci)
            row[5] = name
            for child in row.iterchildren():
                child[4] = child[0]
                child[5] = child[0]

    def _drc_group_count(self, ci):
        if ci is None or self._drc_delta_mode in DRC_NO_CD:
            return None
        setting = (ci, self._drc_delta_mode)
        return self._drc_group_counts.get(
            setting + (self._drc_delta_steps.get(setting),))

    def _drc_rule_label(self, name, ci):
        prefix = self._drc_svrf_status(name)[0]
        count = self._drc_group_count(ci)
        if count:
            prefix += " (%d)" % count
        return (prefix + " " if prefix else "") + name

    def _drc_group_ui_refresh(self):
        old_filter = self._drc_tfilter
        self._drc_types_rebuild()
        if self._drc is None or self._drcwin is None:
            return
        # Keep the active rule visible while its new interval/basis is pending.
        # Hiding it here would cancel the measurement that supplies its count.
        if ("__grouped__" in (old_filter, self._drc_tfilter)
                and not (self._drc_tfilter == "__grouped__" and self._drc_delta_busy)):
            if self._drc_tfilter == "__grouped__" and self._drc_group_rows_refresh():
                return
            self._drc_fill(preserve=True)
        else:
            self._drc_svrf_refresh()

    def _drc_group_rows_refresh(self):
        """Add newly prepared rules without disturbing the active error view."""
        win, db = self._drcwin, self._drc
        expected = [ci for ci, check in enumerate(db.checks)
                    if self._drc_group_count(ci) and self._drc_listed(ci)
                    and (not self._drc_search or self._drc_search in check.name.lower())
                    and (self._drc_wfilter == "all" or self._drc_wf_count(db, ci) > 0)]
        current = [row[2] for row in win._rstore]
        present = set(current)
        if current != [ci for ci in expected if ci in present]:
            return False  # A configuration change removes visible rules.
        if any(row[0] != db.checks[row[2]].name for row in win._rstore):
            return False  # The old DB's tree has not been rebuilt yet.
        selection = win._rules.get_selection()
        had_selection = selection.get_selected()[1] is not None
        busy = self._drc_rules_busy
        self._drc_rules_busy = True
        try:
            for position, ci in enumerate(expected):
                if ci not in present:
                    self._drc_insert_rule(ci, position)
            # GTK may select its first inserted row automatically.
            if not had_selection:
                selection.unselect_all()
        finally:
            self._drc_rules_busy = busy
        self._drc_svrf_refresh()
        return True

    def _drc_group_cache_sync(self):
        """Read warm counts, then prepare missing counts without blocking GTK."""
        db, meta, mode = self._drc, self._drc_rmeta, self._drc_delta_mode
        requests = []
        if db is not None and meta is not None and mode not in DRC_NO_CD:
            checks = meta.get("checks") or {}
            for ci, check in enumerate(db.checks):
                if not self._drc_listed(ci):
                    # (a list of one rule, --drc-rule: no other rule's
                    # groups are counted for it)
                    continue
                step = self._drc_delta_steps.get((ci, mode))
                if self._drc_group_counts.get((ci, mode, step)) is not None:
                    continue
                cons = (checks.get(check.name) or {}).get("constraints") or []
                if cons and len(check.errors):
                    requests.append({"check": ci, "constraints": cons, "step": step})
        worker = self._drc_group_cache_worker
        if not requests:
            if worker is not None:
                worker.cancel()
            self._drc_group_cache_key = None
            return
        key = (id(db), id(meta), mode,
               tuple((r["check"], r["step"]) for r in requests))
        if key == self._drc_group_cache_key:
            return
        if worker is None:
            from .gtkservice import DeltaCachedWorker
            worker = self._drc_group_cache_worker = DeltaCachedWorker()
        self._drc_group_cache_key = key
        worker.submit(key, db, requests, mode)

    def _drc_group_cache_poll(self):
        worker = self._drc_group_cache_worker
        result = worker.poll() if worker is not None else None
        if result is None:
            return
        key, event, error = result
        if key != self._drc_group_cache_key:
            return
        if error:
            self._drc_group_cache_key = None
            self._set_live_status("CD group counts unavailable: %s" % error)
            return
        done = event["state"] == "done"
        if done:
            self._drc_group_cache_key = None
        steps = dict(key[3])
        changed = False
        rows = event.get("rows") or []
        for row in rows:
            ci = row["check"]
            setting = (ci, key[2], steps[ci])
            # A live grouping may have completed while the cache probe ran.
            count = row.get("count")
            if count is not None or setting not in self._drc_group_counts:
                changed |= self._drc_group_counts.get(setting) != count
                self._drc_group_counts[setting] = count
        if changed:
            self._drc_group_ui_refresh()
        errors = [row["error"] for row in rows if row.get("error")]
        if done and errors:
            self._set_live_status("CD group counts unavailable for %d rule(s): %s"
                                  % (len(errors), errors[0]))

    def _drc_insert_rule(self, ci, position=None):
        """Insert one parent and its clusters into the existing rule model."""
        db, rstore = self._drc, self._drcwin._rstore
        c = db.checks[ci]
        # count column = total/waived; both are O(1) cached counts.
        wv = db.status_counts(ci)[0] if hasattr(db, "status_counts") else 0
        # (the tooltip's words are the whole name alone, 0.12.495: the SVRF
        # status is the row's check mark and the SVRF window's, the CD
        # groups' count the number before the name)
        values = [c.name, "%d/%d" % (len(c.errors), wv), ci, None,
                  self._drc_rule_label(c.name, ci), c.name]
        parent = (rstore.append(None, values) if position is None
                  else rstore.insert(None, position, values))
        clusters = (self._drc_clusters.rules.get(ci, ())
                    if self._drc_clusters is not None else ())
        if clusters:
            self._drc_clusters.prepare_counts(ci)
        for cluster in clusters:
            cw, ct = cluster.status_counts()
            matching = self._drc_wf_of(cw, ct)
            if matching or self._drc_wfilter == "all":
                rstore.append(parent, [cluster.name, "%d/%d" % (ct, cw),
                                       ci, cluster, cluster.name,
                                       cluster.name])

    def _drc_rule_tip(self, tree, x, y, keyboard=False):
        """The tooltip of the rule list's row at (x, y): (the row's whole
        name, its path) where the list draws the name cut short - the
        name's column is as wide as the pane leaves it and ends a longer
        name in `…` -, None for a row that shows its name whole and where
        no row is."""
        win = self._drcwin
        named = getattr(win, "_rule_name", None) if win is not None else None
        if named is None:
            return None
        found = tree.get_tooltip_context(x, y, keyboard)
        if not found[0]:
            return None
        model, path, it = found[3], found[4], found[5]
        column, cell = named
        # the cell as this row fills it: its natural width is the whole
        # text's, the row's room in the column what the text is drawn in
        column.cell_set_cell_data(model, it, False, False)
        if cell.get_preferred_width(tree)[1] <= tree.get_cell_area(path, column).width:
            return None
        return model[it][5], path

    def _on_drc_rule_tip(self, tree, x, y, keyboard, tooltip):
        """query-tooltip of the rule list (_drc_rule_tip)."""
        found = self._drc_rule_tip(tree, x, y, keyboard)
        if found is None:
            return False
        tooltip.set_text(found[0])
        tree.set_tooltip_row(tooltip, found[1])
        return True

    def _drc_fill(self, preserve=False):
        """Rules list: NAME + SVRF status + total/waived counts (user call
        2026-08-18); under a waive filter rules with no matching
        errors are hidden (2026-08-14), and under All the rules without
        an error (0.12.475, user 2026-11-14: "룰 필터에서 All의 경우 에러가
        있는 룰만 나오도록 해줘") - a rule with nothing to list is in no
        list. In results a launch opened with --drc-rule the list is the
        named rule's alone (0.12.510, _drc_list_only): the same filters,
        over that one rule."""
        win, db = self._drcwin, self._drc
        self._drc_wf_fit()
        rstore = win._rstore
        keep = (self._drc_open, self._drc_cluster)
        if self._drc_open is not None and self._drc_sel is not None:
            self._drc_sels[self._drc_scope_key()] = self._drc_sel
        expanded = {row[2] for row in rstore
                    if win._rules.row_expanded(row.path)}
        _t0 = time.perf_counter()
        self._drc_rules_busy = True
        win._rules.set_model(None)   # detach: clear/append without
        rstore.clear()               # per-row view+selection work
        win._gstore.clear()
        self._drc_open = None
        self._drc_cluster = None
        self._drc_sel = None
        self._drc_grid_ci = None
        self._drc_grid_rows = 0
        self._drc_grid_map = []
        self._drc_grid_base = None
        self._drc_page_marks = []
        self._drc_cell = None
        self._drc_page = 0
        _t1 = time.perf_counter()
        _tc = 0.0
        shown = 0
        only = getattr(self, "_drc_only", None)
        for ci, c in enumerate(db.checks):
            if only is not None and ci != only:
                continue
            _t2 = time.perf_counter()
            if self._drc_search \
                    and self._drc_search not in c.name.lower():
                continue
            if self._drc_tfilter == "__grouped__":
                if not self._drc_group_count(ci):
                    continue
            elif self._drc_tfilter != "all":
                ts = (self._drc_rtypes or {}).get(c.name)
                if not ts or self._drc_tfilter not in ts:
                    continue
            cnt = self._drc_wf_count(db, ci)
            _tc += time.perf_counter() - _t2
            # a rule with nothing to list is not listed: under a waive
            # filter the rules with no error of its state, under All the
            # rules with no error at all (0.12.475 - a field result has
            # 17,000 rules, 1,500 of them with errors; until then All
            # listed every rule, user call 2026-08-14)
            if cnt <= 0:
                continue
            self._drc_insert_rule(ci)
            shown += 1
        win._rules.set_model(rstore)
        win._rules.get_selection().unselect_all()
        for row in rstore:
            if row[2] in expanded:
                win._rules.expand_row(row.path, False)
        self._drc_rules_busy = False
        if preserve:
            self._drc_select_row(*keep)
        if self._drc_open is None:
            self._drc_marker_invalidate()
            self._drc_delta_reset()
            self._drc_focus = None
            self._drc_pos = -1
            self.drc_mark = None
            self._drc_hl_res = None
            for ruler in self._drc_ruler:
                if ruler in self.rulers:
                    self.rulers.remove(ruler)
            self._drc_ruler = []
            win._detail.set_text("")
            self._drc_detail_of = None
            self._drc_detail_at = None
            self._drc_svrf_show()
            win._plabel.set_text("")
            win._pprev.set_sensitive(False)
            win._pnext.set_sensitive(False)
        if _DRC_PROF:
            sys.stderr.write(
                "[drcprof] rules_fill rules=%d shown=%d clear=%.1f "
                "counts=%.1f appends=%.1f ms\n"
                % (len(db.checks), shown,
                   (_t1 - _t0) * 1e3, _tc * 1e3,
                   (time.perf_counter() - _t1 - _tc) * 1e3))
            sys.stderr.flush()

    def _drc_types_rebuild(self):
        """Classify every rule by its SVRF measurement metrics
        (rules.json constraints) and rebuild the type combo: 'all
        types' + each metric present with its rule count. A matched
        rule with no parsed measurement (and any unmatched rule)
        classifies as 'other'. No sidecar -> combo empty+disabled,
        filter forced back to 'all'."""
        win, db = self._drcwin, self._drc
        self._drc_rtypes = None
        counts = {}
        meta = (self._drc_rmeta or {}).get("checks", {})
        if db is not None and meta:
            types = {}
            for ci, c in enumerate(db.checks):
                mc = meta.get(c.name)
                ms = frozenset(
                    x.get("metric")
                    for x in (mc or {}).get("constraints", ())
                    if x.get("metric")) or frozenset(("other",))
                types[c.name] = ms
                # (counted where the rule has errors: the others are in
                # no list, All's neither - and, in a list of one rule,
                # that rule alone)
                if len(c.errors) and self._drc_listed(ci):
                    for m in ms:
                        counts[m] = counts.get(m, 0) + 1
            self._drc_rtypes = types
        grouped_available = (self._drc_rmeta is not None
                             and self._drc_delta_mode not in DRC_NO_CD)
        if (self._drc_tfilter == "__grouped__" and not grouped_available
                or self._drc_tfilter not in ("all", "__grouped__")
                and self._drc_tfilter not in counts):
            self._drc_tfilter = "all"
        if win is None:
            return
        tf = win._tf
        self._drc_tf_busy = True
        try:
            tf.remove_all()
            tf.append("all", "all types")
            if grouped_available:
                grouped = sum(bool(self._drc_group_count(ci))
                              for ci in range(len(db.checks))
                              if self._drc_listed(ci)) if db is not None else 0
                tf.append("__grouped__", "CD grouped" + (" (%d)" % grouped if grouped else ""))
            ordered = [m for m in DRC_METRICS if m in counts]
            ordered += sorted(set(counts) - set(DRC_METRICS))
            for m in ordered:
                tf.append(m, "%s (%d)" % (m, counts[m]))
            tf.set_active_id(self._drc_tfilter)
            tf.set_sensitive(bool(counts) or grouped_available)
        finally:
            self._drc_tf_busy = False

    def _on_drc_tfilter(self, combo):
        if self._drc_tf_busy:
            return
        tid = combo.get_active_id() or "all"
        if tid == self._drc_tfilter or self._drc is None:
            return
        self._drc_tfilter = tid
        # per-rule selections stay valid (the filter only hides
        # RULES); the open rule may vanish from the list, though
        self._drc_fill(preserve=True)
        self._display()

    def _drc_wf_class(self):
        """Whether the waive filter shows the errors OF the class the
        service's status readers follow for it (gtkservice LENS_OF_FILTER:
        the waived, the confirmed, the rejected) - `Not Waived` shows the
        rest of its class, every error with a waive. What a scope's count,
        page and rank are asked with (`waived`); `All` asks with None."""
        return self._drc_wfilter != "notwaived"

    def _drc_wf_of(self, w, t):
        """The errors the waive filter shows, of a scope's (errors of the
        filter's class, total)."""
        if self._drc_wfilter == "all":
            return t
        return w if self._drc_wf_class() else t - w

    def _drc_state(self, db, ci, ei):
        """The error's state (gtkservice STATE_*): not waived, waived,
        rejected, confirmed - and requested, declined in a role's session.
        A results file without a review has none; one that says only
        whether an error is waived has the two."""
        if hasattr(db, "get_state"):
            return db.get_state(ci, ei)
        if hasattr(db, "get_status") and db.get_status(ci, ei) == STATUS_WAIVED:
            return gtkservice.STATE_WAIVED
        return gtkservice.STATE_NONE

    WF_STATE = {"notwaived": gtkservice.STATE_NONE,
                "waived": gtkservice.STATE_WAIVED,
                "confirmed": gtkservice.STATE_CONFIRMED,
                "rejected": gtkservice.STATE_REJECTED,
                "requested": gtkservice.STATE_REQUESTED,
                "declined": gtkservice.STATE_DECLINED}
    # the waive filter's entries: a reviewer's (no role), and a role's
    # session's - whose states are the error's, as everybody's files say
    # (user 2026-11-14: "error 상태에 waive requested가 추가되어야 함")
    WF_ENTRIES = (("all", "All"), ("notwaived", "Not Waived"),
                  ("waived", "Waived"), ("confirmed", "Confirmed"),
                  ("rejected", "Rejected"))
    WF_ROLE_ENTRIES = (("all", "All"), ("notwaived", "Not Waived"),
                       ("requested", "Requested"), ("declined", "Declined"),
                       ("waived", "Waived"), ("confirmed", "Confirmed"),
                       ("rejected", "Rejected"))
    # (What the filter's entries mean - until 0.12.508 the combo's tooltip,
    # `WF_TIP` / `WF_ROLE_TIP`: the errors of one state. Without a role
    # the states are the reviewer's own - Not Waived: no waive of theirs;
    # Waived: waived by them, no confirmer's word yet; Confirmed: their
    # waive, confirmed; Rejected: their waive, rejected by a confirmer -
    # waived again with a reason, or turned back. In a role's session they
    # are the error's as everybody's files say it, with Requested - a
    # requester asked, no waiver has waived - and Declined - a waiver
    # declined the request: its requester asks again with a reason, or
    # takes it back. The number after a rule's total is the state's; under
    # All the waived, confirmed or not; under Not Waived the errors it
    # leaves out.)

    def _drc_wf_fit(self):
        """The waive filter has the entries of the results' session: a
        role's has `Requested` and `Declined` among them. Filled again when
        the results shown are of the other kind. (The DRC menu's commands
        that are a role's follow with it: _drc_menu_roles.)"""
        self._drc_menu_roles()
        win = self._drcwin
        if win is None or not hasattr(win, "_wf"):
            return
        role = bool(getattr(self._drc, "role", ""))
        if getattr(win, "_wf_role", False) == role:
            return
        win._wf_role = role
        if not role and self._drc_wfilter in ("requested", "declined"):
            self._drc_wfilter = "notwaived"
        wf = win._wf
        wf.handler_block_by_func(self._on_drc_wfilter)
        try:
            wf.remove_all()
            for wid, lbl in (self.WF_ROLE_ENTRIES if role else self.WF_ENTRIES):
                wf.append(wid, lbl)
            wf.set_active_id(self._drc_wfilter)
        finally:
            wf.handler_unblock_by_func(self._on_drc_wfilter)

    def _drc_wf_shows(self, db, ci, ei):
        """Whether the waive filter shows rule `ci`'s error `ei`."""
        wanted = self.WF_STATE.get(self._drc_wfilter)
        return wanted is None or self._drc_state(db, ci, ei) == wanted

    def _drc_lens_sync(self):
        """Tell the service which class of errors the waive filter shows:
        its counts, pages and ranks - a rule's, a cluster's, a CD group's -
        are of that class from now (PackDrc.set_lens)."""
        db = self._drc
        if db is None or not hasattr(db, "set_lens"):
            return
        try:
            db.set_lens(self._drc_wfilter)
        except (OSError, gtkservice.ServiceError) as exc:
            self._set_live_status("waive filter: %s" % exc)

    def _drc_wf_count(self, db, ci):
        """Error count of a rule under the waive filter."""
        total = len(db.checks[ci].errors)
        if self._drc_wfilter == "all":
            return total
        if not hasattr(db, "status_counts"):
            return 0 if self._drc_wf_class() else total
        w, t = db.status_counts(ci)
        return self._drc_wf_of(w, t)

    def _drc_wf_base(self, db, ci):
        """Grid base under the waive filter: None = all errors,
        list = explicit eis, ('status', waived) = LAZY - pages come
        from status_page so a 100M-error rule never materializes
        its filtered list (field report 2026-08-14: filter
        switches still took seconds)."""
        if not hasattr(db, "status_page"):
            return [] if self._drc_wf_class() else None
        return ("status", self._drc_wf_class())

    def _on_drc_wfilter(self, combo):
        wid = combo.get_active_id() or "all"
        if wid == self._drc_wfilter or self._drc is None:
            return
        if _DRC_PROF:
            import platform
            sys.stderr.write(
                "[drcprof] == filter -> %s | py %s %s\n"
                % (wid, sys.version.split()[0], platform.machine()))
        self._drc_wfilter = wid
        self._drc_lens_sync()
        if self._drc_delta_mode == "reason":
            # (whose reason groups the group list has is the filter's to say: the
            # requests' or the waives' - _drc_reason_stages)
            self._drc_delta_sync()
        self._drc_hl_res = None
        # a waive-filter switch RESETS the selections (user call
        # 2026-08-15): the old sets no longer match what is listed
        self._drc_sel = None
        self._drc_sels = {}
        self._drc_focus = None
        with _dprof("wfilter: rules refill"):
            self._drc_fill(preserve=True)
        with _dprof("wfilter: display"):
            self._display()

    def _drc_set_sel(self, selobj):
        """Keep selections separate for each rule/cluster scope."""
        self._drc_selection_cancel()
        self._drc_sel = selobj
        self._drc_marker_invalidate()
        key = self._drc_scope_key()
        if selobj is not None:
            self._drc_sels[key] = selobj
        elif self._drc_open is not None:
            self._drc_sels.pop(key, None)

    def _drc_active_members(self):
        if getattr(self, "_drc_conflict_only", False):
            return self._drc_conflict_sync()
        return self._drc_base_members()

    def _drc_scope_key(self):
        key = (self._drc_open, self._drc_cluster)
        group = getattr(self, "_drc_delta_group", None)
        if group is not None:
            key += (id(self._drc_rmeta), self._drc_delta_mode,
                    self._drc_delta_step, group.key)
        if getattr(self, "_drc_conflict_only", False):
            key += ("conflict", id(getattr(self, "_drc_conflict_source", None)),
                    getattr(self, "_drc_conflict_revision", 0), self._drc_wfilter)
        return key

    def _drc_constraints(self, ci):
        """The measurement constraints the loaded SVRF metadata has of rule
        `ci` - what its CD is measured and grouped by; none without."""
        db, meta = self._drc, self._drc_rmeta
        if db is None or ci is None or not meta:
            return []
        return ((meta.get("checks") or {}).get(db.checks[ci].name)
                or {}).get("constraints") or []

    # (The step button had a tooltip until 0.12.508 - `_drc_step_tip`: the
    # step in use and what to type. A step is a positive value of up to 5
    # decimal places - absolute: um, area: um²; ratio: percentage points -
    # or the automatic one, which targets 10 groups from the rule's full
    # delta range; `same CD` and `reason` have none; unresolved single-edge
    # length groups use exact lengths in um, and no step applies to them.
    # The step in use is the `All errors` row's to say, and what the
    # dialog starts from.)

    def _drc_step_unit(self):
        """The unit a step of the rule in the grid is typed in."""
        if self._drc_delta_mode == "percent":
            return "%"
        metrics = set(c.get("metric")
                      for c in self._drc_constraints(self._drc_open))
        if metrics == {"area"}:
            return "um²"
        return "um (area: um²)" if "area" in metrics else "um"

    def _drc_delta_write_step(self, step):
        """Keep the step in use as text: what the step dialog starts from
        (the pane has no entry for it, and - 0.12.509 - the step button no
        tooltip that says it)."""
        self._drc_delta_step_text = ("auto" if step is None
                                     else format_ticks(step))

    def _drc_delta_reset(self, drop_worker=False):
        worker = getattr(self, "_drc_delta_worker", None)
        if worker is not None:
            if drop_worker:
                worker.close()
                self._drc_delta_worker = None
            else:
                worker.cancel()
        if drop_worker:
            cached = self._drc_group_cache_worker
            if cached is not None:
                cached.close()
                self._drc_group_cache_worker = None
            self._drc_group_counts = {}
            self._drc_group_cache_key = None
            self._drc_delta_steps = {}
            self._drc_delta_auto_steps = {}
            self._drc_delta_step_scope = None
            self._drc_delta_step = None
            self._drc_delta_write_step(None)
        self._drc_delta_key = None
        self._drc_delta_soft = None
        self._drc_delta_groups = self._drc_delta_group = None
        self._drc_delta_busy = False
        self._drc_delta_restore = None
        self._drc_delta_progress = None
        self._drc_delta_error = None
        self._drc_delta_page = 0
        self._drc_delta_refresh()

    def _drc_delta_sync(self, force=False):
        """Request grouping once per rule/cluster, basis and interval."""
        db, ci = self._drc, self._drc_open
        mode = getattr(self, "_drc_delta_mode", DRC_DELTA_DEFAULT)
        meta = self._drc_rmeta
        cons = self._drc_constraints(ci)
        setting = (ci, mode)
        requested_step = self._drc_delta_steps.get(setting)
        self._drc_delta_step = (requested_step if requested_step is not None
                                else self._drc_delta_auto_steps.get(setting))
        scope = (id(db), id(meta), ci, mode)
        if scope != self._drc_delta_step_scope:
            self._drc_delta_step_scope = scope
            self._drc_delta_write_step(self._drc_delta_step)
        # (the `reason` basis: the rule's reason groups in the place of its CD groups.
        # Whose marks' reason groups - the requests' or the waives' - is the waive
        # filter's to say, where a CD grouping has its step)
        stages = self._drc_reason_stages() if mode == "reason" else None
        key = (id(db), ci, id(meta), self._drc_cluster, mode,
               requested_step if stages is None else stages,
               getattr(self, "_drc_delta_revision", 0))
        if not force and key == getattr(self, "_drc_delta_key", None):
            self._drc_delta_refresh()
            return False
        self._drc_delta_key = key
        self._drc_delta_soft = None
        self._drc_delta_restore = None
        self._drc_delta_progress = None
        self._drc_delta_groups = self._drc_delta_group = None
        self._drc_delta_page = 0
        self._drc_delta_error = None
        self._drc_delta_busy = bool(ci is not None and (
            stages if mode == "reason" else cons and mode != "off"))
        self._drc_delta_since, self._drc_delta_said = time.monotonic(), False
        worker = getattr(self, "_drc_delta_worker", None)
        if self._drc_delta_busy:
            from .gtkservice import DeltaWorker
            if worker is None:
                worker = self._drc_delta_worker = DeltaWorker()
            if mode == "reason":
                worker.submit_reasons(key, db, ci, stages, self._drc_cluster)
            else:
                worker.submit(key, db, ci, cons, requested_step, mode,
                              self._drc_cluster)
        elif worker is not None:
            worker.cancel()
        self._drc_delta_refresh()
        return True

    # whose reason groups the group list has under each waive filter (`reason` basis)
    REASON_STAGES = {"all": ("request", "waive"),
                   "requested": ("request",), "declined": ("request",),
                   "waived": ("waive",), "confirmed": ("waive",),
                   "rejected": ("waive",)}

    def _drc_reason_stages(self):
        """Whose reason groups the group list has under the `reason` basis (user
        2026-11-16: "waive 요청등이 그룹으로 하나의 노트를 이용해서 만들어진
        경우 waiver가 그 요청을 쉽게 확인할 수 있어야"): the requests' under
        the filters that show requests - Requested, Declined -, the waives'
        under those that show waives - Waived, Confirmed, Rejected -, both
        under All, and none under Not Waived, whose errors nobody marked.
        None either of results with no review to read (an ASCII file)."""
        db = self._drc
        if db is None or not hasattr(db, "waive_ask"):
            return ()
        return self.REASON_STAGES.get(self._drc_wfilter, ())

    def _drc_reasons_again(self):
        """The reasons of the rule in the grid asked again behind the list
        shown: what the marks say may have changed - an action of this
        viewer's, or the team's - and the list is exchanged for the new one
        when it comes (_drc_reasons_swap), the group in the grid kept where it
        still is one. The counts follow at once without this (the
        service's, asked at every refresh); this brings a new reason group in and
        takes one that is gone out - without the list and the grid going
        back to their start, as a grouping asked anew would send them."""
        db, ci = self._drc, self._drc_open
        stages = self._drc_reason_stages()
        worker = getattr(self, "_drc_delta_worker", None)
        if (db is None or ci is None or not stages or worker is None
                or getattr(self, "_drc_delta_groups", None) is None):
            return False
        self._drc_delta_revision = getattr(self, "_drc_delta_revision", 0) + 1
        key = (id(db), ci, id(self._drc_rmeta), self._drc_cluster, "reason",
               stages, self._drc_delta_revision)
        self._drc_delta_key = self._drc_delta_soft = key
        self._drc_delta_busy = True
        self._drc_delta_since, self._drc_delta_said = time.monotonic(), False
        worker.submit_reasons(key, db, ci, stages, self._drc_cluster)
        return True

    def _drc_reasons_swap(self, groups, error):
        """The answer to _drc_reasons_again: `groups` take the place of the
        reason groups shown. The reason group in the grid stays the grid's scope where the
        new list has it - by who said what -, its errors listed again when
        their number changed; a reason group that is gone leaves the rule's
        errors. No answer (the reviewers' files did not read): the list
        shown stays, and the next change asks again."""
        if groups is None:
            if error:
                self._set_live_status("reasons failed: %s" % error)
            self._drc_delta_refresh()
            return
        active = getattr(self, "_drc_delta_group", None)
        self._drc_delta_groups = groups
        if active is not None:
            row = groups.find(active.key)
            if row is None:
                self._drc_delta_group = None
                self._drc_delta_scope_refresh()
                return
            self._drc_delta_group = groups[row]
            if self._drc_delta_group.total != active.total:
                self._drc_marker_invalidate()
                self._drc_grid_fill(self._drc_open)
                self._display()
        self._drc_delta_refresh()

    def _drc_delta_refresh(self):
        """Only 50 group adapters and GTK rows, regardless of group count."""
        win = self._drcwin
        if win is None or not hasattr(win, "_delta_store"):
            return
        groups = getattr(self, "_drc_delta_groups", None)
        want = None if self._drc_wfilter == "all" else self._drc_wf_class()
        total = 0
        if groups is not None:
            # (a rule's reason groups: the ones with an error the waive filter shows)
            total = groups.shown(want) if hasattr(groups, "shown") else len(groups)
        pages = max(1, (total + 49) // 50)
        page = max(0, min(getattr(self, "_drc_delta_page", 0), pages - 1))
        self._drc_delta_page = page
        active = getattr(self, "_drc_delta_group", None)
        if (active is not None and want is not None and getattr(groups, "reasons", False)
                and gtkservice.DrcScope.count(active, want) == 0):
            # the reason group in the grid has no error the waive filter shows any
            # more - its requests were waived, or the filter is another -:
            # it is not listed, and the grid has the rule's errors again
            self._drc_delta_group = None
            self._drc_delta_scope_refresh()
            return
        count = 0
        if self._drc is not None and self._drc_open is not None:
            count = (self._drc_cluster.count(want) if self._drc_cluster is not None
                     else self._drc_wf_count(self._drc, self._drc_open))
        self._drc_delta_ui_busy = True
        try:
            store, tree = win._delta_store, win._delta_tree
            summary = self._drc_delta_summary()
            rows = [["All errors", str(count), None, GLib.markup_escape_text(
                "All errors" + (" · " + summary if summary else ""))]]
            active = getattr(self, "_drc_delta_group", None)
            chosen = 0
            if groups is not None:
                for group in groups.page(page * 50, 50, want):
                    if active is not None and active.key == group.key:
                        chosen = len(rows)
                    rows.append([group.label, str(group.count(want)), group,
                                 GLib.markup_escape_text(group.name)])
            # The list is written over where it stands when its rows are the
            # groups it has already, in their order - what choosing a group
            # leaves, and a count that changed: it keeps its place, and GTK
            # its cursor there. Until 0.12.497 it was emptied and filled at
            # every refresh, which put it back at its top: a group chosen
            # far down went out of sight, by a click and - user 2026-11-15:
            # "CD 그룹 목록이 길 경우 키로 내려도 스크롤이 따라가지 않음" - by the
            # cursor keys, whose row GTK brings in sight only while the
            # rows it had are there. Other groups - another page, rule,
            # basis or step, a group a filter leaves out - make the list
            # anew, from its top.
            key = lambda group: None if group is None else group.key
            same = (len(store) == len(rows)
                    and all(key(old[2]) == key(new[2]) for old, new in zip(store, rows)))
            if same:
                for old, new in zip(store, rows):
                    for column, value in enumerate(new):
                        if column == 2 or old[column] != value:
                            old[column] = value
            else:
                store.clear()
                for row in rows:
                    store.append(row)
            # Paging the group directory does not change the selected scope.
            selection = tree.get_selection()
            path = Gtk.TreePath.new_from_string(str(chosen))
            if active is not None and not chosen:
                selection.unselect_all()
            elif not selection.path_is_selected(path):
                selection.unselect_all()
                selection.select_path(path)
            if not same and (active is None or chosen):
                # (a list made anew stands at its top: the scope's row in sight)
                tree.scroll_to_cell(path, None, False, 0.0, 0.0)
        finally:
            self._drc_delta_ui_busy = False
        # the pager: `page/pages`, and there only for a second page
        win._delta_label.set_text("%d/%d" % (page + 1, pages))
        win._delta_prev.set_sensitive(page > 0)
        win._delta_next.set_sensitive(page + 1 < pages)
        controls, listed = self._drc_delta_shown()
        win._delta_controls.set_visible(controls)
        win._delta_list.set_visible(listed)
        win._delta_bar.set_visible(pages > 1)
        # (no step to set with grouping off, for the same CD or the reason groups -
        # nor for a rule that has nothing to measure a CD by)
        win._delta_step.set_sensitive(
            getattr(self, "_drc_delta_mode", DRC_DELTA_DEFAULT) not in DRC_NO_STEP
            and bool(self._drc_constraints(self._drc_open)))

    def _drc_delta_summary(self):
        """A grouping in a line - the `All errors` row's tooltip, where the
        group pager's line read it for every rule until 2026-11-11: the
        groups, the step in use (also the step button's tooltip), the
        edge-length groups, the estimated CDs; of a grouping that failed,
        why; nothing while there is none."""
        error = getattr(self, "_drc_delta_error", None)
        if error:
            return error
        groups = getattr(self, "_drc_delta_groups", None)
        if getattr(self, "_drc_delta_mode", DRC_DELTA_DEFAULT) == "reason":
            # (the reason groups: how many, and whose marks' the filter lists)
            stages = self._drc_reason_stages()
            if groups is None or not stages:
                return "" if getattr(self, "_drc_delta_busy", False) else "no reasons"
            # (the ones listed: with an error the waive filter shows)
            listed = groups.shown(None if self._drc_wfilter == "all"
                                  else self._drc_wf_class())
            return "%d reason%s of the %s" % (
                listed, "" if listed == 1 else "s",
                " and ".join("%ss" % stage for stage in stages))
        if groups is None:
            return ""
        message = "%d groups" % len(groups)
        step = getattr(groups, "step_ticks", None)
        if getattr(self, "_drc_delta_mode", DRC_DELTA_DEFAULT) == "value":
            # (no step: a group is the errors of one CD)
            message += " · same CD (5 decimal places)"
        elif step is not None:
            message += " · %sstep %s" % (
                "auto " if getattr(groups, "auto_step", False) else "",
                format_ticks(step))
        geometry = getattr(groups, "geometry_count", 0)
        if geometry:
            message += " · %d edge-length groups (um; CD unresolved)" % geometry
        estimated = getattr(groups, "estimated_total", 0)
        if estimated:
            message += " · %d estimated (all statuses)" % estimated
        return message

    def _drc_delta_shown(self):
        """(controls, list): what of the pane's CD part is in sight - both,
        whenever a rule or a cluster is in the grid (0.12.502, user
        2026-11-16: "CD 그룹이 없는 룰의 경우 CD 그룹 표시 부분을 없애기로
        이전에 결정했는데 다시 복원하고 All Errors 만 표시되도록 하면 될 것
        같아. 그러면 All Errors를 통해 에러 전체 선택도 가능해고 콤보에
        note만 추가하면 될 것 같음"). A rule without CD groups - no SVRF
        metadata of it, no constraint that can be measured, grouping off -
        has the list's first row alone, `All errors`: the row whose menu
        takes all the rule's errors at once, and beside it the basis
        control, where `reason` lists what the rule's requests and waives
        say. From 0.12.443 (user call 2026-11-10) to 0.12.501 such a rule
        had neither part, and grouping off the controls alone. With no
        rule picked there is nothing to list: neither."""
        if self._drc is None or self._drc_open is None:
            return False, False
        return True, True

    def _drc_delta_page_step(self, delta):
        self._drc_delta_page = max(0, self._drc_delta_page + delta)
        self._drc_delta_refresh()

    def _drc_delta_poll(self):
        worker = getattr(self, "_drc_delta_worker", None)
        result = worker.poll() if worker is not None else None
        if result is None:
            progress = getattr(worker, "progress", None)
            if (getattr(self, "_drc_delta_busy", False) and isinstance(progress, str)
                    and progress != getattr(self, "_drc_delta_progress", None)):
                self._drc_delta_progress = progress
                # the pane has no line for it (2026-11-11): a measurement
                # that takes its time says where it is in the status line,
                # and then that it is done; one made at once says nothing
                if (time.monotonic() - getattr(self, "_drc_delta_since", 0.0)
                        >= DRC_SAY_AFTER_S):
                    self._drc_delta_said = True
                    self._set_live_status("CD groups: %s" % progress)
            return
        key, groups, error = result
        if key != getattr(self, "_drc_delta_key", None):
            return
        self._drc_delta_busy = False
        if getattr(self, "_drc_delta_soft", None) == key:
            # (the reason groups asked again behind the list shown)
            self._drc_delta_soft = None
            self._drc_reasons_swap(groups, error)
            return
        by_reason = key[4] == "reason"
        self._drc_delta_groups = groups
        if groups is not None and key[3] is None and not by_reason:
            self._drc_group_counts[(key[1], key[4], key[5])] = groups.cd_count
        self._drc_delta_error = ("%s failed: %s" % ("reasons" if by_reason else "CD grouping", error)
                                 if error else None)
        if groups is not None:
            self._drc_delta_step = groups.step_ticks
            if groups.auto_step:
                setting = (self._drc_open, self._drc_delta_mode)
                self._drc_delta_auto_steps[setting] = groups.step_ticks
            self._drc_delta_write_step(groups.step_ticks)
            restore = getattr(self, "_drc_delta_restore", None)
            if restore is not None and restore[0] == key:
                row = groups.find(restore[1])
                self._drc_delta_group = groups[row] if row is not None else None
                self._drc_delta_restore = None
                self._drc_delta_scope_refresh()
        self._drc_delta_refresh()
        self._drc_group_ui_refresh()
        if error:
            self._set_live_status(self._drc_delta_error)
        elif getattr(self, "_drc_delta_said", False):
            self._set_live_status("%s: %s" % (
                "reasons" if by_reason else "CD groups",
                self._drc_delta_summary() or "none for this rule"))
        self._drc_delta_said = False

    def _drc_delta_scope_refresh(self):
        """A new scope starts at page one, with only its own saved picks."""
        ci = self._drc_open
        self._drc_focus = None
        self._drc_pos = -1
        self.drc_mark = None
        self._drc_hl_res = None
        for ruler in self._drc_ruler:
            if ruler in self.rulers:
                self.rulers.remove(ruler)
        self._drc_ruler = []
        self._drc_sel = self._drc_sels.get(self._drc_scope_key())
        self._drc_page = 0
        self._drc_marker_invalidate()
        self._drc_selection_restore()
        self._drc_delta_refresh()
        if ci is not None:
            self._drc_grid_fill(ci)
            self._drc_show_rule(ci)
        self._display()

    def _drc_delta_choose(self, group):
        if group is getattr(self, "_drc_delta_group", None):
            return
        if self._drc_sel is not None:
            self._drc_sels[self._drc_scope_key()] = self._drc_sel
        self._drc_delta_group = group
        self._drc_delta_scope_refresh()

    def _on_drc_delta_sel(self, selection):
        if getattr(self, "_drc_delta_ui_busy", False):
            return
        model, it = selection.get_selected()
        if it is not None:
            self._drc_delta_choose(model.get_value(it, 2))

    def _popup(self, menu, ev, slot):
        """Pop `menu` up at the pointer. It is kept in `self.<slot>` while
        it is up - a menu nothing refers to is gone before it is shown -
        and destroyed once it is done with, chosen from or dismissed: here,
        on the GTK thread. A menu and its handlers refer to each other, so
        a menu merely let go of waits for the garbage collector, which
        frees it - and closes its window - on whichever thread it runs
        (_MainThreadGc: the crash of 2026-11-16 was that, on the service's
        reader thread). GTK says "deactivate" before the chosen item's
        "activate": the menu goes in an idle after both."""
        setattr(self, slot, menu)

        def done(_menu):
            if getattr(self, slot, None) is menu:
                setattr(self, slot, None)
            GLib.idle_add(lambda: (menu.destroy(), False)[1])

        menu.connect("deactivate", done)
        menu.show_all()
        if hasattr(menu, "popup_at_pointer"):
            menu.popup_at_pointer(ev)
        else:
            menu.popup(None, None, None, None, ev.button, ev.time)

    def _on_drc_delta_menu(self, tree, ev):
        """Right click on a row of the group list (user call 2026-11-11):
        the row becomes the grid's scope, as a click on it makes it, and a
        menu offers what is done to all its errors at once - `All errors`
        the rule's or the cluster's, a group row the group's: select all /
        deselect all, waive all / unwaive all, mark / clear not for review
        all (_drc_scope_all)."""
        if ev.button != 3 or ev.type != Gdk.EventType.BUTTON_PRESS:
            return False
        hit = tree.get_path_at_pos(int(ev.x), int(ev.y))
        db, ci = self._drc, self._drc_open
        if hit is None or db is None or ci is None:
            return False
        # (the selection's own handler makes the row the scope)
        tree.get_selection().select_path(hit[0])
        # (a session that makes no mark - a confirmer alone - has no waive
        # to offer; one with a role has its role's verdicts on the whole
        # group: a confirmer's confirm and reject, a waiver's decline. Of
        # what the roles have, the menu has the commands there is
        # something to do with in the scope - 0.12.506, _drc_offers)
        members = self._drc_active_members()
        offers = self._drc_offers(db, ci, scope=members, whole=members is None)
        groups = [[("select", None), ("deselect", None)]]
        groups += self._drc_offered_groups(db, offers)
        asking = getattr(db, "marks", "waive") == "request"
        menu = Gtk.Menu()
        for group in groups:
            if menu.get_children():
                menu.append(Gtk.SeparatorMenuItem())
            for action, on in group:
                it = Gtk.MenuItem(label=self._drc_scope_words(action, on, asking))
                it.connect("activate", lambda _i, a=action, o=on, d=db, c=ci:
                           self._drc_scope_all(a, o)
                           if self._drc is d and self._drc_open == c else None)
                menu.append(it)
        self._popup(menu, ev, "_drc_menu")
        return True

    def _drc_offers(self, db, ci, errors=None, scope=None, whole=False):
        """What the service says there is to do with rule `ci`'s errors -
        `errors`, a `scope` (a selection, a cluster, a group: what has the
        service's spec), or the `whole` rule - for the right-click menus
        (PackDrc.offers). None where it cannot say: results without a
        review, a scope the service does not keep, a request that failed -
        the menu is then what the session's roles alone make it, as until
        0.12.505, and a command that finds nothing to do says so."""
        ask = getattr(db, "offers", None)
        if ask is None:
            return None
        if errors is None and not whole:
            scope = getattr(scope, "spec", None)
            if scope is None:
                return None
        try:
            return ask(ci, errors=errors, scope=scope)
        except (OSError, gtkservice.ServiceError):
            return None

    @staticmethod
    def _drc_offered_groups(db, offers):
        """The marking, verdict and setting-aside commands of a right-click
        menu, a group a list of (action, on): what the session's roles have
        (user 2026-11-16: "각 role별로 마우스 우측 버튼에 나와야 하는 액션만
        보여주고 권한이 없는 액션은 가리고") and - `offers`, the service's
        word, when there is one - what there is something to do with among
        the errors the menu is of ("에러 상태도 메뉴에 반영되도록 해줘"): a
        command that would change nothing of them is left out, and a group
        with none left is no group. Setting aside is a confirmer's among
        the roles, and a session's without one ("confirmer만 가능하게")."""
        def there(action, on):
            pair = None if offers is None else offers.get(action)
            return True if pair is None else bool(pair[0 if on else 1])

        groups = []
        if getattr(db, "marks", "waive") != "none":
            groups.append([("waive", True), ("waive", False)])
        groups += [list(verdicts) for verdicts in Viewer._drc_verdict_items(db)]
        if hasattr(db, "review_flags") and getattr(db, "sets_aside", True):
            groups.append([("not-required", True), ("not-required", False)])
        groups = [[entry for entry in group if there(*entry)] for group in groups]
        return [group for group in groups if group]

    def _drc_scope_said(self, action, on=None):
        """A group menu command as the status line names it: its item's
        words in this session (_drc_scope_words)."""
        return self._drc_scope_words(
            action, on, getattr(getattr(self, "_drc", None), "marks", "waive") == "request")

    @staticmethod
    def _drc_scope_words(action, on=None, asking=False):
        """A group menu command as its item reads. `asking`: a requester's
        session, whose mark is a request (0.12.506: its two commands say
        so - they read `waive all` / `unwaive all` until then)."""
        if asking and action == "waive":
            return "request waive all" if on else "take back request all"
        return {("select", False): "select all", ("deselect", False): "deselect all",
                ("waive", True): "waive all", ("waive", False): "unwaive all",
                ("confirm", True): "confirm all", ("confirm", False): "unconfirm all",
                ("reject", True): "reject all…", ("reject", False): "unreject all",
                ("decline", True): "decline all…", ("decline", False): "undecline all",
                ("not-required", True): "mark not for review all",
                ("not-required", False): "clear not for review all"}[(action, bool(on))]

    def _drc_scope_all(self, action, on=None):
        """A group menu command on the scope in the grid - the rule, the
        cluster or the CD group picked in the group list. `select all`
        selects what the grid lists, all its pages - the scope under the
        waive filter, as a box selection does - and `deselect all` drops
        the selection. The other four are done to EVERY error of the scope
        whatever the waive filter lists: `waive all` leaves the whole group
        waived and `unwaive all` not waived, so the one undoes the other
        under any filter (under Not Waived the errors a `waive all` took
        are no longer listed to be picked again). They do not touch the
        selection in the grid: the service collects the scope's errors
        (the select job) and the command is done to that (the review
        job), in the background for a scope of any size. A role's
        verdicts (0.12.474) - `confirm all` / `unconfirm all`, `reject
        all…` / `unreject all`, `decline all…` / `undecline all` - are done
        the same way to every error of the scope they apply to: the group
        a waiver waived at once is confirmed at once (_drc_verdict)."""
        db, ci = self._drc, self._drc_open
        if db is None or ci is None:
            return
        if action == "deselect":
            if getattr(self, "_drc_selection_key", None) is not None:
                self._drc_selection_cancel()
            self._drc_set_sel(None)
            self._drc_grid_fill(ci)
            self._set_live_status("error select %s: none selected"
                                  % db.checks[ci].name)
            self._display()
            return
        if action == "waive" and not hasattr(db, "set_status"):
            self._set_live_status("waive needs a packed index: "
                                  "floe-index drc <db>")
            return
        if action == "not-required" and not hasattr(db, "review_flags"):
            self._set_live_status("review flags need a packed index: "
                                  "floe-index drc <db>")
            return
        if action in ("confirm", "reject", "decline") and not self._drc_verdict_may(db, action):
            return
        if action != "select" and self._drc_review_pending():
            return
        self._drc_selection_submit(
            ci, None, self._drc_active_members(), "replace",
            then=None if action == "select" else (action, on))

    def _drc_scope_apply(self, ci, targets, action, on):
        """The second half of a group menu command: the scope's errors are
        collected (`targets`, the service's selection), now the command."""
        if not targets:
            self._set_live_status("%s: no error in this scope"
                                  % self._drc_scope_said(action, on))
            return
        if action == "waive":
            self._drc_set_waived(ci, targets, on)
        elif action in ("confirm", "reject", "decline"):
            self._drc_verdict(ci, targets, action, on)
        else:
            self._drc_set_not_required(ci, targets, on)

    def _on_drc_delta_mode(self, combo):
        mode = combo.get_active_id() or DRC_DELTA_DEFAULT
        if mode == self._drc_delta_mode:
            return
        active = getattr(self, "_drc_delta_group", None)
        if self._drc_sel is not None:
            self._drc_sels[self._drc_scope_key()] = self._drc_sel
        self._drc_delta_mode = mode
        self._drc_group_cache_sync()
        self._drc_delta_sync()
        if mode != "off" and active is not None and active.key[0] == -2:
            self._drc_delta_restore = (self._drc_delta_key, active.key)
        self._drc_group_ui_refresh()
        self._drc_delta_scope_refresh()

    def _drc_step_dialog(self, _widget=None):
        """The step button's modal (user call 2026-11-10: a small one in
        place of the pane's entry): the CD group step of the rule in the
        grid, starting from the one in use, in the basis' unit. Enter or
        ok sets it and closes; an empty value or `auto` is the automatic
        step again; a value that is refused is said in the dialog, which
        stays; Esc, cancel or the window's close leave the step as it is."""
        ci, mode = self._drc_open, self._drc_delta_mode
        if mode in DRC_NO_STEP or ci is None:
            return
        if self._sdlg is not None:
            self._sdlg.present()
            return
        dlg = Gtk.Window(title="CD group step")
        self._dialog_setup(dlg)
        self._sdlg = dlg
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(14)
        box.set_margin_end(14)
        dlg.add(box)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        box.pack_start(row, False, False, 0)
        entry = Gtk.Entry()
        entry.set_width_chars(12)
        entry.set_text(self._drc_delta_step_text)
        row.pack_start(entry, False, False, 0)
        unit = Gtk.Label(label=self._drc_step_unit())
        row.pack_start(unit, False, False, 0)
        # the hint, and in its place why a value was refused (one width
        # for both: the dialog must not change size under the cursor)
        why = Gtk.Label()
        why.set_xalign(0.0)
        why.set_width_chars(30)
        why.set_markup("<small>empty or auto: the automatic step</small>")
        box.pack_start(why, False, False, 0)
        # (named for the drc_analysis gate, which types in the entry)
        entry.set_name("drc-step")
        unit.set_name("drc-step-unit")
        why.set_name("drc-step-why")
        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        box.pack_start(buttons, False, False, 0)
        ok = Gtk.Button(label="ok")
        cancel = Gtk.Button(label="cancel")
        buttons.pack_end(ok, False, False, 0)
        buttons.pack_end(cancel, False, False, 0)

        def _set(*_a):
            # the rule and the basis the dialog was opened for, or nothing
            if (self._drc_open, self._drc_delta_mode) != (ci, mode):
                dlg.destroy()
                return
            refused = self._drc_delta_set_step(entry.get_text())
            if refused is None:
                dlg.destroy()
            else:
                why.set_markup("<small>%s</small>"
                               % GLib.markup_escape_text(refused))
        entry.connect("activate", _set)
        ok.connect("clicked", _set)
        cancel.connect("clicked", lambda *_: dlg.destroy())

        def on_dialog_key(_w, ev):
            if Gdk.keyval_name(ev.keyval) == "Escape":
                dlg.destroy()
                return True
            return False
        dlg.connect("key-press-event", on_dialog_key)

        def _gone(*_a):
            self._sdlg = None
            self._restore_keys()
        dlg.connect("destroy", _gone)
        self._dialog_show(dlg, entry)

    def _drc_delta_set_step(self, text):
        """Set the CD group step of the rule in the grid from what was
        typed (`auto` or nothing: the automatic one). None, or why the
        text is refused - nothing changes then."""
        from .gtkservice import parse_step
        if self._drc_delta_mode in DRC_NO_STEP or self._drc_open is None:
            return None
        text = text.strip()
        try:
            step = None if text.lower() in ("", "auto") else parse_step(text)
        except ValueError as exc:
            return str(exc)
        setting = (self._drc_open, self._drc_delta_mode)
        previous = self._drc_delta_steps.get(setting)
        if step == previous:
            return None
        active = getattr(self, "_drc_delta_group", None)
        if self._drc_sel is not None:
            self._drc_sels[self._drc_scope_key()] = self._drc_sel
        if step is None:
            self._drc_delta_steps.pop(setting, None)
        else:
            self._drc_delta_steps[setting] = step
        # (until the new grouping says its step: the one asked, or the
        # automatic one where it is known)
        self._drc_delta_write_step(
            step if step is not None else self._drc_delta_auto_steps.get(setting))
        self._drc_group_cache_sync()
        self._drc_delta_sync()
        if active is not None and active.key[0] == -2:
            self._drc_delta_restore = (self._drc_delta_key, active.key)
        self._drc_group_ui_refresh()
        self._drc_delta_scope_refresh()
        return None

    def _drc_delta_status_changed(self, ci, eis=None):
        if ci != self._drc_open:
            return
        groups = getattr(self, "_drc_delta_groups", None)
        if groups is not None and getattr(groups, "reasons", False):
            # (a reason group's counts are the service's, asked at the refresh; what
            # the marks say is read again behind the list shown)
            self._drc_reasons_again()
            self._drc_delta_refresh()
            return
        if groups is not None:
            if eis is None:
                if getattr(groups, "_persistent", False):
                    active = getattr(self, "_drc_delta_group", None)
                    if self._drc_sel is not None:
                        self._drc_sels[self._drc_scope_key()] = self._drc_sel
                    self._drc_delta_revision = getattr(self, "_drc_delta_revision", 0) + 1
                    self._drc_delta_sync(force=True)
                    if active is not None:
                        self._drc_delta_restore = (self._drc_delta_key, active.key)
                    return
                groups.reset_status()
            else:
                groups.status_changed(eis)
        if getattr(self, "_drc_delta_busy", False):
            # A result's status snapshot may precede this write. Re-bin with
            # current statuses in the worker, reusing the measured CDs.
            self._drc_delta_revision = getattr(self, "_drc_delta_revision", 0) + 1
            self._drc_delta_sync()
        self._drc_delta_refresh()

    def _on_drc_search(self, entry):
        txt = entry.get_text().strip().lower()
        if txt == self._drc_search or self._drc is None:
            return
        self._drc_search = txt
        self._drc_fill(preserve=True)
        self._display()

    def _on_drc_selview(self, btn):
        self._drc_show_sel = btn.get_active()
        if self._drc_open is not None:
            self._drc_grid_fill(self._drc_open)
        self._display()

    def _drc_page_step(self, delta):
        ci = self._drc_grid_ci
        if ci is None:
            return
        p = self._drc_page + delta
        if p < 0:
            return
        self._drc_page = p       # the fill clamps to the last page
        self._drc_grid_fill(ci)
        self._display()          # refresh focus; marker population stays fixed

    def _on_drc_rule_sel(self, sel):
        """Selecting a rule shows ITS error grid alone (the
        accordion ask) and its info in the detail pane."""
        if self._drc_rules_busy:
            # ListStore.clear() deletes row by row and SOME GTK
            # builds auto-select the next row each time - without
            # this guard the full handler (grid fill + query +
            # display) ran per deleted row: a 1000-rule filter
            # switch took 9.7s on one machine (field profile
            # 2026-08-15)
            return
        model, it = sel.get_selected()
        if it is None or self._drc is None:
            return
        ci = model.get_value(it, 2)
        cluster = model.get_value(it, 3)
        if ci == self._drc_open and cluster is self._drc_cluster:
            return
        if self._drc_sel is not None and self._drc_open is not None:
            self._drc_sels[self._drc_scope_key()] = self._drc_sel
        self._drc_marker_invalidate()
        self._drc_open = ci
        self._drc_cluster = cluster
        self._drc_delta_sync()
        self._drc_focus = None
        self._drc_pos = -1
        self._drc_hl_res = None
        # a live jump belongs to the PREVIOUS rule: drop its mark,
        # position and auto CD rulers or they linger on the canvas
        # over the new rule's errors (user call 2026-08-18)
        if self.drc_mark is not None:
            self.drc_mark = None
            self._drc_pos = -1
            for r in self._drc_ruler:
                if r in self.rulers:
                    self.rulers.remove(r)
            self._drc_ruler = []
        # Each rule/cluster keeps its own selection. A batch waive or
        # note action must never include another cluster's hidden picks.
        self._drc_sel = self._drc_sels.get(self._drc_scope_key())
        self._drc_selection_restore()
        self._drc_page = 0
        with _dprof("rule_sel: grid fill"):
            self._drc_grid_fill(ci)
        self._drc_show_rule(ci)
        # the rule's errors are painted on the canvas: repaint NOW,
        # not on the next incidental redraw (user call 2026-08-14)
        self._drc_hl_res = None
        with _dprof("rule_sel: display"):
            self._display()

    def _on_drc_grid_alloc(self, _w, alloc):
        n = max(1, min(24, alloc.width // max(24, self._drc_cellw)))
        if n != self._drc_gridw:
            self._drc_grid_set_cols(n)

    def _drc_grid_set_cols(self, n):
        """Rebuild the grid with n columns (model column count is
        fixed per ListStore) and refill, keeping the marked cell."""
        win = self._drcwin
        if win is None:
            return
        grid = win._grid
        mei = None
        if self._drc_cell is not None:
            row, j = self._drc_cell
            idx = row * self._drc_gridw + j
            if self._drc_grid_map is not None:
                if idx < len(self._drc_grid_map):
                    mei = self._drc_grid_map[idx]
            else:
                mei = idx
        self._drc_gridw = n
        for col in list(grid.get_columns()):
            grid.remove_column(col)
        store = Gtk.ListStore(*([str] * n))
        for j in range(n):
            col = Gtk.TreeViewColumn(
                "", Gtk.CellRendererText(), markup=j)
            col.set_expand(True)
            grid.append_column(col)
        grid.set_model(store)
        win._gstore = store
        if self._drc_grid_ci is not None:
            keep = self._drc_focus
            self._drc_grid_fill(self._drc_grid_ci)
            self._drc_focus = keep
            if mei is not None:
                if self._drc_grid_map is not None:
                    idx = (self._drc_grid_map.index(mei)
                           if mei in self._drc_grid_map else None)
                else:
                    idx = mei
                if idx is not None:
                    self._drc_cell_mark(idx // n, idx % n)

    def _drc_grid_fill(self, ci):
        """One PAGE (DRC_PAGE cells) of the rule's error grid.

        Numbers are RULE-LOCAL 1-based (user call 2026-08-14 - the
        Calibre-style global number lives in the detail pane as
        #local(global)). The base honours the waive filter and,
        with 'filter errors in view' on, the viewport;
        _drc_grid_map always holds the page's ei list."""
        win, db = self._drcwin, self._drc
        if win is None or db is None or ci != self._drc_open:
            return
        _t0 = time.perf_counter()
        gstore = win._gstore
        gstore.clear()
        self._drc_cell = None
        self._drc_grid_ci = ci
        c = db.checks[ci]
        # the visible list = cluster ∧ selected ∧ in-view ∧ waive filter
        # (each stage narrows; None = every error of the rule)
        cluster = self._drc_active_members()
        conflict_only = getattr(self, "_drc_conflict_only", False)
        base = None
        sel = self._drc_sel
        selected = sel[1] if sel is not None and sel[0] == ci else None
        if self._drc_show_sel:
            if selected:
                if hasattr(selected, "page"):
                    base = ("cluster", selected, None)
                else:
                    base = list(selected)  # legacy bounded selection fixture
            else:
                base = []
        if self._drc_hl and hasattr(db, "query_rect"):
            inview = [ei for rci, ei, _k, _p in self._drc_hl_list() if rci == ci]
            if self._drc_show_sel:
                base = ([ei for ei, ok in zip(inview, selected.contains_many(inview)) if ok]
                        if selected is not None else [])
            else:
                base = inview
        if cluster is not None and base is None:
            want = None if conflict_only or self._drc_wfilter == "all" else self._drc_wf_class()
            base = ("cluster", cluster, want)
        elif cluster is not None and isinstance(base, list):
            # one service question for the page, not one per error
            base = [ei for ei, ok in zip(base, cluster.contains_many(base)) if ok]
        if not conflict_only and self._drc_wfilter != "all" and not isinstance(base, tuple):
            if base is None:
                base = self._drc_wf_base(db, ci)
            else:
                base = [ei for ei in base if self._drc_wf_shows(db, ci, ei)]
        if base is None:
            count = len(c.errors)
        elif isinstance(base, tuple):
            count = (base[1].count(base[2]) if base[0] == "cluster" else
                     self._drc_wf_count(db, ci))
        else:
            count = len(base)
        self._drc_grid_base = base
        pages = max(1, -(-count // DRC_PAGE))
        self._drc_grid_pages = pages
        self._drc_page = max(0, min(self._drc_page, pages - 1))
        start = self._drc_page * DRC_PAGE
        stop = min(start + DRC_PAGE, count)
        if base is None:
            eis = list(range(start, stop))
        elif isinstance(base, tuple):
            eis = (base[1].page(start, stop - start, base[2])
                   if base[0] == "cluster" else
                   db.status_page(ci, base[1], start, stop - start))
        else:
            eis = base[start:stop]
        self._drc_grid_map = eis
        win._plabel.set_text("%d/%d" % (self._drc_page + 1, pages))
        win._pprev.set_sensitive(self._drc_page > 0)
        win._pnext.set_sensitive(self._drc_page < pages - 1)
        sel = self._drc_sel
        eset = (sel[3] if sel is not None and sel[0] == ci
                else frozenset())
        # errors carrying a note get a "*" prefix in the grid
        noted = ({ei for ei in eis if db.get_note(ci, ei)}
                 if hasattr(db, "get_note") else set())
        # cell width follows the page's widest LOCAL number (+1 for
        # the "*" when any cell on the page is noted)
        maxloc = (max(eis) + 1) if eis else 1
        probe = win._grid.create_pango_layout(
            "0" * (max(2, len(str(maxloc))) + (1 if noted else 0)
                   + (2 if hasattr(db, "review_flags") else 0)))
        self._drc_cellw = probe.get_pixel_size()[0] + 18
        avail = win._grid.get_allocation().width
        n = max(1, min(24, avail // max(24, self._drc_cellw)))
        if n != self._drc_gridw:
            self._drc_grid_set_cols(n)  # refills at the new width
            return
        W = self._drc_gridw

        def cellfmt(ei):
            return self._drc_cell_markup(db, ci, ei, ei in noted, eset)

        for b2 in range(0, len(eis), W):
            cells = [cellfmt(ei) for ei in eis[b2:b2 + W]]
            cells += [""] * (W - len(cells))
            gstore.append(cells)
        self._drc_grid_rows = (len(eis) + W - 1) // W
        # keep the focused error marked when it is on this page
        f = self._drc_focus
        if f is not None and f[0] != ci:
            self._drc_focus = None
        elif f is not None and f[1] in eis:
            idx = eis.index(f[1])
            self._drc_cell_mark(idx // W, idx % W)
        # Grid rows only need IDs/statuses. Geometry is decoded on an
        # explicit jump or by the marker worker, never eagerly on a click.
        self._drc_page_marks = []
        if _DRC_PROF:
            dt = (time.perf_counter() - _t0) * 1e3
            if dt >= 1.0:
                sys.stderr.write(
                    "[drcprof] grid_fill ci=%d page=%d cells=%d "
                    "base=%s %8.1f ms\n"
                    % (ci, self._drc_page, len(eis),
                       ("all" if base is None else
                        "lazy" if isinstance(base, tuple)
                        else "list"), dt))
                sys.stderr.flush()

    def _drc_sel_click(self, ci, row, j, idx, ei, is_range):
        """Edit a bounded grid page without expanding the saved selection."""
        from .gtkservice import ListMembers
        if is_range:
            aidx = idx
            if self._drc_cell is not None:
                aidx = self._drc_cell[0] * self._drc_gridw + self._drc_cell[1]
            lo, hi = sorted((aidx, idx))
            indices = self._drc_grid_map[lo:hi + 1]
        else:
            indices = [ei]
        self._drc_selection_submit(ci, None, ListMembers(indices),
                                   "add" if is_range else "toggle")
        self._drc_cell_mark(row, j)
        self._drc_show_detail(ci, ei)
        self._display()

    def _on_drc_grid_menu(self, tree, ev):
        """Right click on an error number: waive/unwaive it - or
        the whole GOLD selection when one exists (user call
        2026-08-14; writes the v2 status byte in place)."""
        hit = tree.get_path_at_pos(int(ev.x), int(ev.y))
        if hit is None:
            return False
        path, col, _cx, _cy = hit
        row = path.get_indices()[0]
        ci = self._drc_grid_ci
        db = self._drc
        if ci is None or db is None \
                or row >= self._drc_grid_rows:
            return False
        try:
            j = tree.get_columns().index(col)
        except ValueError:
            return False
        idx = row * self._drc_gridw + j
        gmap = self._drc_grid_map
        if idx >= len(gmap):
            return False
        ei = gmap[idx]
        if not hasattr(db, "set_status"):
            self._set_live_status(
                "waive needs a packed index: "
                "floe-index drc <db>")
            return True
        self._drc_cell_mark(row, j)
        self._drc_show_detail(ci, ei)
        sel = self._drc_sel
        if sel is not None and sel[0] == ci and sel[1]:
            targets = sel[1]
            scope = "%d selected" % len(targets)
        else:
            targets = [ei]
            scope = "#%d" % (ei + 1)
        menu = Gtk.Menu()
        # What the session's roles have - a session that makes no mark, a
        # confirmer alone, has no waive to offer; a role's verdicts on the
        # error, or on the selection (0.12.474, user 2026-11-14: "confirmer의
        # 경우 오른쪽 버튼 메뉴에 confirm 관련을 넣는게 좋을 것 같음"): a
        # confirmer's confirm and reject, a waiver's decline - and, of
        # those, what there is something to do with (0.12.506, user
        # 2026-11-16: "에러 상태도 메뉴에 반영되도록 해줘"): the service says
        # it of the error, or of the selection - a command is there when it
        # has something to do with at least one of them (_drc_offers). A
        # requester's mark is a request, and its two commands say so (the
        # same day: they read `waive #5` / `unwaive #5` until then).
        if getattr(targets, "sid", None) is not None:
            offers = self._drc_offers(db, ci, scope=targets)
        else:
            offers = self._drc_offers(db, ci, errors=list(targets))
        asking = getattr(db, "marks", "waive") == "request"
        words = dict(self.VERDICT_ITEMS)
        words.update({("waive", True): "request waive %s" if asking else "waive %s",
                      ("waive", False): "take back request %s" if asking else "unwaive %s",
                      ("not-required", True): "mark not for review: %s",
                      ("not-required", False): "clear not for review: %s"})

        def run(action, on, t=targets, d=db):
            if self._drc is not d:
                return
            if action == "waive":
                self._drc_set_waived(ci, t, on)
            elif action == "not-required":
                self._drc_set_not_required(ci, t, on)
            else:
                self._drc_verdict(ci, t, action, on)

        groups = self._drc_offered_groups(db, offers)
        # what was marked with this error: the group its waiver waived at
        # once, or its requester asked for at once - after the verdicts,
        # before the commands that set aside
        stage = self._drc_group_stage(db, ci, ei)
        aside = [g for g in groups if g[0][0] == "not-required"]
        for group in [g for g in groups if g[0][0] != "not-required"] + [None] + aside:
            if group is None and stage is None:
                continue
            if menu.get_children():
                menu.append(Gtk.SeparatorMenuItem())
            if group is None:
                it = Gtk.MenuItem(label="select %s with #%d" % (stage, ei + 1))
                it.connect("activate", lambda _i, e=ei, d=db:
                           self._drc_group_select(ci, e)
                           if self._drc is d else None)
                menu.append(it)
                continue
            for action, on in group:
                it = Gtk.MenuItem(label=words[(action, on)] % scope)
                it.connect("activate", lambda _i, a=action, o=on: run(a, o))
                menu.append(it)
        if menu.get_children():
            menu.append(Gtk.SeparatorMenuItem())
        it = Gtk.MenuItem(label="SVRF info…")
        it.connect("activate", lambda _i: self._drc_svrf_dialog())
        menu.append(it)
        self._popup(menu, ev, "_drc_menu")
        return True

    def _drc_set_waived(self, ci, eis, on, reason=None):
        """Write the status of the targets and refresh every dependent
        surface (rule counts, grid, detail, canvas); a selection past a
        page is one service job (feature/jobdeck-drc). Waiving asks why
        first (user call 2026-11-13, _drc_reason_then): `reason` None is
        not asked yet, a text - "" for none - is the answer. The reason is
        the action's, one line whatever the action takes."""
        db = self._drc
        if db is None or not hasattr(db, "set_status"):
            return
        if self._drc_review_pending():
            return
        if getattr(db, "marks", "waive") == "none":
            # a session that only confirms makes no mark (0.12.473: it has
            # no waive file either): said before anything is asked
            self._set_live_status(
                "waive failed: a confirmer's session does not waive: it "
                "confirms or rejects the team's waives (--role waiver waives)")
            return
        if on and reason is None and not getattr(db, "read_only", False):
            self._drc_reason_then(
                "waive", ci, eis, lambda _on, text, d=db:
                self._drc_set_waived(ci, eis, True, reason=text)
                if self._drc is d else None)
            return
        if len(eis) > DRC_PAGE:
            self._drc_review_submit("waive", ci, eis, on=on,
                                    reason=reason or None)
            return
        val = STATUS_WAIVED if on else STATUS_NONE
        error = unkept = locked = rejected = None
        again = unasked = past = doubled = 0
        try:
            # one request for the selection (floe2 gtk-service)
            unkept = db.set_statuses(ci, list(eis), val,
                                     reason=(reason or None) if on else None)
            if hasattr(db, "locked_take"):
                locked = db.locked_take()
            if hasattr(db, "rejected_take"):
                rejected = db.rejected_take()
            if hasattr(db, "resubmitted_take"):
                again = db.resubmitted_take()
            if hasattr(db, "unrequested_take"):
                unasked = db.unrequested_take()
            if hasattr(db, "waived_take"):
                past = db.waived_take()
            if hasattr(db, "requested_take"):
                doubled = db.requested_take()
        except (OSError, gtkservice.ServiceError) as exc:
            # (a session that makes no mark: the service says so)
            error = (str(exc) if getattr(db, "marks", "waive") == "none"
                     else "%s - is the waive store writable?" % exc)
        self._drc_waived_refresh(ci, eis, on, error, reason=reason,
                                 unkept=unkept, locked=locked, rejected=rejected,
                                 again=again, **dict(
                                     ({"unrequested": unasked} if unasked else {}),
                                     **dict(({"past": past} if past else {}),
                                            **({"doubled": doubled} if doubled else {}))))

    def _drc_visit_drawn(self, mark, points, width, height):
        """Queue one visit only after individual geometry was painted.

        No review-store access belongs in this paint path. In particular a
        sparse edge pair's bounding box can cross the view without either
        edge being visible, so test segments rather than just the bbox.
        """
        target = mark.get("review_target")
        if (mark is not getattr(self, "drc_mark", None) or not target
                or target[0] is not getattr(self, "_drc", None)
                or mark.get("review_queued")
                or getattr(self, "overlay_mode", 0) == 2
                or width <= 0 or height <= 0 or not points):
            return
        xs, ys = zip(*points)
        if max(xs) - min(xs) < DRC_MARK_PX and max(ys) - min(ys) < DRC_MARK_PX:
            return

        def rect_visible(x, y, w, h):
            x, y, w, h = (int(round(v)) for v in (x, y, w, h))
            return w > 0 and h > 0 and x < width and y < height and x + w > 0 and y + h > 0

        def painted_segment(a, b):
            ax, ay = a
            dx, dy = b[0] - ax, b[1] - ay
            if round(ay) == round(b[1]):
                return rect_visible(min(ax, b[0]), ay - 1, abs(dx) + 1, 2)
            if round(ax) == round(b[0]):
                return rect_visible(ax - 1, min(ay, b[1]), 2, abs(dy) + 1)
            # stamp_segment samples free-angle lines at most 8,001 times.
            # A very long diagonal can cross the viewport between dabs and
            # paint nothing. Clip the possible 2px-core dab centers first,
            # then test those exact samples with fill_rect's rounding rule.
            lo, hi = 0.0, 1.0
            for p, q in ((-dx, ax + 0.5), (dx, width + 0.5 - ax),
                         (-dy, ay + 0.5), (dy, height + 0.5 - ay)):
                if p == 0:
                    if q < 0:
                        return False
                    continue
                t = q / p
                if p < 0:
                    lo = max(lo, t)
                else:
                    hi = min(hi, t)
                if lo > hi:
                    return False
            steps = min(int(max(abs(dx), abs(dy))) + 1, 8000)
            first = max(0, int(math.floor(lo * steps)) - 1)
            last = min(steps, int(math.ceil(hi * steps)) + 1)
            return any(rect_visible(ax + dx * i / steps - 1,
                                    ay + dy * i / steps - 1, 2, 2)
                       for i in range(first, last + 1))

        polygon = mark.get("kind") == "p"
        segments = (zip(points, points[1:] + points[:1]) if polygon else
                    ((points[j], points[j + 1]) for j in range(0, len(points) - 1, 2)))
        visible = any(painted_segment(a, b) for a, b in segments)
        if not visible and polygon and 3 <= len(points) <= 256:
            # Match the translucent renderer's actual clipped scanline spans,
            # including polygons whose off-screen edges surround the view.
            edges = [(a, b) for a, b in zip(points, points[1:] + points[:1])
                     if a[1] != b[1]]
            for y in range(max(0, int(math.floor(min(ys)))),
                           min(height - 1, int(math.ceil(max(ys)))) + 1):
                yc = y + 0.5
                crossings = sorted(ax + (yc - ay) * (bx - ax) / (by - ay)
                    for (ax, ay), (bx, by) in edges
                    if (ay <= yc < by) or (by <= yc < ay))
                if any(min(width, int(math.floor(crossings[i + 1])) + 1)
                       > max(0, int(math.ceil(crossings[i])))
                       for i in range(0, len(crossings) - 1, 2)):
                    visible = True
                    break
        if not visible:
            return
        db, ci, ei = target
        if not hasattr(db, "mark_visited"):
            return
        mark["review_queued"] = True
        # no service request in the paint path: the next idle sends it
        GLib.idle_add(self._drc_visit_send, db, ci, ei)

    def _drc_visit_send(self, db, ci, ei):
        try:
            db.mark_visited(ci, ei)
        except gtkservice.ServiceError as exc:
            if db is getattr(self, "_drc", None):
                self._set_live_status("visit save failed: %s" % exc)
        return False

    def _drc_visit_poll(self):
        db = getattr(self, "_drc", None)
        if db is None or not hasattr(db, "visit_events"):
            return
        dirty, errors = set(), []
        for ci, _ei, error in db.visit_events():
            if error:
                errors.append(error)
            else:
                dirty.add(ci)
        for ci in dirty:
            self._drc_review_flags_refresh(ci)
        if errors:
            self._set_live_status("visit save failed: %s" % errors[-1])

    def _drc_not_required_key(self, on):
        target = self._drc_current_target()
        if target is None:
            self._set_live_status("select or focus errors to change their review requirement")
            return
        self._drc_set_not_required(*target, on)

    def _drc_set_not_required(self, ci, targets, on, reason=None):
        """Set the targets aside from the review, or bring them back.
        Setting aside asks why first, as waiving does (_drc_set_waived)."""
        db = getattr(self, "_drc", None)
        if db is None or not hasattr(db, "review_flags"):
            self._set_live_status("review flags need a packed index: floe-index drc <db>")
            return
        if not getattr(db, "sets_aside", True):
            # (a role that is no confirmer's - 0.12.506: said before
            # anything is asked; the service refuses the same)
            self._set_live_status(
                "not for review failed: setting errors aside from the review is for a viewer "
                "started with the confirmer's role (floe2 view --role confirmer)")
            return
        if on and reason is None:
            if self._drc_review_pending():
                return
            self._drc_reason_then(
                "not-required", ci, targets, lambda _on, text, d=db:
                self._drc_set_not_required(ci, targets, True, reason=text)
                if self._drc is d else None)
            return
        # Even one SQLite update runs outside the GTK thread.
        self._drc_review_submit("not-required", ci, targets, on=bool(on),
                                reason=(reason or None) if on else None)

    def _drc_review_flags(self, db, ci, ei):
        if not hasattr(db, "review_flags"):
            return 0
        try:
            return db.review_flags(ci, ei)
        except Exception as exc:
            key = (id(db), str(exc))
            if key != getattr(self, "_drc_review_read_error", None):
                self._drc_review_read_error = key
                self._set_live_status("review flags unavailable: %s" % exc)
            return None

    def _drc_review_flags_refresh(self, ci):
        """Only repaint this page's labels; flags never change its members."""
        win, db = getattr(self, "_drcwin", None), getattr(self, "_drc", None)
        if db is None:
            return
        if win is not None and ci == getattr(self, "_drc_grid_ci", None):
            sel = getattr(self, "_drc_sel", None)
            selected = sel[3] if sel is not None and sel[0] == ci else ()
            cols = self._drc_gridw
            current = getattr(self, "_drc_cell", None)
            for i, ei in enumerate(self._drc_grid_map):
                row, col = divmod(i, cols)
                noted = bool(hasattr(db, "get_note") and db.get_note(ci, ei))
                win._gstore[row][col] = self._drc_cell_markup(
                    db, ci, ei, noted, selected, current == (row, col))
        if ci == getattr(self, "_drc_open", None):
            focus = getattr(self, "_drc_focus", None)
            shown = focus[1] if focus is not None and focus[0] == ci else None
            pos, cumulative = getattr(self, "_drc_pos", -1), getattr(self, "_drc_cum", ())
            if shown is None and pos >= 0 and cumulative:
                current_ci = bisect.bisect_right(cumulative, pos) - 1
                if current_ci == ci:
                    shown = pos - cumulative[ci]
            if shown is not None:
                self._drc_show_detail(ci, shown)

    @staticmethod
    def _drc_loaded_text(db, path, svrf=None):
        """The status line of a DRC load: the results, the rules metadata
        found beside them (`svrf` = matched / all rules; a hand-loaded one
        says its own line), then whose review it is - the id its waive,
        visit and note files are kept by; one that was not stated
        (--userid, FLOE_REVIEWER) is said to be where the viewer runs - and
        what the open found amiss. The panel keeps no line of it (user
        2026-11-10)."""
        text = "DRC %s: %d checks, %d errors (. / , = step)" % (
            os.path.basename(path), len(db.checks), db.total)
        if not getattr(db, "packed", False):
            # no waives, no review, no in-view filter: each says so when
            # asked, and the load says it once
            text += " · ASCII read, no index"
        if svrf is not None:
            text += " · svrf %d/%d" % tuple(svrf)
        text += Viewer._drc_reviewer_text(db)
        moved = getattr(db, "moved_aside", None) or []
        if moved:
            text += (" · a review of other DRC results moved aside (%d "
                     "file(s), .stale-…)" % len(moved))
        return text

    @staticmethod
    def _drc_reviewer_text(db):
        """The part of a load's status line that says whose review it is
        (` · reviewer ID …`), or nothing for results without a review."""
        reviewer = getattr(db, "_reviewer", None)
        if not reviewer:
            return ""
        text = " · reviewer %s" % reviewer
        if not getattr(db, "_reviewer_stated", True):
            text += (" (the %s - not a personal ID; start with --userid ID)"
                     % (getattr(db, "_reviewer_source", None) or "host"))
        if getattr(db, "read_only", False):
            text += " · read-only (no waive file could be made)"
        role = getattr(db, "role", "")
        if role:
            # (floe2 view --role: what this session does in the workflow -
            # one role, or several with commas)
            text += " · %s" % role
        return text

    @staticmethod
    def _drc_moved_aside_text(db):
        """What the error-detail area says after an open that found a review
        of other errors under this result's name (the DRC ran again): the
        service moved the reviewer's files aside and named them in the
        open's notices. None when the review goes on."""
        moved = getattr(db, "moved_aside", None) or []
        if not moved:
            return None
        return "\n".join(
            ["a review of other DRC results was here: %d file(s) moved aside "
             "(.stale-…), this review starts anew" % len(moved), ""]
            + [str(line) for line in moved])

    def _drc_not_loaded(self, msg):
        """A DRC open that did not happen: the status line says it, and -
        cursor motion replaces that line - so does the error-detail area
        while no results are loaded (the panel has no line of its own)."""
        self._set_live_status(msg)
        win = getattr(self, "_drcwin", None)
        if win is not None and getattr(self, "_drc", None) is None:
            win._detail.set_text(msg)

    def _drc_refused(self, exc):
        """A DRC open the service refused for who asks, not for the pack:
        the review open in another session (busy), a reviewer ID required
        and not given (admission), a pack being indexed (busy). Said as any
        open that did not happen (_drc_not_loaded) and - it stops the user's
        review - in a dialog that does not block the viewer."""
        msg = str(exc)
        self._drc_not_loaded(msg)
        if getattr(exc, "kind", None) == "busy" and "being indexed" in msg:
            return
        dlg = Gtk.MessageDialog(
            transient_for=self.window, modal=False,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.CLOSE, text="DRC review not opened")
        dlg.format_secondary_text(msg)
        dlg.connect("response", lambda d, *_: d.destroy())
        self._drc_refusal_dialog = dlg
        dlg.show()

    def _drc_conflict_retired_jobs(self):
        """Keep canceled readers alive until their final pack access finishes."""
        jobs = [job for job in getattr(self, "_drc_conflict_retired", ())
                if not job.get("done", False)]
        self._drc_conflict_retired = jobs
        return jobs

    def _drc_conflict_reset(self, drop_source=False):
        retired = self._drc_conflict_retired_jobs()
        job = getattr(self, "_drc_conflict_job", None)
        if job is not None:
            job["cancel"].set()
            if not job.get("done", False) and not any(old is job for old in retired):
                retired.append(job)
        self._drc_conflict_job = None
        self._drc_conflict_key = None
        self._drc_conflict_members = None
        if drop_source:
            source = getattr(self, "_drc_conflict_source", None)
            self._drc_conflict_source = None
            self._drc_conflict_only = False
            self._drc_conflict_stamp = ""
            if source is not None:
                source.close()
            button = getattr(getattr(self, "_drcwin", None), "_conflict", None)
            if button is not None:
                self._drc_conflict_guard = True
                try:
                    button.set_active(False)
                finally:
                    self._drc_conflict_guard = False

    def _drc_conflict_clear_scope(self):
        """A new conflict scope must never inherit all-rule picks or hits."""
        self._drc_selection_cancel()
        self._drc_sel, self._drc_sels = None, {}
        self._drc_page, self._drc_focus = 0, None
        self.drc_mark, self._drc_pos = None, -1
        for ruler in getattr(self, "_drc_ruler", ()):
            if ruler in getattr(self, "rulers", ()):
                self.rulers.remove(ruler)
        self._drc_ruler = []
        self._drc_hl_res = None
        self._drc_hl_key = None
        query = getattr(self, "_drc_query_worker", None)
        if query is not None:
            query.cancel()
        self._drc_marker_invalidate()

    def _on_drc_conflict(self, button):
        if getattr(self, "_drc_conflict_guard", False):
            return
        on = bool(button.get_active())
        if on == getattr(self, "_drc_conflict_only", False):
            return
        self._drc_conflict_only = on
        self._drc_conflict_reset()
        self._drc_conflict_clear_scope()
        if self._drc_open is not None:
            self._drc_grid_fill(self._drc_open)
        self._display()
        # the filter's state is said in the status line (the panel keeps no
        # line of it, user 2026-11-10): what it needs here, its progress,
        # its failure and its count in _drc_conflict_poll
        if on and getattr(self, "_drc_conflict_source", None) is None:
            self._set_live_status("Conflict only needs a reviewer snapshot: load peer work, then Refresh.")
            self._drc_waive_load_dialog()
        elif on and self._drc_open is None:
            self._set_live_status("Conflict only: select a rule.")

    def _drc_conflict_publish(self, aggregate, stamp):
        """Retain the last published comparison independently of its window."""
        source = aggregate.lease()
        previous = getattr(self, "_drc_conflict_source", None)
        self._drc_conflict_reset()
        self._drc_conflict_source = source
        self._drc_conflict_stamp = stamp
        if previous is not None:
            previous.close()
        if getattr(self, "_drc_conflict_only", False):
            self._drc_conflict_clear_scope()
            if self._drc_open is not None:
                self._drc_grid_fill(self._drc_open)
            self._display()

    def _drc_conflict_status_changed(self):
        if not getattr(self, "_drc_conflict_only", False):
            return
        # Conflict votes remain the labelled snapshot; the live waive filter
        # must be resolved again after a completed local waiver batch.
        self._drc_conflict_revision = getattr(self, "_drc_conflict_revision", 0) + 1
        self._drc_conflict_reset()
        self._drc_conflict_clear_scope()

    def _drc_conflict_sync(self):
        db = self._drc
        ci = self._drc_open
        if ci is None and getattr(self, "_drc_pos", -1) >= 0 and getattr(self, "_drc_cum", ()):
            ci = bisect.bisect_right(self._drc_cum, self._drc_pos) - 1
        if db is None or ci is None:
            if (getattr(self, "_drc_conflict_job", None) is not None or
                    getattr(self, "_drc_conflict_key", None) is not None):
                self._drc_conflict_reset()
            if getattr(self, "_drc_conflict_members", None) is None:
                self._drc_conflict_members = gtkservice.EmptyScope(db, ci)
            return self._drc_conflict_members
        source = getattr(self, "_drc_conflict_source", None)
        base = self._drc_base_members()
        # Retain the source membership: a rebuilt CD group may otherwise
        # reuse a released object's id and accidentally reuse its old mask.
        key = (id(db), id(source), ci, base, self._drc_wfilter,
               getattr(self, "_drc_conflict_revision", 0))
        if key == getattr(self, "_drc_conflict_key", None):
            return self._drc_conflict_members
        self._drc_conflict_reset()
        self._drc_conflict_key = key
        self._drc_conflict_members = gtkservice.EmptyScope(db, ci)
        self._drc_conflict_clear_scope()
        if source is None:
            return self._drc_conflict_members
        cancel = threading.Event()
        job = dict(key=key, db=db, ci=ci, cancel=cancel, done=False,
                   result=None, error=None, progress=None)
        try:
            lease = source.lease()
        except Exception as exc:
            # said once: the key above keeps the next poll from asking again
            self._set_live_status("Conflict filter failed: %s" % exc)
            return self._drc_conflict_members
        self._drc_conflict_job = job
        want = None if self._drc_wfilter == "all" else self._drc_wf_class()

        def run():
            try:
                from .gtkservice import prepare_conflict_selection
                job["result"] = prepare_conflict_selection(db, lease, ci,
                    membership=base, waived=want, cancelled=cancel.is_set,
                    progress=lambda done, total, *_: job.update(progress=(done, total)))
            except Exception as exc:
                job["error"] = str(exc)
            finally:
                lease.close()
                job["done"] = True
        threading.Thread(target=run, name="drc-conflict-filter", daemon=True).start()
        return self._drc_conflict_members

    def _drc_conflict_poll(self):
        self._drc_conflict_retired_jobs()
        if not getattr(self, "_drc_conflict_only", False):
            return
        # Rule/group changes may occur while the preparation thread runs.
        self._drc_conflict_sync()
        job = getattr(self, "_drc_conflict_job", None)
        if job is None:
            return
        if not job["done"]:
            progress = job.get("progress")
            if progress is not None and progress != job.get("said"):
                # each step once: the line is the cursor's between them
                job["said"] = progress
                self._set_live_status("Conflict only: %d / %d processed" % progress)
            return
        if (job["cancel"].is_set() or job["db"] is not self._drc or
                job["key"] != self._drc_conflict_key):
            return
        self._drc_conflict_job = None
        if not job["error"]:
            self._drc_conflict_members = job["result"]
        self._drc_hl_res, self._drc_hl_key = None, None
        self._drc_marker_invalidate()
        if self._drc_open == job["ci"]:
            self._drc_grid_fill(job["ci"])
        self._display()
        # after the grid and the frame, which may write the line themselves
        if job["error"]:
            self._set_live_status("Conflict filter failed: " + job["error"])
        else:
            self._set_live_status(
                "Conflict only: %d errors in this scope · snapshot %s"
                % (len(job["result"]),
                   getattr(self, "_drc_conflict_stamp", "") or "not loaded"))

    def _drc_base_members(self):
        """A delta group already intersects the selected file cluster."""
        group = getattr(self, "_drc_delta_group", None)
        return group if group is not None else self._drc_cluster

    def _drc_migration_dialog(self):
        if self._load_refused("review from previous run"):
            # the window is two paths to read and nothing else
            return None
        db = getattr(self, "_drc", None)
        if db is None or not hasattr(db, "review_counts"):
            self._set_live_status("review migration needs a packed index: floe-index drc <db>")
            return None
        window = getattr(self, "_drc_migration", None)
        if window is not None and (window.closed or window.db is not db):
            if not window.closed:
                window.window.destroy()
            window = None
        if window is None:
            window = _DrcMigrationWindow(self)
            self._drc_migration = window
        window.window.present()
        return window

    def _drc_waives_dialog(self):
        """DRC > team waives…: every reviewer's waives, and their
        confirmation (_DrcWaivesWindow)."""
        db = getattr(self, "_drc", None)
        if db is None or not hasattr(db, "waive_ask"):
            self._set_live_status("the team's waives need a packed index: floe-index drc <db>")
            return None
        window = getattr(self, "_drc_waives_win", None)
        if window is not None and (window.closed or window.db is not db):
            if not window.closed:
                window.window.destroy()
            window = None
        if window is None:
            window = _DrcWaivesWindow(self)
            self._drc_waives_win = window
        window.window.present()
        return window

    def _drc_team_waives_changed(self, db):
        """This viewer confirmed waives, or took a confirmation back: the
        detail of the error shown says who confirmed it."""
        if self._drc is not db or self._drcwin is None:
            return
        if self.drc_mark is not None and self._drc_pos >= 0 and self._drc_cum:
            mci = bisect.bisect_right(self._drc_cum, self._drc_pos) - 1
            self._drc_show_detail(mci, self._drc_pos - self._drc_cum[mci])

    def _drc_team_lines(self, db, ci, ei):
        """The error detail's lines of the team's review - who else has the
        error waived, who confirmed its waive - as the last answer said them
        for this error, and the service asked anew: reading every reviewer's
        files lists folders, and a selection must not wait for that (8 ms of
        a temp folder of 19,000 names lost a frame of the view). The answer
        shows the detail again when its lines are other ones
        (_drc_team_poll)."""
        known = self._drc_team_row
        lines = (list(known[3]) if known is not None and known[0] is db
                 and known[1:3] == (ci, ei) else [])
        self._drc_team_shown = (db, ci, ei, tuple(lines))
        if not self._drc_team_quiet:
            try:
                db.waive_ask(ci, ei)
            except (OSError, gtkservice.ServiceError):
                return lines
            self._drc_team_pending = (db, ci, ei)
            if self._drc_team_timer is None:
                self._drc_team_timer = GLib.timeout_add(POLL_MS, self._drc_team_poll)
        return lines

    def _drc_team_poll(self):
        """The answer to the detail's ask (GLib timer): its lines are kept
        for the error, and the detail shown again when it is still that
        error's and the lines are new."""
        pending = self._drc_team_pending
        if pending is None or pending[0] is not self._drc:
            self._drc_team_pending = self._drc_team_timer = None
            return False
        db, ci, ei = pending
        try:
            answer = db.waive_answer()
        except (OSError, gtkservice.ServiceError):
            answer = False
        if answer is None:
            return True
        self._drc_team_pending = self._drc_team_timer = None
        lines = tuple(self._drc_team_text(answer)) if answer else ()
        self._drc_team_row = (db, ci, ei, lines)
        shown = self._drc_team_shown
        if (self._drc_detail_of == (ci, ei) and shown is not None and shown[0] is db
                and shown[1:3] == (ci, ei) and shown[3] != lines):
            self._drc_team_quiet = True
            try:
                self._drc_show_detail(ci, ei)
            finally:
                self._drc_team_quiet = False
        return False

    @staticmethod
    def _drc_past_lines(past):
        """What was before a waive was waived again, of (what, who, text)
        events in the order they happened: `waived (reason)`, `rejected by
        hong (why)` - and before a request was asked again: `requested
        (reason)`, `declined by kim (why)`."""
        lines = []
        for what, who, text in past:
            if what in ("rejected", "declined"):
                lines.append("%s by %s%s" % (what, who, " (%s)" % text if text else ""))
            elif text:
                lines.append("%s (%s)" % ("requested" if what == "requested" else "waived", text))
        return lines

    @classmethod
    def _drc_past_text(cls, history, named):
        """A team row's history on one line: its reviewers' events one
        after the other, each reviewer named when there is more than one
        (`named`)."""
        parts, last = [], None
        for event in history:
            line = cls._drc_past_lines(
                [(event.get("what"), event.get("by") or "", event.get("text") or "")])
            if not line:
                continue
            who = event.get("reviewer") or ""
            parts.append("%s: %s" % (who, line[0]) if named and who != last else line[0])
            last = who
        return "before: " + ", then ".join(parts) if parts else ""

    @classmethod
    def _drc_team_text(cls, team):
        """An answer's lines: who else has the error waived (with why, where
        they said), who confirmed its waive, who rejected it - and what was
        before a waive of another reviewer's was waived again. None for an
        error nobody else waived, nobody confirmed and nobody rejected."""
        waived = team.get("waived_by") or []
        gone = set(team.get("rejected_of") or ())
        why = {w["reviewer"]: w["text"] for w in team.get("reasons") or []}
        me = team.get("reviewer")
        others = [name for name in waived if name != me]
        lines = []
        if team.get("requested_by"):
            # (a role's workflow: who asked for the waive, and why - and
            # whose request of it a waiver declined)
            shut = set(team.get("declined_of") or ())
            lines.append("waive requested by: %s" % ", ".join(
                "%s%s%s" % (w["reviewer"], " (%s)" % w["text"] if w.get("text") else "",
                            " · declined" if w["reviewer"] in shut else "")
                for w in team["requested_by"]))
        if team.get("declined_by"):
            # (declined: the request is none until its requester asks again
            # with a reason, or the waiver takes the decline back)
            lines.append("request declined by: %s" % ", ".join(
                "%s (%s)" % (w["reviewer"], w["text"]) if w.get("text") else w["reviewer"]
                for w in team["declined_by"]))
        if others:
            lines.append("waived by: %s" % ", ".join(
                "%s%s%s" % (name, " (%s)" % why[name] if why.get(name) else "",
                            " · rejected" if name in gone else "")
                for name in others))
        if team.get("rejected_by"):
            # (rejected: the waive is none until its reviewer waives the
            # error again with a reason, or the confirmer takes it back)
            lines.append("waive rejected by: %s" % ", ".join(
                "%s (%s)" % (w["reviewer"], w["text"]) if w.get("text") else w["reviewer"]
                for w in team["rejected_by"]))
        if team.get("confirmed_by") and any(name not in gone for name in waived):
            # (confirmed is locked: its reviewer's session leaves it waived
            # - a waive that is rejected is not)
            lines.append("waive confirmed by: %s%s" % (
                ", ".join(team["confirmed_by"]),
                " · locked" if me not in gone else ""))
        theirs = [e for e in team.get("history") or () if e.get("reviewer") != me]
        past = cls._drc_past_text(theirs, True)
        if past:
            lines.append(past)
        return lines

    def _drc_team_dialog(self):
        db = getattr(self, "_drc", None)
        if db is None or not hasattr(db, "review_counts"):
            self._set_live_status("review sharing needs a packed index: floe-index drc <db>")
            return None
        window = getattr(self, "_drc_team", None)
        if window is not None and (window.closed or window.db is not db):
            if not window.closed:
                window.window.destroy()
            window = None
        if window is None:
            window = _DrcTeamWindow(self)
            self._drc_team = window
        window.window.present()
        return window

    def _drc_team_changed(self, db, waived=True):
        """Publish completed peer edits without switching the marker source."""
        if self._drc is not db:
            return
        ci = self._drc_open
        jump = None
        if (not getattr(self, "_drc_conflict_only", False) and
                self.drc_mark is not None and self._drc_pos >= 0):
            jump = (self.drc_mark, self._drc_pos, tuple(self._drc_ruler))
        if waived:
            self._drc_conflict_status_changed()
            self._drc_marker_invalidate()
            self._drc_delta_status_changed(ci)
            self._drc_hl_res = None
            if self.drc_mark is not None and self._drc_pos >= 0 and self._drc_cum:
                mci = bisect.bisect_right(self._drc_cum, self._drc_pos) - 1
                mei = self._drc_pos - self._drc_cum[mci]
                self.drc_mark["color"] = (DRC_GREEN if self._drc_waived(db, mci, mei) else DRC_RED)
            if self._drc_sel is not None and self._drc_wfilter != "all":
                self._drc_selection_restore()
            if self._drcwin is not None:
                self._drc_fill(preserve=True)
                if jump is not None:
                    # Rebuilding the rule tree clears a jump even when the
                    # peer browser owns navigation. Keep the already viewed
                    # shape/rulers without changing filters or reframing it.
                    self.drc_mark, self._drc_pos = jump[:2]
                    self._drc_focus = None
                    self._drc_ruler = list(jump[2])
                    for ruler in self._drc_ruler:
                        if ruler not in self.rulers:
                            self.rulers.append(ruler)
                    mci = bisect.bisect_right(self._drc_cum, self._drc_pos) - 1
                    self._drc_show_detail(mci, self._drc_pos - self._drc_cum[mci])
        if ci is not None:
            self._drc_review_flags_refresh(ci)
        self._display()

    def _drc_review_pending(self):
        if getattr(self, "_drc_selection_key", None) is not None:
            self._set_live_status("error selection is still being updated")
            return True
        if getattr(self, "_drc_review_job", None) is not None:
            self._set_live_status("review update is still running")
            return True
        if getattr(self, "_drc_team_busy", None) is not None:
            self._set_live_status("review sharing operation is still running")
            return True
        if getattr(self, "_drc_verdict_job", None) is not None:
            self._set_live_status("review update is still running")
            return True
        return False

    def _drc_review_submit(self, operation, ci, targets, on=None, text=None,
                           reason=None, kind=None, toggle=False, then=None):
        """One review writer (the service's review job); the request keeps
        its database and targets - a selection of any size. `reason`: why
        the targets are waived or set aside. `reason-read` writes nothing:
        it reads what the reason dialog of a `kind` action starts from, and
        `then` goes on from the dialog (_drc_reason_reply)."""
        if self._drc_review_pending():
            return
        db = self._drc
        if not targets:
            return
        if operation not in ("not-required", "reason-read"):
            self._drc_marker_invalidate()
        fields = dict(check=int(ci), action=operation, on=on, text=text)
        if reason:
            fields["reason"] = reason
        if operation == "reason-read":
            fields.update(reason_of=kind, toggle=bool(toggle))
        if getattr(targets, "sid", None) is not None:
            fields["selection"] = targets.sid
        else:
            fields["errors"] = [int(e) for e in targets]
        try:
            db._start("review", "drc_review", **fields)
        except gtkservice.ServiceError as exc:
            self._set_live_status("%s failed: %s" % (operation, exc))
            return
        self._drc_review_job = dict(db=db, ci=ci, targets=targets,
                                    operation=operation, on=on, reason=reason,
                                    kind=kind, then=then)
        self._set_live_status("%s: processing %d selected errors…"
                              % (kind if operation == "reason-read"
                                 else operation, len(targets)))

    def _drc_review_poll(self):
        self._drc_visit_poll()
        job = getattr(self, "_drc_review_job", None)
        if job is None:
            return
        event = job["db"].poll("review")
        if event is None:
            return
        if event["state"] == "progress":
            self._set_live_status("%s: %d / %d processed"
                                  % (job["operation"], event["done"], event["total"]))
            return
        self._drc_review_job = None
        error = event.get("message") if event["state"] != "done" else None
        if self._drc is not job["db"]:
            if error:
                self._set_live_status("previous DRC review update failed: %s" % error)
            return
        ci, targets, operation = job["ci"], job["targets"], job["operation"]
        db = self._drc
        if operation == "reason-read":
            # nothing was written: the dialog, then what it was asked for
            if error:
                self._set_live_status("%s failed: %s" % (job["kind"], error))
            else:
                self._drc_reason_reply(job["kind"], ci, targets, event,
                                       job["then"])
        elif operation == "not-required":
            # a failed batch may have committed earlier chunks: show the
            # flags as they are, markers, groups and selection untouched
            db.review_flags_changed(ci)
            self._drc_review_flags_refresh(ci)
            on = event.get("on", job["on"])
            self._set_live_status(("review update failed: %s" % error)
                if error else "%s on %d errors%s" % (
                    "not for review set" if on else "not for review cleared",
                    len(targets),
                    self._drc_reason_said(job.get("reason") if on else None,
                                          event.get("reason_error"))))
            focus = self._drc_focus
            if focus is not None and focus[0] == ci and not error:
                self._drc_show_detail(ci, focus[1])
        elif operation == "waive":
            db.statuses_changed(ci, event.get("counts"))
            if self._drc_clusters is not None:
                self._drc_clusters.status_changed(ci)
            self._drc_waived_refresh(ci, targets, event.get("on", job["on"]),
                                     error, bulk=True, reason=job.get("reason"),
                                     unkept=event.get("reason_error"),
                                     locked=(event.get("locked") or 0,
                                             tuple(event.get("locked_by") or ())),
                                     rejected=(event.get("rejected") or 0,
                                               gtkservice._rejecters(event.get("rejected_by"))),
                                     again=int(event.get("resubmitted") or 0),
                                     **dict(
                                         ({"unrequested": int(event["unrequested"])}
                                          if event.get("unrequested") else {}),
                                         **dict(({"past": int(event["waived"])}
                                                 if event.get("waived") else {}),
                                                **({"doubled": int(event["requested"])}
                                                   if event.get("requested") else {}))))
        elif error:
            if operation in ("note", "note-clear"):
                self._drc_note_refresh(ci, targets, fallback=False)
            self._set_live_status("%s failed: %s" % (operation, error))
        elif operation == "note-read":
            prefill = event.get("prefill") or ""
            text = self._drc_note_dialog(prefill, len(targets))
            if text is not None and not (prefill and text == prefill):
                self._drc_review_submit("note", ci, targets, text=text)
        else:
            db._notes_reply(event)
            self._drc_note_refresh(ci, targets, fallback=False)
            self._set_live_status("%s: %d errors updated" % (operation, len(targets)))

    @staticmethod
    def _drc_reason_said(reason, unkept=None):
        """The end of a status line after a waive or an exclusion: the
        reason it was given, or that the reason could not be kept (the
        errors are waived or set aside all the same)."""
        if unkept:
            return " · reason not saved: %s" % unkept
        if not reason:
            return ""
        return " · reason: %s" % (reason if len(reason) <= 60
                                  else reason[:59] + "…")

    @staticmethod
    def _drc_locked_said(locked, on):
        """The end of a status line when a waive action left confirmed
        waives as they were (0.12.467, user 2026-11-13: "confirm된 waive는
        되돌릴 수 없게 잠구고 confirmer만 되돌릴 수 있게 해줘"): `locked` is
        (how many, who confirmed them). Turning back says who to ask;
        waiving again with a reason says the reason they had stays."""
        count, by = locked or (0, ())
        if not count:
            return ""
        who = " by %s" % ", ".join(by) if by else ""
        if on:
            return " · %d locked: confirmed%s, reason unchanged" % (count, who)
        return (" · %d locked: confirmed%s - only a confirmer turns them back"
                % (count, who))

    @staticmethod
    def _drc_rejecters_text(by):
        """Who rejected and why, of ((who, why), ...): `hong (why), park`."""
        return ", ".join("%s (%s)" % (who, why) if why else who for who, why in by)

    @classmethod
    def _drc_rejected_said(cls, rejected):
        """The end of a status line when a waive left errors unwaived
        because a confirmer has rejected their waive and the waive gave no
        reason (0.12.468, user 2026-11-14: "confirmer가 다른 리뷰어의
        waive를 반려할 수 있게 해줘"; 0.12.469: "리뷰어가 사유를 수정해서
        다시 waive를 할 수 있게"): `rejected` is (how many, ((who, why),
        ...))."""
        count, by = rejected or (0, ())
        if not count:
            return ""
        who = " by %s" % cls._drc_rejecters_text(by) if by else ""
        return " · %d rejected%s: waive again with a reason" % (count, who)

    def _drc_waived_refresh(self, ci, eis, on, error=None, bulk=False,
                            reason=None, unkept=None, locked=None,
                            rejected=None, said=None, again=0, unrequested=0,
                            past=0, doubled=0):
        db = self._drc
        self._drc_conflict_status_changed()
        self._drc_marker_invalidate()
        self._drc_hl_res = None
        if self._drc_clusters is not None:
            self._drc_clusters.status_changed(ci)
            self._drc_clusters.prepare_counts(ci)
        self._drc_delta_status_changed(ci, None if bulk else eis)
        # the jump mark stores a RESOLVED color: re-derive it for
        # the marked error or a toggle leaves the old status color
        if self.drc_mark is not None and self._drc_pos >= 0 and self._drc_cum:
            mci = bisect.bisect_right(self._drc_cum, self._drc_pos) - 1
            mei = self._drc_pos - self._drc_cum[mci]
            self.drc_mark["color"] = (DRC_GREEN if self._drc_waived(db, mci, mei)
                                      else DRC_RED)
        # under a waive filter the toggled errors leave the list -
        # the selection is rechecked against it (user report 2026-08-15)
        sel = self._drc_sel
        if sel is not None and sel[0] == ci and self._drc_wfilter != "all":
            self._drc_selection_restore()
            focus = self._drc_focus
            if focus is not None and focus[0] == ci and \
                    not self._drc_wf_shows(db, ci, focus[1]):
                self._drc_focus = None
        if self._drcwin is not None:
            if self._drc_wfilter == "all":
                # membership is unchanged but the row's total/waived
                # text is not: refresh that row (and its clusters) in place
                for row in self._drcwin._rstore:
                    if row[2] == ci:
                        waived = db.status_counts(ci)[0] if hasattr(db, "status_counts") else 0
                        row[1] = "%d/%d" % (len(db.checks[ci].errors), waived)
                        for child in row.iterchildren():
                            cw, ct = child[3].status_counts()
                            child[1] = "%d/%d" % (ct, cw)
                        break
                self._drc_grid_fill(ci)
            else:
                # counts and membership changed under a waive filter:
                # rebuild the rule list and reselect the open rule
                self._drc_fill(preserve=True)
        focus = self._drc_focus
        if focus is not None and focus[0] == ci:
            self._drc_show_detail(ci, focus[1])
        # (a confirmed waive is not turned back here, nor its reason
        # changed: said, with who confirmed it)
        kept, by = locked or (0, ())
        refused, rejecters = rejected or (0, ())
        # (a role's session: a requester's marks are requests, and a
        # waiver waives the errors somebody asked the waive of)
        asking = getattr(db, "marks", "waive") == "request"
        if said is not None:
            # (the caller's own word - or none: what is there stays)
            text = said
        elif error:
            text = "%s failed: %s" % ("request" if asking else "waive", error)
        elif asking and on and refused and refused >= len(eis):
            # every target is a request a waiver declined, and no reason
            # was given: nothing was asked again
            text = "declined: %d request(s) in %s%s - ask again with a reason" % (
                refused, db.checks[ci].name,
                " by %s" % self._drc_rejecters_text(rejecters) if rejecters else "")
        elif on and unrequested and unrequested >= len(eis):
            # nobody asked for the waive of any target: nothing was waived
            text = ("not requested: %d error(s) in %s - a waiver waives the "
                    "errors somebody asked the waive of" % (
                        unrequested, db.checks[ci].name))
        elif on and past + doubled and past + doubled >= len(eis):
            # a mark of every target would only double what the error has
            # (`past`: somebody has it waived, `doubled`: somebody else asks
            # its waive): nothing was asked, nothing waived again
            # (0.12.506, 0.12.507)
            name = db.checks[ci].name
            if past and doubled:
                text = "not asked: %d error(s) in %s - %d waived already, %d requested already" % (
                    past + doubled, name, past, doubled)
            elif doubled:
                text = ("requested already: %d error(s) in %s - an error somebody asks the waive of "
                        "is not asked for again" % (doubled, name))
            elif asking:
                text = ("waived already: %d error(s) in %s - no waive is asked of "
                        "an error somebody has waived" % (past, name))
            else:
                text = ("waived already: %d error(s) in %s - an error somebody has waived "
                        "is not waived again" % (past, name))
        elif asking and kept and kept >= len(eis):
            # every target is a request somebody has waived: it stays
            text = "locked: %d request(s) in %s waived%s - not taken back while waived" % (
                kept, db.checks[ci].name, " by %s" % ", ".join(by) if by else "")
        elif asking:
            # (`again`: the declined requests among them, asked again -
            # what was is kept, and they wait for a waiver anew)
            text = "%s %d error(s) in %s%s%s%s%s%s%s" % (
                "waive requested for" if on else "request taken back for",
                len(eis) - (refused + past + doubled if on else kept), db.checks[ci].name,
                self._drc_reason_said(reason if on else None, unkept),
                " · %d asked again after a decline" % again if on and again else "",
                " · %d locked: waived%s" % (kept, " by %s" % ", ".join(by) if by else "")
                if kept and not on else "",
                " · %d declined%s: ask again with a reason" % (
                    refused, " by %s" % self._drc_rejecters_text(rejecters) if rejecters else "")
                if on and refused else "",
                " · %d waived already" % past if on and past else "",
                " · %d requested already" % doubled if on and doubled else "")
        elif on and refused and refused >= len(eis):
            # every target is under a rejection, and no reason was given:
            # nothing was waived
            text = "rejected: %d error(s) in %s%s - waive again with a reason" % (
                refused, db.checks[ci].name,
                " by %s" % self._drc_rejecters_text(rejecters) if rejecters else "")
        elif kept and kept >= len(eis):
            # every target is a confirmed waive: nothing was done
            text = "locked: %d waive(s) in %s confirmed%s - %s" % (
                kept, db.checks[ci].name,
                " by %s" % ", ".join(by) if by else "",
                "their reason stays as it is" if on
                else "only a confirmer turns them back")
        else:
            # (`again`: the rejected waives among them, waived again -
            # what was is kept, and they wait for the confirmer anew)
            text = "%s %d error(s) in %s%s%s%s%s%s%s" % (
                "waived" if on else "unwaived",
                len(eis) - refused - unrequested - past if on else len(eis) - kept, db.checks[ci].name,
                self._drc_reason_said(reason if on else None, unkept),
                " · %d waived again after a rejection" % again if on and again else "",
                self._drc_locked_said(locked, on),
                self._drc_rejected_said(rejected) if on else "",
                " · %d not requested" % unrequested if on and unrequested else "",
                " · %d waived already" % past if on and past else "")
        if text:
            self._set_live_status(text)
        self._display()

    # a role's verdicts, as the right-click menus offer them: (action, on)
    # -> the grid menu's item (its scope filled in: `#5`, `12 selected`)
    VERDICT_ITEMS = {("confirm", True): "confirm %s", ("confirm", False): "unconfirm %s",
                     ("reject", True): "reject %s…", ("reject", False): "unreject %s",
                     ("decline", True): "decline %s…", ("decline", False): "undecline %s"}
    # ... what the status line says when it is done (how many, the rule),
    # and of the errors it passed over
    VERDICT_SAID = {
        ("confirm", True): ("confirmed %d waive(s) in %s", " · %d not waived"),
        ("confirm", False): ("confirmation taken back for %d waive(s) in %s", ""),
        ("reject", True): ("rejected %d waive(s) in %s", " · %d not waived, or rejected already"),
        ("reject", False): ("rejection taken back for %d waive(s) in %s", ""),
        ("decline", True): ("declined %d request(s) in %s", " · %d with no request waiting"),
        ("decline", False): ("decline taken back for %d request(s) in %s", "")}
    VERDICT_OPS = {"confirm": "drc_team_confirm", "reject": "drc_team_reject",
                   "decline": "drc_team_decline"}

    @staticmethod
    def _drc_verdict_items(db):
        """The verdicts a session's roles have, a group a role: a
        confirmer's confirm / unconfirm / reject / unreject, a waiver's
        decline / undecline. None for a session without a role, and for
        results without a review."""
        if not hasattr(db, "waive_ask"):
            return []
        items = []
        if getattr(db, "confirmer", False):
            items.append((("confirm", True), ("confirm", False),
                          ("reject", True), ("reject", False)))
        if getattr(db, "waiver", False):
            items.append((("decline", True), ("decline", False)))
        return items

    def _drc_verdict_may(self, db, action):
        """Whether this session's roles have `action`; said when not."""
        role = "waiver" if action == "decline" else "confirmer"
        if getattr(db, role, False):
            return True
        self._set_live_status(
            "%s failed: %s is for a viewer started with the %s's role (floe2 view --role %s)"
            % (action, "declining" if action == "decline" else
               "confirming" if action == "confirm" else "rejecting", role, role))
        return False

    def _drc_verdict(self, ci, targets, action, on, reason=None):
        """A role's verdict on rule `ci`'s `targets` - a few errors, or a
        selection of any size the service keeps -, from a right-click menu
        (0.12.474; user 2026-11-14: "confirmer의 경우 오른쪽 버튼 메뉴에 confirm
        관련을 넣는게 좋을 것 같음"): a confirmer confirms the waives, takes
        the confirmation back, rejects them (asking why first - `reason`
        None is not asked yet, a text is the answer) or takes the rejection
        back; a waiver declines the requests or takes the decline back.
        One job of the service's whatever the size, and one line of the
        log for a rejection or a decline. The verdict is of the targets it
        applies to - a confirmation of the ones somebody has waived -, and
        the others are said."""
        db = self._drc
        if db is None or not targets or not self._drc_verdict_may(db, action):
            return
        if self._drc_review_pending():
            return
        if action != "confirm" and on and reason is None:
            self._drc_reason_then(
                action, ci, targets, lambda _on, text, d=db:
                self._drc_verdict(ci, targets, action, True, reason=text)
                if self._drc is d else None)
            return
        fields = dict(check=int(ci), on=bool(on))
        if getattr(targets, "sid", None) is not None:
            fields["selection"] = targets.sid
        else:
            fields["errors"] = [int(e) for e in targets]
        if reason and on:
            fields["reason"] = reason
        word = self.VERDICT_ITEMS[(action, bool(on))].split(" ")[0]
        try:
            db._start("confirm", self.VERDICT_OPS[action], **fields)
        except (OSError, gtkservice.ServiceError) as exc:
            self._set_live_status("%s failed: %s" % (word, exc))
            return
        self._drc_verdict_job = dict(db=db, ci=ci, action=action, on=bool(on),
                                     reason=reason, word=word, targets=targets)
        self._set_live_status("%s: processing %d error(s)…" % (word, len(targets)))

    def _drc_verdict_poll(self):
        """The answer to a verdict (the viewer's poll): the states are
        others - the lists, the counts, the markers and the detail follow at
        once - and the status line says what was done."""
        job = getattr(self, "_drc_verdict_job", None)
        if job is None:
            return
        event = job["db"].poll("confirm")
        if event is None:
            return
        if event["state"] == "progress":
            self._set_live_status("%s: %d / %d processed" % (
                job["word"], event.get("done", 0), event.get("total", 0)))
            return
        self._drc_verdict_job = None
        db, ci = job["db"], job["ci"]
        if self._drc is not db:
            return
        error = event.get("message") if event["state"] != "done" else None
        changed, skipped = int(event.get("changed") or 0), int(event.get("skipped") or 0)
        if error:
            text = "%s failed: %s" % (job["word"], error)
            if changed:
                text += " · %d done before it" % changed
        else:
            done, passed = self.VERDICT_SAID[(job["action"], job["on"])]
            text = done % (changed, db.checks[ci].name)
            if job["on"]:
                text += self._drc_reason_said(job.get("reason"))
            if skipped and passed:
                text += passed % skipped
        # (what the service wrote stays whatever became of the job: the
        # states read so far are dropped, and the rule's count is the
        # answer's)
        db.statuses_changed(ci, event.get("counts"))
        self._drc_waived_refresh(ci, (), False, bulk=True, said=text)
        if getattr(self, "_drc_selection_key", None) is not None:
            # (the selection is being rechecked against the filter's list:
            # its answer leaves this line)
            self._drc_selection_after = text
        self._drc_team_waives_changed(db)

    def _drc_own_statuses_changed(self, db, ci, counts):
        """The service changed this reviewer's own statuses of rule `ci`
        beside an action of another kind (a confirmer's rejection turns
        their own waive of the error back): the lists, the markers and the
        counts follow; the status line is the action's."""
        if self._drc is not db or counts is None:
            return
        db.statuses_changed(ci, counts)
        self._drc_waived_refresh(ci, (), False, bulk=True, said="")

    def _drc_states_changed(self):
        """What the confirmers say of this reviewer's waives changed, and
        no rule's waives with it (a confirmation made or taken back): the
        states shown are read again - a filter of the confirmed or the
        not yet confirmed lists other errors, the rest keeps its lists."""
        if self._drcwin is not None:
            if self._drc_wfilter in ("waived", "confirmed"):
                self._drc_fill(preserve=True)
            elif self._drc_open is not None:
                self._drc_grid_fill(self._drc_open)
        focus = self._drc_focus
        if focus is not None:
            self._drc_show_detail(focus[0], focus[1])
        self._display()

    # ---- the waives a confirmer rejected (0.12.468) -----------------------
    def _drc_returned_start(self):
        """Results are open: the review follows the confirmers from now -
        which of this reviewer's waives are rejected, who confirmed what -
        at once and every RETURNED_MS from here on (app-core
        desktop::Review look, the service's job `returned`). Nothing of
        the reviewer's is written by it: a rejected waive stays, rejected,
        until they waive the error again with a reason or turn it back."""
        if self._drc_returned_timer is None:
            self._drc_returned_timer = GLib.timeout_add(
                self.RETURNED_MS, self._drc_returned_tick)
        self._drc_returned_look()

    def _drc_returned_tick(self):
        """The timer's look: it goes on while results with a review of
        this reviewer's own are open."""
        if self._drc_returned_look():
            return True
        self._drc_returned_timer = None
        return False

    def _drc_returned_look(self):
        """Ask the service once; False when there is no review to ask
        about (no results, an ASCII file, a pack shown read-only)."""
        db = self._drc
        if (db is None or not hasattr(db, "returned_ask")
                or getattr(db, "read_only", False)):
            return False
        if self._drc_returned_asked is not None:
            self._drc_returned_poll()
            return True
        if (getattr(self, "_drc_review_job", None) is not None
                or getattr(self, "_drc_team_busy", None) is not None
                or getattr(self, "_drc_verdict_job", None) is not None):
            return True     # a write of this viewer's own runs: the next tick
        try:
            db.returned_ask()
        except (OSError, gtkservice.ServiceError):
            return True
        self._drc_returned_asked = db
        GLib.timeout_add(POLL_MS, self._drc_returned_poll)
        return True

    def _drc_returned_poll(self):
        """The answer to the look (GLib timer): the waives found rejected
        are shown as rejected and said, with who rejected them and why;
        states that changed without that are read again."""
        db = self._drc_returned_asked
        if db is None:
            return False
        if db is not self._drc:
            self._drc_returned_asked = None
            return False
        try:
            answer = db.returned_answer()
        except (OSError, gtkservice.ServiceError):
            answer = False
        if answer is None:
            return True
        self._drc_returned_asked = None
        if answer and (answer.get("returned") or answer.get("changed")):
            self._drc_returned_show(db, answer.get("returned") or [], answer)
        return False

    def _drc_returned_show(self, db, rows, answer):
        said = ""
        if rows:
            total = sum(int(r["count"]) for r in rows)
            by = []
            for r in rows:
                for who in gtkservice._rejecters(r.get("by")):
                    if who not in by:
                        by.append(who)
            where = (db.checks[rows[0]["check"]].name if len(rows) == 1
                     else "%d rules" % len(rows))
            # (a requester's session: its requests a waiver declined)
            asking = getattr(db, "marks", "waive") == "request"
            said = "%d %s in %s %s%s: %s again with a reason" % (
                total, "request(s)" if asking else "waive(s)", where,
                "declined" if asking else "rejected",
                " by %s" % self._drc_rejecters_text(by) if by else "",
                "ask" if asking else "waive")
        # (the service's answer dropped the states read so far and brought
        # the counts: PackDrc.returned_answer)
        rules = sorted(set(int(r["check"]) for r in rows)
                       | set(int(ci) for ci in answer.get("rules") or ()))
        if not rules:
            self._drc_states_changed()
            return
        for ci in rules[:-1]:
            self._drc_waived_refresh(ci, (), False, bulk=True, said="")
        self._drc_waived_refresh(rules[-1], (), False, bulk=True, said=said)

    def _drc_waive_key(self):
        """w (user calls 2026-08-20/22): with a gold SELECTION,
        toggle the selected errors as ONE batch - all waived means
        unwaive all, anything else means waive all (a mixed set
        resolves to waived, so w-w round-trips). Without a
        selection, toggle the CURRENT error - the single-clicked/
        stepped focus first, else the jump position (_drc_focus is
        None while a jump mark is live, and _drc_pos survives the
        Esc restore, so the error still shown in the detail pane
        stays toggleable)."""
        db = self._drc
        if db is None:
            return
        if not hasattr(db, "set_status"):
            self._set_live_status(
                "waive needs a packed index: "
                "floe-index drc <db>")
            return
        sel = self._drc_sel
        if sel is not None and sel[1]:
            ci, eis = sel[0], sel[1]
            if len(eis) > DRC_PAGE and getattr(db, "read_only", False):
                self._drc_review_submit("waive", ci, eis)
            elif len(eis) > DRC_PAGE:
                # which way the toggle goes is the service's to say (a
                # selection that is not waived whole is waived): waiving
                # asks why first, turning back asks nothing
                if not self._drc_review_pending():
                    self._drc_reason_then(
                        "waive", ci, eis, lambda on, text, d=db:
                        self._drc_set_waived(ci, eis, on, reason=text)
                        if self._drc is d else None, toggle=True)
            else:
                on = not all(self._drc_marked(db, ci, e) for e in eis)
                self._drc_set_waived(ci, eis, on)
            return
        ci = ei = None
        f = self._drc_focus
        if f is not None:
            ci, ei = f[0], f[1]
        elif self._drc_pos >= 0 and self._drc_cum:
            ci = bisect.bisect_right(self._drc_cum,
                                     self._drc_pos) - 1
            ei = self._drc_pos - self._drc_cum[ci]
        if ci is None or ei >= len(db.checks[ci].errors):
            self._set_live_status(
                "w toggles the selected/current error: select, "
                "click or jump one first")
            return
        self._drc_set_waived(ci, [ei],
                             not self._drc_marked(db, ci, ei))

    def _drc_current_target(self):
        """(ci, [ei,...]) for the gold selection, else the current or
        jumped error, else None - the target of note/waive actions."""
        sel = self._drc_sel
        if sel is not None and sel[1]:
            return sel[0], sel[1]
        db = self._drc
        ci = ei = None
        f = self._drc_focus
        if f is not None:
            ci, ei = f[0], f[1]
        elif self._drc_pos >= 0 and self._drc_cum:
            ci = bisect.bisect_right(self._drc_cum, self._drc_pos) - 1
            ei = self._drc_pos - self._drc_cum[ci]
        if ci is None or db is None \
                or ei >= len(db.checks[ci].errors):
            return None
        return ci, [ei]

    REASON_TITLES = {"waive": "Waive reason",
                     "not-required": "Not for review reason",
                     "reject": "Reject reason",
                     "decline": "Decline reason"}

    def _drc_reason_dialog(self, kind, count, prefill="", known=(),
                           parent=None, rejected_by=(), requested_by=(),
                           title=None, declined=False):
        """Why the errors are waived, or set aside from the review (user
        call 2026-11-13: "waive와 not for waive 처리할 때 사유를 입력할 수
        있게 입력창이 뜨도록"): a small modal with one line. Enter or OK
        takes it, Esc or Cancel leaves the errors as they were. The reason
        is the action's - kept once however many errors the action takes
        (app-core drc::reasons), where a note is kept an error at a time.
        The line starts from `prefill` - the reason the errors hold
        already, else the one typed last -, selected, so typing replaces
        it and Enter keeps it; its list offers the reasons given before
        (`known`, the latest first); the built-in hangul composer is the
        note editor's. `rejected_by` - ((who, why), ...) - are the
        rejections the waive answers: said above the line, which starts
        from the reason the rejected waive has, to be mended (user
        2026-11-14: "리뷰어가 사유를 수정해서 다시 waive를 할 수 있게"); an
        empty reason leaves those errors rejected. Returns the text ("" =
        no reason), None when cancelled."""
        # (`title`: a requester's waive is a request; `requested_by`: who
        # asked for the waive a waiver is about to make - said above the
        # line; `declined`: the verdicts answered are a waiver's declines
        # of this requester's requests, not rejections of a waive)
        title = title or self.REASON_TITLES[kind]
        if count > 1:
            title += "  (%d errors)" % count
        dlg = Gtk.Dialog(title=title, transient_for=parent or self.window,
                         modal=True)
        dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dlg.add_button("OK", Gtk.ResponseType.OK)
        dlg.set_default_response(Gtk.ResponseType.OK)
        dlg.set_resizable(False)
        self._center_on_parent(dlg)
        if known:
            line = Gtk.ComboBoxText.new_with_entry()
            for text in known:
                line.append_text(text)
            entry = line.get_child()
        else:
            line = entry = Gtk.Entry()
        entry.set_width_chars(46)
        entry.set_max_length(1000)
        entry.set_activates_default(True)
        entry.set_text(prefill or "")
        # (named for the gates, which type in the entry)
        entry.set_name("drc-reason")
        # built-in hangul input for hosts with no IME (the note editor's)
        hangul = Gtk.CheckButton(label="Hangul (Shift+Space)")
        editable = EntryEditable(entry)
        state = {"composer": HangulComposer(), "check": hangul,
                 "anchor": None}
        hangul.connect("toggled", lambda *a: state["composer"].reset())

        def on_key(_w, ev):
            if Gdk.keyval_name(ev.keyval) == "Escape":
                dlg.response(Gtk.ResponseType.CANCEL)
                return True
            return self._note_entry_key(editable, ev, state)
        entry.connect("key-press-event", on_key)
        hint = Gtk.Label()
        hint.set_markup("<small>Enter: OK · Esc: cancel · "
                        "Shift+Space: 한글 · empty: %s</small>" % (
                            "the declined stay declined" if rejected_by and declined
                            else "the rejected stay rejected" if rejected_by
                            else "no reason"))
        hint.set_halign(Gtk.Align.START)
        box = dlg.get_content_area()
        box.set_border_width(10)
        box.set_spacing(6)
        if rejected_by:
            said = Gtk.Label(label="%s by %s%s\nA reason %s %s again." % (
                "Declined" if declined else "Rejected",
                self._drc_rejecters_text(rejected_by[:3]),
                ", …" if len(rejected_by) > 3 else "",
                "asks for" if declined else "waives",
                "it" if count == 1 else "them"))
            said.set_halign(Gtk.Align.START)
            said.set_line_wrap(True)
            said.set_max_width_chars(60)
            # (named for the gates, which read it)
            said.set_name("drc-reason-rejected")
            box.pack_start(said, False, False, 0)
        if requested_by:
            asked = Gtk.Label(label="Requested by %s%s" % (
                ", ".join(requested_by[:5]), ", …" if len(requested_by) > 5 else ""))
            asked.set_halign(Gtk.Align.START)
            asked.set_line_wrap(True)
            asked.set_max_width_chars(60)
            asked.set_name("drc-reason-requested")
            box.pack_start(asked, False, False, 0)
        box.pack_start(line, False, False, 0)
        box.pack_start(hangul, False, False, 0)
        box.pack_start(hint, False, False, 0)
        self._grab_focus_once(dlg, entry)
        dlg.show_all()
        ok = dlg.run() == Gtk.ResponseType.OK
        text = entry.get_text().strip()
        dlg.destroy()
        (parent or self.window).present()
        return text if ok else None

    def _drc_reason_then(self, kind, ci, targets, done, toggle=False):
        """Ask why before `targets` are waived or set aside from the
        review (`kind`: "waive", "not-required"), then `done(on, text)`:
        `on` - the way a `w` toggle goes (`toggle`; True for a command that
        is no toggle; a toggle that turns the errors back asks nothing) -,
        `text` - the reason typed, "" for none. A cancelled dialog does
        nothing. What the dialog starts from is the service's to read: at
        once for a few errors, as a review job for a selection of any
        size."""
        db = self._drc
        if self._drc_review_pending():
            return
        if getattr(targets, "sid", None) is not None or len(targets) > DRC_PAGE:
            self._drc_review_submit("reason-read", ci, targets, kind=kind,
                                    toggle=toggle, then=done)
            return
        try:
            reply = db.reason_read(ci, list(targets), kind, toggle)
        except (OSError, gtkservice.ServiceError) as exc:
            self._set_live_status("%s failed: %s" % (kind, exc))
            return
        self._drc_reason_reply(kind, ci, targets, reply, done)

    def _drc_reason_reply(self, kind, ci, targets, reply, done):
        """The second half of _drc_reason_then: the dialog, then `done`."""
        db = self._drc
        if not reply.get("on", True):
            done(False, "")
            return
        if reply.get("nothing"):
            # (a mark of every one of them would only double what the error
            # has - somebody has it waived, or asks for it already: nothing
            # will be marked, so no reason is asked for, and the write says
            # what it left. 0.12.506 for a requester's of waived errors,
            # 0.12.507 for every doubled mark - the `w` key's way to one)
            done(True, "")
            return
        # (a waive of errors under a rejection: the dialog says whose, and
        # starts from the reason the rejected waive has)
        rejecters = gtkservice._rejecters(reply.get("rejected_by"))
        # (a role's session: a requester's waive is a request - the dialog
        # says so; a waiver's answers one - it says who asked)
        asking = kind == "waive" and bool(reply.get("request"))
        more = {}
        if asking:
            more["title"] = "Request reason"
            if rejecters:
                # (the verdicts a request answers are declines)
                more["declined"] = True
        if reply.get("requested_by"):
            more["requested_by"] = tuple(reply["requested_by"])
        text = self._drc_reason_dialog(
            kind, len(targets),
            reply.get("prefill") or ("" if rejecters else self._drc_reason_last.get(kind, "")),
            reply.get("known") or (), rejected_by=rejecters, **more)
        if self._drc is not db:
            return      # other results came in under the dialog
        if text is None:
            self._set_live_status(
                "%s cancelled: %d error(s) left as they were"
                % ("request" if asking else
                   {"waive": "waive", "reject": "reject", "decline": "decline"}.get(
                       kind, "not for review"),
                   len(targets)))
            return
        self._drc_reason_last[kind] = text
        done(True, text)

    def _drc_note_key(self):
        """n: add/edit a note SHARED by the selected errors (or the
        current/jumped one); empty text clears it. Notes autosave to
        a per-reviewer flateyes .fe sidecar beside the pack."""
        db = self._drc
        if db is None:
            return
        if not hasattr(db, "set_note"):
            self._set_live_status(
                "note needs a packed index: floe-index drc <db>")
            return
        if self._drc_review_pending():
            return
        target = self._drc_current_target()
        if target is None:
            self._set_live_status(
                "note는 선택/현재 에러 대상입니다: 먼저 선택·클릭·점프하세요")
            return
        ci, eis = target
        if len(eis) > DRC_PAGE:
            self._drc_review_submit("note-read", ci, eis)
            return
        texts = set(db.get_note(ci, e) for e in eis)
        prefill = (texts.pop() if len(texts) == 1 and None not in texts
                   else "")
        text = self._drc_note_dialog(prefill, len(eis))
        if text is None or (prefill and text == prefill):
            return
        db.set_note([db.error_gid(ci, e) for e in eis], text)
        self._drc_note_refresh(ci, eis)
        self._set_live_status(
            ("note set on %d error(s)" % len(eis)) if text
            else ("note cleared on %d error(s)" % len(eis)))

    def _drc_note_clear(self):
        """Clear the note(s) on the selected/current error(s) - the
        group-clear path (select the noted errors, then this)."""
        db = self._drc
        if db is None or not hasattr(db, "clear_note"):
            return
        if self._drc_review_pending():
            return
        target = self._drc_current_target()
        if target is None:
            self._set_live_status("먼저 note 있는 에러를 선택하세요")
            return
        ci, eis = target
        if len(eis) > DRC_PAGE:
            self._drc_review_submit("note-clear", ci, eis)
            return
        db.clear_note([db.error_gid(ci, e) for e in eis])
        self._drc_note_refresh(ci, eis)
        self._set_live_status("note cleared on %d error(s)" % len(eis))

    def _drc_note_refresh(self, ci, eis, fallback=True):
        """Repaint after a note change: the grid (the "*" prefix), the
        detail pane if it shows one of these errors, and the canvas.
        Note membership never changes the list, so the grid keeps its
        page/selection - only the cell text is rebuilt."""
        self._drc_hl_res = None
        if getattr(self, "_drc_grid_ci", None) == ci \
                and self._drcwin is not None:
            self._drc_grid_fill(ci)
        shown = None
        f = self._drc_focus
        if f is not None and f[0] == ci:
            shown = f[1]
        elif self._drc_pos >= 0 and self._drc_cum:
            c2 = bisect.bisect_right(self._drc_cum, self._drc_pos) - 1
            if c2 == ci:
                shown = self._drc_pos - self._drc_cum[ci]
        if ci == self._drc_open and (shown is not None or fallback):
            self._drc_show_detail(ci, shown if shown is not None else eis[0])
        self._display()

    def _drc_note_dialog(self, prefill, count):
        """Modal note editor (flateyes-style): multi-line text with
        OK/Cancel and a built-in dubeolsik hangul composer for hosts
        without an input method (Shift+Space toggles it). Returns the
        text (empty string = clear) or None on cancel."""
        title = "Edit Note" if prefill else "Note"
        if count > 1:
            title += "  (%d errors)" % count
        dlg = Gtk.Dialog(title=title, transient_for=self.window,
                         modal=True)
        dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dlg.add_button("OK", Gtk.ResponseType.OK)
        dlg.set_default_response(Gtk.ResponseType.OK)
        self._center_on_parent(dlg)
        view = Gtk.TextView()
        view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        editable = TextViewEditable(view)
        if prefill:
            editable.set_text(prefill)
            editable.set_position(len(prefill))
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC,
                          Gtk.PolicyType.AUTOMATIC)
        scroll.set_shadow_type(Gtk.ShadowType.IN)
        scroll.set_size_request(360, 100)
        scroll.add(view)
        # built-in hangul input for hosts with no IME (flateyes port)
        hangul = Gtk.CheckButton(label="Hangul (Shift+Space)")
        state = {"composer": HangulComposer(), "check": hangul,
                 "anchor": None}
        hangul.connect("toggled", lambda *a: state["composer"].reset())

        def on_key(_w, ev):
            name = Gdk.keyval_name(ev.keyval)
            if name == "Escape":
                dlg.response(Gtk.ResponseType.CANCEL)
                return True
            if name in ("Return", "KP_Enter") \
                    and (ev.state & Gdk.ModifierType.CONTROL_MASK):
                dlg.response(Gtk.ResponseType.OK)
                return True
            return self._note_entry_key(editable, ev, state)
        view.connect("key-press-event", on_key)
        hint = Gtk.Label()
        hint.set_markup("<small>Ctrl+Enter: OK · Esc: cancel · "
                        "Shift+Space: 한글 · empty removes the note"
                        "</small>")
        hint.set_halign(Gtk.Align.START)
        box = dlg.get_content_area()
        box.set_border_width(10)
        box.set_spacing(6)
        box.pack_start(scroll, True, True, 0)
        box.pack_start(hangul, False, False, 0)
        box.pack_start(hint, False, False, 0)
        dlg.show_all()
        ok = dlg.run() == Gtk.ResponseType.OK
        text = editable.get_text().strip()
        dlg.destroy()
        self.window.present()
        return text if ok else None

    def _note_entry_key(self, entry, event, state):
        """Dubeolsik hangul composition for the note editor (port of
        flateyes on_text_entry_key). Returns True when it consumed the
        key, False to let the TextView handle it."""
        name = Gdk.keyval_name(event.keyval)
        shift = event.state & Gdk.ModifierType.SHIFT_MASK
        if name in ("Hangul", "Hangul_Hanja") \
                or (name == "space" and shift):
            state["check"].set_active(not state["check"].get_active())
            return True
        if not state["check"].get_active():
            return False
        composer = state["composer"]
        if event.state & (Gdk.ModifierType.CONTROL_MASK
                          | Gdk.ModifierType.MOD1_MASK):
            composer.reset()   # keep Ctrl+A/C/V working
            state["anchor"] = None
            return False
        # a cursor that left the preedit span (click, arrows) finishes
        # that syllable; composition restarts wherever the cursor is
        if composer.pending() and entry.get_position() != \
                state["anchor"] + len(composer.preedit()):
            composer.reset()
            state["anchor"] = None
        if name == "BackSpace":
            if not composer.pending():
                return False
            old_len = len(composer.preedit())
            self._note_entry_replace(entry, state["anchor"], old_len,
                                     composer.backspace())
            if not composer.pending():
                state["anchor"] = None
            return True
        code = Gdk.keyval_to_unicode(event.keyval)
        if not code:
            # modifiers/arrows/F-keys carry no character: never end the
            # syllable (Shift for a double jamo must not break it)
            return False
        char = chr(code)
        jamo = HangulComposer.KEYMAP.get(char) \
            or HangulComposer.KEYMAP.get(char.lower())
        if jamo is None:
            composer.reset()   # syllable done; the entry handles the key
            state["anchor"] = None
            return False
        if not composer.pending():
            entry.delete_selection()   # type over a selection, like an IME
            state["anchor"] = entry.get_position()
            old_len = 0
        else:
            old_len = len(composer.preedit())
        committed, preedit = composer.feed(jamo)
        self._note_entry_replace(entry, state["anchor"], old_len,
                                 committed + preedit)
        state["anchor"] += len(committed)
        return True

    @staticmethod
    def _note_entry_replace(entry, anchor, old_len, new):
        """Replace the preedit span at anchor, cursor after it."""
        entry.replace_span(anchor, old_len, new)

    def _drc_note_save_dialog(self):
        """DRC > save notes as… : snapshot the per-reviewer note state
        to a picked flateyes .fe (share a review / keep a record)."""
        if self._drc_review_pending():
            return
        db = self._drc
        if db is None or not hasattr(db, "note_export"):
            self._set_live_status(
                "notes need a packed index: floe-index drc <db>")
            return
        dlg = Gtk.FileChooserDialog(title="save notes as",
                                    parent=self.window,
                                    action=Gtk.FileChooserAction.SAVE)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                        "Save", Gtk.ResponseType.OK)
        self._only_close_button(dlg)
        self._center_on_parent(dlg)
        dlg.set_do_overwrite_confirmation(True)
        dlg.set_current_folder(
            os.path.dirname(os.path.abspath(db.path)))
        base = gtkservice.db_name_of(db.path)
        dlg.set_current_name(base + ".notes.fe")
        out = dlg.get_filename() \
            if dlg.run() == Gtk.ResponseType.OK else None
        dlg.destroy()
        self.window.present()
        if not out:
            return
        try:
            db.note_export(out)
        except OSError as exc:
            self._set_live_status("note save failed (%s)" % exc)
            return
        self._set_live_status("notes saved: %s" % out)

    def _drc_note_load_dialog(self):
        """DRC > load notes… : REPLACE the notes from a saved .fe
        (save your own first). Files from a different pack are refused."""
        if self._drc_review_pending():
            return
        db = self._drc
        if db is None or not hasattr(db, "note_import"):
            self._set_live_status(
                "notes need a packed index: floe-index drc <db>")
            return
        path = self._browse_file_dialog(
            "load notes", os.path.dirname(os.path.abspath(db.path)),
            [("flateyes notes (*.fe)", ("*.fe",)),
             ("all files", ("*",))])
        self._restore_keys()
        if not path:
            return
        try:
            n = db.note_import(path)
        except (OSError, ValueError) as exc:
            self._set_live_status("note load failed: %s" % exc)
            return
        self._drc_hl_res = None
        gci = getattr(self, "_drc_grid_ci", None)
        if gci is not None and self._drcwin is not None:
            self._drc_grid_fill(gci)   # refresh the "*" prefixes
        self._display()
        self._set_live_status(
            "notes loaded: %d (%s)" % (n, os.path.basename(path)))

    def _drc_waive_save_dialog(self):
        """DRC > save waives as… (user call 2026-08-28): snapshot
        the auto-saved per-user waive state (~/.cache/floe/waive)
        to a picked file - for sharing a review or keeping a
        round's record. Same format as the auto sidecar."""
        if self._drc_review_pending():
            return
        db = self._drc
        if db is None or not hasattr(db, "waive_export"):
            self._set_live_status(
                "waive save needs a packed index: "
                "floe-index drc <db>")
            return
        dlg = Gtk.FileChooserDialog(title="save waives as",
                                    parent=self.window,
                                    action=Gtk.FileChooserAction.SAVE)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                        "Save", Gtk.ResponseType.OK)
        self._only_close_button(dlg)
        self._center_on_parent(dlg)
        dlg.set_do_overwrite_confirmation(True)
        dlg.set_current_folder(
            os.path.dirname(os.path.abspath(db.path)))
        base = gtkservice.db_name_of(db.path)
        dlg.set_current_name(base + ".waive")
        out = dlg.get_filename() \
            if dlg.run() == Gtk.ResponseType.OK else None
        dlg.destroy()
        self.window.present()
        if not out:
            return
        try:
            db.waive_export(out)
        except OSError as exc:
            self._set_live_status("waive save failed (%s)" % exc)
            return
        self._set_live_status("waives saved: %s" % out)

    def _drc_waive_load_dialog(self):
        """Load an external snapshot for comparison; never replace my state."""
        if self._load_refused("load waives"):
            return
        window = self._drc_team_dialog()
        if window is not None:
            # A comparison may still be running. Queue the chooser after it
            # so the legacy menu always reaches the non-destructive loader.
            if window.job is None:
                window._load_dialog()
            else:
                window._open_load_when_ready = True

    @staticmethod
    def _rgb_hex(rgba):
        """'#rrggbb' of a 0xRRGGBBAA palette constant (Pango markup)."""
        return "#%06x" % ((rgba >> 8) & 0xFFFFFF)

    def _drc_cell_markup(self, db, ci, ei, noted, eset, current=False):
        """Pango markup of ONE error-grid cell - the single formatter
        the page fill and the current-cell mark both use, so a cell
        looks the same whichever path repainted it last. Field
        2026-09-08: the mark path still carried the pre-90dec4d cyan
        for waived errors, so a waived number went green -> cyan the
        moment the mark moved to another cell."""
        t = "%d" % (ei + 1)          # rule-local numbering
        flags = self._drc_review_flags(db, ci, ei)
        not_required = flags is not None and bool(flags & gtkservice.NOT_REQUIRED)
        if flags is not None and flags & gtkservice.VISITED:
            t = "<u>%s</u>" % t
        if noted:
            t = "*" + t              # note present (user call 2026-08-28)
        if flags is None:
            t = "? " + t
        if current:
            fg = (self._rgb_hex(DRC_NOT_REQUIRED_CURRENT)
                  if not_required else "#ffffff")
            return ("<span background='#3465a4' "
                    "foreground='%s'>%s</span>" % (fg, t))
        waived = self._drc_waived(db, ci, ei)
        # (a waive a confirmer has rejected: its own hue, until its reviewer
        # waives the error again or turns it back)
        state = gtkservice.STATE_NONE if waived else self._drc_state(db, ci, ei)
        # (... and a request a waiver has declined: sent back the same way)
        rejected = state in (gtkservice.STATE_REJECTED, gtkservice.STATE_DECLINED)
        # (asked for, waived by nobody yet: a role's session)
        requested = state == gtkservice.STATE_REQUESTED
        if ei in eset:
            # gold like the canvas marker of a box-selected error, the
            # number in the darkened hue that reads on it
            fg = self._rgb_hex(DRC_NOT_REQUIRED_ON_GOLD if not_required
                               else DRC_GREEN_ON_GOLD if waived
                               else DRC_REJECTED_ON_GOLD if rejected
                               else DRC_REQUESTED_ON_GOLD if requested
                               else DRC_RED_ON_GOLD)
            return ("<span background='%s' foreground='%s'>%s</span>"
                    % (self._rgb_hex(DRC_GOLD), fg, t))
        fg = self._rgb_hex(DRC_NOT_REQUIRED if not_required
                           else DRC_GREEN if waived
                           else DRC_REJECTED if rejected
                           else DRC_REQUESTED if requested else DRC_RED)
        return "<span foreground='%s'>%s</span>" % (fg, t)

    def _drc_cell_mark(self, row, j):
        """Mark ONE grid cell as current: the previous cell reverts
        through the shared formatter (local number, gold when
        selected)."""
        win = self._drcwin
        ci = self._drc_grid_ci
        if win is None or ci is None:
            return
        gstore = win._gstore
        sel = self._drc_sel
        eset = (sel[3] if sel is not None and sel[0] == ci
                else frozenset())
        gmap = self._drc_grid_map

        db = self._drc

        has_note = hasattr(db, "get_note")

        def cell_at(r, c_, current):
            k2 = r * self._drc_gridw + c_
            if k2 >= len(gmap):
                return ""
            ei = gmap[k2]
            noted = bool(has_note and db.get_note(ci, ei))
            return self._drc_cell_markup(db, ci, ei, noted, eset, current)

        old = self._drc_cell
        if old is not None and old != (row, j):
            orow, oj = old
            gstore[orow][oj] = cell_at(orow, oj, False)
        gstore[row][j] = cell_at(row, j, True)
        self._drc_cell = (row, j)

    def _on_drc_grid_click(self, tree, ev):
        """Click an error number: mark the cell + detail pane;
        double-click also jumps; Ctrl/Shift edit the selection;
        right click = waive/unwaive menu."""
        if ev.button == 3 \
                and ev.type == Gdk.EventType.BUTTON_PRESS:
            return self._on_drc_grid_menu(tree, ev)
        if ev.button != 1:
            return False
        hit = tree.get_path_at_pos(int(ev.x), int(ev.y))
        if hit is None:
            return False
        path, col, _cx, _cy = hit
        row = path.get_indices()[0]
        ci = self._drc_grid_ci
        if ci is None or row >= self._drc_grid_rows:
            return False
        try:
            j = tree.get_columns().index(col)
        except ValueError:
            return False
        idx = row * self._drc_gridw + j
        gmap = self._drc_grid_map
        if idx >= len(gmap):
            return False
        ei = gmap[idx]
        db = self._drc
        if db is None or ei >= len(db.checks[ci].errors):
            return False
        if ev.type == Gdk.EventType.DOUBLE_BUTTON_PRESS:
            self._drc_jump(ci, ei, isolate=True)
            return False
        if ev.state & (Gdk.ModifierType.CONTROL_MASK
                       | Gdk.ModifierType.SHIFT_MASK):
            self._drc_sel_click(
                ci, row, j, idx, ei,
                bool(ev.state & Gdk.ModifierType.SHIFT_MASK))
            return False
        self._drc_cell_mark(row, j)
        if self.drc_mark is not None:
            # user call 2026-09-08: while an error is being viewed
            # (double-click jump live) a plain click on another
            # number behaves like n/p - it jumps there
            self._drc_jump(ci, ei)
            return False
        e = db.checks[ci].errors[ei]
        self._drc_focus = (ci, ei, e.kind,
                           [(x / self.dbu, y / self.dbu)
                            for x, y in e.pts])
        self._drc_show_detail(ci, ei)
        self._display()
        return False

    @staticmethod
    def _drc_desc_lines(check):
        """A rule's text as the detail pane shows it: its description less
        the two lines every rule of a run repeats, the deck's `Rule File
        Pathname:` and `Rule File Title:` (out of an error's detail since
        2026-08-15, out of a rule's since 2026-11-11)."""
        if not check.desc:
            return []
        return [ln for ln in check.desc.split("\n")
                if not ln.startswith(("Rule File Pathname:", "Rule File Title:"))]

    def _drc_show_rule(self, ci):
        """Bottom pane of a rule picked without an error: its name and
        the rule's text. Out of it (user calls 2026-11-11): `errors: N
        (declared N)` - the count is the rules list's -, the SVRF status -
        the rule's check mark, its tooltip and the SVRF info window say it
        -, `cluster: …` - the row picked under the rule, with its count -,
        `delta group: …` - the row picked in the group list - and the
        deck's path and title lines (_drc_desc_lines)."""
        win, db = self._drcwin, self._drc
        if win is None or db is None:
            return
        c = db.checks[ci]
        lines = ["rule: %s" % c.name]
        text = self._drc_desc_lines(c)
        if text:
            lines.append("")
            lines += text
        win._detail.set_text("\n".join(lines))
        self._drc_detail_of = None
        self._drc_detail_at = (ci, None)
        self._drc_svrf_show()

    def _drc_show_detail(self, ci, ei):
        """Bottom pane: rule description, kind, coordinates and the
        review status of one violation. What the SVRF metadata adds of it
        - the constraint, the measured CD against its bound, the layers,
        their gds numbers and derivations - is not listed here (user call
        2026-11-11): the SVRF info window shows it (_drc_svrf_dialog, i),
        following the error in this pane while it is open. Nor is the
        SVRF status line (`SVRF: applied …`; the same day's second call):
        the rule's check mark, its tooltip and that window say it."""
        win, db = self._drcwin, self._drc
        if win is None or db is None:
            return
        self._drc_detail_of = (ci, ei)
        c = db.checks[ci]
        e = c.errors[ei]
        status = "-"
        if hasattr(db, "get_status"):
            # the error's state: none, waived, rejected, confirmed - and
            # requested, declined in a role's session
            s = self._drc_state(db, ci, ei)
            status = gtkservice.STATE_NAMES.get(s, "status %d" % s)
        lines = ["#%d(%d)  [%s]" % (ei + 1, e.num, status),
                 "rule: %s" % c.name]
        if hasattr(db, "review_flags"):
            flags = self._drc_review_flags(db, ci, ei)
            if flags is None:
                lines.append("review: unavailable")
            else:
                lines.append("visited: %s · not for review: %s" % (
                    "yes" if flags & gtkservice.VISITED else "no",
                    "yes" if flags & gtkservice.NOT_REQUIRED else "no"))
        if hasattr(db, "reason_get"):
            # why it is waived / set aside, when a reason was given
            try:
                why = db.reason_get(ci, ei)
            except (OSError, gtkservice.ServiceError):
                why = (None, None)
            # (a requester's mark is a request, and its reason the
            # request's)
            mine = ("request reason" if getattr(db, "marks", "waive") == "request"
                    else "waive reason")
            for label, text in zip((mine, "not for review reason"), why):
                if text:
                    lines.append("%s: %s" % (label, text))
            if hasattr(db, "history_get"):
                # what was before this waive was waived again: the reason it
                # had, the rejection it answers - in the order it happened
                try:
                    past = db.history_get(ci, ei)
                except (OSError, gtkservice.ServiceError):
                    past = ()
                lines += ["before: %s" % text
                          for text in self._drc_past_lines(past)]
        if hasattr(db, "waive_ask"):
            # the team's: who else waived it, who confirmed its waive
            lines += self._drc_team_lines(db, ci, ei)
        if hasattr(db, "get_note"):
            note = db.get_note(ci, ei)
            if note:
                lines.append("note: %s" % note.replace("\n", "\n      "))
        lines += self._drc_desc_lines(c)
        pts = e.pts
        if e.kind == "e":
            lines.append("edge (um):")
            for j in range(0, min(len(pts) - 1, 128), 2):
                lines.append("  (%.4f, %.4f) - (%.4f, %.4f)"
                             % (pts[j][0], pts[j][1],
                                pts[j + 1][0], pts[j + 1][1]))
            if len(pts) > 129:
                lines.append("  … %d more edges"
                             % ((len(pts) - 128) // 2))
        else:
            lines.append("polygon (um):")
            for x, y in pts[:64]:
                lines.append("  (%.4f, %.4f)" % (x, y))
            if len(pts) > 64:
                lines.append("  … %d more" % (len(pts) - 64))
        win._detail.set_text("\n".join(lines))
        self._drc_detail_at = (ci, ei)
        self._drc_svrf_show()

    def _drc_svrf_text(self):
        """The SVRF info window's text: of the error in the detail pane
        the constraint as the deck writes it, its measured CD against the
        bound, the layers with their gds numbers and derivations; of a
        rule without an error picked the same less the measurement; of a
        rule the metadata does not have, that."""
        db, at = self._drc, getattr(self, "_drc_detail_at", None)
        if db is None or at is None or at[0] >= len(db.checks):
            return "pick a rule or an error in the DRC pane"
        ci, ei = at
        c = db.checks[ci]
        e = c.errors[ei] if ei is not None and ei < len(c.errors) else None
        head = c.name if e is None else "%s  #%d(%d)" % (c.name, ei + 1, e.num)
        lines = self._drc_meta_lines(c.name, e)[1:]
        return "\n".join([head] + (lines or self._drc_svrf_status(c.name)[1].splitlines()))

    def _drc_svrf_show(self):
        """Keep the SVRF info window, when it is open, to the detail pane."""
        dlg = getattr(self, "_svrfdlg", None)
        if dlg is not None:
            dlg._buffer.set_text(self._drc_svrf_text())

    def _drc_svrf_dialog(self, toggle=False):
        """DRC > SVRF info (i; also the error grid's menu): a window of
        its own for what the SVRF metadata says of the rule and the error
        in the detail pane (user call 2026-11-11 - the pane listed it under
        every error). It does not block: left open it follows the error
        picked or stepped to, the viewer's keys work from it, Esc or i
        closes it."""
        dlg = getattr(self, "_svrfdlg", None)
        if dlg is not None:
            if toggle:
                dlg.destroy()
            else:
                dlg.present()
            return
        if self._drc is None:
            self._set_live_status("SVRF info: open a DRC .db first")
            return
        dlg = Gtk.Window(title="SVRF info")
        dlg.set_transient_for(self.window)
        dlg.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        dlg.set_default_size(460, 230)
        view = Gtk.TextView()
        view.set_editable(False)
        view.set_cursor_visible(False)
        view.set_monospace(True)
        view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        view.set_left_margin(6)
        view.set_right_margin(6)
        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sc.add(view)
        dlg.add(sc)
        dlg._buffer = view.get_buffer()
        self._svrfdlg = dlg
        self._drc_svrf_show()

        def on_key(_w, ev):
            name = self._command_key(ev)
            if name in ("Escape", "i"):
                dlg.destroy()
                return True
            if ev.state & Gdk.ModifierType.CONTROL_MASK:
                return False        # Ctrl+C on the text is the window's own
            return self._on_key(self.window, ev)
        dlg.connect("key-press-event", on_key)

        def _gone(*_a):
            self._svrfdlg = None
            self._restore_keys()
        dlg.connect("destroy", _gone)

        def _place(*_a):
            # over the detail pane, at the main window's lower left - not
            # over the error being looked at
            par = self.window
            if not (par.get_realized() and dlg.get_realized()):
                return False
            px, py = par.get_position()
            _pw, ph = par.get_size()
            dh = dlg.get_allocated_height()
            if dh <= 1:
                dh = dlg.get_preferred_size()[1].height
            dlg.move(px + 12, py + max(0, ph - dh - 70))
            return False
        dlg.set_position(Gtk.WindowPosition.NONE)
        dlg.connect("realize", _place)
        dlg.connect("map", _place)
        dlg.show_all()

    def _drc_jump(self, ci, ei, isolate=False):
        db = self._drc
        check = db.checks[ci]
        e = check.errors[ei]
        # user call 2026-09-08: a framing jump shrinks the in-view
        # list to this one error and every other number vanishes -
        # release the filter first (the button's handler refills the
        # grid), then put the mark back on this error's cell
        win_ = self._drcwin
        if self._drc_hl and win_ is not None:
            win_._hl.set_active(False)
            self._drc_goto_cell(ci, ei)
        # user call 2026-09-08: a zoom made while an error is being
        # viewed sticks - n/p and list clicks only recenter. A fresh
        # double-click (isolate) or a new session (mark cleared by
        # Esc) frames at the default fraction again.
        changed = (self._drc_jump_spp is not None
                   and abs(self.spp / self._drc_jump_spp - 1.0) > 1e-6)
        if isolate or self.drc_mark is None:
            self._drc_zoom_lock = False      # a new viewing session
        elif changed:
            self._drc_zoom_lock = True       # the user's zoom sticks
        keep_zoom = self._drc_zoom_lock
        self._drc_pos = self._drc_cum[ci] + ei
        self._drc_focus = None    # the jump mark supersedes it
        iso = None
        if isolate:   # double-click only (user call 2026-08-15)
            iso = self._drc_isolate_layers(check.name)
        b = e.bbox()
        w_um, h_um = b[2] - b[0], b[3] - b[1]
        cx, cy = e.center()
        if keep_zoom:
            self.goto(cx, cy, None)   # recenter at the user's zoom
        else:
            # zoom so the whole violation spans ~DRC_VIEW_FRACTION of
            # the view on BOTH axes (goto sets the view WIDTH, so the
            # vertical requirement converts through the canvas aspect)
            vw, vh = self._viewport_size()
            win = w_um / DRC_VIEW_FRACTION
            if vh > 0:
                win = max(win,
                          h_um / DRC_VIEW_FRACTION * (vw / float(vh)))
            if win <= 0:
                win = 0.1   # degenerate (point-like) violation
            self.goto(cx, cy, win)
        self._drc_jump_spp = self.spp
        self.drc_mark = {"kind": e.kind,
                         "pts": [(x / self.dbu, y / self.dbu)
                                 for x, y in e.pts],
                         "color": (DRC_GREEN
                                   if self._drc_waived(db, ci, ei)
                                   else DRC_RED)}
        # visited once its own geometry is drawn (_drc_visit_drawn)
        self.drc_mark["review_target"] = (db, ci, ei)
        # auto CD rulers: replaced on every jump (hand-drawn rulers
        # stay; k/Esc treat them like any ruler)
        for r in self._drc_ruler:
            if r in self.rulers:
                self.rulers.remove(r)
        self._drc_ruler = self._drc_cd_ruler(e, check.name)
        if e.kind == "e" and len(e.pts) == 2 and self._drc_ruler:
            # A ruler painted directly over a one-edge violation hides the
            # red error. Tag it for a constant screen-space parallel offset;
            # rendering adds dotted endpoint extension lines.
            self._drc_ruler = [_DrcOffsetRuler(self._drc_ruler[0])]
        self.rulers.extend(self._drc_ruler)
        self._set_live_status(
            "DRC %s #%d(%d)/%d · %s · %.3f x %.3f um at (%.3f, %.3f)%s"
            % (check.name, ei + 1, e.num, len(check.errors),
               "poly" if e.kind == "p" else "edge",
               w_um, h_um, cx, cy,
               "" if iso is None
               else " · %d layer(s) on, Esc restores" % iso))
        self._drc_show_detail(ci, ei)
        self._display()

    def _drc_isolate_layers(self, name):
        """Double-click jump: show ONLY the layers the rule
        metadata traces this check to (source_gds closure; dt None
        = every datatype of that gds layer). The pre-isolation
        visibility is snapshotted ONCE - Esc restores it (its own
        stage, before the DRC mark). Applied BEFORE goto so the
        jump renders once with the new layer set. Returns the
        matched layer count or None (no sidecar / no match)."""
        meta = self._drc_rmeta
        mc = meta.get("checks", {}).get(name) if meta else None
        gds = (mc or {}).get("source_gds") or []
        if not gds:
            return None
        want = set()
        for l in self.meta["layers"]:
            key = (l["layer"], l["datatype"])
            for g, d in gds:
                if key[0] == g and (d is None or key[1] == d):
                    want.add(key)
                    break
        if not want:
            return None   # metadata names no layer of THIS design
        if self._drc_lyr_saved is None:
            self._drc_lyr_saved = set(self.visible)
        if want != self.visible:
            self._layers_batch = True
            try:
                for key, row in self._layer_rows.items():
                    row.set_active(key in want)
            finally:
                self._layers_batch = False
        return len(want)

    def _drc_restore_layers(self):
        """Esc: back to the visibility snapshot taken by the first
        isolation."""
        saved, self._drc_lyr_saved = self._drc_lyr_saved, None
        if saved is None:
            return
        self._layers_batch = True
        try:
            for key, row in self._layer_rows.items():
                row.set_active(key in saved)
        finally:
            self._layers_batch = False
        self._set_live_status(
            "layer visibility restored (%d on)" % len(saved))
        self.redraw(immediate=True)

    def _drc_marker_invalidate(self, drop_worker=False):
        """Cancel stale scope/status work, including same-count status swaps."""
        self._drc_selection_cancel(close=drop_worker)
        self._drc_marker_revision = getattr(self, "_drc_marker_revision", 0) + 1
        self._drc_marker_key = None
        self._drc_marker_result = None
        self._drc_marker_overlay = None
        self._drc_marker_busy = False
        self._drc_hits = []
        self._drc_point_hits = None
        self._drc_hl_key = None
        self._drc_hl_res = None
        for name in ("_drc_query_worker", "_drc_marker_worker"):
            worker = getattr(self, name, None)
            if worker is not None:
                if drop_worker:
                    worker.close()
                    setattr(self, name, None)
                else:
                    worker.cancel()

    def _drc_marker_request(self, obox, ospp, width, height):
        """Query the whole rule/cluster/group at the DISPLAYED frame's
        transform (a service job; its partial pictures arrive while it
        runs)."""
        db, ci = self._drc, self._drc_open
        if db is None or ci is None or width < 1 or height < 1:
            return []
        active_members = self._drc_active_members()
        conflict_only = getattr(self, "_drc_conflict_only", False)
        if conflict_only and (active_members is None or not active_members):
            return []
        sel = self._drc_sel
        selected = sel[1] if sel is not None and sel[0] == ci else None
        # obox/ospp may describe a frozen base while the widget resizes.
        # Query the actual canvas corners under the same sx/sy transform.
        bounds = (obox[0] * self.dbu,
                  (obox[3] - height * ospp) * self.dbu,
                  (obox[0] + width * ospp) * self.dbu,
                  obox[3] * self.dbu)
        key = (id(db), ci,
               None if active_members is None
               else tuple(sorted(active_members.spec.items())),
               self._drc_wfilter,
               getattr(self, "_drc_marker_revision", 0),
               None if selected is None else selected.sid, self._drc_show_sel,
               bounds, width, height)
        if key != getattr(self, "_drc_marker_key", None):
            self._drc_marker_key = key
            self._drc_marker_result = None
            self._drc_marker_overlay = None
            self._drc_point_hits = None
            self._drc_marker_busy = True
            worker = getattr(self, "_drc_marker_worker", None)
            if worker is None:
                worker = self._drc_marker_worker = gtkservice.MarkerWorker()
            membership = (gtkservice.intersect(
                selected if selected is not None
                else gtkservice.DrcScope(db, ci, {"empty": True}),
                active_members) if self._drc_show_sel else active_members)
            # (the picture's circles the viewer's marker size, DRC_MARK_PX:
            # the service draws 5 px ones when it is not told, as 0.12.525)
            query = dict(bounds_um=bounds, width_px=width, height_px=height,
                         checks=(ci,), radius=DRC_MARK_PX // 2,
                         selected={ci: selected} if selected is not None else None,
                         progressive=True,
                         members=({ci: membership}
                                  if membership is not None else None),
                         waived=(None if conflict_only or self._drc_wfilter == "all" else
                                 self._drc_wf_class()))
            worker.submit(key, db, query)
        result = getattr(self, "_drc_marker_result", None)
        return result[1] if result is not None and result[0] == key else []

    def _drc_marker_poll(self):
        worker = getattr(self, "_drc_marker_worker", None)
        if worker is None:
            return
        reply = worker.poll()
        if reply is None:
            return
        key, markers, error = reply
        if key != self._drc_marker_key:
            return
        partial = isinstance(markers, gtkservice.MarkerProgress)
        self._drc_marker_busy = partial and error is None
        if error is not None:
            # A preview is never presented as a successfully completed scope.
            self._drc_marker_result = None
            self._drc_marker_overlay = None
            self._drc_point_hits = None
            self._drc_hits = []
            self._set_live_status("DRC markers failed: %s" % error)
        else:
            if partial:
                markers = markers.markers
            self._drc_marker_result = (key, markers)
            self._drc_marker_overlay = None
            # a picture still being made must not pass for the whole one
            # (the panel's info line said `(partial)` until 2026-11-10): a
            # computation long enough to show a part says in the status
            # line how far it is and, having said so, that it is done; a
            # quick one says nothing
            if partial:
                self._drc_marker_said = key
                self._set_live_status(
                    "DRC markers: %d / %d errors processed (partial)…"
                    % (markers.processed_count, markers.total_count)
                    if markers.total_count else "DRC markers (partial)…")
            elif getattr(self, "_drc_marker_said", None) == key:
                self._drc_marker_said = None
                self._set_live_status(
                    "DRC markers: %d errors / %d markers in view"
                    % (markers.visible_count, markers.occupied_count))
        self._display()

    def _drc_stamp_markers(self, disp, obox, ospp):
        """Composite the service's full-scope circle picture and keep its
        pixel hit map."""
        width, height = disp.get_width(), disp.get_height()
        markers = self._drc_marker_request(obox, ospp, width, height)
        self._drc_point_hits = None
        if not isinstance(markers, gtkservice.PointMarkers):
            return  # no picture for this view yet
        if markers.width != width or markers.height != height:
            return
        key = self._drc_marker_key
        cached = getattr(self, "_drc_marker_overlay", None)
        if cached is None or cached[0] != key:
            layer = GdkPixbuf.Pixbuf.new_from_bytes(
                GLib.Bytes.new(markers.rgba), GdkPixbuf.Colorspace.RGB,
                True, 8, width, height, width * 4)
            cached = self._drc_marker_overlay = (key, layer)
        cached[1].composite(disp, 0, 0, width, height, 0, 0, 1, 1,
                            GdkPixbuf.InterpType.NEAREST, 255)
        self._drc_point_hits = markers

    def _drc_display_view(self):
        """World bounds and scale of the pixels currently on the canvas."""
        view = getattr(self, "_drc_marker_view", None)
        if view is None:
            return self.view_bbox(), self.spp
        box, spp, width, height = view
        return (box[0], box[3] - height * spp,
                box[0] + width * spp, box[3]), spp

    def _drc_stamp_errs(self, disp, sx, sy, items, color=None):
        """Error painter: geometry in `color`, or per-status when
        None (user call 2026-08-14/17: not waived = red, waived =
        green). ONLY the jumped error (double-click / n-p - the one
        drc_mark points at) draws its real shape, collapsing to a
        marker when its screen span is below the marker size; every
        OTHER error is a DRC_MARK_PX circle at ANY zoom (user call
        2026-08-18 - shape soup at wide views; the focused one:
        DRC_HOVER_PX). A 20k segment budget bounds pathological frames."""
        db = self._drc
        focus = self._drc_focus
        jci = jei = -1
        if self.drc_mark is not None and self._drc_pos >= 0 \
                and self._drc_cum:
            jci = bisect.bisect_right(self._drc_cum,
                                      self._drc_pos) - 1
            jei = self._drc_pos - self._drc_cum[jci]
        budget = 20000
        sprites = {}
        for ci_, ei_, kind, spts in items:
            col = color
            if col is None:
                col = (DRC_GREEN
                       if self._drc_waived(db, ci_, ei_)
                       else DRC_RED)
            sp = [(sx(x), sy(y)) for x, y in spts]
            hxs = [p[0] for p in sp]
            hys = [p[1] for p in sp]
            if (ci_ != jci or ei_ != jei) \
                    or (max(hxs) - min(hxs) < DRC_MARK_PX
                        and max(hys) - min(hys) < DRC_MARK_PX):
                cxp = (min(hxs) + max(hxs)) / 2.0
                cyp = (min(hys) + max(hys)) / 2.0
                s_px = DRC_HOVER_PX if (focus is not None
                                        and focus[0] == ci_
                                        and focus[1] == ei_) else DRC_MARK_PX
                stamp_drc_circle(disp, cxp, cyp, s_px // 2, col,
                                 sprites=sprites, solid=True)
                self._drc_hits.append((cxp, cyp, ci_, ei_))
                budget -= 1
            else:
                if kind == "p":
                    segs = list(zip(sp, sp[1:] + sp[:1]))
                else:
                    segs = [(sp[j], sp[j + 1])
                            for j in range(0, len(sp) - 1, 2)]
                for a, b in segs:
                    stamp_segment(disp, a, b, None, col)
                    budget -= 1
            if budget <= 0:
                return

    def _drc_waived(self, db, ci, ei):
        """True when the error's status byte says WAIVED (v1 dbs
        have no status: everything counts as not waived)."""
        return (hasattr(db, "get_status")
                and db.get_status(ci, ei)
                == STATUS_WAIVED)

    def _drc_marked(self, db, ci, ei):
        """True when this reviewer has the error marked - what decides
        which way `w` goes. A role's session reads the error's state as
        everybody's files say it, and its own mark beside (a requester's
        request, a waiver's waive: gtkservice PackDrc.get_mark); a session
        without a role has the one thing, `_drc_waived`."""
        if getattr(db, "role", "") and hasattr(db, "get_mark"):
            return db.get_mark(ci, ei) == STATUS_WAIVED
        return self._drc_waived(db, ci, ei)

    def _drc_fill_strip(self, width, color):
        """One-row SOLID strip in `color` at 50% alpha, composited
        row-by-row into polygon spans (composite BLENDS, fill would
        replace). Cached per color. The old 50% checker of opaque
        pixels shared the design speckle's period: at zoom/pan
        parities where the two checkers landed in phase, the error
        covered exactly every drawn design pixel and the layer
        underneath vanished (field report 2026-08-22) - an alpha
        blend is phase-free."""
        strips = getattr(self, "_drc_strips", None)
        if strips is None:
            strips = self._drc_strips = {}
        strip = strips.get(color)
        if strip is not None and strip.get_width() >= width:
            return strip
        strip = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, True,
                                     8, max(width, 2), 1)
        strip.fill((color & 0xFFFFFF00) | 0x80)
        strips[color] = strip
        return strip

    def _drc_fill_translucent(self, disp, pts, color=DRC_RED):
        """Even-odd scanline fill of the violation polygon with a
        SOLID 50%-alpha wash (capture-embed parity - the underlying
        layers always show through at every zoom). Degenerate and
        very complex outlines fall back to outline-only."""
        if len(pts) < 3 or len(pts) > 256:
            return
        w_px, h_px = disp.get_width(), disp.get_height()
        ys = [p[1] for p in pts]
        y0 = max(0, int(math.floor(min(ys))))
        y1 = min(h_px - 1, int(math.ceil(max(ys))))
        if y1 < y0:
            return
        strip = self._drc_fill_strip(w_px, color)
        edges = [(a, b) for a, b in zip(pts, pts[1:] + pts[:1])
                 if a[1] != b[1]]
        budget = 20000   # spans; beyond this the fill just stops
        for y in range(y0, y1 + 1):
            yc = y + 0.5
            xs = []
            for (ax, ay), (bx, by) in edges:
                if (ay <= yc < by) or (by <= yc < ay):
                    xs.append(ax + (yc - ay) * (bx - ax) / (by - ay))
            if not xs:
                continue
            xs.sort()
            for i in range(0, len(xs) - 1, 2):
                x0 = max(0, int(math.ceil(xs[i])))
                x1 = min(w_px, int(math.floor(xs[i + 1])) + 1)
                if x1 <= x0:
                    continue
                strip.composite(disp, x0, y, x1 - x0, 1,
                                0, y, 1, 1,
                                GdkPixbuf.InterpType.NEAREST, 255)
                budget -= 1
                if budget <= 0:
                    return

    def _drc_meta_lines(self, name, e):
        """Detail-pane block from the `floe-index svrf` sidecar: the
        constraint as written in the deck, this violation's own
        measured dimension vs the bound (the waive-decision aid),
        the referenced layer names + source gds, and the derivation
        chain that produced them."""
        meta = self._drc_rmeta
        mc = meta.get("checks", {}).get(name) if meta else None
        if not mc:
            return []
        lines = [""]
        cons = mc.get("constraints") or []
        for t in dict.fromkeys(c.get("text", "") for c in cons):
            if t:
                lines.append("constraint: %s" % t)
        # the CD the rule's condition flagged on this marker, its bound and
        # their difference in five-decimal ticks (app-core drc::analysis -
        # the delta groups' numbers; feature/jobdeck-drc 2026-10-06);
        # without a marker (the rule alone) none of that
        info = self._drc_cd_info(e, name) if e is not None else {}
        pick = info.get("pick")
        ticks = pick.get("ticks") if pick else None
        if ticks:
            mv, v, delta = ticks
            con = cons[pick["constraint"]]
            ratio = pick.get("ratio")
            pct = (" (%s%%)" % format_ticks(ratio) if ratio is not None
                   else " (ratio unavailable)")
            unit = "um2" if con.get("metric") == "area" else "um"
            label = "estimated CD" if pick.get("estimated") else "measured"
            lines.append("%s: %s %s vs %s %s · Δ %s%s"
                         % (label, format_ticks(mv), unit, con.get("op", "?"),
                            format_ticks(v), format_ticks(delta), pct))
            if pick.get("estimated"):
                cticks = pick.get("candidate_ticks") or []
                if len(cticks) > 1:
                    lines.append("CD candidates: %s %s" % (", ".join(
                        format_ticks(t) if t is not None else "?"
                        for t in cticks), unit))
                if pick.get("reason"):
                    lines.append("CD selection: %s" % pick["reason"])
        elif cons and e is not None:
            lines.append("CD unavailable: geometry or rule condition "
                         "unresolved")
        if pick is None and info.get("marker_length_ticks") is not None:
            lines.append("Marker edge length: %s um (CD unresolved)"
                         % format_ticks(info["marker_length_ticks"]))
        lays = mc.get("layers") or []
        if lays:
            lines.append("layers: %s" % ", ".join(lays))
        gds = mc.get("source_gds") or []
        if gds:
            lines.append("gds: %s" % ", ".join(
                "%s/%s" % (g, "*" if d is None else d)
                for g, d in gds))
        if mc.get("unresolved"):
            lines.append("unresolved: %s"
                         % ", ".join(mc["unresolved"]))
        derived = meta.get("derived", {})
        out, seen, stack = [], set(), list(lays)
        while stack and len(out) < 6:
            n = stack.pop(0)
            if n in seen or n not in derived:
                continue
            seen.add(n)
            out.append("  %s = %s" % (n, derived[n]))
            stack.extend(gtkservice.svrf_operands(derived[n]))
        if out:
            lines.append("derivation:")
            lines += out
            if any(n in derived and n not in seen for n in stack):
                lines.append("  …")
        return lines

    def _drc_cd_info(self, e, name):
        """The rule-aware rulers, an AREA rule's label and the CD pick of
        one violation (gtk-service drc_cd_info), with the rule's sidecar
        constraints; none when the service refuses."""
        meta = self._drc_rmeta or {}
        cons = ((meta.get("checks", {}).get(name) or {}).get("constraints")
                or [])
        try:
            return e.cd_info(cons)
        except gtkservice.ServiceError as exc:
            self._set_live_status("DRC CD: %s" % exc)
            return {"rulers": [], "area": None, "pick": None}

    def _drc_cd_ruler(self, e, name=None):
        """Auto CD rulers as dbu 4-tuples, area/zero-gap point readouts as
        _DrcAreaLabel - the rectangle directions the rule flags (both
        when it cannot tell), SHARED with the CLI snapshot embeds."""
        info = self._drc_cd_info(e, name)
        k = self.dbu
        rulers = []
        for x0, y0, x1, y1 in info.get("rulers") or []:
            if x0 == x1 and y0 == y1:
                rulers.append(_DrcAreaLabel(x0 / k, y0 / k, "0.00000 um"))
            else:
                rulers.append((x0 / k, y0 / k, x1 / k, y1 / k))
        if info.get("area"):
            x, y, text = info["area"]
            rulers.append(_DrcAreaLabel(x / k, y / k, text))
        return rulers

    def _drc_step(self, delta):
        """n/p: cycle within the VISIBLE list of the open rule
        (user call 2026-08-15) - whatever the selected/in-view/
        waive filters left, across pages."""
        db = self._drc
        ci = self._drc_sel_check()
        if db is None or ci is None:
            self._set_live_status(
                "n/p cycles the open rule: select a rule first")
            return
        win = self._drcwin
        # sync the browser FIRST so the grid base belongs to ci
        if win is not None and self._drc_grid_ci != ci:
            self._drc_page = 0
            self._drc_select_row(ci, self._drc_cluster)
        n_all = len(db.checks[ci].errors)
        lo = self._drc_cum[ci]
        cur = (self._drc_pos - lo
               if self._drc_pos >= 0
               and lo <= self._drc_pos < lo + n_all else None)
        ei = self._drc_step_ei(db, ci, self._drc_grid_base, cur,
                               delta)
        if ei is None:
            self._set_live_status(
                "no errors in the current list (rule %s)"
                % db.checks[ci].name)
            return
        if win is not None:
            self._drc_goto_cell(ci, ei)
        self._drc_arrive(ci, ei)

    def _drc_arrive(self, ci, ei):
        """The error a key took the grid's mark to - n/p, a cursor key in
        the grid (its cell is marked already)."""
        db = self._drc
        if self.drc_mark is not None:
            # an error is designated (double-click/pick jump is
            # live): the key keeps the full framing jump + CD rulers
            self._drc_jump(ci, ei)
            return
        # Esc-restored (or never jumped): the key acts like a plain
        # click on the grid number - cell mark, detail, focus - the
        # VIEW does not move (user call 2026-08-18); position still
        # advances for the next step
        e = db.checks[ci].errors[ei]
        self._drc_pos = self._drc_cum[ci] + ei
        self._drc_focus = (ci, ei, e.kind,
                           [(x / self.dbu, y / self.dbu)
                            for x, y in e.pts])
        self._drc_show_detail(ci, ei)
        self._display()

    # ---- the cursor keys in the DRC pane's lists ----------------------------
    def _drc_list_key(self, focus, name):
        """A cursor key while one of the DRC pane's three lists has the
        keys - the rule list, the CD group list, the error numbers - moves
        in that list (user 2026-11-15); True when the key was such a key.
        Any other key, and the cursor keys with the keys anywhere else,
        are the view's as before: the arrows pan it. The four arrows are
        the list's whatever is held with them, and where a list has
        nowhere to go the key does nothing - it does not pan the view
        behind the list, and the keys do not leave the list."""
        win = getattr(self, "_drcwin", None)
        if win is None or focus is None:
            return False
        key = name[3:] if name.startswith("KP_") else name
        if key not in ("Up", "Down", "Left", "Right"):
            return False
        if focus is win._grid:
            self._drc_grid_arrow(key)
        elif focus is win._rules:
            self._drc_rules_arrow(key)
        elif focus is win._delta_tree:
            self._drc_delta_arrow(key)
        else:
            return False
        return True

    @staticmethod
    def _tree_row_beside(tree, path, delta):
        """The path of the row a tree view shows under (delta 1) or over
        (-1) the row at `path` - a closed row's children are not shown -,
        None at the list's end."""
        model = tree.get_model()
        it = model.get_iter(path)
        if delta > 0:
            if model.iter_has_child(it) and tree.row_expanded(path):
                return model.get_path(model.iter_children(it))
            while it is not None:
                following = model.iter_next(it)
                if following is not None:
                    return model.get_path(following)
                it = model.iter_parent(it)
            return None
        before = model.iter_previous(it)
        if before is None:
            parent = model.iter_parent(it)
            return model.get_path(parent) if parent is not None else None
        # (the last row shown under the row before)
        while model.iter_has_child(before) \
                and tree.row_expanded(model.get_path(before)):
            before = model.iter_nth_child(
                before, model.iter_n_children(before) - 1)
        return model.get_path(before)

    def _drc_rules_arrow(self, key):
        """A cursor key with the rule list focused: Up / Down select the
        row over / under the selected one - a rule, or a cluster of an
        open rule - as a click on it does (its errors in the grid); Right
        opens a rule's clusters, Left closes them, and from a cluster goes
        back to its rule. With no row selected Up and Down take the
        first."""
        tree = self._drcwin._rules
        model, it = tree.get_selection().get_selected()
        if it is None:
            first = model.get_iter_first()
            if first is not None and key in ("Up", "Down"):
                tree.set_cursor(model.get_path(first), None, False)
            return
        path = model.get_path(it)
        if key in ("Up", "Down"):
            to = self._tree_row_beside(tree, path, 1 if key == "Down" else -1)
            if to is not None:
                tree.set_cursor(to, None, False)
        elif key == "Right":
            if model.iter_has_child(it) and not tree.row_expanded(path):
                tree.expand_row(path, False)
        elif tree.row_expanded(path):
            tree.collapse_row(path)
        elif path.get_depth() > 1:
            parent = path.copy()
            parent.up()
            tree.set_cursor(parent, None, False)

    def _drc_delta_arrow(self, key):
        """A cursor key with the CD group list focused: Up / Down make the
        row over / under the selected one the grid's scope, as a click on
        it does. The list goes on over its pages: under a page's last row
        comes the next page's first group, over its first row (`All
        errors`) the last group of the page before. With no row selected -
        the scope's group is on another page - Down takes the page's first
        group and Up its last. Left and Right do nothing."""
        if key not in ("Up", "Down"):
            return
        tree = self._drcwin._delta_tree
        model, it = tree.get_selection().get_selected()
        rows = model.iter_n_children(None)
        if not rows:
            return
        groups = getattr(self, "_drc_delta_groups", None)
        pages = max(1, ((len(groups) if groups is not None else 0) + 49) // 50)
        page = getattr(self, "_drc_delta_page", 0)
        if it is None:
            at = min(1, rows - 1) if key == "Down" else rows - 1
        else:
            at = model.get_path(it).get_indices()[0] + (1 if key == "Down" else -1)
        if at >= rows:
            if page + 1 >= pages:
                return
            self._drc_delta_page = page + 1
            self._drc_delta_refresh()
            at = min(1, model.iter_n_children(None) - 1)
        elif at < 0:
            if page <= 0:
                return
            self._drc_delta_page = page - 1
            self._drc_delta_refresh()
            at = model.iter_n_children(None) - 1
        if at < 0:
            return
        # (the selection's own handler makes the row the scope)
        tree.set_cursor(Gtk.TreePath.new_from_string(str(at)), None, False)

    @staticmethod
    def _drc_grid_move(cur, cells, width, key):
        """Where a cursor key takes the marked cell `cur` of a grid page
        of `cells` cells, `width` to a row: the cell's index on the page,
        or (-1 | 1, column) when the cell is over the page's edge - the
        page before or after, at that column of its last or first row
        (None: the page before's last cell). Under the last cell of a
        column that the page's shorter last row does not reach, Down takes
        the page's last cell."""
        row, column = divmod(cur, width)
        if key == "Left":
            return cur - 1 if cur > 0 else (-1, None)
        if key == "Right":
            return cur + 1 if cur + 1 < cells else (1, 0)
        if key == "Up":
            return cur - width if row > 0 else (-1, column)
        if cur + width < cells:
            return cur + width
        return cells - 1 if row < (cells - 1) // width else (1, column)

    def _drc_grid_place(self, ci):
        """Where the current error - the one the detail is of: the clicked
        or stepped one, else the one jumped to - stands on the grid's page
        while no cell is marked: (its cell, True) when the page lists it,
        (the cell of the error listed after it, False) when it left the
        list - waived under the filter that lists what is not waived, the
        usual way through a rule - and its neighbours are on the page.
        None otherwise: no such error, one outside this page, a list that
        is not in the errors' order."""
        cells = self._drc_grid_map or ()
        current = None
        focus = self._drc_focus
        if focus is not None and focus[0] == ci:
            current = focus[1]
        elif self._drc_pos >= 0 and self._drc_cum:
            low = self._drc_cum[ci]
            if low <= self._drc_pos < low + len(self._drc.checks[ci].errors):
                current = self._drc_pos - low
        if current is None or any(a >= b for a, b in zip(cells, cells[1:])):
            return None
        k = bisect.bisect_left(cells, current)
        if k < len(cells) and cells[k] == current:
            return k, True
        return (k, False) if 0 < k < len(cells) else None

    def _drc_grid_arrow(self, key):
        """A cursor key with the error numbers focused: the mark moves to
        the cell beside it - Left / Right the error before / after in the
        list, Up / Down the one a row over / under - and what a click on
        that number does is done: its detail, and with an error being
        viewed the jump to it. Over a page's edge the list goes on in the
        page before / after; at the list's ends the mark stays. With no
        cell marked on the page the keys take up where the current error
        is or was (_drc_grid_place), else at the first cell."""
        win, db, ci = self._drcwin, self._drc, self._drc_grid_ci
        if win is None or db is None or ci is None:
            return
        cells = len(self._drc_grid_map or ())
        if not cells:
            return
        width = max(1, self._drc_gridw)
        mark, place = self._drc_cell, None
        if mark is None:
            place = self._drc_grid_place(ci)
        if mark is not None:
            at = self._drc_grid_move(mark[0] * width + mark[1], cells, width, key)
        elif place is None:
            at = 0
        elif place[1]:
            at = self._drc_grid_move(place[0], cells, width, key)
        else:
            at = place[0] if key in ("Right", "Down") else place[0] - 1
        if isinstance(at, tuple):
            step, column = at
            page = self._drc_page + step
            if page < 0 or page >= getattr(self, "_drc_grid_pages", 1):
                return
            self._drc_page = page
            self._drc_grid_fill(ci)
            cells = len(self._drc_grid_map or ())
            if not cells:
                return
            width = max(1, self._drc_gridw)
            if step > 0:
                at = min(column, cells - 1)
            elif column is None:
                at = cells - 1
            else:
                at = min((cells - 1) // width * width + column, cells - 1)
        ei = self._drc_grid_map[at]
        if ei >= len(db.checks[ci].errors):
            return
        row, j = divmod(at, width)
        self._drc_cell_mark(row, j)
        win._grid.scroll_to_cell(
            Gtk.TreePath.new_from_string(str(row)), None, False, 0.0, 0.0)
        self._drc_arrive(ci, ei)

    def _drc_step_ei(self, db, ci, base, cur, delta):
        """Next/previous ei within the visible list, wrapping."""
        if base is None:
            n = len(db.checks[ci].errors)
            if not n:
                return None
            if cur is None:
                return 0 if delta > 0 else n - 1
            return (cur + delta) % n
        if isinstance(base, tuple):     # lazy waive filter
            if base[0] == "cluster":
                cluster, waived = base[1:]
                cnt = cluster.count(waived)
                if not cnt:
                    return None
                rank = (cluster.rank(cur, waived) if cur is not None else None)
                nrank = ((rank + delta) % cnt if rank is not None
                         else (0 if delta > 0 else cnt - 1))
                page = cluster.page(nrank, 1, waived)
                return page[0] if page else None
            waived = base[1]
            cnt = self._drc_wf_count(db, ci)
            if not cnt:
                return None
            rank = (db.status_rank(ci, waived, cur)
                    if cur is not None else None)
            nrank = ((rank + delta) % cnt if rank is not None
                     else (0 if delta > 0 else cnt - 1))
            page = db.status_page(ci, waived, nrank, 1)
            return page[0] if page else None
        if not base:
            return None
        if cur is None or cur not in base:
            return base[0] if delta > 0 else base[-1]
        return base[(base.index(cur) + delta) % len(base)]

    def _drc_goto_cell(self, ci, ei):
        """Flip the grid to the page holding ei and mark its
        cell (skips silently when a filter hides it)."""
        win = self._drcwin
        if win is None or self._drc_grid_ci != ci:
            return
        base = self._drc_grid_base
        if base is None:
            bidx = ei
        elif isinstance(base, tuple):
            bidx = (base[1].rank(ei, base[2]) if base[0] == "cluster" else
                    self._drc.status_rank(ci, base[1], ei))
            if bidx is None:
                return
        elif ei in base:
            bidx = base.index(ei)
        else:
            return
        page = bidx // DRC_PAGE
        if page != self._drc_page:
            self._drc_page = page
            self._drc_grid_fill(ci)
        rel = bidx - page * DRC_PAGE
        row, j = divmod(rel, self._drc_gridw)
        self._drc_cell_mark(row, j)
        win._grid.scroll_to_cell(
            Gtk.TreePath.new_from_string(str(row)),
            None, False, 0.0, 0.0)

    # ---- ruler / snap / pick -----------------------------------------------
    def _update_cursor(self, ev):
        bbox, spp = (self._drc_display_view() if self.mode == "esel" else
                     (self.view_bbox(), self.spp))
        self._cursor = (bbox[0] + ev.x * spp,
                        bbox[3] - ev.y * spp)

    def _hover(self, ev):
        x, y = self._cursor
        parts = ["x %.3f  y %.3f um" % (x * self.dbu, y * self.dbu)]
        if self.mode == "ruler":
            self._ruler_free = bool(ev.state &
                                    Gdk.ModifierType.SHIFT_MASK)
            self._request_snap()
            if self._ruler_start is not None:
                x1, y1 = self._ruler_end_preview()
                x0, y0 = self._ruler_start
                d = math.hypot(x1 - x0, y1 - y0) * self.dbu
                parts.append("measure %s um (dx %s, dy %s)"
                             % tuple(format_um5(v) for v in
                                     (d, (x1 - x0) * self.dbu,
                                      (y1 - y0) * self.dbu)))
            else:
                parts.append("ruler: click 1st point"
                             + (" [snap]" if self.snap_on else ""))
            self._display()
        elif self.mode == "esel":
            if self._esel_start is not None:
                parts.append("error select: click the opposite "
                             "corner (Esc cancels)")
                self._display()   # live box preview
            else:
                parts.append("error select: click the 1st corner")
        else:
            if self._sel_text:
                parts.append(self._sel_text)
            # the cell selected in the cell tree stays on the line
            cell = self._cell_status_text()
            if cell:
                parts.append(cell)
        text = "   |   ".join(parts)
        self._set_live_status(text)

    def _toggle_ruler(self):
        if self.mode == "ruler":
            self.mode = "normal"
            self._ruler_start = None
            self._snap_res = None
            self._set_live_status("ruler off")
        else:
            self.mode = "ruler"
            n = self._measure_selection()
            if n:
                self._set_live_status(
                    "ruler: %d auto rulers from selection (closest "
                    "gaps) · click two points, Esc=done" % n)
            else:
                self._set_live_status(
                    "ruler: click two points (Shift=free angle, "
                    "m=snap %s, k=undo, Shift+K=clear, Esc=done)"
                    % ("on" if self.snap_on else "off"))
        self._set_cursor(self._idle_cursor())
        self._display()

    def _measure_selection(self):
        """Entering ruler mode with 2+ picked objects auto-measures
        them at their CLOSEST parts only (field request: no union
        spans): every object pairs with its nearest neighbour, and
        each pair gets a horizontal and/or vertical ruler between
        the facing edges - only on axes where the pair is disjoint,
        so touching or overlapping geometry adds nothing. Bbox
        based. Regenerated on every ruler-mode entry; the previous
        auto set is replaced, hand-drawn rulers are kept."""
        boxes = [tuple(s["bbox"]) for s in self.selections
                 if s.get("bbox")]
        if len(boxes) < 2:
            return 0
        if self._auto_rulers:
            self.rulers = [r for r in self.rulers
                           if r not in self._auto_rulers]

        def sep(a, b):
            dx = max(a[0] - b[2], b[0] - a[2], 0)
            dy = max(a[1] - b[3], b[1] - a[3], 0)
            return math.hypot(dx, dy)

        pairs = set()
        for i in range(len(boxes)):
            best, bd = None, None
            for j in range(len(boxes)):
                if j == i:
                    continue
                d = sep(boxes[i], boxes[j])
                if bd is None or d < bd:
                    bd, best = d, j
            pairs.add((min(i, best), max(i, best)))

        def cross_mid(a, b, olo, ohi):
            # anchor a gap ruler where the pair overlaps on the
            # OTHER axis; midway between centers when it does not
            lo = max(a[olo], b[olo])
            hi = min(a[ohi], b[ohi])
            if lo <= hi:
                return (lo + hi) / 2.0
            return (a[olo] + a[ohi] + b[olo] + b[ohi]) / 4.0

        auto = []
        for i, j in sorted(pairs):
            a, b = boxes[i], boxes[j]
            for horiz in (True, False):
                lo, hi, olo, ohi = ((0, 2, 1, 3) if horiz
                                    else (1, 3, 0, 2))
                if b[lo] >= a[hi]:
                    d, e0, e1 = b[lo] - a[hi], a[hi], b[lo]
                elif a[lo] >= b[hi]:
                    d, e0, e1 = a[lo] - b[hi], b[hi], a[lo]
                else:
                    continue  # overlapping on this axis: no gap
                if d <= 0:
                    continue  # touching edges measure nothing
                m = cross_mid(a, b, olo, ohi)
                auto.append((e0, m, e1, m) if horiz
                            else (m, e0, m, e1))
        self.rulers.extend(auto)
        self._auto_rulers = auto
        return len(auto)

    def _toggle_snap(self):
        self.snap_on = not self.snap_on
        if not self.snap_on:
            self._snap_res = None
        self._set_live_status(
            "vector snap %s" % ("on" if self.snap_on else "off"))
        self._display()

    def _esc(self):
        """Step out flateyes-style: pending point -> ruler mode ->
        finished rulers -> selection -> markers. EVERYTHING
        ruler-related outranks the selection (field reports): with
        an object selected, Esc first cancels the measurement in
        progress, then clears finished rulers, and only then drops
        the selection. Before all of that, a render in flight
        ("rendering…" or the density round being drawn) is cancelled
        (field 2026-09-30) - the next Esc runs the chain."""
        if self._pending is not None or getattr(self, "_refining", False):
            self._cancel_render()
            return
        if getattr(self, "_drc_selection_key", None) is not None:
            self._drc_selection_cancel()
            self._set_live_status("error selection cancelled")
            return
        if self.mode == "esel":
            if self._esel_start is not None:
                self._esel_start = None
            else:
                self.mode = "normal"
                self._set_cursor(self._idle_cursor())
        elif self._ruler_start is not None:
            self._ruler_start = None
        elif self.mode == "ruler":
            self.mode = "normal"
            self._snap_res = None
            self._set_cursor(self._idle_cursor())
        elif self.rulers:
            self.rulers = []
            self._auto_rulers = []
            self._drc_ruler = []
        elif self.selection is not None:
            self._clear_selection()
        elif self._cell_hl is not None or self._cell_sel is not None:
            # the cell tree's highlight and the selection it follows (its
            # status line goes with it, the highlight on or off)
            self._cell_hl_clear(display=False)
        elif self._drc_sel is not None:
            self._drc_set_sel(None)
            if self._drc_grid_ci is not None:
                self._drc_grid_fill(self._drc_grid_ci)
        elif self._drc_lyr_saved is not None:
            self._drc_restore_layers()
            # restoring isolation ALSO ends the jump (user call
            # 2026-08-18): mark and auto CD rulers go in the same
            # Esc; _drc_pos stays so click-mode n/p continues from
            # the same error
            self.drc_mark = None
            for r in self._drc_ruler:
                if r in self.rulers:
                    self.rulers.remove(r)
            self._drc_ruler = []
        elif self.drc_mark is not None or self._drc_focus is not None:
            self.drc_mark = None
            self._drc_focus = None
        self._display()

    def _copy_view(self):
        """Ctrl+C (user call 2026-08-19): copy the canvas AS SEEN -
        grabbed from the WINDOW (flateyes capture_view) so widget
        overlays ride along: ruler distance chips and design labels
        are Gtk.Labels on the overlay, NOT part of the composed
        pixbuf (field report: lengths missing from copies). NO
        clipboard.store() - a clipboard manager (Exceed TurboX sync
        agent) can drop the image targets on store; the viewer
        serves the selection itself and it empties on quit."""
        pb = None
        win = self.window.get_window()
        if win is not None:
            # the overlay's allocation x/y are NOT toplevel-relative
            # in this nested paned/scroller layout (field report:
            # the whole app window got captured) - translate the
            # canvas origin into toplevel coordinates explicitly
            alloc = self.overlay.get_allocation()
            try:
                ox, oy = self.overlay.translate_coordinates(
                    self.window, 0, 0)
            except (TypeError, ValueError):
                ox = None
            if ox is not None:
                pb = Gdk.pixbuf_get_from_window(
                    win, ox, oy, alloc.width, alloc.height)
        if pb is None:
            pb = self.image.get_pixbuf()   # unmapped fallback
        if pb is None:
            self._set_live_status("nothing to copy yet")
            return
        cb = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        cb.set_image(pb)
        self._set_live_status(
            "copied  %dx%d" % (pb.get_width(), pb.get_height()))

    def _toggle_overlays(self):
        """Tab cycles THREE states (user call 2026-08-21): all
        shown -> other errors hidden (the jumped error, its note,
        rulers and chips stay) -> everything hidden (the old
        flateyes-parity clean look) -> all shown. (Rulers are removed
        with Esc, not Tab.)"""
        self.overlay_mode = (self.overlay_mode + 1) % 3
        self._set_live_status(
            {0: "overlays shown",
             1: "other errors hidden (Tab cycles)",
             2: "overlays hidden (Tab restores)"}[self.overlay_mode])
        self._display()

    def _ruler_pop(self):
        """k: delete the most recently created ruler."""
        if self.rulers:
            r = self.rulers.pop()
            if r in self._auto_rulers:
                self._auto_rulers.remove(r)
            if r in self._drc_ruler:
                self._drc_ruler.remove(r)
            self._display()

    def _rulers_clear(self):
        """Shift+K: remove every ruler (and a pending first point)."""
        if self.rulers or self._ruler_start is not None:
            self.rulers = []
            self._auto_rulers = []
            self._drc_ruler = []
            self._ruler_start = None
            self._display()

    def _cursor_snapped(self):
        if self.snap_on and self._snap_res \
                and self._snap_res.get("found"):
            return self._snap_res["x"], self._snap_res["y"]
        return self._cursor

    def _ruler_end_preview(self):
        x0, y0 = self._ruler_start
        x1, y1 = self._cursor_snapped()
        if not self._ruler_free:  # snap to the dominant axis
            if abs(x1 - x0) >= abs(y1 - y0):
                y1 = y0
            else:
                x1 = x0
        return x1, y1

    def _ruler_click(self, ev):
        self._update_cursor(ev)
        if self._ruler_start is None:
            # rulers accumulate (Calibre): k pops the newest,
            # Shift+K clears all (user call 2026-08-10)
            self._ruler_start = self._cursor_snapped()
        else:
            x0, y0 = self._ruler_start
            x1, y1 = self._ruler_end_preview()
            if (x0, y0) != (x1, y1):
                self.rulers.append((x0, y0, x1, y1))
            self._ruler_start = None
        self._display()

    def _snap_shapes(self, x, y, r):
        """The segments (x0, y0, x1, y1; dbu) of the error shape on the
        canvas that a snap around (x, y) may land on - the view channel's
        `overlay` (user 2026-11-12: the ruler's snap passed the error's
        shape by, the shape being the viewer's own drawing and no part of
        the layout the snap is answered from). The jumped error's edges -
        a polygon's outline, an edge record's edges - where _draw_overlays
        draws them as the shape: not where the error is its marker circle,
        not with the overlays off (Tab). Only the segments in reach of the
        snap are handed over, so a long outline costs what is near the
        cursor; the rule itself (a vertex before an edge, the nearer, with
        the layout's answer) is the service's (app-core view::overlay)."""
        mark = self.drc_mark
        if mark is None or self.overlay_mode == 2 or not mark.get("pts"):
            return []
        pts = mark["pts"]
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        spp = self._drc_display_view()[1]   # the scale it is drawn at
        if ((max(xs) - min(xs)) / spp < DRC_MARK_PX
                and (max(ys) - min(ys)) / spp < DRC_MARK_PX):
            return []   # drawn as the marker, not as its shape
        if mark["kind"] == "p":
            pairs = zip(pts, pts[1:] + pts[:1])
        else:
            pairs = ((pts[j], pts[j + 1])
                     for j in range(0, len(pts) - 1, 2))
        reach = r + 2   # the service asks around the whole dbu under (x, y)
        out = []
        for (ax, ay), (bx, by) in pairs:
            if (max(ax, bx) < x - reach or min(ax, bx) > x + reach
                    or max(ay, by) < y - reach or min(ay, by) > y + reach):
                continue
            out.append((ax, ay, bx, by))
            if len(out) == SNAP_SHAPES_MAX:
                break
        return out

    def _request_snap(self):
        if not self.snap_on:
            return
        now = time.perf_counter()
        if now - self._snap_sent < 0.04:
            return
        x, y = self._cursor
        r = max(1, int(10 * self.spp))
        shapes = self._snap_shapes(x, y, r)
        # too far out for meaningful geometry snapping: the layout's is
        # not asked - an error's shape drawn there still is
        layout = self.tiles_spanned((x - r, y - r, x + r, y + r)) <= 4
        if not layout and not shapes:
            # nothing is asked here: no mark left behind from where the
            # shape was in reach, and no late answer to bring one back
            self._snap_res = None
            self._snap_seq += 1
            return
        self._snap_sent = now
        self._snap_seq += 1
        job = {"kind": "snap", "seq": self._snap_seq,
               "x": int(x), "y": int(y), "r": r,
               "layers": self._layers_arg()}
        if shapes:
            job["overlay"] = shapes
        if not layout:
            job["layout"] = False
        self.worker.submit(job)

    @property
    def selection(self):
        """Primary (most recent) picked object, or None. The full
        multi-selection lives in `selections`; this single-object
        view keeps Esc/reset/deselect-contract code unchanged."""
        return self.selections[-1] if self.selections else None

    @selection.setter
    def selection(self, res):
        self.selections = [] if res is None else [res]

    @staticmethod
    def _sel_key(res):
        """Identity for Ctrl-toggle/dedup: geometry + layer, NOT the
        pick index (the same object reports a different nth/index
        when clicked at a different spot)."""
        pts = res.get("points")
        return (res.get("layer"), res.get("datatype"), res.get("cell"),
                tuple(res.get("bbox") or ()),
                tuple(map(tuple, pts)) if pts else None)

    def _drc_hit_at(self, x, y, r=6):
        """(ci, ei) of the nearest DRC marker painted within r px
        of the screen point, else None (list rebuilt per frame)."""
        hit = self._drc_hit_near(x, y, r)
        return None if hit is None else hit[:2]

    def _drc_hit_near(self, x, y, r=6):
        """The nearest DRC marker painted within r px of the screen point:
        (ci, ei, its centre's x, y on the canvas, the colour it is drawn
        in), else None - _drc_hit_at's, and the hover's (0.12.526)."""
        best = None
        bd = r * r + 1
        for hx, hy, ci, ei in self._drc_hits:
            d = (hx - x) ** 2 + (hy - y) ** 2
            if d <= r * r and d < bd:
                bd = d
                best = (ci, ei, hx, hy, None)
        points = getattr(self, "_drc_point_hits", None)
        if points is not None:
            # At most (2r+1)^2 cells even for a hundred million errors.
            # Focus/gold hits above retain priority at equal distances.
            x0, x1 = max(0, math.ceil(x - r)), min(points.width, math.floor(x + r) + 1)
            y0, y1 = max(0, math.ceil(y - r)), min(points.height, math.floor(y + r) + 1)
            for hy in range(y0, y1):
                for hx in range(x0, x1):
                    ei = points.error_id(hx, hy)
                    if ei < 0:
                        continue
                    d = (hx - x) ** 2 + (hy - y) ** 2
                    if d <= r * r and d < bd:
                        bd = d
                        best = (points.check, ei, hx, hy, points)
        if best is None:
            return None
        ci, ei, hx, hy, picture = best
        if picture is None:
            color = self._drc_focus_color(ci, ei)
        else:
            # (the service's picture: the colour drawn at the marker's centre
            # - gold for the selection, green waived, red)
            i = (hy * picture.width + hx) * 4
            red, green, blue = picture.rgba[i], picture.rgba[i + 1], picture.rgba[i + 2]
            color = (red << 24) | (green << 16) | (blue << 8) | 0xFF
        return ci, ei, hx, hy, color

    def _drc_focus_color(self, ci, ei):
        """The colour the error in focus is drawn in over the service's
        picture: gold while the rule's selection has it, else its review
        state's (green waived, red)."""
        sel = self._drc_sel
        if sel is not None and sel[0] == ci and ei in sel[3]:
            return DRC_GOLD
        return DRC_GREEN if self._drc_waived(self._drc, ci, ei) else DRC_RED

    def _drc_pick(self, ci, ei):
        """Canvas marker SINGLE click = plain grid-number click
        (user call 2026-08-18, rev 2): select the error - grid
        cell, focus, detail - the view does not move. The full
        jump lives on the canvas DOUBLE click (_on_press)."""
        db = self._drc
        e = db.checks[ci].errors[ei]
        if self._drcwin is not None:
            self._drc_goto_cell(ci, ei)
        self._drc_focus = (ci, ei, e.kind,
                           [(x / self.dbu, y / self.dbu)
                            for x, y in e.pts])
        self._drc_show_detail(ci, ei)
        self._display()

    def _pick_click(self, ev):
        """A click picks the layout shape seen under the pointer: of the
        shapes over the point, those that show in the frame there - a layer
        that is on but lies under others at the point is not picked -, the
        smallest first; a click at the same spot takes the next larger one,
        round again from the smallest (the rule is the service's: render-core
        pick_scene and seen_planes_around, app-core view::query; SPEC-VIEWER
        §9)."""
        self._update_cursor(ev)
        x, y = self._cursor
        state = getattr(ev, "state", 0)
        # a click ON a DRC marker picks that error (plain clicks
        # only - Ctrl/Shift stay design-selection gestures)
        if self._drc is not None and not (
                state & (Gdk.ModifierType.CONTROL_MASK
                         | Gdk.ModifierType.SHIFT_MASK)):
            hit = self._drc_hit_at(ev.x, ev.y)
            if hit is not None:
                self._drc_pick(*hit)
                return
        if state & Gdk.ModifierType.CONTROL_MASK:
            mode = "toggle"  # add unselected / remove selected
        elif state & Gdk.ModifierType.SHIFT_MASK:
            mode = "add"     # extend the multi-selection
        else:
            mode = "replace"
        if mode == "replace":
            tol = 8 * self.spp  # same-spot test in world coords: pan-proof
            if self._pick_px is not None and \
                    abs(x - self._pick_px[0]) <= tol and \
                    abs(y - self._pick_px[1]) <= tol:
                self._pick_nth += 1  # same spot: cycle overlapping objects
            else:
                self._pick_nth = 0
            self._pick_px = (x, y)
        else:
            # modifier clicks always pick the topmost object: cycling
            # would toggle a DIFFERENT overlapped object on the second
            # Ctrl-click at the same spot
            self._pick_px = None
            self._pick_nth = 0
        r = max(1, int(3 * self.spp))
        if self.tiles_spanned((x - r, y - r, x + r, y + r)) > 4:
            # too wide to pick - but a plain click must still honor
            # the documented deselect contract instead of leaving the
            # old selection (and its row highlight) stuck on screen
            if mode == "replace" and self.selection is not None:
                self._clear_selection()
                self._set_live_status("selection cleared")
                self._display()
            else:
                self._set_live_status("zoom in to pick objects")
            return
        self._pick_seq += 1
        self._pick_mode = mode
        self.worker.submit({
            "kind": "pick", "seq": self._pick_seq,
            "x": int(x), "y": int(y), "r": r, "nth": self._pick_nth,
            "layers": self._layers_arg()})

    def _on_pick_result(self, res):
        mode = self._pick_mode
        if not res.get("found"):
            if mode == "replace":
                self._clear_selection()
            if res.get("err"):
                # a query-side failure is not "no object here" (§3.19:
                # the silent-empty path hid a starvation defect)
                self._set_live_status("pick error: %s" % res["err"])
                return
            # a pick takes what is seen (0.12.456, user 2026-11-12): shapes
            # over the point whose layers are on but lie under others there
            # are not picked - said, so that the point does not pass for an
            # empty one (turning the layers above off shows them)
            hidden = res.get("hidden") or 0
            self._set_live_status(
                "no visible object here (%d hidden)" % hidden
                if hidden else "no object here")
        elif mode == "replace":
            self.selections = [res]
            self._refresh_sel_status()
        else:
            key = self._sel_key(res)
            kept = [s for s in self.selections
                    if self._sel_key(s) != key]
            if mode == "add" or len(kept) == len(self.selections):
                # Shift always selects; Ctrl adds a new object and
                # (the filter above) removes an already selected one
                kept.append(res)
            self.selections = kept
            self._refresh_sel_status()
        self._display()

    def _refresh_sel_status(self):
        """Primary selection changed: row highlight + status text."""
        res = self.selection
        if res is None:
            self._sel_text = ""
            self._set_picked_layer(None)
            self._cell_pick_show(None)
            self._set_live_status("selection cleared")
            return
        self._set_picked_layer(
            (res["layer"], res["datatype"]),
            {(s["layer"], s["datatype"]) for s in self.selections})
        bb = res["bbox"]
        w = (bb[2] - bb[0]) * self.dbu
        h = (bb[3] - bb[1]) * self.dbu
        n = len(self.selections)
        self._sel_text = ("sel%s %s %d/%d · %s · %.3f x %.3f um @ "
                          "(%.3f, %.3f) · %d/%d"
                          % ("(%d)" % n if n > 1 else "",
                             res["lname"], res["layer"],
                             res["datatype"], res["cell"], w, h,
                             bb[0] * self.dbu, bb[1] * self.dbu,
                             res["index"] + 1, res["count"]))
        self._set_live_status(self._sel_text)
        # ... and its cell in the cell tree, as its layer in the layer list
        self._cell_pick_show(res["cell"])

    def _clear_selection(self):
        self.selection = None
        self._sel_text = ""
        # a pick may still be in flight: without this, its late
        # result resurrects the selection the user just dismissed
        # (Esc / row hide), re-expanding and re-scrolling the panel
        self._pick_seq += 1
        self._set_picked_layer(None)
        self._cell_pick_show(None)

    def _set_picked_layer(self, key, keys=None):
        """Highlight the layers of ALL picked polygons; reveal and
        scroll to `key`, the primary pick's layer."""
        if keys is None:
            keys = {key} if key is not None else set()
        for row_key, row in self._layer_rows.items():
            row.set_picked(row_key in keys)
        # a group WE expanded for a previous pick collapses back once
        # it is no longer needed - auto-expansion must not silently
        # flip the parent row's double-click semantics forever
        keep = None
        if key is not None and key in self._layer_rows:
            for parent, children in self._layer_groups.items():
                if key in children:
                    keep = parent
                    break
        auto = getattr(self, "_pick_expanded", None)
        if auto is not None and auto != keep \
                and auto in self._layer_expanded \
                and auto in self._layer_rows:
            self._on_group_expand(self._layer_rows[auto])
        if auto != keep:
            self._pick_expanded = None
        if key is None or key not in self._layer_rows:
            return
        if keep is not None and keep not in self._layer_expanded:
            self._on_group_expand(self._layer_rows[keep])
            self._pick_expanded = keep
        # Showing a collapsed child is laid out on the next GTK cycle.
        GLib.idle_add(self._scroll_to_layer_row, key)

    def _scroll_to_layer_row(self, key, retried=False):
        row = self._layer_rows.get(key)
        if row is None or not row.widget.get_visible():
            return False
        alloc = row.widget.get_allocation()
        if alloc.height <= 1 and not retried:
            # just-shown row not laid out yet (frame-clock throttling
            # can defer allocation past a default-priority idle):
            # clamping to (-1, 0) would yank the panel to the top
            GLib.idle_add(self._scroll_to_layer_row, key, True,
                          priority=GLib.PRIORITY_LOW)
            return False
        if alloc.height <= 1:
            return False
        adj = self._layers_scroller.get_vadjustment()
        adj.clamp_page(alloc.y, alloc.y + alloc.height)
        return False

    def _apply_palette_color(self, color):
        """Palette swatch click: recolor every SELECTED layer row -
        row swatch, meta copy, render service, and the personal override
        file (~/.cache/floe)."""
        keys = set(self._selected_layers)
        if os.environ.get("FLOE_CLICK_DEBUG"):
            sys.stderr.write(
                "[click] apply color %s to %d selected layer(s)\n"
                % (color, len(keys)))
        if not keys:
            self._set_live_status(
                "select a layer row first, then pick a color")
            return
        # a COLLAPSED group parent stands for its whole datatype
        # group: recolor the folded members too (user call
        # 2026-08-11; expanded groups keep per-row control)
        for pkey, children in self._layer_groups.items():
            if pkey in keys and pkey not in self._layer_expanded:
                keys.update(children)
        for key in keys:
            row = self._layer_rows.get(key)
            if row is not None:
                row.set_color(color)
            for l in self.meta["layers"]:
                if (l["layer"], l["datatype"]) == tuple(key):
                    l["color"] = color
        self.worker.submit({
            "kind": "recolor",
            "colors": [[list(k), color] for k in sorted(keys)]})
        # colors are part of the frame identity now: force a fresh
        # render (the covered/preview reuse would keep old pixels)
        self._color_epoch += 1
        self.redraw(immediate=True)

    def _palette_grid_pick(self, box, ev, cells, cb):
        """One EventBox per palette GRID resolves the swatch by
        coordinates (translate_coordinates + allocations). Built
        while chasing the 2026-08-22 "dead palette" reports, which
        turned out to be clicks WITHOUT a selected layer row (the
        only feedback is the status line) - delivery itself was
        verified end to end. Kept as a simplification: 2 input
        windows instead of 69, same pattern as the minimap.
        FLOE_CLICK_DEBUG=1 traces this path."""
        dbg = os.environ.get("FLOE_CLICK_DEBUG")
        if dbg:
            sys.stderr.write(
                "[click] grid press type=%s button=%s at "
                "(%.1f, %.1f) own-window=%s cells=%d\n"
                % (ev.type.value_nick, getattr(ev, "button", "?"),
                   ev.x, ev.y, ev.window is box.get_window(),
                   len(cells)))
        if ev.type != Gdk.EventType.BUTTON_PRESS:
            return True
        for wdg, payload in cells:
            off = wdg.translate_coordinates(box, 0, 0)
            if not off:
                continue
            a = wdg.get_allocation()
            if off[0] <= ev.x < off[0] + a.width \
                    and off[1] <= ev.y < off[1] + a.height:
                if dbg:
                    sys.stderr.write(
                        "[click] grid pick -> %r (cell at %s "
                        "%dx%d)\n" % (payload, off,
                                       a.width, a.height))
                cb(payload, ev)
                return True
        if dbg:
            sys.stderr.write("[click] grid pick MISS (gap)\n")
        return True   # spacing gap: swallow, nothing to do

    def _on_fill_slot_click(self, slot, ev):
        if os.environ.get("FLOE_CLICK_DEBUG"):
            sys.stderr.write("[click] fill slot %d button=%s\n"
                             % (slot, getattr(ev, "button", "?")))
        if ev.type != Gdk.EventType.BUTTON_PRESS:
            return True
        if ev.button == 3:
            # the bitmap editor is a development tool (the Calibre
            # set is finalized) - hidden unless FLOE_FILL_EDIT=1
            if not os.environ.get("FLOE_FILL_EDIT"):
                return True
            menu = Gtk.Menu()
            item = Gtk.MenuItem(label="edit bitmap\u2026")
            fixed = fillpat.FILL_NAMES[slot] in fillpat.FIXED_FILLS
            item.set_sensitive(not fixed)
            item.connect("activate",
                         lambda _i: self._edit_fill_pattern(slot))
            menu.append(item)
            self._popup(menu, ev, "_fill_menu")
            return True
        self._apply_fill_slot(slot)
        return True

    def _apply_fill_slot(self, slot):
        """Assign a fill slot to every SELECTED layer row (folded
        group parents cover their members, like colors)."""
        keys = set(self._selected_layers)
        if not keys:
            self._set_live_status(
                "select a layer row first, then pick a fill")
            return
        for pkey, children in self._layer_groups.items():
            if pkey in keys and pkey not in self._layer_expanded:
                keys.update(children)
        for key in keys:
            self._layer_patterns[tuple(key)] = slot
        self._refresh_row_fills()
        self._push_fills()
        self._set_live_status(
            "fill '%s' -> %d layer(s)"
            % (fillpat.FILL_NAMES[slot], len(keys)))

    def _props_rows(self):
        """Current layer table as layerprops rows: color (7x7 name
        or #hex), fill name, layer name, visibility flag."""
        rows = []
        for l in self.meta["layers"]:
            key = (l["layer"], l["datatype"])
            slot = self._layer_patterns.get(key)
            fill = (fillpat.FILL_NAMES[slot]
                    if slot is not None else "speckle")
            rows.append((key, fillpat.color_name(l["color"]),
                         fill, l.get("name") or "",
                         "1" if key in self.visible else "0",
                         str(self._layer_widths.get(key, 1))))
        return rows

    def _apply_props_visibility(self, rows):
        """layerprops second-to-last column: 0=hide, 1=show.
        Batch-apply to rows the design knows (set_active fires the
        toggle handler, which maintains self.visible)."""
        self._layers_batch = True
        try:
            explicit = {tuple(r[0]) for r in rows if r[4] in ("0", "1")}
            heads = {(l["layer"], l["datatype"]) for l in
                     (self.meta or {}).get("layers", [])
                     if l.get("jobdeck_head")}
            for key, _c, _f, _n, f1, _f2 in rows:
                row = self._layer_rows.get(tuple(key))
                if row is None or f1 not in ("0", "1"):
                    continue
                want = f1 == "1"
                if row.get_active() != want:
                    row.set_active(want)
                if tuple(key) in heads:
                    for child in self._layer_groups.get(tuple(key), []):
                        if child not in explicit:
                            self._layer_rows[child].set_active(want)
        finally:
            self._layers_batch = False
        self._sync_jobdeck_groups()

    def _selected_with_folded(self):
        """Selection for palette-style actions: a COLLAPSED group
        parent stands for its whole datatype group."""
        keys = set(self._selected_layers)
        for pkey, children in self._layer_groups.items():
            if pkey in keys and pkey not in self._layer_expanded:
                keys.update(children)
        return keys

    def _set_layer_width(self, px):
        """Layer menu: outline width for the selected rows
        (layerprops trailing column; width 1 = the default, so it
        drops out of the map). Session-scoped like the palettes."""
        keys = self._selected_with_folded()
        if not keys:
            self._set_live_status(
                "select a layer row first, then pick a width")
            return
        for key in keys:
            k = tuple(key)
            if px <= 1:
                self._layer_widths.pop(k, None)
            else:
                self._layer_widths[k] = min(8, int(px))
        self._push_fills()
        self._set_live_status(
            "line width %d px -> %d layer(s)" % (px, len(keys)))

    def _step_layer_width(self, delta):
        keys = self._selected_with_folded()
        if not keys:
            self._set_live_status(
                "select a layer row first, then pick a width")
            return
        for key in keys:
            k = tuple(key)
            w = max(1, min(8, self._layer_widths.get(k, 1) + delta))
            if w <= 1:
                self._layer_widths.pop(k, None)
            else:
                self._layer_widths[k] = w
        self._push_fills()
        self._set_live_status(
            "line width %+d -> %d layer(s)" % (delta, len(keys)))

    def _refresh_row_fills(self):
        """Sync every layer row's swatch with its assigned fill."""
        for key, row in getattr(self, "_layer_rows", {}).items():
            slot = self._layer_patterns.get(key)
            row.set_fill(
                self._fill_patterns[slot]
                if slot is not None
                and 0 <= slot < len(self._fill_patterns)
                else None)

    def _fills_job(self):
        """The RESOLVED per-layer bitmaps and widths, as the render
        service's `repattern` job."""
        return {
            "kind": "repattern",
            "fills": [[list(k), self._fill_patterns[v]]
                      for k, v in sorted(
                          self._layer_patterns.items())
                      if 0 <= v < len(self._fill_patterns)],
            "widths": [[list(k), w] for k, w in sorted(
                self._layer_widths.items())]}

    def _push_fills(self):
        """Ship the RESOLVED per-layer bitmaps to the render
        service and force a fresh frame."""
        self.worker.submit(self._fills_job())
        self._color_epoch += 1
        self.redraw(immediate=True)

    def _edit_fill_pattern(self, slot):
        """16x16 bitmap editor popup: click toggles a cell, drag
        paints with the first cell's new value."""
        name = fillpat.FILL_NAMES[slot]
        rows = [list(r) for r in
                self._fill_patterns[slot].split("\n")]
        dlg = Gtk.Dialog(title="fill: %s" % name,
                         transient_for=self.window, modal=True)
        for label, code in (("clear", 10), ("solid", 11),
                            ("invert", 12), ("reset", 13)):
            dlg.add_button(label, code)
        dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dlg.add_button("Apply", Gtk.ResponseType.OK)
        cell = 18
        side = 16 * cell + 1
        # an image of the grid, painted again after each change (no
        # cairo "draw" handler: the hosts have no pycairo)
        grid = Gtk.Image()
        da = Gtk.EventBox()
        da.add(grid)
        da.set_halign(Gtk.Align.CENTER)
        paint = {"v": None}

        def draw():
            line = b"\x99\x99\x99"            # the grid lines
            out = []
            for r in rows:
                cells = b"".join(
                    line + (b"\x00\x00\x00" if c == "*"
                            else b"\xff\xff\xff") * (cell - 1) for c in r)
                out.append(line * side)
                out.extend([cells + line] * (cell - 1))
            out.append(line * side)
            grid.set_from_pixbuf(pixbuf_of(side, side, b"".join(out)))

        draw()

        def cell_at(ev):
            return int(ev.x) // cell, int(ev.y) // cell

        def press(_w, ev):
            x, y = cell_at(ev)
            if 0 <= x < 16 and 0 <= y < 16:
                paint["v"] = "." if rows[y][x] == "*" else "*"
                rows[y][x] = paint["v"]
                draw()
            return True

        def motion(_w, ev):
            if paint["v"] is None:
                return False
            x, y = cell_at(ev)
            if 0 <= x < 16 and 0 <= y < 16 \
                    and rows[y][x] != paint["v"]:
                rows[y][x] = paint["v"]
                draw()
            return True

        da.add_events(Gdk.EventMask.BUTTON_PRESS_MASK
                      | Gdk.EventMask.BUTTON1_MOTION_MASK
                      | Gdk.EventMask.BUTTON_RELEASE_MASK)
        da.connect("button-press-event", press)
        da.connect("motion-notify-event", motion)
        da.connect("button-release-event",
                   lambda _w, _e: paint.update(v=None) or True)
        dlg.get_content_area().pack_start(da, True, True, 8)
        dlg.show_all()
        while True:
            r = dlg.run()
            if r == 10:
                rows[:] = [["."] * 16 for _ in range(16)]
            elif r == 11:
                rows[:] = [["*"] * 16 for _ in range(16)]
            elif r == 12:
                rows[:] = [["." if c == "*" else "*" for c in rr]
                           for rr in rows]
            elif r == 13:
                rows[:] = [list(rr) for rr in
                           fillpat.pattern(name).split("\n")]
            else:
                break
            draw()
        ok = r == Gtk.ResponseType.OK
        dlg.destroy()
        if not ok:
            return
        self._fill_patterns[slot] = "\n".join(
            "".join(rr) for rr in rows)
        self._fill_slots[slot].refresh()
        self._refresh_row_fills()
        if slot in self._layer_patterns.values():
            self._push_fills()

    def _props_chooser(self, save):
        """The layer-properties file dialog: loading goes through the
        viewer's own browser (user call 2026-10-21: no symbolic link
        followed while listing); saving, which needs a name to type,
        keeps GTK's chooser."""
        src = os.path.abspath(self.cache.src)
        if not save:
            path = self._browse_file_dialog(
                "load layer properties", os.path.dirname(src),
                [("layerprops (*.layerprops)", ("*.layerprops",)),
                 ("all files", ("*",))])
            self._restore_keys()
            return path
        dlg = Gtk.FileChooserDialog(
            title="save layer properties",
            transient_for=self.window,
            action=Gtk.FileChooserAction.SAVE)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                        "Save", Gtk.ResponseType.OK)
        flt = Gtk.FileFilter()
        flt.set_name("layerprops (*.layerprops)")
        flt.add_pattern("*.layerprops")
        dlg.add_filter(flt)
        allf = Gtk.FileFilter()
        allf.set_name("all files")
        allf.add_pattern("*")
        dlg.add_filter(allf)
        dlg.set_current_folder(os.path.dirname(src))
        dlg.set_do_overwrite_confirmation(True)
        dlg.set_current_name(os.path.basename(src) + ".layerprops")
        ok = dlg.run() == Gtk.ResponseType.OK
        path = dlg.get_filename() if ok else None
        dlg.destroy()
        return path

    def _load_props_dialog(self):
        """Layer menu: apply a Calibre .layerprops file to the
        session (colors, fill assignments, visibility and outline
        width; rows for layers the design lacks are skipped,
        unlisted layers keep their state). Session-scoped: persist
        via "save layer properties..." or the design-default
        publish."""
        path = self._props_chooser(save=False)
        if not path:
            return
        self._props_load(path)

    def _props_tables(self, rows):
        """A layerprops file's rows on the layer table: the colours, fill
        assignments and outline widths of the rows the layout has (the
        others are skipped; a layer the file does not list keeps its
        state), then the visibility. Returns the colours changed by row
        and the number of fills assigned - what has to reach the render
        service."""
        known = set(self._layer_rows)
        recolors = {}
        nfill = 0
        for key, color, fill, _name, _f1, _f2 in rows:
            key = tuple(key)
            if key not in known:
                continue
            c = fillpat.color_hex(color)
            if c:
                for l in self.meta["layers"]:
                    if (l["layer"], l["datatype"]) == key:
                        l["color"] = c
                row = self._layer_rows.get(key)
                if row is not None:
                    row.set_color(c)
                recolors[key] = c
            i = fillpat.fill_index(fill)
            if i is not None:
                self._layer_patterns[key] = i
                nfill += 1
            try:
                w = int(_f2)
                if w > 1:
                    self._layer_widths[key] = w
                elif key in self._layer_widths:
                    del self._layer_widths[key]
            except ValueError:
                pass
        self._apply_props_visibility(rows)
        return recolors, nfill

    @staticmethod
    def _recolor_job(recolors):
        return {"kind": "recolor",
                "colors": [[list(k), v] for k, v in sorted(recolors.items())]}

    def _props_load(self, path):
        """Apply the layerprops file `path` to the layout shown, in place
        (Layer > load layer properties…; a launch's --layerprops for the
        layout the window already shows). Whether it was read."""
        try:
            rows = gtkservice.layerprops_read(path)
        except (OSError, gtkservice.ServiceError) as e:
            self._set_live_status(
                "layer properties load failed: %s" % e)
            return False
        recolors, nfill = self._props_tables(rows)
        if not recolors and not nfill:
            self._set_live_status(
                "no matching layers in %s" % path)
            self.redraw(immediate=True)  # visibility may have changed
            return True
        if recolors:
            self.worker.submit(self._recolor_job(recolors))
        self._refresh_row_fills()
        self._push_fills()  # repattern + epoch bump + redraw
        self._set_live_status(
            "layer properties loaded: %s (%d colors, %d fills)"
            % (path, len(recolors), nfill))
        return True

    # ---- a launch's layer properties file (floe2 view --layerprops) ------
    @staticmethod
    def _props_stamp(path):
        """What tells one state of the file from another."""
        try:
            st = os.stat(path)
        except OSError:
            return None
        return (st.st_mtime_ns, st.st_size)

    @staticmethod
    def _props_refusal(path):
        """Why the layer properties file a launch names cannot be used,
        else None - asked before anything is opened for it, so that the
        launch is told (the answer of a forwarded request, floe/viewcli.py
        for a first launch)."""
        try:
            gtkservice.layerprops_read(path)
        except (OSError, gtkservice.ServiceError) as e:
            return "ERR layer properties file %s: %s" % (path, e)
        return None

    def _props_request(self, path):
        """A launch names `path` for the layout the window already shows
        (open_file): applied in place, as Layer > load layer properties…
        does, and the layout's from here on - unless it is the file in
        use, unchanged: a launcher repeats its command line with every
        launch, and the table then keeps what the user changed since. A
        deck shown in another view than the level view - the view a launch
        opens, the one the file is for - takes it when it is back in that
        view."""
        cache = self.cache
        path = os.path.realpath(path)
        stamp = self._props_stamp(path)
        bound = self._props_bound
        if bound is not None and bound["src"] == cache.src \
                and bound["path"] == path and stamp is not None \
                and bound["stamp"] == stamp:
            return
        self._props_bound = {"src": cache.src, "path": path, "stamp": stamp}
        if getattr(cache, "is_jobdeck", False) and cache.mode != "level":
            self._set_live_status(
                "layer properties of the level view: %s" % path)
            return
        self._props_load(path)

    def _props_bound_apply(self, cache):
        """The layer properties file a launch named for `cache`, put on the
        layer table _apply_cache has just built for it - whenever that is:
        the launch's open, a reload of the layout, a deck's levels chosen
        again, a deck back in its level view (the view a launch opens; the
        other views keep their own files). The rows go on the table as
        Layer > load layer properties… puts them, over the design default.
        Another layout takes the place of the one the file was named for:
        the file goes with it. Returns the jobs for the view that is made
        next (the colours; the fills and widths), and leaves in _props_note
        what the status line says once that view is up."""
        named, self._props_next = self._props_next, None
        self._props_note = None
        if cache is None:
            return []
        bound = self._props_bound
        if named:
            bound = self._props_bound = {
                "src": cache.src, "path": named, "stamp": None}
        elif bound is not None and bound["src"] != cache.src:
            bound = self._props_bound = None
        if bound is None or (getattr(cache, "is_jobdeck", False)
                             and cache.mode != "level"):
            return []
        path = bound["path"]
        bound["stamp"] = self._props_stamp(path)
        try:
            rows = gtkservice.layerprops_read(path)
        except (OSError, gtkservice.ServiceError) as e:
            self._props_note = "layer properties load failed: %s" % e
            print("[%s] %s (%s)" % (APP, self._props_note, path),
                  file=sys.stderr, flush=True)
            return []
        recolors, nfill = self._props_tables(rows)
        if not recolors and not nfill:
            self._props_note = "no matching layers in %s" % path
            return []
        self._refresh_row_fills()
        self._color_epoch += 1
        self._props_note = (
            "layer properties loaded: %s (%d colors, %d fills)"
            % (path, len(recolors), nfill))
        jobs = [self._recolor_job(recolors)] if recolors else []
        jobs.append(self._fills_job())
        return jobs

    def _save_props_dialog(self):
        """Layer menu: export the current layer table as a Calibre
        .layerprops file wherever the user points."""
        path = self._props_chooser(save=True)
        if not path:
            return
        try:
            gtkservice.layerprops_save(path, self._props_rows())
            self._set_live_status(
                "layer properties saved: %s" % path)
        except (OSError, gtkservice.ServiceError) as e:
            self._set_live_status(
                "layer properties save failed: %s" % e)

    def _publish_default_colors(self):
        """Publish the CURRENT layer table as the design-default
        Calibre layerprops next to the source (<file>.layerprops):
        anyone opening the design with no personal palette adopts
        it - and it seeds their personal cache on first open."""
        try:
            path = gtkservice.layerprops_publish(
                getattr(self.cache, "props_src", self.cache.src),
                self._props_rows())
            self._set_live_status(
                "design default layerprops saved: %s" % path)
        except (OSError, gtkservice.ServiceError) as e:
            self._set_live_status(
                "default layerprops save failed: %s" % e)

    # ---- layers / clip -------------------------------------------------------
    def _set_layer_selection(self, keys, anchor=None):
        """Replace the palette selection without changing visibility."""
        keys = set(keys).intersection(self._layer_rows)
        self._selected_layers = keys
        if anchor is not None:
            self._layer_select_anchor = anchor
        for key, row in self._layer_rows.items():
            row.set_selected(key in keys)

    def _selectable_layer_order(self):
        """Return palette order without the rows that are not in the list:
        children hidden by collapsed groups, and under a search the rows it
        leaves out (_layer_row_shown)."""
        if getattr(self, "_layer_search", ""):
            return [key for key in self._layer_order if self._layer_row_shown(key)]
        hidden = set()
        for parent, children in self._layer_groups.items():
            if parent not in self._layer_expanded:
                hidden.update(children)
        return [key for key in self._layer_order if key not in hidden]

    def _on_layer_clicked(self, row, event):
        """Apply desktop-list selection rules and open the row menu."""
        key = row.key
        if event.button == 3:
            # Context-menu clicks never alter the palette selection. This
            # keeps a prepared multi-selection intact even when the menu is
            # opened over some other row or the inter-row padding.
            self._popup_layer_menu(event)
            return

        state = event.state
        shift = bool(state & Gdk.ModifierType.SHIFT_MASK)
        control = bool(state & Gdk.ModifierType.CONTROL_MASK)
        selectable = self._selectable_layer_order()
        if shift and self._layer_select_anchor in selectable:
            first = selectable.index(self._layer_select_anchor)
            last = selectable.index(key)
            if first > last:
                first, last = last, first
            selected = set(selectable[first:last + 1])
            if control:
                selected.update(self._selected_layers)
            self._set_layer_selection(selected)
        elif control:
            # Desktop-list toggle: Ctrl-click adds an unselected row and
            # removes an already selected row without disturbing the rest.
            selected = set(self._selected_layers)
            if key in selected:
                selected.remove(key)
            else:
                selected.add(key)
            self._set_layer_selection(selected, anchor=key)
        elif event.type == Gdk.EventType.BUTTON_PRESS \
                and self._selected_layers == {key}:
            # plain click on the sole selected row deselects it
            # (double-click presses re-select via their 2BP/3BP
            # event, so a visibility toggle still ends selected)
            self._set_layer_selection(set())
        else:
            self._set_layer_selection({key}, anchor=key)

    def _popup_layer_menu(self, event):
        menu = Gtk.Menu()

        def add_item(label, callback, sensitive=True):
            item = Gtk.MenuItem(label=label)
            item.set_sensitive(sensitive)
            item.connect("activate", lambda _item: callback())
            menu.append(item)

        has_selection = bool(self._selected_layers)
        add_item("show selected", lambda: self._set_selected_layers("show"),
                 has_selection)
        add_item("hide selected", lambda: self._set_selected_layers("hide"),
                 has_selection)
        add_item("toggle selected",
                 lambda: self._set_selected_layers("toggle"), has_selection)
        menu.append(Gtk.SeparatorMenuItem())
        add_item("show all", self._all_layers)
        add_item("hide all", self._no_layers)
        menu.append(Gtk.SeparatorMenuItem())
        wsub = Gtk.Menu()
        wroot = Gtk.MenuItem(label="line width")
        wroot.set_sensitive(has_selection)
        wroot.set_submenu(wsub)
        for px in (1, 3, 5):
            it = Gtk.MenuItem(label="%d px" % px)
            it.connect("activate",
                       lambda _i, p=px: self._set_layer_width(p))
            wsub.append(it)
        wsub.append(Gtk.SeparatorMenuItem())
        for label, d in (("increase", 1), ("decrease", -1)):
            it = Gtk.MenuItem(label=label)
            it.connect("activate",
                       lambda _i, dd=d: self._step_layer_width(dd))
            wsub.append(it)
        menu.append(wroot)
        menu.append(Gtk.SeparatorMenuItem())
        add_item("load layer properties\u2026",
                 self._load_props_dialog, self._file_load)
        add_item("save layer properties\u2026",
                 self._save_props_dialog)
        # dev-only, like the fill bitmap editor: publishing the design
        # default next to the source stays hidden from end users
        if os.environ.get("FLOE_FILL_EDIT"):
            add_item("save colors+fills as design default",
                     self._publish_default_colors)
        self._popup(menu, event, "_layer_menu")

    def _set_selected_layers(self, action):
        """Show, hide, or toggle the selected palette rows as one batch."""
        changes = {}
        covered = set()
        for key in self._layer_order:
            if key not in self._selected_layers or key in covered:
                continue
            row = self._layer_rows[key]
            on = (not row.get_active()) if action == "toggle" \
                else action == "show"
            affected = [key]
            kids = self._layer_groups.get(key)
            if kids and (key not in self._layer_expanded or
                         self._is_jobdeck_head(key)):
                affected.extend(kids)
            for affected_key in affected:
                changes[affected_key] = on
                covered.add(affected_key)

        if not changes:
            return
        self._layers_batch = True
        try:
            for key, on in changes.items():
                self._layer_rows[key].set_active(on)
        finally:
            self._layers_batch = False
        self._sync_jobdeck_groups()
        self.redraw(immediate=True)

    def _is_jobdeck_head(self, key):
        return any(l.get("jobdeck_head") and
                   (l["layer"], l["datatype"]) == key
                   for l in (self.meta or {}).get("layers", []))

    def _sync_jobdeck_groups(self):
        for key, children in self._layer_groups.items():
            if not self._is_jobdeck_head(key):
                continue
            count = sum(k in self.visible for k in children)
            if count:
                self.visible.add(key)
            else:
                self.visible.discard(key)
            self._layer_rows[key].set_group_state(
                count > 0, 0 < count < len(children))

    def _on_layer_toggled(self, row, key):
        if row.get_active():
            self.visible.add(key)
        else:
            self.visible.discard(key)
            if self.selections:
                # hiding a layer drops only ITS objects from the
                # multi-selection
                kept = [s for s in self.selections
                        if (s.get("layer"), s.get("datatype")) != key]
                if not kept:
                    self._clear_selection()
                elif len(kept) != len(self.selections):
                    self.selections = kept
                    self._refresh_sel_status()
        if self._layers_batch:
            return  # group/all/none toggle: one redraw at the end
        kids = self._layer_groups.get(key)
        if kids and (key not in self._layer_expanded or
                     self._is_jobdeck_head(key)):
            # A collapsed group acts as one row, so its parent drags every
            # datatype with it. Once expanded, every visible row (including
            # the parent datatype) toggles independently.
            on = row.get_active()
            self._layers_batch = True
            try:
                for k in kids:
                    # set_active fires _on_layer_toggled, which keeps
                    # self.visible in sync even while batched
                    self._layer_rows[k].set_active(on)
            finally:
                self._layers_batch = False
        self._sync_jobdeck_groups()
        self.redraw(immediate=True)

    def _set_all_layers(self, on):
        self._layers_batch = True
        try:
            for row in self._layer_rows.values():
                row.set_active(on)
        finally:
            self._layers_batch = False
        self._sync_jobdeck_groups()
        self.redraw(immediate=True)

    def _all_layers(self):
        self._set_all_layers(True)

    def _no_layers(self):
        self._set_all_layers(False)

    def _clip_dialog(self):
        if self._load_refused("clip region", NO_CLIP):
            return
        if self.cache is None:
            self._set_live_status("no layout loaded")
            return
        bbox = self.view_bbox()
        um = [round(v * self.dbu, 1) for v in bbox]
        dlg = Gtk.FileChooserDialog(title="save clip as OASIS",
                                    parent=self.window,
                                    action=Gtk.FileChooserAction.SAVE)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                        "Save", Gtk.ResponseType.OK)
        self._only_close_button(dlg)
        self._center_on_parent(dlg)
        dlg.set_do_overwrite_confirmation(True)
        dlg.set_current_name("%s_clip_%s_%s_%s_%sum.oas"
                             % (APP, um[0], um[1], um[2], um[3]))
        out = dlg.get_filename() if dlg.run() == Gtk.ResponseType.OK \
            else None
        dlg.destroy()
        self._restore_keys()  # quartz: refocus parent after the dialog
        if not out:
            return
        self.worker.submit({"kind": "clip",
                            "bbox": tuple(int(round(v)) for v in bbox),
                            "layers": self._layers_arg(), "out": out,
                            "root": self._root_ci()})
        self._set_live_status("clipping…")

    # ---- shutdown -------------------------------------------------------------
    def _confirm_quit(self):
        """Ask before quitting (q key). Modal, centered on the parent;
        default is No so a stray Enter does not exit."""
        if self._quitting:
            return
        dlg = Gtk.MessageDialog(
            transient_for=self.window, modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text="Quit %s?" % APP)
        self._center_on_parent(dlg)
        self._only_close_button(dlg)
        dlg.set_default_response(Gtk.ResponseType.NO)
        self._grab_focus_once(
            dlg, lambda: dlg.get_widget_for_response(Gtk.ResponseType.NO))
        resp = dlg.run()
        dlg.destroy()
        # quartz fails to refocus the parent when a transient closes,
        # leaving key commands dead until a click (same as _gone)
        self._restore_keys()
        if resp == Gtk.ResponseType.YES:
            self._quit()

    def _gc_release(self):
        """This viewer no longer runs the garbage collector on its thread
        (_MainThreadGc): once, at its quit or with its window."""
        if getattr(self, "_gc_held", False):
            self._gc_held = False
            _MainThreadGc.release()

    def _quit(self):
        if self._quitting:
            return
        self._quitting = True
        self._gc_release()
        for window in (getattr(self, "_drc_team", None),
                       getattr(self, "_drc_migration", None),
                       getattr(self, "_drc_waives_win", None)):
            if window is not None:
                window.window.destroy()
        self._drc_conflict_reset(drop_source=True)
        self._drc_selection_cancel(close=True)
        marker_worker = getattr(self, "_drc_marker_worker", None)
        if marker_worker is not None:
            marker_worker.close()
        delta_worker = getattr(self, "_drc_delta_worker", None)
        if delta_worker is not None:
            delta_worker.close()
        cached_worker = getattr(self, "_drc_group_cache_worker", None)
        if cached_worker is not None:
            cached_worker.close()
        query_worker = getattr(self, "_drc_query_worker", None)
        if query_worker is not None:
            query_worker.close()
        if self.server_sock is not None:
            # the socket's watch goes with it. A watch left in the loop is
            # run for whatever takes the closed socket's number next, and
            # _on_incoming's accept fails there every time: a regular file
            # is readable for good, so the loop of a process that goes on
            # after this viewer never rests (2026-11-16: a gate's next
            # viewer, the number taken by a file AppKit keeps open - the
            # gate's wait never came back, its window on the screen for
            # hours). `floe2 view`'s process ends with its viewer; the
            # gates' goes on.
            watch, self._server_watch = getattr(self, "_server_watch", None), None
            if watch:
                GLib.source_remove(watch)
            try:
                self.server_sock.close()
            except OSError:
                pass
        if self.worker is not None:
            self.worker.stop()
        if Gtk.main_level() > 0:
            Gtk.main_quit()


def run_viewer(cache, server_sock=None, goto=None, drc=None,
               detail=None, dump=False, depth=None, lod=DEFAULT_LOD,
               frames=DEFAULT_FRAMES, labels=DEFAULT_LABELS,
               label_font_px=DEFAULT_LABEL_FONT_PX,
               frame_cache=True, margin=False,
               stream_kb=None, stream_target_ms=500,
               render_debug=False, pending_open=None, pending_fields=(),
               thin="auto", density=None, occupancy=None, rules=None,
               file_load=True, layerprops=None, drc_pick=None,
               role="", debug=False):
    """`pending_open`: a layout/jobdeck given on the command line that
    has no index yet - the viewer starts empty, asks, indexes and
    opens it (user call 2026-09-09), then applies `pending_fields`
    (the request options as `key=value` strings, goto included).
    `file_load` False (--no-file-load): the viewer loads no file but
    these - `cache` / `pending_open`, `drc`, `rules`, `layerprops`.
    `layerprops` (--layerprops): the layer properties file for `cache`;
    a `pending_open` carries it among its fields (`layerprops=`).
    `drc_pick` (--drc-rule, --drc-err): (rule name, error number or None)
    to select in the `drc` results once they are open.
    `debug` (--debug): the viewer's debug parts are on (Viewer._debug_show)."""
    import_gtk()
    # the viewer's process: the garbage collector is this thread's to run
    # until the process ends - past the viewer's quit too, when the reader
    # threads still run (_MainThreadGc; the interpreter's own last
    # collection is on this thread)
    _MainThreadGc.hold()
    # the window starts maximized (user 2026-11-15) - a smoke start, the
    # gates' own (FLOE_GUI_SMOKE_MS), keeps the default size
    maximized = os.environ.get("FLOE_GUI_SMOKE_MS") is None
    # (said only when the launch says them)
    more = {}
    if role:
        more["role"] = role
    if debug:
        more["debug"] = True
    viewer = Viewer(cache, server_sock, goto=goto, detail=detail,
                    dump=dump, depth=depth, lod=lod, frames=frames,
                    labels=labels, label_font_px=label_font_px,
                    frame_cache=frame_cache, margin=margin,
                    stream_kb=stream_kb,
                    stream_target_ms=stream_target_ms,
                    render_debug=render_debug, thin=thin, density=density,
                    occupancy=occupancy, file_load=file_load,
                    layerprops=layerprops, maximized=maximized,
                    **more)
    smoke_ms = os.environ.get("FLOE_GUI_SMOKE_MS")
    smoke_error = []
    if smoke_ms is not None:
        try:
            smoke_ms = int(smoke_ms)
        except ValueError:
            raise SystemExit(
                "%s: FLOE_GUI_SMOKE_MS must be an integer" % APP)
        if not 100 <= smoke_ms <= 60000:
            raise SystemExit(
                "%s: FLOE_GUI_SMOKE_MS must be 100..60000" % APP)

        def finish_smoke():
            if cache is not None or pending_open is not None:
                if viewer.cache is None:
                    smoke_error.append("the pending open never landed")
                elif viewer._worker_starting:
                    smoke_error.append("Rust render cache is still opening")
                elif viewer.worker is None or not viewer.worker.alive():
                    smoke_error.append("Rust render worker is not alive%s" % (
                        "" if viewer.worker is None
                        else " (%s)" % viewer.worker.exitcode()))
                elif viewer.last_frame is None:
                    smoke_error.append("no GUI frame was displayed")
            if drc and not smoke_error and viewer._drc_total == 0:
                # the --drc results must still be loaded once the
                # layout (possibly indexed first) is up
                smoke_error.append("the --drc results did not load")
            viewer._quit()
            return False

        GLib.timeout_add(smoke_ms, finish_smoke)
    # NO _drc_window() here: its grab_focus made the BROWSE TreeView
    # auto-select row 0 on focus-in, so --drc startups showed the first
    # rule selected (field reports 2026-08-18; a db must open with no
    # rule selected). The embedded panel is always visible - there is
    # nothing to focus. A db without a usable pack is ASKED about
    # and packed first, as the DRC > open dialog does (user call
    # 2026-09-09).
    drc_path = os.path.abspath(drc) if drc else None
    rules_path = os.path.abspath(rules) if rules else None
    if pending_open is not None:
        # the window is up; the question, the index log and the open
        # need the main loop. The --drc load runs AFTER that open: an
        # in-place open resets the DRC state, so a db loaded first was
        # gone once the indexed layout arrived (review 2026-09-09
        # (4th) P2-1)
        GLib.idle_add(viewer._open_or_index, pending_open,
                      list(pending_fields),
                      (lambda: viewer._drc_open_db(drc_path, rules=rules_path,
                                                   pick=drc_pick))
                      if drc_path else None)
    elif drc_path:
        GLib.idle_add(lambda: (viewer._drc_open_db(drc_path, rules=rules_path,
                                                   pick=drc_pick), False)[1])
    try:
        import signal as _signal
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, _signal.SIGINT,
                             lambda *_: (viewer._quit(), False)[1])
    except Exception:
        pass
    try:
        Gtk.main()
    except KeyboardInterrupt:
        pass
    finally:
        viewer._quit()
    if smoke_error:
        raise SystemExit("%s: GUI smoke failed: %s" %
                         (APP, smoke_error[0]))
