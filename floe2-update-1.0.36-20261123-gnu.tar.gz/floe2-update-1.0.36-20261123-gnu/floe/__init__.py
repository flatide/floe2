"""floe - fast viewer/clipper for large OASIS files backed by a spatial tile cache."""

# floe app/display version - bumped on EVERY push (the About dialog,
# --version and the portable bundle name read this), 2026-08-30.
# 1.0.0 on 2026-11-18 (user: "floe2의 버전을 1.0.0으로 올리고 문서에도
# 반영해줘"): the version after 0.12.528, the same program under the
# product's first whole number; pushes go on as 1.0.1, 1.0.2, ...
__version__ = "1.0.36"

# Expected version of the bundled Rust binaries. floe-renderd reports
# its CARGO_PKG_VERSION in the ready handshake and the adapter refuses a
# mismatch (the gates' adapter, tools/oracle/floe_oracle/rust_render.py;
# floe2 gtk-service is built with renderd), so this MUST equal the built binaries; keep
# it == rust/{cli,renderd,render-cli}/Cargo.toml. Bumped ONLY on pushes
# that rebuild the Rust binaries - that decoupling lets a Python-only
# push advance __version__ without tripping the renderd version guard
# (no rebuild needed on the deploy host). The floe2 review branch has
# rebuilt on every push so far, so both move together there.
# 1.0.0 with the product (user 2026-11-18, asked: the three binaries all
# 1.0.0): floe-index and floe-renderd are 0.12.526's code, rebuilt under
# the new number - the one bump with no Rust change behind it.
# 1.0.9 (2026-11-19): the first code change of the two since - the cell
# instance walk's cap (render-core cells, renderd cell_insts).
# 1.0.11 (2026-11-19): renderd's cell_insts spends one budget a request.
# 1.0.12 (2026-11-19): its plain walk ends where it has learned of more.
# 1.0.13 (2026-11-19): a later placement is asked for its first instance.
# 1.0.14 (2026-11-21): floe-index's rules sidecar has each rule's digest
# (renderd's code unchanged, its number with floe-index's).
# 1.0.15 (2026-11-21): floe-index's SVRF parser - a rule's own layers,
# names whatever their case, LAYER MAP constraints (renderd unchanged).
# 1.0.16 (2026-11-21): its maps, outputs, wrapped measurements and the
# readers' limits (renderd unchanged).
# 1.0.17 (2026-11-22): a rule's digest is of the deck's words (form 2,
# the sidecar's digest_version), a map's number keeps its own shapes
# (renderd unchanged).
# 1.0.18 (2026-11-22): a rule's digest is of its block and of all the deck
# says outside its rule checks (form 3); a block measurement's bound goes
# with a copy, a selection or a cut of its layer alone (renderd unchanged).
# 1.0.19 (2026-11-22): a rule's digest follows the definitions its words
# reach by name; what is not surely a definition's own is every rule's
# (form 4; renderd unchanged).
# 1.0.20 (2026-11-22): floe-index's SVRF reader is the crate floe-svrf,
# shared with the rules service - what `floe-index svrf` writes is as it
# was (renderd unchanged).
# 1.0.21 (2026-11-22): the reader takes the environment a deck is read
# under from its caller (the rules service gives its request's); what
# floe-index svrf writes is as it was. renderd's code is as it was.
# 1.0.22 (2026-11-22): `floe-index svrf` is a build feature (`svrf`), in
# no usage and in no distribution's floe-index. renderd's code is as it was.
RENDERD_VERSION = "1.0.22"
