floe2 포터블 번들 (floe2 1.0.36: 20261123 빌드의 갱신 묶음을 적용한 상태)
====================
이 번들은 갱신 묶음으로 갱신되었다. floe2 자체 파일(runtime/bin의 실행 파일 셋,
floe/ 패키지, 런처, EULA.txt, 실행 파일 쪽 고지, 이 글)은 위 판의 것이고,
런타임(Python, GTK)과 selfcheck는 처음 설치한 전체 번들의 것 그대로다.
바꾸기 전의 파일은 previous/에 있다(되돌리기는 아래 "코드 업데이트").

PyGObject(python3-gobject)가 없는 호스트에서 floe2를 실행하기 위한 자체
포함 런타임. Python + PyGObject + GTK3 + floe 패키지(GTK 뷰어) +
floe2(러스트 명령: index/info/render/clip/jobdeck/drc…), floe-index(러스트
인덱서/VFS daemon)와 floe-renderd(기본 CPU renderer)가
runtime/bin/ 안에 들어
있으며 시스템에는 아무것도 설치·변경하지 않는다. 시스템에서
쓰는 것은 X 디스플레이와 (있다면) 시스템 폰트뿐.

기본 floe2 번들은 KLayout을 포함하지 않는다. 개발용 KLayout 번들은
FLOE_PORTABLE_KLAYOUT=1로 별도 빌드하며, 이 번들은 같은 runtime에서
floe2(Rust)와 동결 floe 셸(KLayout, 개발 전용 오라클 floe_oracle: index/
info/render/clip/probe/drc/jobdeck 명령만 - 뷰어는 floe2 view, KLayout
뷰어는 floe-legacy 브랜치)을 함께 제공한다.

요구: x86_64 리눅스, glibc 2.28+ (실행 파일의 요구; 런타임은 처음 설치한 번들의 요구 그대로), X 디스플레이.

사용권 계약: 이 번들의 사용 조건은 최상위의 EULA.txt에 있다(한국어와 영어,
한국어판 우선). 번들을 설치하거나 사용하면 그 계약에 동의한 것으로 본다.
사용 범위(사용자 수, 호스트 수, 기간)는 따로 맺은 계약을 따른다. 뷰어의
Help > License Agreement가 같은 글을 보여준다.

오픈소스 고지: NOTICES/에 이 번들에 들어 있는 제3자 구성요소의 목록과
라이선스(THIRD-PARTY-NOTICES.txt), 라이선스 전문, conda 패키지별 버전과
출처(PACKAGES.txt)가 있다. LGPL/GPL 구성요소의 소스를 받는 방법도 거기에
적혀 있다. 번들을 다른 곳에 전달할 때 NOTICES/를 빼지 않는다. 뷰어의
Help > Open Source Licenses가 같은 목록을 보여준다.

설치/실행:
    tar xzf floe2-portable-<버전>-<날짜>.tar.gz -C /opt   # 전체 번들, 위치 자유
    /opt/floe2-portable/selfcheck
    /opt/floe2-portable/floe2 view /path/to/chip.oas
    /opt/floe2-portable/floe2 index /path/to/chip.oas
    /opt/floe2-portable/floe2 drc-prepare /path/to/results.db --svrf /path/to/deck.rules.json --jobs 4
    # KLayout 포함 floe-portable에서만 (동결 floe 셸, 명령만):
    /opt/floe-portable/floe render /path/to/chip.oas --out frame.png

편의상 링크: ln -s /opt/floe2-portable/floe2 /usr/local/bin/floe2

실행은 번들 최상위의 floe2(런처)로 한다: 런처가 번들의 Python·GTK
환경을 잡는다. runtime/bin/floe2를 직접 실행해도 뷰어는 런처를 거쳐
뜬다. FLOE2_BIN·FLOE_INDEX_BIN·FLOE_RENDERD_BIN은 설정하지 않는다 -
floe2와 뷰어가 runtime/bin에서 찾고, 설정돼 있으면 그 경로가 이긴다.

코드 업데이트: 갱신 묶음 하나를 받아 파일 이름과 같은 폴더로 풀고, 그 폴더의
apply로 적용한다(번들 소유자 계정으로, 번들의 뷰어를 모두 닫고. 번들을 여러
호스트가 함께 쓰면 그 호스트들의 뷰어도). <묶음>은 받은 파일의 이름에서
.tar.gz를 뺀 것이다(floe2-update-<버전>-<날짜>, gnu 빌드는 끝에 -gnu):
    tar xzf <묶음>.tar.gz -C /tmp
    sh /tmp/<묶음>/apply /opt/floe2-portable
갱신 묶음은 floe2 자체 파일만 담는다: runtime/bin의 세 실행 파일(floe2,
floe-index, floe-renderd), floe/ 패키지(GTK 뷰어), 런처,
사용권 계약(EULA.txt), 이 README, 실행 파일 쪽 고지. 런타임은 그대로 쓴다.
apply는 바꾸기 전에 새 실행 파일이 이 호스트에서 도는지 확인하고, 바꾼
파일을 previous/에 남긴다. 같은 묶음을 다시 적용하면 아무것도 바꾸지 않는다.
되돌리기:
    sh /opt/floe2-portable/previous/apply --rollback /opt/floe2-portable
파이썬 패키지와 러스트 바이너리는 포맷 버전이 한 쌍이라 항상 같이 움직여야
하므로 파일을 손으로 하나씩 바꾸지 않는다.

문제 해결:
- "GLIBC_x.xx not found": 호스트 glibc가 요구보다 낮다 → 사용 불가 (selfcheck 확인)
- 코드 3 종료: DISPLAY 미설정/접속 불가
- 창은 뜨는데 회색/렌더 오류: ~/.cache/floe2-rt 또는 ~/.cache/floe-rt 삭제 후 재실행
- 뷰어는 열리는데 렌더가 멈춤·인덱싱이 안 됨: runtime/bin/floe-index
  누락/실행 불가 (selfcheck의 floe-index 줄 확인)
- floe2 시작 오류: runtime/bin/floe-renderd 누락/실행 불가
