floe2 갱신 묶음 (floe2 0.12.519, 20261117 빌드, Rust 바이너리: gnu)
====================
이미 설치된 floe2 포터블 번들에 floe2 자체 파일만 바꿔 넣는다: 실행 파일
셋(floe2, floe-index, floe-renderd), 뷰어의 Python 패키지(floe/), 런처,
실행 파일에 들어 있는 제3자 구성요소의 고지(NOTICES/), 그리고 이 판의
사용권 계약(EULA.txt). 번들의
런타임(Python, GTK)은 건드리지 않고 그대로 쓴다. 번들이 없는 호스트에는
먼저 전체 번들(floe2-portable-*.tar.gz)을 설치한다.

요구: 설치된 floe2 포터블 번들, x86_64 리눅스, glibc 2.28 이상 (any = 무관).

적용 (번들 소유자 계정으로, 뷰어를 모두 닫고):
    tar xzf floe2-update-0.12.519-20261117-gnu.tar.gz -C /tmp
    sh /tmp/floe2-update/apply /opt/floe2-portable

apply는 바꾸기 전에 확인한다: 묶음이 온전한지(SHA256SUMS), 대상이 floe2
번들이고 쓸 수 있는지, 그 번들에서 도는 프로세스가 없는지, 새 실행 파일이
이 호스트에서 도는지(glibc가 낮으면 여기서 멈춘다). 하나라도 걸리면 아무것도
바꾸지 않는다. 바꾼 뒤에는 번들의 floe2 --version과 selfcheck를 돌린다.

되돌리기 (직전 한 번):
    sh /opt/floe2-portable/previous/apply --rollback /opt/floe2-portable
apply가 바꾸기 전의 파일을 번들의 previous/에 남긴다.

옵션:
    --force          번들에서 도는 프로세스가 있어도 적용한다. 돌고 있던
                     세션은 시작할 때의 실행 파일로 계속 돈다.
    --no-run-check   새 실행 파일을 이 호스트에서 돌려 보지 않는다(번들을
                     다른 종류의 호스트가 쓰는 공유 디스크에 적용할 때).

0.12.511 이전에 만든 번들에는 GNU readline(GPL-3.0, 쓰이지 않음)이 들어
있었다. apply가 런타임에서 지우고, 되돌리기에서도 복구하지 않는다. 그런
번들의 런타임에는 제3자 고지가 없다: 런타임의 고지는 0.12.511 이후의
전체 번들에 들어 있다.

이 묶음의 README-PORTABLE.txt는 갱신된 번들의 설명이다. apply가 번들 최상위의
것을 이것으로 바꾼다(이전 것은 previous/에 남는다).
