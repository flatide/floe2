"""floe - fast viewer/clipper for large OASIS files backed by a spatial tile cache."""

# floe app/display version - bumped on EVERY push (the About dialog,
# --version and the portable bundle name read this), 2026-08-30.
# 1.0.0 on 2026-11-18 (user: "floe2의 버전을 1.0.0으로 올리고 문서에도
# 반영해줘"): the version after 0.12.528, the same program under the
# product's first whole number; pushes go on as 1.0.1, 1.0.2, ...
__version__ = "1.0.3"

# Expected version of the bundled Rust binaries. floe-renderd reports
# its CARGO_PKG_VERSION in the ready handshake and the adapter refuses a
# mismatch (the gates' adapter, tools/oracle/floe_oracle/rust_render.py;
# floe2 gtk-service is built with renderd), so this MUST equal the built binaries; keep
# it == rust/{cli,renderd,render-cli}/Cargo.toml. Bumped ONLY on pushes
# that rebuild the Rust binaries - that decoupling lets a Python-only
# push advance __version__ without tripping the renderd version guard
# (no rebuild needed on the deploy host). The floe2 review branch has
# rebuilt on every push so far, so both move together there.
# 1.0.0 with the product (user 2026-11-18, asked: the three binaries all
# 1.0.0): floe-index and floe-renderd are 0.12.526's code, rebuilt under
# the new number - the one bump with no Rust change behind it.
RENDERD_VERSION = "1.0.0"
